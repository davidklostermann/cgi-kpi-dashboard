import * as i0 from '@angular/core';
import { ViewContainerRef, OnChanges, EventEmitter, ComponentFactoryResolver, OnInit, AfterViewInit, OnDestroy, ElementRef, Renderer2, TemplateRef, SimpleChanges, ChangeDetectorRef, QueryList } from '@angular/core';
import * as i2 from '@angular/common';
import * as i3 from '@angular/material/icon';
import { MatIconRegistry } from '@angular/material/icon';
import * as i4 from '@angular/material/button';
import { BreakpointObserver } from '@angular/cdk/layout';
import * as rxjs from 'rxjs';
import { Observable } from 'rxjs';
import * as i4$1 from '@angular/router';
import { Router, NavigationEnd } from '@angular/router';
import * as i5 from '@angular/material/badge';
import * as i7 from '@angular/material/menu';
import { MatMenuTrigger } from '@angular/material/menu';
import * as i4$2 from '@angular/material/toolbar';
import * as i7$1 from '@angular/material/expansion';
import * as i5$1 from '@angular/forms';
import { UntypedFormGroup, UntypedFormBuilder, UntypedFormControl, FormGroupDirective, ControlValueAccessor, FormGroup, FormBuilder } from '@angular/forms';
import * as i6 from '@angular/material/autocomplete';
import { MatAutocompleteTrigger, MatAutocomplete, MatAutocompleteSelectedEvent } from '@angular/material/autocomplete';
import * as i7$2 from '@angular/material/select';
import { MatSelect } from '@angular/material/select';
import * as i5$2 from '@angular/material/form-field';
import { MatFormFieldAppearance } from '@angular/material/form-field';
import * as i5$3 from '@angular/material/input';
import * as i10 from '@angular/material/progress-spinner';
import { ConfigurableFocusTrapFactory } from '@angular/cdk/a11y';
import * as i7$3 from '@angular/cdk/overlay';
import { MatSnackBarRef } from '@angular/material/snack-bar';
import * as i9 from '@angular/material/card';
import * as i4$3 from '@angular/material/button-toggle';
import * as i7$4 from '@angular/material/divider';
import * as i9$1 from '@angular/material/tooltip';
import * as i7$5 from '@angular/material/table';
import { MatTable, MatColumnDef, MatTableDataSource } from '@angular/material/table';
import { SelectionModel } from '@angular/cdk/collections';
import * as i8 from '@angular/material/sort';
import { MatSort } from '@angular/material/sort';
import * as i9$2 from '@angular/material/checkbox';
import * as i10$1 from '@angular/platform-browser/animations';
import { DomSanitizer } from '@angular/platform-browser';
import * as i16 from '@angular/material/list';
import * as i20 from '@angular/material/paginator';
import { MatPaginator } from '@angular/material/paginator';
import * as i4$4 from '@angular/material/sidenav';
import * as i5$4 from '@angular/material/slide-toggle';
import * as i10$2 from '@angular/material/slider';
import * as i11 from '@angular/material/datepicker';
import * as i12 from '@angular/material/radio';
import * as i15 from '@angular/material/core';
import * as i4$5 from '@angular/material/chips';
import * as i4$6 from '@angular/material/stepper';
import { MatStepper } from '@angular/material/stepper';

/**
 * Alert Directive.
 */
declare class CGIAlertDirective {
    viewContainerRef: ViewContainerRef;
    /**
     * Constructor for Alert Directive
     * @param viewContainerRef container reference for alert container
     */
    constructor(viewContainerRef: ViewContainerRef);
    static ɵfac: i0.ɵɵFactoryDeclaration<CGIAlertDirective, never>;
    static ɵdir: i0.ɵɵDirectiveDeclaration<CGIAlertDirective, "[cgiAlertHost]", never, {}, {}, never, never, false, never>;
}

/**
 * Alert Container component.
 *
 * TODO: How to use component and examples.
 */
declare class CGIAlertContainerComponent implements OnChanges {
    private componentFactoryResolver;
    /** Array to store alerts inputted from parent */
    alerts: any[];
    /** Event Emitter to invoke parent when an action is preformed */
    action: EventEmitter<any>;
    /** Reference to Alert Directive */
    cgiAlertHost: CGIAlertDirective;
    /**
     * Constructor for Alert Container Directive
     * @param componentFactoryResolver Factory Resolver for dynamic components
     */
    constructor(componentFactoryResolver: ComponentFactoryResolver);
    /**
     * Life cycle hook for when the component is first initiated and when there are changes to the component's input.
     */
    ngOnChanges(): void;
    /** Load an alert into the container */
    loadAlert(alert: any): void;
    /** Remove an alert in the container */
    removeAlert(alertItem: any): void;
    /** Get alerts being passed in from parent */
    getAlerts(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<CGIAlertContainerComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<CGIAlertContainerComponent, "cgi-alert-container", never, { "alerts": { "alias": "alerts"; "required": false; }; }, { "action": "action"; }, never, never, false, never>;
}

/**
 * Alert component.
 *
 * TODO: How to use component and examples.
 */
declare class CGIAlertComponent implements OnInit {
    /**
     * Boolean variable to set the container class="cgi-alert"
     */
    isClassContainer: boolean;
    /**
     * String variable to set the animation state
     */
    animationState: string;
    /**
     * Boolean variable to set the container class="cgi-alert-info"
     */
    isInfo: boolean;
    /**
     * Boolean variable to set the container class="cgi-alert-warning"
     */
    isWarning: boolean;
    /**
     * Boolean variable to set the container class="cgi-alert-success"
     */
    isSuccess: boolean;
    /**
     * Boolean variable to set the container class="cgi-alert-error"
     */
    isError: boolean;
    /** Event Emitter to emit custom events back to the parent component */
    action: EventEmitter<boolean>;
    /** Object to store input data from the parent component */
    data: {
        type: any;
        header: any;
        message: any;
        customAction: any;
    };
    /** String to store the icon associated with the type of alert */
    icon: string;
    /** Boolean for specifying if the alert has a header */
    hasHeader: boolean;
    /** Boolean for specifying if the alert emitted an animation */
    actionEmitted: boolean;
    /**
     * Constructor
     */
    constructor();
    /**
     * Life cycle hook for when the component is first initiated.
     */
    ngOnInit(): void;
    /** Method that sets the style and icon for the type of alert */
    setType(): void;
    /** close method that will initiate the close animation */
    close(): void;
    /** Listener for when the close animation has finished */
    animationDone(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<CGIAlertComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<CGIAlertComponent, "cgi-alert", never, { "data": { "alias": "data"; "required": false; }; }, { "action": "action"; }, never, never, false, never>;
}

declare class CGIAlertContainerModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<CGIAlertContainerModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<CGIAlertContainerModule, [typeof CGIAlertContainerComponent, typeof CGIAlertComponent, typeof CGIAlertDirective], [typeof i2.CommonModule, typeof i3.MatIconModule, typeof i4.MatButtonModule], [typeof CGIAlertContainerComponent, typeof CGIAlertComponent, typeof CGIAlertDirective]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<CGIAlertContainerModule>;
}

/**
 * Anchor Link class
 */
declare class AnchorLink {
    /** id of the section */
    id: string;
    /** header type */
    type: string;
    /** If the anchor is in view of the page */
    active: boolean;
    /** name of the anchor */
    name: string;
    /** top offset px of the anchor */
    top: number;
    /** Number of errors present on each form */
    errorCount?: number;
}

/**
 * Anchor Scroll component.
 */
declare class CGIAnchorScrollComponent implements OnInit, AfterViewInit, OnDestroy, OnChanges {
    private _element;
    _document: any;
    /** Array to the anchor links */
    links: AnchorLink[];
    /** Anchor Scroll Container */
    container: string;
    /** Class of parent element */
    parentClass: string;
    /** Headers that will be selected as anchor scroll links */
    headerSelectors: string;
    /** Offset in pixels for links to trigger as active */
    linkOffset: number;
    /** All form IDs and their respective error counts (part of exception handling) */
    errorCounts: Array<{
        id: string;
        errors: number;
    }>;
    /** Scroll Container that the anchor scroll component resides */
    private _scrollContainer;
    /** Fixed navigation bar */
    private _navBar;
    /** On destroy subject */
    private _destroyed;
    /** Selected anchor link */
    private _selectedSection;
    /** Anchor links container class */
    private _linkContainer;
    /** Class name used to sticky the scroll container */
    private _stickyClass;
    /**
     * Constructor for Anchor Scroll Component
     * @param _element Native anchor scroll HTML Element
     * @param _document Application's HTML Document
     */
    constructor(_element: ElementRef, _document: any);
    /**
     * Life cycle hook for when the component is first initiated.
     */
    ngOnInit(): void;
    /** Initialization block after view has been rendered */
    ngAfterViewInit(): void;
    /** When Component is destroyed remove event listeners */
    ngOnDestroy(): void;
    /** When changes to inputs are detected */
    ngOnChanges(): void;
    /** Update scroll position when selected link has changed */
    updateScrollPosition(): void;
    /** When a link is selected change the selected link and update scroll position */
    goToSection(id: string): void;
    /** Gets the scroll offset of the scroll container */
    private getScrollOffset;
    /** Create the links based on the header selectors */
    private createLinks;
    /** Update error counts for each link */
    private updateErrors;
    /** Check to see if link is active or not */
    private isLinkActive;
    /** Check to see if the component should be sticky or not */
    private checkSticky;
    /** Make component sticky */
    private addSticky;
    /** When there is a scroll event */
    onScroll: () => void;
    /** When the browser changes size */
    adjustWidth: () => void;
    static ɵfac: i0.ɵɵFactoryDeclaration<CGIAnchorScrollComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<CGIAnchorScrollComponent, "cgi-anchor-scroll", never, { "container": { "alias": "container"; "required": false; }; "parentClass": { "alias": "parentClass"; "required": false; }; "linkOffset": { "alias": "linkOffset"; "required": false; }; "errorCounts": { "alias": "errorCounts"; "required": false; }; }, {}, never, never, false, never>;
}

/**
 * Anchor Scroll Container component.
 *
 * TODO: How to use component and examples.
 */
declare class CGIAnchorScrollContainerComponent {
    /** Class of parent element */
    parentClass: string;
    /** Offset in pixels for links to trigger as active */
    linkOffset: number;
    /** All form IDs and their respective error counts (part of exception handling) */
    errorCounts: Array<{
        id: string;
        errors: number;
    }>;
    /** Anchor Scroll child component */
    anchorScroll: CGIAnchorScrollComponent;
    /** Boolean for showing the child anchor scroll component */
    showAnchor: Observable<boolean>;
    /**
     * Constructor for Anchor Scroll Component
     * @param breakpointObserver Breakpoint Observable for when to remove the anchor scroll component
     */
    constructor(breakpointObserver: BreakpointObserver);
    static ɵfac: i0.ɵɵFactoryDeclaration<CGIAnchorScrollContainerComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<CGIAnchorScrollContainerComponent, "cgi-anchor-scroll-container", never, { "parentClass": { "alias": "parentClass"; "required": false; }; "linkOffset": { "alias": "linkOffset"; "required": false; }; "errorCounts": { "alias": "errorCounts"; "required": false; }; }, {}, never, ["*"], false, never>;
}

declare class CGIAnchorScrollContainerModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<CGIAnchorScrollContainerModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<CGIAnchorScrollContainerModule, [typeof CGIAnchorScrollContainerComponent, typeof CGIAnchorScrollComponent], [typeof i2.CommonModule, typeof i4$1.RouterModule, typeof i5.MatBadgeModule], [typeof CGIAnchorScrollContainerComponent, typeof CGIAnchorScrollComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<CGIAnchorScrollContainerModule>;
}

/** The supported landmarks for the quick-nav in the top-nav */
declare const enum PageLandmarks$1 {
    GLOBAL_SEARCH = "global-search-component",
    LEFT_NAV = "left-nav",
    MAIN_CONTENT = "main-content"
}

/** Interface for supported landmarks for the quick-nav dropdown of the top-nav */
interface ILandmark$1 {
    /** The label used for the landmark */
    label: string;
    /** The id of the landmark on the DOM */
    id: PageLandmarks$1;
}

/**
 * General top navigation component.
 *
 * TODO: How to use component and examples.
 */
declare class CGITopNavComponent implements OnInit {
    /** Boolean variable to set the container class="cgi-top-nav" */
    isClassContainer: boolean;
    /** Flag for setting the visibility of the quick-nav button when focused/unfocused */
    hideButton: boolean;
    /** The landmarks to be quickly focused to from the quick-nav dropdown */
    landmarks: ILandmark$1[];
    /** Quick nav button text */
    quickSkipButtonText: string;
    /** Quick nav aria label */
    quickSkipAriaLabel: string;
    /** MatMenuTrigger element for controlling the open/close of the quick-nav menu */
    matMenu: MatMenuTrigger;
    /** Color attribute to set toolbar. */
    color: string;
    /** Custom aria-label attribute for accessibility. */
    ariaLabel: string;
    private _document;
    /**
     * Empty constructor.
     */
    constructor(document: any);
    /**
     * Set the default landmarks
     */
    ngOnInit(): void;
    /** Go (focus) to the specified landmark */
    goToLandmark(landmark: any): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<CGITopNavComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<CGITopNavComponent, "cgi-top-nav", never, { "landmarks": { "alias": "landmarks"; "required": false; }; "quickSkipButtonText": { "alias": "quickSkipButtonText"; "required": false; }; "quickSkipAriaLabel": { "alias": "quickSkipAriaLabel"; "required": false; }; "color": { "alias": "color"; "required": false; }; "ariaLabel": { "alias": "ariaLabel"; "required": false; }; }, {}, never, [".cgi-top-nav--left", ".cgi-top-nav--right"], false, never>;
}

/** Service to maintain one true source of whether navigation panel is opened. */
declare class CGINavContainerService$1 {
    /** BehaviourSubject to emit default value of Observable on subscription. */
    private _navOpen;
    /** Convert to public Observable. */
    changes: rxjs.Observable<boolean>;
    /**
     * Toggle value of whether panel is opened.
     * @param isOpen Override for what state the panel should be.
     */
    toggle(isOpen?: boolean): void;
    /** Getter for private variable _navOpen. */
    getState(): boolean;
    static ɵfac: i0.ɵɵFactoryDeclaration<CGINavContainerService$1, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<CGINavContainerService$1>;
}

/**
 * Navigation item component for the top nav bar.
 */
declare class CGITopNavItemComponent implements OnInit {
    private navContainerService;
    /** Variable to determine style for top-nav-item. */
    _menuItem: boolean;
    /** Variable to set style for search top-nav-item */
    _showSearchIcon: boolean;
    /** Boolean to toggle the icon */
    opened: boolean;
    /** Boolean variable to set the container class="cgi-top-nav__item" */
    isClassContainer: boolean;
    /** Load for DOM manipulation. */
    constructor(navContainerService: CGINavContainerService$1);
    /** Subscribe to service to listen for changes in opened state, used to change icon */
    ngOnInit(): void;
    /** Getter for menuItem, used to set style class. */
    get isMenuItem(): boolean;
    /** Getter for _showSearchIcon, used to set style class */
    get isSearchBarItem(): boolean;
    /** Toggle sidebar on click */
    toggleSidebar(): void;
    /** Setter for menuItem, attribute to be set on the cgi-nav-item element. */
    set menuItem(value: boolean);
    /** Setter for _showSearchIcon, attribute to be set on the cgi-top-nav-item element */
    set showSearchIcon(value: boolean);
    static ɵfac: i0.ɵɵFactoryDeclaration<CGITopNavItemComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<CGITopNavItemComponent, "cgi-top-nav-item", never, { "opened": { "alias": "opened"; "required": false; }; "menuItem": { "alias": "menuItem"; "required": false; }; "showSearchIcon": { "alias": "showSearchIcon"; "required": false; }; }, {}, never, ["*"], false, never>;
}

declare class CGITopNavModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<CGITopNavModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<CGITopNavModule, [typeof CGITopNavComponent, typeof CGITopNavItemComponent], [typeof i2.CommonModule, typeof i4$2.MatToolbarModule, typeof i4.MatButtonModule, typeof i3.MatIconModule, typeof i7.MatMenuModule], [typeof CGITopNavComponent, typeof CGITopNavItemComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<CGITopNavModule>;
}

/**
 * Side Navigation Item data model
 */
declare class SideNavItem {
    /** ligatures to icon */
    icon: string;
    /** url link */
    link: string;
    /** text to displayed on navigation */
    text: string;
    /** sub level navigation */
    subsection: SideNavItem[];
    /** feature request: to support query attributes in navigation url */
    state: any;
    /** feature request: customizable attributes to be added to particular navigation route */
    queryParams: any;
    /**
     * Default constructor for SideNavItem
     * @param text Text/Title of side nav item
     * @param link Router link of side nav item
     * @param icon Icon of the side nav item
     * @param subsection Subsection of side nav item if applicable
     * @param state query attributes in navigation url
     * @param params customizable attributes to be added to particular navigation route
     */
    constructor(text?: string, link?: string, icon?: string, subsection?: SideNavItem[], state?: any, params?: any);
}

/**
 * General navigation component.
 *
 * TODO: How to use component and examples.
 */
declare class CGINavContainerComponent {
    static ɵfac: i0.ɵɵFactoryDeclaration<CGINavContainerComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<CGINavContainerComponent, "cgi-nav-container", never, {}, {}, never, ["*"], false, never>;
}

/**
 * Side navigation component.
 */
declare class CGISideNavComponent implements OnInit, OnDestroy {
    private renderer;
    private elRef;
    private navContainerService;
    /** Boolean variable to set the container class="cgi-side-nav" */
    isClassContainer: boolean;
    /** Input for links object */
    links: SideNavItem[];
    /** This opens the sidebar but doesn't stick it to the side of the page */
    private _open;
    /** Hovered state. */
    private _mouseOver;
    /** To automatically unsubscribe at the end of life of the component. */
    private alive;
    /** Variable to evaluate observable, boolean true if in mobile window size. */
    private mobileView;
    /** Variable for width */
    private MOBILE_WIDTH;
    /** Variable for delay */
    private DELAY;
    /** Variable for width */
    private PUSH_CLASS;
    /** Set a timer. */
    private _timer;
    /** Subscription for timer. */
    private timerSub;
    /** An id for targeting the left nav */
    leftNavId: string;
    /** SOURCE: https://stackoverflow.com/a/43834596
     * Determine current window size in Observable to avoid spam of resize events.  */
    initial$: rxjs.Observable<boolean>;
    /** Observable to be aware of when window size changes.  */
    resize$: rxjs.Observable<boolean>;
    /** Observable combined to provide boolean value for when window size is mobile. */
    mobile$: rxjs.Observable<boolean>;
    /** Load renderer, elementRef, and navContainerService for DOM manipulation. */
    constructor(renderer: Renderer2, elRef: ElementRef, navContainerService: CGINavContainerService$1);
    /**
     * Subscribe to navContainerService boolean value as one true source of state.
     * Also closes open navigation panel when screen resized to mobile view.
     */
    ngOnInit(): void;
    /** Efficient way of unsubscribing from service session. */
    ngOnDestroy(): void;
    /** Listener for MouseEnter. */
    mouseEnter(): void;
    /** Listener for MouseLeave. */
    mouseLeave(): void;
    /** Getter to determine whether or not to add opened class to host component. */
    get isOpened(): boolean;
    /** Provide option to set whether sidenav is opened or closed on initialization.  */
    set opened(value: boolean);
    /** Open this sidenav. */
    open(): void;
    /** Close this sidenav. */
    close(): void;
    /** Close this sidenav only when in mobile view. */
    closeOnMobile(): void;
    /**
     * Toggle this sidenav. This is equivalent to calling open() when it's already opened, or
     * close() when it's closed.
     * @param isOpen Whether the sidenav should be open.
     * @returns Changes sidenav element width based on boolean value.
     */
    toggle(isOpen?: boolean): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<CGISideNavComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<CGISideNavComponent, "cgi-side-nav", never, { "links": { "alias": "links"; "required": false; }; "opened": { "alias": "opened"; "required": false; }; }, {}, never, never, false, never>;
}

/**
 * Side navigation item component.
 * Recursive side navigation item component to allow for unlimited submenus (design limit of 3)
 */
declare class CGISideNavItemComponent implements OnInit, OnDestroy {
    private navContainerService;
    private router;
    /** check isOpened to hide or show the sidebar */
    isOpened: boolean;
    /** Input for links object */
    links: SideNavItem[];
    /** Input for level object */
    level: number;
    /** Alive for service checking */
    private alive;
    private _document;
    /**
     *  Constructor
     * @param _document Application's HTML Document
     */
    constructor(navContainerService: CGINavContainerService$1, document: any, router: Router);
    /**
     * Subscribe to navContainerService boolean value as one true source of state.
     */
    ngOnInit(): void;
    /** Efficient way of unsubscribing from service session. */
    ngOnDestroy(): void;
    /** A method to focus to the main content section of the page, after a delay */
    focusToContent(): void;
    /** A programmatic router navigation method used to fix the links not working as mat-expansion-panel headers */
    goToLink(url: string): void;
    /** Converts object to array if given only object */
    convertArray(input: object): any;
    static ɵfac: i0.ɵɵFactoryDeclaration<CGISideNavItemComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<CGISideNavItemComponent, "cgi-side-nav-item", never, { "links": { "alias": "links"; "required": false; }; "level": { "alias": "level"; "required": false; }; }, {}, never, never, false, never>;
}

/**
 * Content outside of navigation header/sidenav component.
 *
 * TODO: How to use component and examples.
 */
declare class CGINavContentComponent {
    private renderer;
    private elRef;
    private navContainerService;
    private router;
    /** Inject Dom Object  */
    document: any;
    /** Boolean variable to set the container class="cgi-nav-content" */
    isClassContainer: boolean;
    /** Observable that publishes when the routers navigation end event is triggered */
    scrollToTop: Observable<NavigationEnd>;
    /** Load renderer, elementRef, and navContainerService for DOM manipulation. */
    constructor(renderer: Renderer2, elRef: ElementRef, navContainerService: CGINavContainerService$1, router: Router, 
    /** Inject Dom Object  */
    document: any);
    /** Close navigation when backdrop is clicked, only available on mobile view. */
    closeNav(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<CGINavContentComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<CGINavContentComponent, "cgi-nav-content", never, {}, {}, never, ["*"], false, never>;
}

declare class CGINavContainerModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<CGINavContainerModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<CGINavContainerModule, [typeof CGINavContainerComponent, typeof CGISideNavComponent, typeof CGISideNavItemComponent, typeof CGINavContentComponent], [typeof i2.CommonModule, typeof i4$2.MatToolbarModule, typeof i7$1.MatExpansionModule, typeof i4.MatButtonModule, typeof i3.MatIconModule, typeof i4$1.RouterModule], [typeof CGINavContainerComponent, typeof CGISideNavComponent, typeof CGISideNavItemComponent, typeof CGINavContentComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<CGINavContainerModule>;
}

/**
 * Breadcrumbs component.
 *
 * TODO: How to use component and examples.
 */
declare class CGIBreadcrumbsComponent implements OnInit {
    /**
     * Boolean variable to set the container class="cgi-breadcrumbs"
     */
    isClassContainer: boolean;
    /** Custom aria-label attribute for accessibility. */
    ariaLabel: string;
    /**
     * Empty constructor.
     */
    constructor();
    /**
     * Set title property in component.
     */
    ngOnInit(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<CGIBreadcrumbsComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<CGIBreadcrumbsComponent, "cgi-breadcrumbs", never, { "ariaLabel": { "alias": "ariaLabel"; "required": false; }; }, {}, never, ["*"], false, never>;
}

/**
 * Breadcrumbs component.
 *
 * TODO: How to use component and examples.
 */
declare class CGIBreadcrumbItemComponent implements OnInit {
    /**
     * Boolean variable to set the container class="cgi-breadcrumbs"
     */
    isClassContainer: boolean;
    /**
     * Empty constructor.
     */
    constructor();
    /**
     * Set title property in component.
     */
    ngOnInit(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<CGIBreadcrumbItemComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<CGIBreadcrumbItemComponent, "cgi-breadcrumb-item", never, {}, {}, never, ["*"], false, never>;
}

declare class CGIBreadcrumbsModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<CGIBreadcrumbsModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<CGIBreadcrumbsModule, [typeof CGIBreadcrumbsComponent, typeof CGIBreadcrumbItemComponent], [typeof i2.CommonModule], [typeof CGIBreadcrumbsComponent, typeof CGIBreadcrumbItemComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<CGIBreadcrumbsModule>;
}

/**
 * GlobalSearchCategory class
 */
declare class GlobalSearchCategory {
    /** variable for saving category name */
    name: string;
    /** variable for saving category value */
    value: string;
    /** variable for saving category icon name */
    icon?: string;
    /** variable for route link */
    moreResultsLink?: string;
    /** variable to attach search key for queryparam to route link */
    queryParamKey?: string;
    /**
     * constructor ( it receive variables ( name, value ) and saving )
     * @param name getting category name
     * @param value getting category value
     * @param icon getting category icon name
     * @param moreResultsLink getting category link for more results
     * @param queryParamKey getting key for queryparams
     */
    constructor(name: string, value: string, icon?: string, moreResultsLink?: string, queryParamKey?: string);
}

/**
 * GlobalSearchEntity class
 */
declare class GlobalSearchEntity {
    /** variable for saving entity code */
    code: string;
    /** variable for saving entity code  */
    name: string;
    /**
     * constructor ( it receive variables ( code, name ) and saving )
     * @param code code for content
     * @param name name for content
     */
    constructor(code: string, name: string);
}

/**
 * GlobalSearchGroupOptions class
 */
declare class GlobalSearchGroupOptions {
    /** save category data as a type of GlobalSearchCategory */
    category: GlobalSearchCategory;
    /** save total records of search result data */
    totalRecords: number;
    /** save contents as a type of GlobalSearchEntity[] */
    contents: GlobalSearchEntity[];
    /** boolean for expanding category in autocomplete panel (false=collapse, true=expand) */
    expandCategory?: boolean;
    /** constructor
     * @param contents getting GlobalSearchEntity type of array
     * @param totalRecords getting total name of result
     * @param category getting category data ( not necessary )
     */
    constructor(contents: GlobalSearchEntity[], totalRecords: number, category?: GlobalSearchCategory, expandCategory?: boolean);
}

/** Global Search Component */
declare class CgiGlobalSearchComponent implements AfterViewInit, OnInit {
    private fb;
    private router;
    /** HostBinding for Global Search */
    isClassContainer: boolean;
    /** define FormGroup name as globalSearch */
    globalSearch: UntypedFormGroup;
    /** variable for toggling display of search component on small screens */
    isSearchToggled: boolean;
    /** Input - Categories for drop-down list of category form */
    categories: GlobalSearchCategory[];
    /** Input - variable for checking global search use category or not */
    enableCategory: boolean;
    /** Input - variable for checking statement for spinner ( true or false ) */
    isLoading: boolean;
    /** Input - variable for getting result of searching  */
    globalSearchResult: GlobalSearchGroupOptions[];
    /** Input - Getting Data size from Search Result, it is used for showing No search result option  */
    globalSearchResultSize: number;
    /** Input - allow users to specify autoComplete panel width. Can be any CSS sizing value, otherwise it will match the width of its host */
    panelWidth: string | number;
    /** Input - variable for setting aria-label for the select menu : string type and default value */
    selectorAriaLabel: string;
    /** Input - for globalSearchSelect ( drop-down list for Category ) : string type and default value */
    globalSearchSelectID: string;
    /** Input - for  global search input box  ( search section  ) : string type and default value */
    globalSearchInputID: string;
    /** Input - for  global search placeholder ( search section ) : string type and default value */
    globalSearchInputPlaceholder: string;
    /** Input - for global search autocomplete ( search result section ) : string type and default value */
    globalSearchAutocompleteID: string;
    /** Input - for i18n : show more results message */
    moreResults: string;
    /** Input - for i18n : no results message */
    noResults: string;
    /** Input - specifies the number of results to display in dropdown panel  */
    resultLimit: number;
    /** Input - enable custom template for result item subTemplate */
    subTemplate: TemplateRef<any>;
    /** Output - variable for checking a category is selected or not  */
    optionSelected: EventEmitter<any>;
    /** Output - variable for emitting search to app-shell  */
    search: EventEmitter<any>;
    /** ViewChild - check Mat autocomplete is triggered or not  */
    /** variable for trigger  */
    trigger: MatAutocompleteTrigger;
    /** An id for targeting the global search component */
    globalSearchId: string;
    /** constructor for host binding and form group */
    constructor(fb: UntypedFormBuilder, router: Router);
    /** when search bar is loaded, displayFn() set up first value in searchString */
    displayFn(): string;
    /** Initialization block when component is loaded */
    ngOnInit(): void;
    /** Initialization block after view has been rendered */
    ngAfterViewInit(): void;
    /**
     * Callback function to call when form values change, and emit the form group as an output
     */
    loadSearchResults(): void;
    /**
     * Navigation link for more results button
     */
    gotoLink(link: any, queryKey?: string): void;
    /**
     * Callback function for selecting an option from Autocomplete, and return the data in the following format as output
     * {searchText, category, entity, isShowMore}
     * @param category Category selected in the dropdown
     * @param entity Search result selected in the autocomplete
     * @param isShowMore Select to show more results
     */
    onEnter(category: GlobalSearchCategory, entity: GlobalSearchEntity, isShowMore?: boolean): void;
    /**
     * Method for displaying search on small screens
     */
    toggle(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<CgiGlobalSearchComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<CgiGlobalSearchComponent, "cgi-global-search", never, { "categories": { "alias": "categories"; "required": false; }; "enableCategory": { "alias": "enableCategory"; "required": false; }; "isLoading": { "alias": "isLoading"; "required": false; }; "globalSearchResult": { "alias": "globalSearchResult"; "required": false; }; "globalSearchResultSize": { "alias": "globalSearchResultSize"; "required": false; }; "panelWidth": { "alias": "panelWidth"; "required": false; }; "selectorAriaLabel": { "alias": "selectorAriaLabel"; "required": false; }; "globalSearchSelectID": { "alias": "globalSearchSelectID"; "required": false; }; "globalSearchInputID": { "alias": "globalSearchInputID"; "required": false; }; "globalSearchInputPlaceholder": { "alias": "globalSearchInputPlaceholder"; "required": false; }; "globalSearchAutocompleteID": { "alias": "globalSearchAutocompleteID"; "required": false; }; "moreResults": { "alias": "moreResults"; "required": false; }; "noResults": { "alias": "noResults"; "required": false; }; "resultLimit": { "alias": "resultLimit"; "required": false; }; "subTemplate": { "alias": "subTemplate"; "required": false; }; }, { "optionSelected": "optionSelected"; "search": "search"; }, never, never, false, never>;
}

declare class CGIGlobalSearchModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<CGIGlobalSearchModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<CGIGlobalSearchModule, [typeof CgiGlobalSearchComponent], [typeof i2.CommonModule, typeof i4.MatButtonModule, typeof i3.MatIconModule, typeof i5$1.FormsModule, typeof i5$1.ReactiveFormsModule, typeof i6.MatAutocompleteModule, typeof i7$2.MatSelectModule, typeof i5$2.MatFormFieldModule, typeof i5$3.MatInputModule, typeof i10.MatProgressSpinnerModule, typeof i4$1.RouterModule], [typeof CgiGlobalSearchComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<CGIGlobalSearchModule>;
}

/**
 * Popover component.
 */
declare class CGIPopoverComponent {
    private _focusTrapFactory;
    private document;
    /** Unique name identifier for the popover */
    popoverName: any;
    /** The width of the popover */
    popoverWidth: number;
    /** Boolean for whether the popover is open or closed */
    isPopoverOpen: boolean;
    /** Output event for when the popover is closed */
    popoverClose: EventEmitter<any>;
    /** variable keeps track of trapping popover */
    private restoreTrap;
    /** variable keeps track of close button focus restore */
    private closeButton;
    /** Current state of the popover animation. */
    popoverAnimationState: 'void' | 'enter';
    /** focus trap class from a11y */
    private _focusTrap;
    /** Element that was focused before the popover was opened. Save this to restore upon close. */
    private _elementFocusedBeforeDialogWasOpened;
    /** Constructor for Popover Component
     * @param _focusTrapFactory Create focus trap service for a11y
     * @param document Allows for focus trap within the component
     */
    constructor(_focusTrapFactory: ConfigurableFocusTrapFactory, document: any);
    /** called when overlay is attached */
    overlayAttached(): void;
    /** called when overlay is detached */
    overlayDetached(): void;
    /** Close method for when the popover is closed by clicking outside */
    closePopover(): void;
    /** Sets focus to the closing button on popover */
    private focusButton;
    /** creates focus to the popover that was opened. */
    private createTrapFocus;
    /** Restores focus to the element that was focused before the popover opened. */
    private restoreFocus;
    static ɵfac: i0.ɵɵFactoryDeclaration<CGIPopoverComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<CGIPopoverComponent, "cgi-popover", never, { "popoverName": { "alias": "popoverName"; "required": false; }; "popoverWidth": { "alias": "popoverWidth"; "required": false; }; "isPopoverOpen": { "alias": "isPopoverOpen"; "required": false; }; }, { "popoverClose": "popoverClose"; }, never, ["*"], false, never>;
}

/**
 * Popover Header component.
 */
declare class CGIPopoverHeaderComponent {
    /**
     * Boolean variable to set the container class="cgi-popover-header"
     */
    isClassContainer: boolean;
    /** Output event for when the popover is closed */
    popoverClose: EventEmitter<any>;
    /**
     * Constructor for popover header
     */
    constructor();
    /** Close method for when the close button is clicked */
    closePopover(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<CGIPopoverHeaderComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<CGIPopoverHeaderComponent, "cgi-popover-header", never, {}, { "popoverClose": "popoverClose"; }, never, ["*"], false, never>;
}

/**
 * Popover Content component.
 */
declare class CGIPopoverContentComponent {
    static ɵfac: i0.ɵɵFactoryDeclaration<CGIPopoverContentComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<CGIPopoverContentComponent, "cgi-popover-content", never, {}, {}, never, ["*"], false, never>;
}

/**
 * Popover Footer component.
 */
declare class CGIPopoverFooterComponent {
    /**
     * Boolean variable to set the container class="cgi-popover-footer"
     */
    isClassContainer: boolean;
    /**
     * Constructor for popover footer
     */
    constructor();
    static ɵfac: i0.ɵɵFactoryDeclaration<CGIPopoverFooterComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<CGIPopoverFooterComponent, "cgi-popover-footer", never, {}, {}, never, ["*"], false, never>;
}

/**
 * Click Outside Directive that emits an event whenever a target element is clicked.
 */
declare class CGIClickOutsideDirective {
    private _elementRef;
    /** Output event for when the user clicks outside the selected element */
    cgiClickOutside: EventEmitter<MouseEvent>;
    /** Boolean to tell if the overlay has opened yet */
    hasOpened: boolean;
    /**
     * Constructor for Click Outside Directive
     * @param _elementRef Reference to element the directive is declared in
     */
    constructor(_elementRef: ElementRef);
    /** On click function that runs everytime the document is clicked */
    onClick(event: MouseEvent, targetElement: HTMLElement): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<CGIClickOutsideDirective, never>;
    static ɵdir: i0.ɵɵDirectiveDeclaration<CGIClickOutsideDirective, "[cgiClickOutside]", never, {}, { "cgiClickOutside": "cgiClickOutside"; }, never, never, false, never>;
}

declare class CGIPopoverModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<CGIPopoverModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<CGIPopoverModule, [typeof CGIPopoverComponent, typeof CGIPopoverHeaderComponent, typeof CGIPopoverContentComponent, typeof CGIPopoverFooterComponent, typeof CGIClickOutsideDirective], [typeof i2.CommonModule, typeof i7$3.OverlayModule, typeof i4.MatButtonModule, typeof i3.MatIconModule], [typeof CGIPopoverComponent, typeof CGIPopoverHeaderComponent, typeof CGIPopoverContentComponent, typeof CGIPopoverFooterComponent, typeof CGIClickOutsideDirective]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<CGIPopoverModule>;
}

/** Select Search component */
declare class CGISelectSearchComponent implements OnInit, OnDestroy {
    matSelect: MatSelect;
    /** HostBinding for Select Search */
    isClassContainer: boolean;
    /** Input - List of options */
    options: any[];
    /** Input - Placeholder text */
    placeholder: string;
    /** Input - aria label for the input field */
    ariaLabel: string;
    /** Input - text for no results found */
    noResultsMessage: string;
    /** Output - event emitter that emits the filtered options */
    filterEvent: EventEmitter<any[]>;
    /** ViewChild - Reference to the input field */
    selectSearchInput: ElementRef;
    /** form control for the input field */
    inputFormControl: UntypedFormControl;
    /** variable used to determine if no results message should be displayed */
    noResultsFound: boolean;
    /** subject that emits when the component is destroyed */
    private _onDestroy;
    /** Input - function for getting the filtered values using the search string */
    filterFunction(options: string[], search: string): string[];
    /**
     * Constructor for CGISelectSearch component
     * @param matSelect reference to the MatSelect component paired with CGISelectSearch
     */
    constructor(matSelect: MatSelect);
    /** Initialization block when component is loaded */
    ngOnInit(): void;
    /** Lifecycle hook for when component is destroyed */
    ngOnDestroy(): void;
    /**
     * Intercept keyboard input when search field is active
     * @param event keyboard event
     */
    handleKeyDown(event: KeyboardEvent): void;
    /**
     * Filter the options list on the value of the search field
     */
    private filterOptions;
    /**
     * Apply focus to the search field
     */
    focus(): void;
    /**
     * Reset the value of the search field
     */
    reset(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<CGISelectSearchComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<CGISelectSearchComponent, "cgi-select-search", never, { "options": { "alias": "options"; "required": false; }; "placeholder": { "alias": "placeholder"; "required": false; }; "ariaLabel": { "alias": "ariaLabel"; "required": false; }; "noResultsMessage": { "alias": "noResultsMessage"; "required": false; }; "filterFunction": { "alias": "filterFunction"; "required": false; }; }, { "filterEvent": "filterEvent"; }, never, never, false, never>;
}

declare class CGISelectSearchModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<CGISelectSearchModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<CGISelectSearchModule, [typeof CGISelectSearchComponent], [typeof i2.CommonModule, typeof i5$1.ReactiveFormsModule, typeof i7$2.MatSelectModule, typeof i5$3.MatInputModule, typeof i5$2.MatFormFieldModule], [typeof CGISelectSearchComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<CGISelectSearchModule>;
}

/**
 * Skeleton component.
 *
 * TODO: How to use component and examples.
 */
declare class CGISkeletonComponent {
    static ɵfac: i0.ɵɵFactoryDeclaration<CGISkeletonComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<CGISkeletonComponent, "cgi-skeleton", never, {}, {}, never, never, false, never>;
}

declare class CGISkeletonModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<CGISkeletonModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<CGISkeletonModule, [typeof CGISkeletonComponent], [typeof i2.CommonModule, typeof i3.MatIconModule, typeof i4.MatButtonModule], [typeof CGISkeletonComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<CGISkeletonModule>;
}

/**
 * Toaster component.
 *
 * TODO: How to use component and examples.
 */
declare class CGIToasterComponent implements OnInit {
    data: any;
    private snackBarRef;
    /**
     * Boolean variable to set the container class="cgi-breadcrumbs"
     */
    isClassContainer: boolean;
    /** String to store the icon associated with the type of alert */
    icon: string;
    /** Boolean for specifying if the toaster has a header */
    hasHeader: boolean;
    /**
     * Constructor injecting custom snack bar detail for customization
     * @param data for what to display to the user
     * @param snackBarRef Reference to the MatSnackbar of the toaster component
     */
    constructor(data: any, snackBarRef: MatSnackBarRef<CGIToasterComponent>);
    /**
     * Life cycle hook for when the component is first initiated.
     */
    ngOnInit(): void;
    /** Method that sets the icon for the type of alert */
    setType(): void;
    /** close method will dismiss snackbar notification */
    close(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<CGIToasterComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<CGIToasterComponent, "cgi-toaster", never, {}, {}, never, never, false, never>;
}

declare class CGIToasterModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<CGIToasterModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<CGIToasterModule, [typeof CGIToasterComponent], [typeof i2.CommonModule, typeof i3.MatIconModule, typeof i4.MatButtonModule], [typeof CGIToasterComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<CGIToasterModule>;
}

/** Presentational container for timeline */
declare class CGITimelineComponent {
    /** Empty constructor */
    constructor();
    static ɵfac: i0.ɵɵFactoryDeclaration<CGITimelineComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<CGITimelineComponent, "cgi-timeline", never, {}, {}, never, ["*"], false, never>;
}

/** Presentational component to represent unit of timeline entry */
declare class CGITimelineEntryComponent implements OnInit {
    /** whether the timeline entry is inverted */
    private _inverted;
    /** Empty constructor */
    constructor();
    /** Value of the inverted property. */
    get inverted(): any;
    /** Set value of the inverted property. */
    set inverted(value: any);
    /** ngoninignitninitnit */
    ngOnInit(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<CGITimelineEntryComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<CGITimelineEntryComponent, "cgi-timeline-entry", never, { "inverted": { "alias": "inverted"; "required": false; }; }, {}, never, ["cgi-timeline-entry-icon", "cgi-timeline-entry-avatar", "cgi-timeline-entry-title", "cgi-timeline-entry-body"], false, never>;
}

/** Presentational component for timeline entry title */
declare class CGITimelineEntryTitleComponent {
    /** Empty constructor */
    constructor();
    static ɵfac: i0.ɵɵFactoryDeclaration<CGITimelineEntryTitleComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<CGITimelineEntryTitleComponent, "cgi-timeline-entry-title", never, {}, {}, never, ["*"], false, never>;
}

/** Presentational component for timeline entry icon */
declare class CGITimelineEntryIconComponent {
    /** Empty constructor */
    constructor();
    static ɵfac: i0.ɵɵFactoryDeclaration<CGITimelineEntryIconComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<CGITimelineEntryIconComponent, "cgi-timeline-entry-icon", never, {}, {}, never, ["*"], false, never>;
}

/** Presentational Component for entry body */
declare class CGITimelineEntryBodyComponent {
    /** Empty constructor */
    constructor();
    static ɵfac: i0.ɵɵFactoryDeclaration<CGITimelineEntryBodyComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<CGITimelineEntryBodyComponent, "cgi-timeline-entry-body", never, {}, {}, never, ["*"], false, never>;
}

/** Presentational component for entry avatar */
declare class CGITimelineEntryAvatarComponent {
    /** Empty constructor */
    constructor();
    static ɵfac: i0.ɵɵFactoryDeclaration<CGITimelineEntryAvatarComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<CGITimelineEntryAvatarComponent, "cgi-timeline-entry-avatar", never, {}, {}, never, ["*"], false, never>;
}

declare class CGITimelineModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<CGITimelineModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<CGITimelineModule, [typeof CGITimelineComponent, typeof CGITimelineEntryComponent, typeof CGITimelineEntryTitleComponent, typeof CGITimelineEntryIconComponent, typeof CGITimelineEntryBodyComponent, typeof CGITimelineEntryAvatarComponent], [typeof i2.CommonModule, typeof i3.MatIconModule, typeof i9.MatCardModule], [typeof CGITimelineComponent, typeof CGITimelineEntryComponent, typeof CGITimelineEntryTitleComponent, typeof CGITimelineEntryIconComponent, typeof CGITimelineEntryBodyComponent, typeof CGITimelineEntryAvatarComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<CGITimelineModule>;
}

/** Timepicker component */
declare class CGITimepickerComponent implements OnInit, OnChanges {
    private parentFormGroup;
    /**
     * Boolean variable to set the container class="cgi-timepicker"
     */
    isClassContainer: boolean;
    /** Input type (Date): set time in timepicker */
    setDateTime: Date;
    /** Input type (string): error message for timepicker */
    errorMessage: string;
    /** Input type (boolean): If component is required */
    required: boolean;
    /** Input type (boolean): If component is disabled */
    disabled: boolean;
    /** Input type (boolean): If component is read-only */
    readonly: boolean;
    /** Output for time */
    timeSelected: EventEmitter<any>;
    /** Variable to determine if form elements are valid */
    valid: boolean;
    /** Variable to get parent form */
    parentForm: FormGroupDirective;
    /** Autocomplete options for hours */
    hours: string[];
    /** Filtered autocomplete options for hours */
    filteredHrs: Observable<string[]>;
    /** Autocomplete options for minutes */
    minutes: string[];
    /** Filtered autocomplete options for minutes */
    filteredMins: Observable<string[]>;
    /** Form Control for hour field */
    hourFC: UntypedFormControl;
    /** Form control for minute field */
    minutesFC: UntypedFormControl;
    /** Form control for AM/PM field */
    dayPeriodFC: UntypedFormControl;
    /**
     * Constructor
     */
    constructor(parentFormGroup: FormGroupDirective);
    ngOnChanges(changes: SimpleChanges): void;
    /**
     * Generate array for autocomplete options
     */
    private generateArray;
    /**
     * Initialization block when component is loaded
     */
    ngOnInit(): void;
    /**
     * Private function: filter autocomplete lists
     */
    private filterList;
    /**
     * Function: updates the timepicker
     */
    updateTime(): void;
    /** Get function that returns if form elements in component are valid */
    getValidity(): boolean;
    static ɵfac: i0.ɵɵFactoryDeclaration<CGITimepickerComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<CGITimepickerComponent, "cgi-timepicker", never, { "setDateTime": { "alias": "setDateTime"; "required": false; }; "errorMessage": { "alias": "errorMessage"; "required": false; }; "required": { "alias": "required"; "required": false; }; "disabled": { "alias": "disabled"; "required": false; }; "readonly": { "alias": "readonly"; "required": false; }; }, { "timeSelected": "timeSelected"; }, never, never, false, never>;
}

declare class CGITimepickerModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<CGITimepickerModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<CGITimepickerModule, [typeof CGITimepickerComponent], [typeof i2.CommonModule, typeof i6.MatAutocompleteModule, typeof i4$3.MatButtonToggleModule, typeof i5$2.MatFormFieldModule, typeof i5$1.FormsModule, typeof i5$3.MatInputModule, typeof i5$1.ReactiveFormsModule], [typeof CGITimepickerComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<CGITimepickerModule>;
}

/**
 * Footer Container component.
 *
 */
declare class CGIFooterContainerComponent implements OnDestroy, OnInit, OnChanges {
    private cgiNavContainer;
    private document;
    private breakpointObserver;
    /** value for toggling the footer */
    toggle: any;
    /** footer container css selector */
    private cgiFooter;
    /** reference to small screen */
    private navBarScreenObservable$;
    /** constructor for DI */
    constructor(cgiNavContainer: CGINavContainerService$1, document: any, breakpointObserver: BreakpointObserver);
    /** subscribes to sidenav value and screen size for footer flexibility  */
    ngOnInit(): void;
    /** toggles the footer */
    ngOnChanges(): void;
    /** cleaning up observables */
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<CGIFooterContainerComponent, [{ optional: true; }, null, null]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<CGIFooterContainerComponent, "cgi-footer-container", never, { "toggle": { "alias": "toggle"; "required": false; }; }, {}, never, ["*"], false, never>;
}

declare class CGIFooterModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<CGIFooterModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<CGIFooterModule, [typeof CGIFooterContainerComponent], [typeof i2.CommonModule, typeof i3.MatIconModule, typeof i4.MatButtonModule, typeof i5$1.ReactiveFormsModule], [typeof CGIFooterContainerComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<CGIFooterModule>;
}

/**
 *  Headstone Component
 */
declare class CGIHeadstoneComponent implements OnInit {
    /** HostBinding for CSS */
    isClassContainer: boolean;
    /** Constructor */
    constructor();
    /** Life cycle hook for when the component is first initiated. */
    ngOnInit(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<CGIHeadstoneComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<CGIHeadstoneComponent, "cgi-headstone", never, {}, {}, never, ["*", "cgi-headstone-accordion"], false, never>;
}

/**
 * Headstone Item Component
 */
declare class CGIHeadstoneItemComponent implements OnInit {
    /** HostBinding for CSS */
    class: string;
    /** Input: variable for tooltip message */
    toolTip: string;
    /** constructor */
    constructor();
    /** Life cycle hook for when the component is first initiated. */
    ngOnInit(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<CGIHeadstoneItemComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<CGIHeadstoneItemComponent, "cgi-headstone-item", never, { "toolTip": { "alias": "toolTip"; "required": false; }; }, {}, never, ["label", "*", ".cgi-headstone-item__footer"], false, never>;
}

/**
 * Headstone Accordion component.
 */
declare class CGIHeadstoneAccordionComponent implements OnInit {
    /** HostBinding for CSS */
    isClassContainer: boolean;
    /** Boolean to toggle Accordion expansion */
    accordionExpanded: boolean;
    /** Component Constructor */
    constructor();
    /** Life cycle hook for when the component is first initiated. */
    ngOnInit(): void;
    /** Toggle Accordion expansion */
    toggle(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<CGIHeadstoneAccordionComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<CGIHeadstoneAccordionComponent, "cgi-headstone-accordion", never, {}, {}, never, [".cgi-headstone-accordion__header", "*"], false, never>;
}

declare class CGIHeadstoneModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<CGIHeadstoneModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<CGIHeadstoneModule, [typeof CGIHeadstoneComponent, typeof CGIHeadstoneItemComponent, typeof CGIHeadstoneAccordionComponent], [typeof i2.CommonModule, typeof i4.MatButtonModule, typeof i9.MatCardModule, typeof i7$4.MatDividerModule, typeof i7$1.MatExpansionModule, typeof i9$1.MatTooltipModule], [typeof CGIHeadstoneComponent, typeof CGIHeadstoneItemComponent, typeof CGIHeadstoneAccordionComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<CGIHeadstoneModule>;
}

/** set of properties related to the selection model */
interface SelectionSet {
    /** variable indicating total number of selected checkboxes */
    totalSelected: number;
    /** variable indicating the last selected checkboxes' index */
    lastSelected: number;
    /** variable for storing selection Models */
    selection: SelectionModel<any>;
}

declare class CGIMultiSelectCheckboxesComponent implements AfterViewInit, OnInit {
    table: MatTable<any>;
    private cdRef;
    /**
     * Boolean variable to set the container class="cgi-multi-select"
     */
    isClassContainer: boolean;
    /** ViewChild for defining columns on a MatTable */
    columnDef: MatColumnDef;
    /** selection from parent table */
    selection: SelectionModel<any>;
    /** set of properties related to the selection model */
    selectionSet: SelectionSet;
    /** sorted data used to define parent table */
    dataSourceSorted: any[];
    /** Event Emitter to emit the modified selection set back to the parent component */
    updatedSelectionSet: EventEmitter<SelectionSet>;
    /** Aria labels in HTML */
    checkboxLabel: string;
    /** flag to keep track of whether the shift key is being held down - defaulted to false */
    shiftKeyHeldDown: boolean;
    constructor(table: MatTable<any>, cdRef: ChangeDetectorRef);
    ngAfterViewInit(): void;
    ngOnInit(): void;
    /** function: detects when a shift key is clicked - associated with (click) to allow multi select */
    shiftHandler(event: any): void;
    /** function: handles a click event for multi-select table - associated with (change) but occurs after (click) */
    clickHandler(row: any, index: any, checkboxClicked: any): void;
    /** function: checks the last data value selected on multi-select table */
    checkLastSelected(): void;
    /**  function: selects multiple rows at once on multi-select table */
    selectRows(index: any): void;
    /** function: checks if all values in multi-select table are selected */
    isAllSelected(): boolean;
    /** function: selects/deselects all values in multi-select table */
    masterToggle(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<CGIMultiSelectCheckboxesComponent, [{ optional: true; }, null]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<CGIMultiSelectCheckboxesComponent, "cgi-multi-select-checkboxes", never, { "selection": { "alias": "selection"; "required": false; }; "selectionSet": { "alias": "selectionSet"; "required": false; }; "dataSourceSorted": { "alias": "dataSourceSorted"; "required": false; }; }, { "updatedSelectionSet": "updatedSelectionSet"; }, never, never, false, never>;
}

declare class CGIMultiSelectHeaderComponent implements OnInit {
    /** Applies the container CSS class to the host */
    isClassContainer: boolean;
    /** Counts how many table rows are selected in the parent table. */
    totalSelected: number;
    constructor();
    /** Lifecycle hook called once after first display */
    ngOnInit(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<CGIMultiSelectHeaderComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<CGIMultiSelectHeaderComponent, "cgi-multi-select-header", never, { "totalSelected": { "alias": "totalSelected"; "required": false; }; }, {}, never, ["*"], false, never>;
}

declare class CGIMultiSelectModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<CGIMultiSelectModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<CGIMultiSelectModule, [typeof CGIMultiSelectCheckboxesComponent, typeof CGIMultiSelectHeaderComponent], [typeof i2.CommonModule, typeof i9.MatCardModule, typeof i3.MatIconModule, typeof i4.MatButtonModule, typeof i7$5.MatTableModule, typeof i8.MatSortModule, typeof i9$2.MatCheckboxModule, typeof i10$1.BrowserAnimationsModule], [typeof CGIMultiSelectCheckboxesComponent, typeof CGIMultiSelectHeaderComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<CGIMultiSelectModule>;
}

/**
 * Alert Directive.
 */
declare class CGIAlertBrandDirective {
    viewContainerRef: ViewContainerRef;
    /**
     * Constructor for Alert Directive
     * @param viewContainerRef container reference for alert container
     */
    constructor(viewContainerRef: ViewContainerRef);
    static ɵfac: i0.ɵɵFactoryDeclaration<CGIAlertBrandDirective, never>;
    static ɵdir: i0.ɵɵDirectiveDeclaration<CGIAlertBrandDirective, "[cgiAlertHost]", never, {}, {}, never, never, false, never>;
}

/**
 * Alert Container component.
 *
 * TODO: How to use component and examples.
 */
declare class CGIAlertContainerBrandComponent implements OnChanges {
    private componentFactoryResolver;
    /** Array to store alerts inputted from parent */
    alerts: any[];
    /** Event Emitter to invoke parent when an action is preformed */
    action: EventEmitter<any>;
    /** Reference to Alert Directive */
    cgiAlertHost: CGIAlertBrandDirective;
    /**
     * Constructor for Alert Container Directive
     * @param componentFactoryResolver Factory Resolver for dynamic components
     */
    constructor(componentFactoryResolver: ComponentFactoryResolver);
    /**
     * Life cycle hook for when the component is first initiated and when there are changes to the component's input.
     */
    ngOnChanges(): void;
    /** Load an alert into the container */
    loadAlert(alert: any): void;
    /** Remove an alert in the container */
    removeAlert(alertItem: any): void;
    /** Get alerts being passed in from parent */
    getAlerts(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<CGIAlertContainerBrandComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<CGIAlertContainerBrandComponent, "cgi-alert-container-brand", never, { "alerts": { "alias": "alerts"; "required": false; }; }, { "action": "action"; }, never, never, false, never>;
}

/**
 * Alert component.
 *
 * TODO: How to use component and examples.
 */
declare class CGIAlertBrandComponent implements OnInit {
    private matIconRegistry;
    private domSanitizer;
    /**
     * Boolean variable to set the container class="cgi-alert"
     */
    isClassContainer: boolean;
    /**
     * String variable to set the animation state
     */
    animationState: string;
    /**
     * Boolean variable to set the container class="cgi-alert-info"
     */
    isInfo: boolean;
    /**
     * Boolean variable to set the container class="cgi-alert-warning"
     */
    isWarning: boolean;
    /**
     * Boolean variable to set the container class="cgi-alert-success"
     */
    isSuccess: boolean;
    /**
     * Boolean variable to set the container class="cgi-alert-error"
     */
    isError: boolean;
    /** Event Emitter to emit custom events back to the parent component */
    action: EventEmitter<boolean>;
    /** Object to store input data from the parent component */
    data: {
        type: any;
        header: any;
        message: any;
        customAction: any;
        actionSmall: any;
        actionBigOne: any;
        actionBigTwo: any;
        icon: boolean;
        showCloseButton: boolean;
    };
    /** String to store the icon associated with the type of alert */
    icon: string;
    /** Boolean for specifying if the alert has a header */
    hasHeader: boolean;
    hasIcon: boolean;
    /** Boolean for specifying if the alert emitted an animation */
    actionEmitted: boolean;
    /**
     * Constructor
     */
    constructor(matIconRegistry: MatIconRegistry, domSanitizer: DomSanitizer);
    /**
     * Life cycle hook for when the component is first initiated.
     */
    ngOnInit(): void;
    private registerCustomIcons;
    /** Method that sets the style and icon for the type of alert */
    setType(): void;
    /** close method that will initiate the close animation */
    close(): void;
    onActionClick(event: any): void;
    /** Listener for when the close animation has finished */
    animationDone(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<CGIAlertBrandComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<CGIAlertBrandComponent, "cgi-alert", never, { "data": { "alias": "data"; "required": false; }; }, { "action": "action"; }, never, never, false, never>;
}

declare class CGIAlertContainerBrandModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<CGIAlertContainerBrandModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<CGIAlertContainerBrandModule, [typeof CGIAlertContainerBrandComponent, typeof CGIAlertBrandComponent, typeof CGIAlertBrandDirective], [typeof i2.CommonModule, typeof i3.MatIconModule, typeof i4.MatButtonModule], [typeof CGIAlertContainerBrandComponent, typeof CGIAlertBrandComponent, typeof CGIAlertBrandDirective]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<CGIAlertContainerBrandModule>;
}

/**
 * Anchor Link class
 */
declare class AnchorBrandLink {
    /** id of the section */
    id: string;
    /** header type */
    type: string;
    /** If the anchor is in view of the page */
    active: boolean;
    /** name of the anchor */
    name: string;
    /** top offset px of the anchor */
    top: number;
    /** Number of errors present on each form */
    errorCount?: number;
}

/**
 * Anchor Scroll component.
 */
declare class CGIAnchorScrollBrandComponent implements OnInit, AfterViewInit, OnDestroy, OnChanges {
    private _element;
    _document: any;
    /** Array to the anchor links */
    links: AnchorBrandLink[];
    /** Anchor Scroll Container */
    container: string;
    /** Class of parent element */
    parentClass: string;
    /** Headers that will be selected as anchor scroll links */
    headerSelectors: string;
    /** Offset in pixels for links to trigger as active */
    linkOffset: number;
    /** All form IDs and their respective error counts (part of exception handling) */
    errorCounts: Array<{
        id: string;
        errors: number;
    }>;
    /** Auto link active on scroll event */
    linkActiveOnScroll: boolean;
    /** Selected section to be active */
    selectedSection: string;
    /** Emit the link selection id */
    linkClicked: EventEmitter<string>;
    /** Scroll Container that the anchor scroll component resides */
    private _scrollContainer;
    /** Fixed navigation bar */
    private _navBar;
    /** On destroy subject */
    private _destroyed;
    /** Selected anchor link */
    private _selectedSection;
    /** Anchor links container class */
    private _linkContainer;
    /** Class name used to sticky the scroll container */
    private _stickyClass;
    /**
     * Constructor for Anchor Scroll Component
     * @param _element Native anchor scroll HTML Element
     * @param _document Application's HTML Document
     */
    constructor(_element: ElementRef, _document: any);
    /**
     * Life cycle hook for when the component is first initiated.
     */
    ngOnInit(): void;
    /** Initialization block after view has been rendered */
    ngAfterViewInit(): void;
    /** When Component is destroyed remove event listeners */
    ngOnDestroy(): void;
    /** When changes to inputs are detected */
    ngOnChanges(changes: SimpleChanges): void;
    /** Update scroll position when selected link has changed */
    updateScrollPosition(): void;
    /** When a link is selected change the selected link and update scroll position */
    goToSection(id: string): void;
    /** Gets the scroll offset of the scroll container */
    private getScrollOffset;
    /** Create the links based on the header selectors */
    private createLinks;
    /** Update error counts for each link */
    private updateErrors;
    /** Check to see if link is active or not */
    private isLinkActive;
    /** Check to see if the component should be sticky or not */
    private checkSticky;
    /** Make component sticky */
    private addSticky;
    /** When there is a scroll event */
    onScroll: () => void;
    /** When the browser changes size */
    adjustWidth: () => void;
    static ɵfac: i0.ɵɵFactoryDeclaration<CGIAnchorScrollBrandComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<CGIAnchorScrollBrandComponent, "cgi-anchor-scroll", never, { "container": { "alias": "container"; "required": false; }; "parentClass": { "alias": "parentClass"; "required": false; }; "linkOffset": { "alias": "linkOffset"; "required": false; }; "errorCounts": { "alias": "errorCounts"; "required": false; }; "linkActiveOnScroll": { "alias": "linkActiveOnScroll"; "required": false; }; "selectedSection": { "alias": "selectedSection"; "required": false; }; }, { "linkClicked": "linkClicked"; }, never, never, false, never>;
}

/**
 * Anchor Scroll Container component.
 *
 * TODO: How to use component and examples.
 */
declare class CGIAnchorScrollContainerBrandComponent {
    /** Class of parent element */
    parentClass: string;
    /** Offset in pixels for links to trigger as active */
    linkOffset: number;
    /** All form IDs and their respective error counts (part of exception handling) */
    errorCounts: Array<{
        id: string;
        errors: number;
    }>;
    /** Title of anchor scroll */
    title: string;
    /** Auto link active on scroll event */
    linkActiveOnScroll: boolean;
    /** Selected section to be active */
    selectedSection: string;
    container: string;
    /** Emitt the link selection id */
    linkSection: EventEmitter<string>;
    /** Anchor Scroll child component */
    anchorScroll: CGIAnchorScrollBrandComponent;
    /** Boolean for showing the child anchor scroll component */
    showAnchor: Observable<boolean>;
    /**
     * Constructor for Anchor Scroll Component
     * @param breakpointObserver Breakpoint Observable for when to remove the anchor scroll component
     */
    constructor(breakpointObserver: BreakpointObserver);
    linkSectionEvent(id: string): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<CGIAnchorScrollContainerBrandComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<CGIAnchorScrollContainerBrandComponent, "cgi-anchor-scroll-container", never, { "parentClass": { "alias": "parentClass"; "required": false; }; "linkOffset": { "alias": "linkOffset"; "required": false; }; "errorCounts": { "alias": "errorCounts"; "required": false; }; "title": { "alias": "title"; "required": false; }; "linkActiveOnScroll": { "alias": "linkActiveOnScroll"; "required": false; }; "selectedSection": { "alias": "selectedSection"; "required": false; }; "container": { "alias": "container"; "required": false; }; }, { "linkSection": "linkSection"; }, never, ["*"], false, never>;
}

declare class CGIAnchorScrollContainerBrandModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<CGIAnchorScrollContainerBrandModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<CGIAnchorScrollContainerBrandModule, [typeof CGIAnchorScrollContainerBrandComponent, typeof CGIAnchorScrollBrandComponent], [typeof i2.CommonModule, typeof i4$1.RouterModule, typeof i5.MatBadgeModule], [typeof CGIAnchorScrollContainerBrandComponent, typeof CGIAnchorScrollBrandComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<CGIAnchorScrollContainerBrandModule>;
}

/** The supported landmarks for the quick-nav in the top-nav */
declare const enum PageLandmarks {
    GLOBAL_SEARCH = "global-search-component",
    LEFT_NAV = "left-nav",
    MAIN_CONTENT = "main-content"
}

/** Interface for supported landmarks for the quick-nav dropdown of the top-nav */
interface ILandmark {
    /** The label used for the landmark */
    label: string;
    /** The id of the landmark on the DOM */
    id: PageLandmarks;
}

/**
 * General top navigation component.
 *
 * TODO: How to use component and examples.
 */
declare class CGITopNavBrandComponent implements OnInit {
    /** Boolean variable to set the container class="cgi-top-nav" */
    isClassContainer: boolean;
    /** Flag for setting the visibility of the quick-nav button when focused/unfocused */
    hideButton: boolean;
    /** The landmarks to be quickly focused to from the quick-nav dropdown */
    landmarks: ILandmark[];
    /** Quick nav button text */
    quickSkipButtonText: string;
    /** Quick nav aria label */
    quickSkipAriaLabel: string;
    /** MatMenuTrigger element for controlling the open/close of the quick-nav menu */
    matMenu: MatMenuTrigger;
    /** Color attribute to set toolbar. */
    color: string;
    /** Custom aria-label attribute for accessibility. */
    ariaLabel: string;
    private _document;
    /**
     * Empty constructor.
     */
    constructor(document: any);
    /**
     * Set the default landmarks
     */
    ngOnInit(): void;
    /** Go (focus) to the specified landmark */
    goToLandmark(landmark: any): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<CGITopNavBrandComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<CGITopNavBrandComponent, "cgi-top-nav", never, { "landmarks": { "alias": "landmarks"; "required": false; }; "quickSkipButtonText": { "alias": "quickSkipButtonText"; "required": false; }; "quickSkipAriaLabel": { "alias": "quickSkipAriaLabel"; "required": false; }; "color": { "alias": "color"; "required": false; }; "ariaLabel": { "alias": "ariaLabel"; "required": false; }; }, {}, never, [".cgi-top-nav--left", ".cgi-top-nav--right"], false, never>;
}

/**
 * Service to maintain a single source of truth for whether the navigation
 * panel is opened. Shared between `cgi-side-nav`, `cgi-nav-content`,
 * `cgi-top-nav` and `cgi-footer-container`.
 */
declare class CGINavContainerService {
    /** BehaviourSubject backing the public observable. Default: opened. */
    private readonly _navOpen;
    /**
     * Public stream of the panel's opened state.
     * Kept named `changes` for backwards compatibility.
     */
    readonly changes: Observable<boolean>;
    /**
     * Toggle the panel state.
     * @param isOpen Optional explicit state. If omitted, the current value is flipped.
     *               If provided and equal to the current value, the call is a no-op.
     */
    toggle(isOpen?: boolean): void;
    /** Force open. Convenience wrapper around `toggle(true)`. */
    open(): void;
    /** Force close. Convenience wrapper around `toggle(false)`. */
    close(): void;
    /** Synchronous getter for the current opened state. */
    getState(): boolean;
    static ɵfac: i0.ɵɵFactoryDeclaration<CGINavContainerService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<CGINavContainerService>;
}

/**
 * GlobalSearchCategory class
 */
declare class GlobalSearchBrandCategory {
    /** variable for saving category name */
    name: string;
    /** variable for saving category value */
    value: string;
    /** variable for saving category icon name */
    icon?: string;
    /** variable for route link */
    moreResultsLink?: string;
    /** variable to attach search key for queryparam to route link */
    queryParamKey?: string;
    /**
     * constructor ( it receive variables ( name, value ) and saving )
     * @param name getting category name
     * @param value getting category value
     * @param icon getting category icon name
     * @param moreResultsLink getting category link for more results
     * @param queryParamKey getting key for queryparams
     */
    constructor(name: string, value: string, icon?: string, moreResultsLink?: string, queryParamKey?: string);
}

/**
 * GlobalSearchEntity class
 */
declare class GlobalSearchBrandEntity {
    /** variable for saving entity code */
    code: string;
    /** variable for saving entity code  */
    name: string;
    /**
     * constructor ( it receive variables ( code, name ) and saving )
     * @param code code for content
     * @param name name for content
     */
    constructor(code: string, name: string);
}

/**
 * GlobalSearchGroupOptions class
 */
declare class GlobalSearchGroupBrandOptions {
    /** save category data as a type of GlobalSearchCategory */
    category: GlobalSearchBrandCategory;
    /** save total records of search result data */
    totalRecords: number;
    /** save contents as a type of GlobalSearchEntity[] */
    contents: GlobalSearchBrandEntity[];
    /** boolean for expanding category in autocomplete panel (false=collapse, true=expand) */
    expandCategory?: boolean;
    /** constructor
     * @param contents getting GlobalSearchEntity type of array
     * @param totalRecords getting total name of result
     * @param category getting category data ( not necessary )
     */
    constructor(contents: GlobalSearchBrandEntity[], totalRecords: number, category?: GlobalSearchBrandCategory, expandCategory?: boolean);
}

/**
 * Enum for top-nav-item display modes
 */
declare enum TopNavItemMode {
    /** Default mode - displays ng-content */
    DEFAULT = "default",
    /** Menu mode - displays hamburger menu button */
    MENU = "menu",
    /** Logo mode - displays logo and title */
    LOGO = "logo",
    /** Search mode - displays search bar */
    SEARCH = "search",
    /** Dropdown mode - displays dropdown selector */
    DROPDOWN = "dropdown",
    /** Notification mode - displays notification icon */
    NOTIFICATION = "notification"
}

/** Interface for dropdown items */
interface DropdownItem {
    /** Display name */
    name: string;
    /** Value used for selection */
    value: string;
    /** Path to icon image */
    iconPath?: string;
    /** Optional URL to navigate to when selected */
    url?: string;
    /** Optional description to display below the name */
    description?: string;
    /** Whether the option is disabled */
    disabled?: boolean;
    /** Any additional data associated with this item */
    data?: any;
}

/**
 * Navigation item component for the top nav bar.
 * This component can display different elements based on its mode:
 * - Default: displays ng-content
 * - Menu: displays hamburger menu button
 * - Logo: displays logo and title
 * - Search: displays search bar
 * - Dropdown: displays dropdown selector
 */
declare class CGITopNavItemBrandComponent implements OnInit, AfterViewInit {
    private navContainerService;
    private fb;
    private router;
    private previousWidth;
    /** The display mode of the component */
    mode: TopNavItemMode;
    _menuItem: boolean;
    /** @deprecated Use mode = TopNavItemMode.MENU instead */
    /** @deprecated Use mode = TopNavItemMode.SEARCH instead */
    set _showSearchBar(value: boolean);
    /** @deprecated Use mode = TopNavItemMode.LOGO instead */
    set _showLogo(value: boolean);
    /** @deprecated Use mode = TopNavItemMode.DROPDOWN instead */
    set _showFrameworkSelector(value: boolean);
    /** @deprecated Use mode = TopNavItemMode.DROPDOWN instead */
    set _showDropdownSelector(value: boolean);
    lists: {
        icon: string;
        name: string;
        isClick: boolean;
    }[];
    /** Helper property for backward compatibility */
    _legacyFrameworkMode: boolean;
    /** Screen size breakpoint for search toggle behavior */
    private readonly MOBILE_BREAKPOINT;
    /** Initialize search toggle state based on screen size */
    showSearch: boolean;
    /** Host listener for window resize events */
    onResize(event: any): void;
    /** The source URL for the logo image */
    logoSrc: string;
    /** The alt text for the logo image */
    logoAlt: string;
    /** The title text to display */
    title: string;
    /** Whether to show the divider after the logo */
    showDivider: boolean;
    /** Array of dropdown items to display in the selector */
    dropdownItems: DropdownItem[];
    /** Selected dropdown item value */
    selectedDropdownItem: string;
    /** CSS class for the dropdown */
    dropdownClass: string;
    /** Width of the dropdown */
    dropdownWidth: string;
    /** Panel class for the dropdown */
    dropdownPanelClass: string;
    /** Placeholder text for the dropdown */
    dropdownPlaceholder: string;
    /** Whether the dropdown is disabled */
    dropdownDisabled: boolean;
    /** Aria label for the dropdown */
    dropdownAriaLabel: string;
    /** CSS class for the option labels */
    optionLabelClass: string;
    /** Whether to show descriptions for options */
    showDescriptions: boolean;
    /** Event emitted when a dropdown item is selected */
    dropdownItemSelected: EventEmitter<DropdownItem>;
    /** @deprecated Use dropdownItems instead */
    set frameworks(value: DropdownItem[]);
    /** @deprecated Use dropdownItems instead */
    get frameworks(): DropdownItem[];
    /** @deprecated Use selectedDropdownItem instead */
    set selectedFramework(value: string);
    /** @deprecated Use selectedDropdownItem instead */
    get selectedFramework(): string;
    /** @deprecated Use dropdownItemSelected instead */
    frameworkSelected: EventEmitter<DropdownItem>;
    /** Boolean to toggle the menu icon */
    opened: boolean;
    /** Search form */
    globalSearch: UntypedFormGroup;
    /** variable for toggling display of search component on small screens */
    isSearchToggled: boolean;
    showNotificationCard: boolean;
    /** An id for targeting the global search component */
    globalSearchId: string;
    /** Search categories */
    categories: GlobalSearchBrandCategory[];
    /** Whether to enable category selection */
    enableCategory: boolean;
    /** Whether search is loading */
    isLoading: boolean;
    /** Search results */
    globalSearchResult: GlobalSearchGroupBrandOptions[];
    /** Total number of search results */
    globalSearchResultSize: number;
    /** Autocomplete panel width */
    panelWidth: string | number;
    /** Aria label for the category selector */
    selectorAriaLabel: string;
    /** ID for the category select element */
    globalSearchSelectID: string;
    /** ID for the search input element */
    globalSearchInputID: string;
    /** Placeholder for the search input */
    globalSearchInputPlaceholder: string;
    /** ID for the autocomplete element */
    globalSearchAutocompleteID: string;
    /** Message for showing more results */
    moreResults: string;
    /** Message for no results */
    noResults: string;
    /** Number of results to display */
    resultLimit: number;
    /** Custom template for result item */
    subTemplate: TemplateRef<any>;
    /** Event emitted when a search result is selected */
    optionSelected: EventEmitter<any>;
    /** Event emitted when search is performed */
    search: EventEmitter<any>;
    /** Reference to autocomplete trigger */
    trigger: MatAutocompleteTrigger;
    /** @deprecated Use mode instead */
    /** @deprecated Use mode instead */
    /** @deprecated - Unused property */
    _showSearchIcon: boolean;
    /** Binding for container class */
    isClassContainer: boolean;
    get isMenuItem(): boolean;
    set menuItem(value: boolean);
    /** Binding for menu class */
    /** Binding for search class */
    get isSearchBarItem(): boolean;
    /**
     * Constructor
     */
    constructor(navContainerService: CGINavContainerService, fb: UntypedFormBuilder, router: Router);
    /**
     * Angular lifecycle hook
     */
    ngOnInit(): void;
    /**
     * Angular lifecycle hook
     */
    ngAfterViewInit(): void;
    /**
     * Toggle sidebar
     */
    toggleSidebar(): void;
    /**
     * Toggle search
     */
    toggle(): void;
    /**
     * Empty display function for autocomplete
     */
    displayFn(): string;
    /**
     * Load search results
     */
    loadSearchResults(): void;
    /**
     * Navigate to a link
     */
    gotoLink(link: string, queryKey?: string | null): void;
    /**
     * Handle search option selection
     */
    onEnter(category: GlobalSearchBrandCategory, entity: GlobalSearchBrandEntity, isShowMore?: boolean): void;
    /**
     * Get the selected dropdown item
     */
    getSelectedItem(): DropdownItem | null;
    /**
     * Get the selected dropdown item
     */
    getSelectedDropdownItem(): DropdownItem | null;
    /**
     * @deprecated Use getSelectedDropdownItem instead
     */
    getSelectedFramework(): DropdownItem | null;
    /**
     * Handle dropdown item selection
     */
    navigateToItem(item: DropdownItem): void;
    /**
     * @deprecated Use navigateToItem instead
     */
    navigateToFramework(item: DropdownItem, event: Event): void;
    /**
     * @deprecated Use mode instead
     */
    set showSearchIcon(value: boolean);
    static ɵfac: i0.ɵɵFactoryDeclaration<CGITopNavItemBrandComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<CGITopNavItemBrandComponent, "cgi-top-nav-item", never, { "mode": { "alias": "mode"; "required": false; }; "_showSearchBar": { "alias": "_showSearchBar"; "required": false; }; "_showLogo": { "alias": "_showLogo"; "required": false; }; "_showFrameworkSelector": { "alias": "_showFrameworkSelector"; "required": false; }; "_showDropdownSelector": { "alias": "_showDropdownSelector"; "required": false; }; "lists": { "alias": "lists"; "required": false; }; "logoSrc": { "alias": "logoSrc"; "required": false; }; "logoAlt": { "alias": "logoAlt"; "required": false; }; "title": { "alias": "title"; "required": false; }; "showDivider": { "alias": "showDivider"; "required": false; }; "dropdownItems": { "alias": "dropdownItems"; "required": false; }; "selectedDropdownItem": { "alias": "selectedDropdownItem"; "required": false; }; "dropdownClass": { "alias": "dropdownClass"; "required": false; }; "dropdownWidth": { "alias": "dropdownWidth"; "required": false; }; "dropdownPanelClass": { "alias": "dropdownPanelClass"; "required": false; }; "dropdownPlaceholder": { "alias": "dropdownPlaceholder"; "required": false; }; "dropdownDisabled": { "alias": "dropdownDisabled"; "required": false; }; "dropdownAriaLabel": { "alias": "dropdownAriaLabel"; "required": false; }; "optionLabelClass": { "alias": "optionLabelClass"; "required": false; }; "showDescriptions": { "alias": "showDescriptions"; "required": false; }; "frameworks": { "alias": "frameworks"; "required": false; }; "selectedFramework": { "alias": "selectedFramework"; "required": false; }; "opened": { "alias": "opened"; "required": false; }; "categories": { "alias": "categories"; "required": false; }; "enableCategory": { "alias": "enableCategory"; "required": false; }; "isLoading": { "alias": "isLoading"; "required": false; }; "globalSearchResult": { "alias": "globalSearchResult"; "required": false; }; "globalSearchResultSize": { "alias": "globalSearchResultSize"; "required": false; }; "panelWidth": { "alias": "panelWidth"; "required": false; }; "selectorAriaLabel": { "alias": "selectorAriaLabel"; "required": false; }; "globalSearchSelectID": { "alias": "globalSearchSelectID"; "required": false; }; "globalSearchInputID": { "alias": "globalSearchInputID"; "required": false; }; "globalSearchInputPlaceholder": { "alias": "globalSearchInputPlaceholder"; "required": false; }; "globalSearchAutocompleteID": { "alias": "globalSearchAutocompleteID"; "required": false; }; "moreResults": { "alias": "moreResults"; "required": false; }; "noResults": { "alias": "noResults"; "required": false; }; "resultLimit": { "alias": "resultLimit"; "required": false; }; "subTemplate": { "alias": "subTemplate"; "required": false; }; "menuItem": { "alias": "menuItem"; "required": false; }; "showSearchIcon": { "alias": "showSearchIcon"; "required": false; }; }, { "dropdownItemSelected": "dropdownItemSelected"; "frameworkSelected": "frameworkSelected"; "optionSelected": "optionSelected"; "search": "search"; }, never, ["*"], false, never>;
}

declare class CGITopNavBrandModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<CGITopNavBrandModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<CGITopNavBrandModule, [typeof CGITopNavBrandComponent, typeof CGITopNavItemBrandComponent], [typeof i2.CommonModule, typeof i4$2.MatToolbarModule, typeof i4.MatButtonModule, typeof i3.MatIconModule, typeof i7.MatMenuModule, typeof i6.MatAutocompleteModule, typeof i7$2.MatSelectModule, typeof i5$2.MatFormFieldModule, typeof i5$3.MatInputModule, typeof i5$1.FormsModule, typeof i5$1.ReactiveFormsModule, typeof i10.MatProgressSpinnerModule, typeof i7$4.MatDividerModule, typeof i9.MatCardModule, typeof i16.MatListModule], [typeof CGITopNavBrandComponent, typeof CGITopNavItemBrandComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<CGITopNavBrandModule>;
}

/**
 * Side Navigation Item data model
 */
declare class SideNavBrandItem {
    /** ligatures to icon */
    icon: string;
    /** url link */
    link: string;
    /** text to displayed on navigation */
    text: string;
    /** sub level navigation */
    subsection: SideNavBrandItem[];
    /** feature request: to support query attributes in navigation url */
    state: any;
    /** feature request: customizable attributes to be added to particular navigation route */
    queryParams: any;
    /**
     * Default constructor for SideNavItem
     * @param text Text/Title of side nav item
     * @param link Router link of side nav item
     * @param icon Icon of the side nav item
     * @param subsection Subsection of side nav item if applicable
     * @param state query attributes in navigation url
     * @param params customizable attributes to be added to particular navigation route
     */
    constructor(text?: string, link?: string, icon?: string, subsection?: SideNavBrandItem[], state?: any, params?: any);
}

/**
 * Top-level layout container for the CGI navigation system.
 *
 * Wraps `cgi-side-nav` and `cgi-nav-content` and acts as the positioning
 * context for the navigation panel. The container is self-sizing — no extra
 * `position: absolute; inset: 0` boilerplate is required in the consuming
 * component. For full-screen app shells use `[fillViewport]="true"`.
 *
 * ```html
 * <cgi-nav-container fillViewport>
 *   <cgi-side-nav [links]="links" opened></cgi-side-nav>
 *   <cgi-nav-content>...</cgi-nav-content>
 * </cgi-nav-container>
 * ```
 */
declare class CGINavContainerBrandComponent {
    private readonly navContainerService;
    /**
     * When true, the container stretches to the full browser viewport
     * (`100dvh` / `100vh`). Useful for app shells.
     */
    set fillViewport(value: boolean);
    get fillViewport(): boolean;
    private _fillViewport;
    /**
     * When true, pins the container to the viewport (`position: fixed`).
     * Mirrors `MatSidenavContainer.fixedInViewport`. Combine with
     * `[fixedTopGap]` / `[fixedBottomGap]` for fixed app bars/footers.
     */
    set fixedInViewport(value: boolean);
    get fixedInViewport(): boolean;
    private _fixedInViewport;
    /** Pixels of empty space at the top of the viewport (for fixed top bars). */
    set fixedTopGap(value: number);
    get fixedTopGap(): number;
    private _fixedTopGap;
    /** Pixels of empty space at the bottom of the viewport (for fixed footers). */
    set fixedBottomGap(value: number);
    get fixedBottomGap(): number;
    private _fixedBottomGap;
    /**
     * Optional background color applied to the container's host element.
     * Removes the need to bleed background styles from a parent component.
     */
    backgroundColor?: string;
    /**
     * When true (default), pressing `Escape` while the side-nav is opened in
     * mobile/over mode will close it. Mirrors `MatSidenav.disableClose` (inverted).
     */
    set disableClose(value: boolean);
    get disableClose(): boolean;
    private _disableClose;
    get fillViewportClass(): boolean;
    get fixedClass(): boolean;
    get topGapVar(): string | null;
    get bottomGapVar(): string | null;
    get backgroundStyle(): string | null;
    constructor(navContainerService: CGINavContainerService);
    /** Close the side-nav with `Escape` (unless `[disableClose]="true"`). */
    handleEscape(event: KeyboardEvent): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<CGINavContainerBrandComponent, [{ optional: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<CGINavContainerBrandComponent, "cgi-nav-container", never, { "fillViewport": { "alias": "fillViewport"; "required": false; }; "fixedInViewport": { "alias": "fixedInViewport"; "required": false; }; "fixedTopGap": { "alias": "fixedTopGap"; "required": false; }; "fixedBottomGap": { "alias": "fixedBottomGap"; "required": false; }; "backgroundColor": { "alias": "backgroundColor"; "required": false; }; "disableClose": { "alias": "disableClose"; "required": false; }; }, {}, never, ["*"], false, never>;
}

/**
 * Display mode for the side-nav. Mirrors the spirit of `MatDrawerMode`:
 *  - `rail` (default): collapsed icon rail; hover or click expands it inline.
 *  - `side`: always expanded next to the content (no hover collapse).
 *  - `over`: drawer overlays the content; backdrop is shown.
 */
type CGISideNavMode = 'rail' | 'side' | 'over';
/**
 * Side navigation component.
 *
 * Renders a collapsible vertical navigation rail. State (opened/closed) is
 * coordinated through `CGINavContainerService` so siblings (top-nav, content,
 * footer) react consistently.
 *
 * Features:
 *  - Two-way binding via `[(opened)]` (use `openedChange` output).
 *  - Configurable `mobileBreakpoint` and `hoverDelay` for tuning per app.
 *  - SSR-safe (no `window` access during server rendering).
 *  - `OnPush` change detection.
 */
declare class CGISideNavBrandComponent implements OnInit, OnDestroy {
    private readonly renderer;
    private readonly elRef;
    private readonly navContainerService;
    /** Boolean variable to set the container class="cgi-side-nav" */
    readonly isClassContainer = true;
    get modeRailClass(): boolean;
    get modeSideClass(): boolean;
    get modeOverClass(): boolean;
    /** Input for links object. */
    links: SideNavBrandItem[];
    /** Accessible label for the navigation landmark. */
    ariaLabel: string;
    /** Pixel width below which the nav switches to "mobile" behaviour. */
    mobileBreakpoint: number;
    /** Delay (ms) before opening the panel on hover. */
    hoverDelay: number;
    /**
     * Display mode (`rail` | `side` | `over`). Defaults to `rail` to preserve
     * legacy behaviour. `side` disables hover-to-peek and keeps the nav open.
     * `over` overlays content with a backdrop (the existing `cgi-nav-content`
     * backdrop already renders in mobile/over states).
     */
    set mode(value: CGISideNavMode);
    get mode(): CGISideNavMode;
    private _mode;
    /** When true, disables hover-to-open behaviour. Auto-true for `side` mode. */
    set disableHover(value: boolean);
    get disableHover(): boolean;
    private _disableHover;
    /** Emits whenever the opened state changes (supports `[(opened)]`). */
    readonly openedChange: EventEmitter<boolean>;
    /** Current opened state. */
    private _open;
    /** Hovered state. */
    private _mouseOver;
    /** True when viewport is at or below mobile width. */
    private mobileView;
    /** Pending hover-open timer. */
    private timerSub;
    /** Notifier for cleaning up subscriptions. */
    private readonly destroy$;
    /** True when running in a browser (vs SSR). */
    private readonly isBrowser;
    /** CSS class toggled on the parent container when the nav is opened. */
    private readonly PUSH_CLASS;
    /** An id for targeting the left nav. */
    readonly leftNavId: string;
    /** Observable that resolves to true when the viewport is in mobile range. */
    private readonly mobile$;
    constructor(renderer: Renderer2, elRef: ElementRef<HTMLElement>, navContainerService: CGINavContainerService, platformId: object);
    /**
     * Subscribe to navContainerService boolean value as one true source of state.
     * Also closes open navigation panel when screen resized to mobile view.
     */
    ngOnInit(): void;
    /** Cleanup all subscriptions. */
    ngOnDestroy(): void;
    /** Listener for MouseEnter. */
    mouseEnter(): void;
    /** Listener for MouseLeave. */
    mouseLeave(): void;
    /** Getter to determine whether or not to add opened class to host component. */
    get isOpened(): boolean;
    /** Provide option to set whether sidenav is opened or closed on initialization.  */
    set opened(value: boolean);
    get opened(): boolean;
    /** Open this sidenav. */
    open(): void;
    /** Close this sidenav. */
    close(): void;
    /** Close this sidenav only when in mobile view. */
    closeOnMobile(): void;
    /**
     * Toggle this sidenav. Equivalent to `open()` when closed and `close()` when opened.
     * In `side` mode the nav is pinned open — toggle calls are ignored to
     * prevent the layout from collapsing into a half-rendered rail.
     * @param isOpen Whether the sidenav should be open. Defaults to inverse of current state.
     */
    toggle(isOpen?: boolean): void;
    /** Cancels any pending hover-open timer. */
    private cancelHoverTimer;
    static ɵfac: i0.ɵɵFactoryDeclaration<CGISideNavBrandComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<CGISideNavBrandComponent, "cgi-side-nav", never, { "links": { "alias": "links"; "required": false; }; "ariaLabel": { "alias": "ariaLabel"; "required": false; }; "mobileBreakpoint": { "alias": "mobileBreakpoint"; "required": false; }; "hoverDelay": { "alias": "hoverDelay"; "required": false; }; "mode": { "alias": "mode"; "required": false; }; "disableHover": { "alias": "disableHover"; "required": false; }; "opened": { "alias": "opened"; "required": false; }; }, { "openedChange": "openedChange"; }, never, ["[cgiSideNavFooter]"], false, never>;
}

/**
 * Side navigation item component.
 *
 * Recursive renderer for `SideNavBrandItem` trees. Design supports up to
 * three levels of nesting; deeper structures are rendered but not styled.
 */
declare class CGISideNavItemBrandComponent implements OnInit, OnDestroy {
    private readonly navContainerService;
    private readonly _document;
    private readonly router;
    /** Whether the parent side-nav is opened. */
    isOpened: boolean;
    /** Items to render at this level. */
    links: SideNavBrandItem[];
    /** Current nesting level (0-based at the root, incremented for children). */
    level: number;
    /** Notifier used to tear down subscriptions on destroy. */
    private readonly destroy$;
    constructor(navContainerService: CGINavContainerService, _document: Document, router: Router);
    /** Subscribe to navContainerService boolean value as one true source of state. */
    ngOnInit(): void;
    /** Cleanup subscriptions. */
    ngOnDestroy(): void;
    /** Move focus to the main content region after a short delay. */
    focusToContent(): void;
    /** Programmatic router navigation used to make mat-expansion-panel headers keyboard-activatable. */
    goToLink(url: string): void;
    /** Wraps a single item in an array; returns an empty array for nullish input. */
    convertArray(input: object | null | undefined): SideNavBrandItem[];
    /** Stable identity for *ngFor to avoid re-rendering on reference changes. */
    trackByLink(_index: number, item: SideNavBrandItem): string | number;
    static ɵfac: i0.ɵɵFactoryDeclaration<CGISideNavItemBrandComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<CGISideNavItemBrandComponent, "cgi-side-nav-item", never, { "links": { "alias": "links"; "required": false; }; "level": { "alias": "level"; "required": false; }; }, {}, never, never, false, never>;
}

/**
 * Content host that sits next to `cgi-side-nav` inside `cgi-nav-container`.
 * Responsibilities:
 *  - Provides the projection slot for application content.
 *  - Scrolls back to the top of the projected content on route changes.
 *  - Closes the side nav when the mobile backdrop is clicked.
 */
declare class CGINavContentBrandComponent implements OnInit, OnDestroy {
    private readonly renderer;
    private readonly elRef;
    private readonly navContainerService;
    private readonly router;
    document: Document;
    /** Boolean variable to set the container class="cgi-nav-content" */
    readonly isClassContainer = true;
    /** Observable that publishes when the routers navigation end event is triggered. */
    readonly scrollToTop: Observable<NavigationEnd>;
    /** Notifier used to tear down subscriptions on destroy. */
    private readonly destroy$;
    constructor(renderer: Renderer2, elRef: ElementRef<HTMLElement>, navContainerService: CGINavContainerService, router: Router, document: Document);
    ngOnInit(): void;
    ngOnDestroy(): void;
    /** Close navigation when backdrop is clicked, only available on mobile view. */
    closeNav(): void;
    /**
     * Resets the scroll position of the content host on route change.
     *
     * Important: we use `scrollTo({ top: 0 })` on the host element rather than
     * `Element.scrollIntoView()` on a child, because `scrollIntoView` scrolls
     * EVERY scrollable ancestor (including `window`/the iframe). That caused
     * the page to jump and the top nav to slide out of view on every click.
     */
    private scrollContentToTop;
    static ɵfac: i0.ɵɵFactoryDeclaration<CGINavContentBrandComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<CGINavContentBrandComponent, "cgi-nav-content", never, {}, {}, never, ["*"], false, never>;
}

declare class CGINavContainerBrandModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<CGINavContainerBrandModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<CGINavContainerBrandModule, [typeof CGINavContainerBrandComponent, typeof CGISideNavBrandComponent, typeof CGISideNavItemBrandComponent, typeof CGINavContentBrandComponent], [typeof i2.CommonModule, typeof i4$2.MatToolbarModule, typeof i7$1.MatExpansionModule, typeof i4.MatButtonModule, typeof i3.MatIconModule, typeof i4$1.RouterModule], [typeof CGINavContainerBrandComponent, typeof CGISideNavBrandComponent, typeof CGISideNavItemBrandComponent, typeof CGINavContentBrandComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<CGINavContainerBrandModule>;
}

/**
 * Breadcrumbs component.
 *
 * TODO: How to use component and examples.
 */
declare class CGIBreadcrumbsBrandComponent implements OnInit {
    /**
     * Boolean variable to set the container class="cgi-breadcrumbs"
     */
    isClassContainer: boolean;
    /** Custom aria-label attribute for accessibility. */
    ariaLabel: string;
    /**
     * Empty constructor.
     */
    constructor();
    /**
     * Set title property in component.
     */
    ngOnInit(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<CGIBreadcrumbsBrandComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<CGIBreadcrumbsBrandComponent, "cgi-breadcrumbs", never, { "ariaLabel": { "alias": "ariaLabel"; "required": false; }; }, {}, never, ["*"], false, never>;
}

/**
 * Breadcrumbs component.
 *
 * TODO: How to use component and examples.
 */
declare class CGIBreadcrumbItemBrandComponent implements OnInit {
    /**
     * Boolean variable to set the container class="cgi-breadcrumbs"
     */
    isClassContainer: boolean;
    /**
     * Empty constructor.
     */
    constructor();
    /**
     * Set title property in component.
     */
    ngOnInit(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<CGIBreadcrumbItemBrandComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<CGIBreadcrumbItemBrandComponent, "cgi-breadcrumb-item", never, {}, {}, never, ["*"], false, never>;
}

declare class CGIBreadcrumbsBrandModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<CGIBreadcrumbsBrandModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<CGIBreadcrumbsBrandModule, [typeof CGIBreadcrumbsBrandComponent, typeof CGIBreadcrumbItemBrandComponent], [typeof i2.CommonModule], [typeof CGIBreadcrumbsBrandComponent, typeof CGIBreadcrumbItemBrandComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<CGIBreadcrumbsBrandModule>;
}

/** Global Search Component */
declare class CgiGlobalSearchBrandComponent implements AfterViewInit, OnInit {
    private fb;
    private router;
    /** HostBinding for Global Search */
    isClassContainer: boolean;
    /** define FormGroup name as globalSearch */
    globalSearch: UntypedFormGroup;
    /** variable for toggling display of search component on small screens */
    isSearchToggled: boolean;
    /** Input - Categories for drop-down list of category form */
    categories: GlobalSearchBrandCategory[];
    /** Input - variable for checking global search use category or not */
    enableCategory: boolean;
    /** Input - variable for checking statement for spinner ( true or false ) */
    isLoading: boolean;
    /** Input - variable for getting result of searching  */
    globalSearchResult: GlobalSearchGroupBrandOptions[];
    /** Input - Getting Data size from Search Result, it is used for showing No search result option  */
    globalSearchResultSize: number;
    /** Input - allow users to specify autoComplete panel width. Can be any CSS sizing value, otherwise it will match the width of its host */
    panelWidth: string | number;
    /** Input - variable for setting aria-label for the select menu : string type and default value */
    selectorAriaLabel: string;
    /** Input - for globalSearchSelect ( drop-down list for Category ) : string type and default value */
    globalSearchSelectID: string;
    /** Input - for  global search input box  ( search section  ) : string type and default value */
    globalSearchInputID: string;
    /** Input - for  global search placeholder ( search section ) : string type and default value */
    globalSearchInputPlaceholder: string;
    /** Input - for global search autocomplete ( search result section ) : string type and default value */
    globalSearchAutocompleteID: string;
    /** Input - for i18n : show more results message */
    moreResults: string;
    /** Input - for i18n : no results message */
    noResults: string;
    /** Input - specifies the number of results to display in dropdown panel  */
    resultLimit: number;
    /** Input - enable custom template for result item subTemplate */
    subTemplate: TemplateRef<any>;
    /** Output - variable for checking a category is selected or not  */
    optionSelected: EventEmitter<any>;
    /** Output - variable for emitting search to app-shell  */
    search: EventEmitter<any>;
    /** ViewChild - check Mat autocomplete is triggered or not  */
    /** variable for trigger  */
    trigger: MatAutocompleteTrigger;
    /** An id for targeting the global search component */
    globalSearchId: string;
    /** constructor for host binding and form group */
    constructor(fb: UntypedFormBuilder, router: Router);
    /** when search bar is loaded, displayFn() set up first value in searchString */
    displayFn(): string;
    /** Initialization block when component is loaded */
    ngOnInit(): void;
    /** Initialization block after view has been rendered */
    ngAfterViewInit(): void;
    /**
     * Callback function to call when form values change, and emit the form group as an output
     */
    loadSearchResults(): void;
    /**
     * Navigation link for more results button
     */
    gotoLink(link: any, queryKey?: string): void;
    /**
     * Callback function for selecting an option from Autocomplete, and return the data in the following format as output
     * {searchText, category, entity, isShowMore}
     * @param category Category selected in the dropdown
     * @param entity Search result selected in the autocomplete
     * @param isShowMore Select to show more results
     */
    onEnter(category: GlobalSearchBrandCategory, entity: GlobalSearchBrandEntity, isShowMore?: boolean): void;
    /**
     * Method for displaying search on small screens
     */
    toggle(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<CgiGlobalSearchBrandComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<CgiGlobalSearchBrandComponent, "cgi-global-search", never, { "categories": { "alias": "categories"; "required": false; }; "enableCategory": { "alias": "enableCategory"; "required": false; }; "isLoading": { "alias": "isLoading"; "required": false; }; "globalSearchResult": { "alias": "globalSearchResult"; "required": false; }; "globalSearchResultSize": { "alias": "globalSearchResultSize"; "required": false; }; "panelWidth": { "alias": "panelWidth"; "required": false; }; "selectorAriaLabel": { "alias": "selectorAriaLabel"; "required": false; }; "globalSearchSelectID": { "alias": "globalSearchSelectID"; "required": false; }; "globalSearchInputID": { "alias": "globalSearchInputID"; "required": false; }; "globalSearchInputPlaceholder": { "alias": "globalSearchInputPlaceholder"; "required": false; }; "globalSearchAutocompleteID": { "alias": "globalSearchAutocompleteID"; "required": false; }; "moreResults": { "alias": "moreResults"; "required": false; }; "noResults": { "alias": "noResults"; "required": false; }; "resultLimit": { "alias": "resultLimit"; "required": false; }; "subTemplate": { "alias": "subTemplate"; "required": false; }; }, { "optionSelected": "optionSelected"; "search": "search"; }, never, never, false, never>;
}

declare class CGIGlobalSearchBrandModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<CGIGlobalSearchBrandModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<CGIGlobalSearchBrandModule, [typeof CgiGlobalSearchBrandComponent], [typeof i2.CommonModule, typeof i4.MatButtonModule, typeof i3.MatIconModule, typeof i5$1.FormsModule, typeof i5$1.ReactiveFormsModule, typeof i6.MatAutocompleteModule, typeof i7$2.MatSelectModule, typeof i5$2.MatFormFieldModule, typeof i5$3.MatInputModule, typeof i10.MatProgressSpinnerModule, typeof i4$1.RouterModule], [typeof CgiGlobalSearchBrandComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<CGIGlobalSearchBrandModule>;
}

/**
 * Popover component.
 */
declare class CGIPopoverBrandComponent {
    private _focusTrapFactory;
    private document;
    /** Unique name identifier for the popover */
    popoverName: any;
    /** The width of the popover */
    popoverWidth: number;
    /** Boolean for whether the popover is open or closed */
    isPopoverOpen: boolean;
    /** Output event for when the popover is closed */
    popoverClose: EventEmitter<any>;
    /** Optional panel class applied to the overlay pane for custom positioning */
    panelClass: string;
    /** variable keeps track of trapping popover */
    private restoreTrap;
    /** variable keeps track of close button focus restore */
    private closeButton;
    /** Current state of the popover animation. */
    popoverAnimationState: 'void' | 'enter';
    /** focus trap class from a11y */
    private _focusTrap;
    /** Element that was focused before the popover was opened. Save this to restore upon close. */
    private _elementFocusedBeforeDialogWasOpened;
    /** Constructor for Popover Component
     * @param _focusTrapFactory Create focus trap service for a11y
     * @param document Allows for focus trap within the component
     */
    constructor(_focusTrapFactory: ConfigurableFocusTrapFactory, document: any);
    /** called when overlay is attached */
    overlayAttached(): void;
    /** called when overlay is detached */
    overlayDetached(): void;
    /** Close method for when the popover is closed by clicking outside */
    closePopover(): void;
    /** Sets focus to the closing button on popover */
    private focusButton;
    /** creates focus to the popover that was opened. */
    private createTrapFocus;
    /** Restores focus to the element that was focused before the popover opened. */
    private restoreFocus;
    static ɵfac: i0.ɵɵFactoryDeclaration<CGIPopoverBrandComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<CGIPopoverBrandComponent, "cgi-popover", never, { "popoverName": { "alias": "popoverName"; "required": false; }; "popoverWidth": { "alias": "popoverWidth"; "required": false; }; "isPopoverOpen": { "alias": "isPopoverOpen"; "required": false; }; "panelClass": { "alias": "panelClass"; "required": false; }; }, { "popoverClose": "popoverClose"; }, never, ["*"], false, never>;
}

/**
 * Popover Header component.
 */
declare class CGIPopoverHeaderBrandComponent {
    /**
     * Boolean variable to set the container class="cgi-popover-header"
     */
    isClassContainer: boolean;
    /** Output event for when the popover is closed */
    popoverClose: EventEmitter<any>;
    /**
     * Constructor for popover header
     */
    constructor();
    /** Close method for when the close button is clicked */
    closePopover(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<CGIPopoverHeaderBrandComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<CGIPopoverHeaderBrandComponent, "cgi-popover-header", never, {}, { "popoverClose": "popoverClose"; }, never, ["*"], false, never>;
}

/**
 * Popover Content component.
 */
declare class CGIPopoverContentBrandComponent {
    static ɵfac: i0.ɵɵFactoryDeclaration<CGIPopoverContentBrandComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<CGIPopoverContentBrandComponent, "cgi-popover-content", never, {}, {}, never, ["*"], false, never>;
}

/**
 * Popover Footer component.
 */
declare class CGIPopoverFooterBrandComponent {
    /**
     * Boolean variable to set the container class="cgi-popover-footer"
     */
    isClassContainer: boolean;
    /**
     * Constructor for popover footer
     */
    constructor();
    static ɵfac: i0.ɵɵFactoryDeclaration<CGIPopoverFooterBrandComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<CGIPopoverFooterBrandComponent, "cgi-popover-footer", never, {}, {}, never, ["*"], false, never>;
}

/**
 * Click Outside Directive that emits an event whenever a target element is clicked.
 */
declare class CGIClickOutsideBrandDirective {
    private _elementRef;
    /** Output event for when the user clicks outside the selected element */
    cgiClickOutside: EventEmitter<MouseEvent>;
    /** Boolean to tell if the overlay has opened yet */
    hasOpened: boolean;
    /**
     * Constructor for Click Outside Directive
     * @param _elementRef Reference to element the directive is declared in
     */
    constructor(_elementRef: ElementRef);
    /** On click function that runs everytime the document is clicked */
    onClick(event: MouseEvent, targetElement: HTMLElement): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<CGIClickOutsideBrandDirective, never>;
    static ɵdir: i0.ɵɵDirectiveDeclaration<CGIClickOutsideBrandDirective, "[cgiClickOutside]", never, {}, { "cgiClickOutside": "cgiClickOutside"; }, never, never, false, never>;
}

declare class CGIPopoverBrandModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<CGIPopoverBrandModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<CGIPopoverBrandModule, [typeof CGIPopoverBrandComponent, typeof CGIPopoverHeaderBrandComponent, typeof CGIPopoverContentBrandComponent, typeof CGIPopoverFooterBrandComponent, typeof CGIClickOutsideBrandDirective], [typeof i2.CommonModule, typeof i7$3.OverlayModule, typeof i4.MatButtonModule, typeof i3.MatIconModule], [typeof CGIPopoverBrandComponent, typeof CGIPopoverHeaderBrandComponent, typeof CGIPopoverContentBrandComponent, typeof CGIPopoverFooterBrandComponent, typeof CGIClickOutsideBrandDirective]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<CGIPopoverBrandModule>;
}

/** Select Search component */
declare class CGISelectSearchBrandComponent implements OnInit, OnDestroy {
    matSelect: MatSelect;
    /** HostBinding for Select Search */
    isClassContainer: boolean;
    /** Input - List of options */
    options: any[];
    /** Input - Placeholder text */
    placeholder: string;
    /** Input - aria label for the input field */
    ariaLabel: string;
    /** Input - text for no results found */
    noResultsMessage: string;
    /** Output - event emitter that emits the filtered options */
    filterEvent: EventEmitter<any[]>;
    /** ViewChild - Reference to the input field */
    selectSearchInput: ElementRef;
    /** form control for the input field */
    inputFormControl: UntypedFormControl;
    /** variable used to determine if no results message should be displayed */
    noResultsFound: boolean;
    /** subject that emits when the component is destroyed */
    private _onDestroy;
    /** Input - function for getting the filtered values using the search string */
    filterFunction(options: string[], search: string): string[];
    /**
     * Constructor for CGISelectSearch component
     * @param matSelect reference to the MatSelect component paired with CGISelectSearch
     */
    constructor(matSelect: MatSelect);
    /** Initialization block when component is loaded */
    ngOnInit(): void;
    /** Lifecycle hook for when component is destroyed */
    ngOnDestroy(): void;
    /**
     * Intercept keyboard input when search field is active
     * @param event keyboard event
     */
    handleKeyDown(event: KeyboardEvent): void;
    /**
     * Filter the options list on the value of the search field
     */
    private filterOptions;
    /**
     * Apply focus to the search field
     */
    focus(): void;
    /**
     * Reset the value of the search field
     */
    reset(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<CGISelectSearchBrandComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<CGISelectSearchBrandComponent, "cgi-select-search", never, { "options": { "alias": "options"; "required": false; }; "placeholder": { "alias": "placeholder"; "required": false; }; "ariaLabel": { "alias": "ariaLabel"; "required": false; }; "noResultsMessage": { "alias": "noResultsMessage"; "required": false; }; "filterFunction": { "alias": "filterFunction"; "required": false; }; }, { "filterEvent": "filterEvent"; }, never, never, false, never>;
}

declare class CGISelectSearchBrandModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<CGISelectSearchBrandModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<CGISelectSearchBrandModule, [typeof CGISelectSearchBrandComponent], [typeof i2.CommonModule, typeof i5$1.ReactiveFormsModule, typeof i7$2.MatSelectModule, typeof i5$3.MatInputModule, typeof i5$2.MatFormFieldModule], [typeof CGISelectSearchBrandComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<CGISelectSearchBrandModule>;
}

/**
 * Skeleton component.
 *
 * TODO: How to use component and examples.
 */
declare class CGISkeletonBrandComponent {
    static ɵfac: i0.ɵɵFactoryDeclaration<CGISkeletonBrandComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<CGISkeletonBrandComponent, "cgi-skeleton", never, {}, {}, never, never, false, never>;
}

declare class CGISkeletonBrandModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<CGISkeletonBrandModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<CGISkeletonBrandModule, [typeof CGISkeletonBrandComponent], [typeof i2.CommonModule, typeof i3.MatIconModule, typeof i4.MatButtonModule], [typeof CGISkeletonBrandComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<CGISkeletonBrandModule>;
}

/**
 * Toaster component.
 *
 * TODO: How to use component and examples.
 */
declare class CGIToasterBrandComponent implements OnInit {
    data: any;
    private snackBarRef;
    /**
     * Boolean variable to set the container class="cgi-breadcrumbs"
     */
    isClassContainer: boolean;
    /** String to store the icon associated with the type of alert */
    icon: string;
    /** Boolean for specifying if the toaster has a header */
    hasHeader: boolean;
    /**
     * Constructor injecting custom snack bar detail for customization
     * @param data for what to display to the user
     * @param snackBarRef Reference to the MatSnackbar of the toaster component
     */
    constructor(data: any, snackBarRef: MatSnackBarRef<CGIToasterBrandComponent>);
    /**
     * Life cycle hook for when the component is first initiated.
     */
    ngOnInit(): void;
    /** Method that sets the icon for the type of alert */
    setType(): void;
    /** close method will dismiss snackbar notification */
    close(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<CGIToasterBrandComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<CGIToasterBrandComponent, "cgi-toaster", never, {}, {}, never, never, false, never>;
}

declare class CGIToasterBrandModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<CGIToasterBrandModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<CGIToasterBrandModule, [typeof CGIToasterBrandComponent], [typeof i2.CommonModule, typeof i3.MatIconModule, typeof i4.MatButtonModule], [typeof CGIToasterBrandComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<CGIToasterBrandModule>;
}

/** Presentational container for timeline */
declare class CGITimelineBrandComponent {
    /** Empty constructor */
    constructor();
    static ɵfac: i0.ɵɵFactoryDeclaration<CGITimelineBrandComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<CGITimelineBrandComponent, "cgi-timeline", never, {}, {}, never, ["*"], false, never>;
}

/** Presentational component to represent unit of timeline entry */
declare class CGITimelineEntryBrandComponent implements OnInit {
    /** whether the timeline entry is inverted */
    private _inverted;
    /** Empty constructor */
    constructor();
    /** Value of the inverted property. */
    get inverted(): any;
    /** Set value of the inverted property. */
    set inverted(value: any);
    /** ngoninignitninitnit */
    ngOnInit(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<CGITimelineEntryBrandComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<CGITimelineEntryBrandComponent, "cgi-timeline-entry", never, { "inverted": { "alias": "inverted"; "required": false; }; }, {}, never, ["cgi-timeline-entry-icon", "cgi-timeline-entry-avatar", "cgi-timeline-entry-title", "cgi-timeline-entry-body"], false, never>;
}

/** Presentational component for timeline entry title */
declare class CGITimelineEntryTitleBrandComponent {
    /** Empty constructor */
    constructor();
    static ɵfac: i0.ɵɵFactoryDeclaration<CGITimelineEntryTitleBrandComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<CGITimelineEntryTitleBrandComponent, "cgi-timeline-entry-title", never, {}, {}, never, ["*"], false, never>;
}

/** Presentational component for timeline entry icon */
declare class CGITimelineEntryIconBrandComponent {
    /** Empty constructor */
    constructor();
    static ɵfac: i0.ɵɵFactoryDeclaration<CGITimelineEntryIconBrandComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<CGITimelineEntryIconBrandComponent, "cgi-timeline-entry-icon", never, {}, {}, never, ["*"], false, never>;
}

/** Presentational Component for entry body */
declare class CGITimelineEntryBodyBrandComponent {
    /** Empty constructor */
    constructor();
    static ɵfac: i0.ɵɵFactoryDeclaration<CGITimelineEntryBodyBrandComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<CGITimelineEntryBodyBrandComponent, "cgi-timeline-entry-body", never, {}, {}, never, ["*"], false, never>;
}

/** Presentational component for entry avatar */
declare class CGITimelineEntryAvatarBrandComponent {
    /** Empty constructor */
    constructor();
    static ɵfac: i0.ɵɵFactoryDeclaration<CGITimelineEntryAvatarBrandComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<CGITimelineEntryAvatarBrandComponent, "cgi-timeline-entry-avatar", never, {}, {}, never, ["*"], false, never>;
}

declare class CGITimelineBrandModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<CGITimelineBrandModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<CGITimelineBrandModule, [typeof CGITimelineBrandComponent, typeof CGITimelineEntryBrandComponent, typeof CGITimelineEntryTitleBrandComponent, typeof CGITimelineEntryIconBrandComponent, typeof CGITimelineEntryBodyBrandComponent, typeof CGITimelineEntryAvatarBrandComponent], [typeof i2.CommonModule, typeof i3.MatIconModule, typeof i9.MatCardModule], [typeof CGITimelineBrandComponent, typeof CGITimelineEntryBrandComponent, typeof CGITimelineEntryTitleBrandComponent, typeof CGITimelineEntryIconBrandComponent, typeof CGITimelineEntryBodyBrandComponent, typeof CGITimelineEntryAvatarBrandComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<CGITimelineBrandModule>;
}

/** Timepicker component */
declare class CGITimepickerBrandComponent implements OnInit, OnChanges {
    private parentFormGroup;
    /**
     * Boolean variable to set the container class="cgi-timepicker"
     */
    isClassContainer: boolean;
    /** Input type (Date): set time in timepicker */
    setDateTime: Date;
    /** Input type (string): error message for timepicker */
    errorMessage: string;
    /** Input type (boolean): If component is required */
    required: boolean;
    /** Input type (boolean): If component is disabled */
    disabled: boolean;
    /** Input type (boolean): If component is read-only. When true, only displays the selected period (AM or PM) button */
    readonly: boolean;
    /** Input type (string): Appearance style of the timepicker (fill, outline, legacy, standard) */
    appearance: 'fill' | 'outline';
    /** Input type (number): Minimum hour value */
    minHour: number;
    /** Input type (number): Maximum hour value */
    maxHour: number;
    /** Input type (string): Label for hour field */
    hourLabel: string;
    /** Input type (string): Label for minute field */
    minuteLabel: string;
    /** Input type (string): Placeholder for hour field */
    hourPlaceholder: string;
    /** Input type (string): Placeholder for minute field */
    minutePlaceholder: string;
    /** Input type (string): Label for AM period */
    amLabel: string;
    /** Input type (string): Label for PM period */
    pmLabel: string;
    /** Input type (Date): Minimum allowed time */
    minTime: Date;
    /** Input type (Date): Maximum allowed time */
    maxTime: Date;
    /** Input type (number): Default hour when component initializes without setDateTime */
    defaultHour: number;
    /** Input type (number): Default minute when component initializes without setDateTime */
    defaultMinute: number;
    /** Input type (string): Default period (am/pm) when component initializes without setDateTime */
    defaultPeriod: 'am' | 'pm';
    /** Output for time */
    timeSelected: EventEmitter<any>;
    /** Output for hour change */
    hourChanged: EventEmitter<number>;
    /** Output for minute change */
    minuteChanged: EventEmitter<number>;
    /** Output for period change */
    periodChanged: EventEmitter<string>;
    /** Variable to determine if form elements are valid */
    valid: boolean;
    /** Variable to get parent form */
    parentForm: FormGroupDirective;
    /** Autocomplete options for hours */
    hours: string[];
    /** Filtered autocomplete options for hours */
    filteredHrs: Observable<string[]>;
    /** Autocomplete options for minutes */
    minutes: string[];
    /** Filtered autocomplete options for minutes */
    filteredMins: Observable<string[]>;
    /** Form Control for hour field */
    hourFC: UntypedFormControl;
    /** Form control for minute field */
    minutesFC: UntypedFormControl;
    /** Form control for AM/PM field */
    dayPeriodFC: UntypedFormControl;
    /**
     * Constructor
     */
    constructor(parentFormGroup: FormGroupDirective);
    ngOnChanges(changes: SimpleChanges): void;
    /**
     * Initialize time arrays based on dynamic configuration
     */
    private initializeTimeArrays;
    /**
     * Generate array for autocomplete options
     */
    private generateArray;
    /**
     * Apply default time values
     */
    private applyDefaultTime;
    /**
     * Set time from a Date object, string, or number
     * Converts the input to a Date object and extracts the time portion
     * Handles 12-hour format conversion with AM/PM period
     * @param dateTime - Date object, ISO string, timestamp, or any valid Date constructor input
     */
    private setTimeFromDateTime;
    /**
     * Initialization block when component is loaded
     */
    ngOnInit(): void;
    /**
     * Private function: filter autocomplete lists
     */
    private filterList;
    /**
     * Updates the timepicker and emits time-related events
     * - Validates and constrains hour input within minHour/maxHour range
     * - Validates and constrains minute input within 0-59 range
     * - Checks time against minTime/maxTime constraints
     * - Preserves the date portion from setDateTime input if provided, otherwise uses current date
     * - Emits hourChanged, minuteChanged, periodChanged, and timeSelected events
     * - Auto-corrects invalid times to nearest valid boundary
     */
    updateTime(): void;
    /**
     * Validate if time is within min/max constraints
     * If validation fails, automatically corrects the time to the nearest valid boundary
     * and displays an appropriate error message to the user
     * @param hour - The hour value to validate (in 12-hour format)
     * @param min - The minute value to validate (0-59)
     * @returns boolean - true if time is valid, false if time was corrected
     */
    private validateTimeRange;
    /**
     * Correct time to minimum allowed time
     * Automatically adjusts hour, minute, and period (AM/PM) to match the minTime constraint
     * Converts 24-hour format from minTime to 12-hour format for display
     * Updates both form controls and ngModel properties for bidirectional binding
     */
    private correctToMinTime;
    /**
     * Correct time to maximum allowed time
     * Automatically adjusts hour, minute, and period (AM/PM) to match the maxTime constraint
     * Converts 24-hour format from maxTime to 12-hour format for display
     * Updates both form controls and ngModel properties for bidirectional binding
     */
    private correctToMaxTime;
    /** Get function that returns if form elements in component are valid */
    getValidity(): boolean;
    /** Properties bound to ngModel in template */
    selectedHrTime: string;
    selectedMinTime: string;
    selectedPeriod: string;
    /** Input type (boolean): Indicates if the current time violates minTime/maxTime constraints */
    isTimeOutOfRange: boolean;
    /** Input type (string): Error message displayed when time is outside the allowed range */
    rangeErrorMessage: string;
    /**
     * Handle hour input change from template (on every keystroke)
     * Updates both the FormControl and ngModel property without triggering validation
     * Validation occurs only on blur to allow complete input
     * @param event - The input value from the hour field
     */
    onHrTimeChange(event: any): void;
    /**
     * Handle hour input blur event
     * Triggers validation and time update only when user leaves the field
     * This approach prevents premature validation during typing (e.g., typing "09" won't validate after "0")
     */
    onHrBlur(): void;
    /**
     * Handle minute input change from template (on every keystroke)
     * Updates both the FormControl and ngModel property without triggering validation
     * Validation occurs only on blur to allow complete input
     * @param event - The input value from the minute field
     */
    onMinTimeChange(event: any): void;
    /**
     * Handle minute input blur event
     * Triggers validation and time update only when user leaves the field
     * This approach prevents premature validation during typing (e.g., typing "09" won't validate after "0")
     */
    onMinBlur(): void;
    /**
     * Handle period (AM/PM) change from template
     * Updates the period FormControl and immediately triggers time validation and update
     * Period changes are validated immediately (not on blur) since they come from button toggles
     * @param event - The MatButtonToggleChange event containing the selected period value
     */
    onPeriodChange(event: any): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<CGITimepickerBrandComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<CGITimepickerBrandComponent, "cgi-timepicker-brand", never, { "setDateTime": { "alias": "setDateTime"; "required": false; }; "errorMessage": { "alias": "errorMessage"; "required": false; }; "required": { "alias": "required"; "required": false; }; "disabled": { "alias": "disabled"; "required": false; }; "readonly": { "alias": "readonly"; "required": false; }; "appearance": { "alias": "appearance"; "required": false; }; "minHour": { "alias": "minHour"; "required": false; }; "maxHour": { "alias": "maxHour"; "required": false; }; "hourLabel": { "alias": "hourLabel"; "required": false; }; "minuteLabel": { "alias": "minuteLabel"; "required": false; }; "hourPlaceholder": { "alias": "hourPlaceholder"; "required": false; }; "minutePlaceholder": { "alias": "minutePlaceholder"; "required": false; }; "amLabel": { "alias": "amLabel"; "required": false; }; "pmLabel": { "alias": "pmLabel"; "required": false; }; "minTime": { "alias": "minTime"; "required": false; }; "maxTime": { "alias": "maxTime"; "required": false; }; "defaultHour": { "alias": "defaultHour"; "required": false; }; "defaultMinute": { "alias": "defaultMinute"; "required": false; }; "defaultPeriod": { "alias": "defaultPeriod"; "required": false; }; }, { "timeSelected": "timeSelected"; "hourChanged": "hourChanged"; "minuteChanged": "minuteChanged"; "periodChanged": "periodChanged"; }, never, never, false, never>;
}

declare class CGITimepickerBrandModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<CGITimepickerBrandModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<CGITimepickerBrandModule, [typeof CGITimepickerBrandComponent], [typeof i2.CommonModule, typeof i6.MatAutocompleteModule, typeof i4$3.MatButtonToggleModule, typeof i5$2.MatFormFieldModule, typeof i5$1.FormsModule, typeof i5$3.MatInputModule, typeof i5$1.ReactiveFormsModule], [typeof CGITimepickerBrandComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<CGITimepickerBrandModule>;
}

/**
 * Footer Container component.
 *
 */
declare class CGIFooterContainerBrandComponent implements OnDestroy, OnInit, OnChanges {
    private cgiNavContainer;
    private document;
    private breakpointObserver;
    /** value for toggling the footer */
    toggle: any;
    /** footer container css selector */
    private cgiFooter;
    /** reference to small screen */
    private navBarScreenObservable$;
    /** constructor for DI */
    constructor(cgiNavContainer: CGINavContainerService, document: any, breakpointObserver: BreakpointObserver);
    /** subscribes to sidenav value and screen size for footer flexibility  */
    ngOnInit(): void;
    /** toggles the footer */
    ngOnChanges(): void;
    /** cleaning up observables */
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<CGIFooterContainerBrandComponent, [{ optional: true; }, null, null]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<CGIFooterContainerBrandComponent, "cgi-footer-container", never, { "toggle": { "alias": "toggle"; "required": false; }; }, {}, never, ["*"], false, never>;
}

declare class CGIFooterBrandModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<CGIFooterBrandModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<CGIFooterBrandModule, [typeof CGIFooterContainerBrandComponent], [typeof i2.CommonModule, typeof i3.MatIconModule, typeof i4.MatButtonModule, typeof i5$1.ReactiveFormsModule], [typeof CGIFooterContainerBrandComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<CGIFooterBrandModule>;
}

/**
 *  Headstone Component
 */
declare class CGIHeadstoneBrandComponent implements OnInit {
    /** HostBinding for CSS */
    isClassContainer: boolean;
    /** Constructor */
    constructor();
    /** Life cycle hook for when the component is first initiated. */
    ngOnInit(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<CGIHeadstoneBrandComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<CGIHeadstoneBrandComponent, "cgi-headstone", never, {}, {}, never, ["*", "cgi-headstone-accordion"], false, never>;
}

/**
 * Headstone Item Component
 */
declare class CGIHeadstoneItemBrandComponent implements OnInit {
    /** HostBinding for CSS */
    class: string;
    /** Input: variable for tooltip message */
    toolTip: string;
    /** constructor */
    constructor();
    /** Life cycle hook for when the component is first initiated. */
    ngOnInit(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<CGIHeadstoneItemBrandComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<CGIHeadstoneItemBrandComponent, "cgi-headstone-item", never, { "toolTip": { "alias": "toolTip"; "required": false; }; }, {}, never, ["label", "*", ".cgi-headstone-item__footer"], false, never>;
}

/**
 * Headstone Accordion component.
 */
declare class CGIHeadstoneAccordionBrandComponent implements OnInit {
    /** HostBinding for CSS */
    isClassContainer: boolean;
    /** Boolean to toggle Accordion expansion */
    accordionExpanded: boolean;
    /** Component Constructor */
    constructor();
    /** Life cycle hook for when the component is first initiated. */
    ngOnInit(): void;
    /** Toggle Accordion expansion */
    toggle(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<CGIHeadstoneAccordionBrandComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<CGIHeadstoneAccordionBrandComponent, "cgi-headstone-accordion", never, { "accordionExpanded": { "alias": "accordionExpanded"; "required": false; }; }, {}, never, [".cgi-headstone-accordion__header", "*"], false, never>;
}

declare class CGIHeadstoneBrandModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<CGIHeadstoneBrandModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<CGIHeadstoneBrandModule, [typeof CGIHeadstoneBrandComponent, typeof CGIHeadstoneItemBrandComponent, typeof CGIHeadstoneAccordionBrandComponent], [typeof i2.CommonModule, typeof i4.MatButtonModule, typeof i9.MatCardModule, typeof i7$4.MatDividerModule, typeof i7$1.MatExpansionModule, typeof i9$1.MatTooltipModule], [typeof CGIHeadstoneBrandComponent, typeof CGIHeadstoneItemBrandComponent, typeof CGIHeadstoneAccordionBrandComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<CGIHeadstoneBrandModule>;
}

/** set of properties related to the selection model */
interface SelectionBrandSet {
    /** variable indicating total number of selected checkboxes */
    totalSelected: number;
    /** variable indicating the last selected checkboxes' index */
    lastSelected: number;
    /** variable for storing selection Models */
    selection: SelectionModel<any>;
}

declare class CGIMultiSelectCheckboxesBrandComponent implements AfterViewInit, OnInit {
    table: MatTable<any>;
    private cdRef;
    /**
     * Boolean variable to set the container class="cgi-multi-select"
     */
    isClassContainer: boolean;
    /** ViewChild for defining columns on a MatTable */
    columnDef: MatColumnDef;
    /** selection from parent table */
    selection: SelectionModel<any>;
    /** set of properties related to the selection model */
    selectionSet: SelectionBrandSet;
    /** sorted data used to define parent table */
    dataSourceSorted: any[];
    /** Event Emitter to emit the modified selection set back to the parent component */
    updatedSelectionSet: EventEmitter<SelectionBrandSet>;
    /** Aria labels in HTML */
    checkboxLabel: string;
    /** flag to keep track of whether the shift key is being held down - defaulted to false */
    shiftKeyHeldDown: boolean;
    constructor(table: MatTable<any>, cdRef: ChangeDetectorRef);
    ngAfterViewInit(): void;
    ngOnInit(): void;
    /** function: detects when a shift key is clicked - associated with (click) to allow multi select */
    shiftHandler(event: any): void;
    /** function: handles a click event for multi-select table - associated with (change) but occurs after (click) */
    clickHandler(row: any, index: any, checkboxClicked: any): void;
    /** function: checks the last data value selected on multi-select table */
    checkLastSelected(): void;
    /**  function: selects multiple rows at once on multi-select table */
    selectRows(index: any): void;
    /** function: checks if all values in multi-select table are selected */
    isAllSelected(): boolean;
    /** function: selects/deselects all values in multi-select table */
    masterToggle(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<CGIMultiSelectCheckboxesBrandComponent, [{ optional: true; }, null]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<CGIMultiSelectCheckboxesBrandComponent, "cgi-multi-select-checkboxes", never, { "selection": { "alias": "selection"; "required": false; }; "selectionSet": { "alias": "selectionSet"; "required": false; }; "dataSourceSorted": { "alias": "dataSourceSorted"; "required": false; }; }, { "updatedSelectionSet": "updatedSelectionSet"; }, never, never, false, never>;
}

declare class CGIMultiSelectHeaderBrandComponent implements OnInit {
    /**
   * HostBinding for CSS container class
   */
    isClassContainer: boolean;
    /** Counts how many table rows are selected in the parent table. */
    totalSelected: number;
    constructor();
    /**
     * Lifecycle hook called after data-bound properties initialization
     */
    ngOnInit(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<CGIMultiSelectHeaderBrandComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<CGIMultiSelectHeaderBrandComponent, "cgi-multi-select-header", never, { "totalSelected": { "alias": "totalSelected"; "required": false; }; }, {}, never, ["*"], false, never>;
}

declare class CGIMultiSelectBrandModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<CGIMultiSelectBrandModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<CGIMultiSelectBrandModule, [typeof CGIMultiSelectCheckboxesBrandComponent, typeof CGIMultiSelectHeaderBrandComponent], [typeof i2.CommonModule, typeof i9.MatCardModule, typeof i3.MatIconModule, typeof i4.MatButtonModule, typeof i7$5.MatTableModule, typeof i8.MatSortModule, typeof i9$2.MatCheckboxModule], [typeof CGIMultiSelectCheckboxesBrandComponent, typeof CGIMultiSelectHeaderBrandComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<CGIMultiSelectBrandModule>;
}

/**
 * Directive to define custom content for individual accordion panels.
 * Used with content projection to allow unique templates for each panel.
 *
 * @example
 * <cgi-accordion [panels]="panels">
 *   <ng-template cgiAccordionPanel="0" let-panel>
 *     <div class="custom-content">{{ panel.title }} - Custom Content for Panel 1</div>
 *   </ng-template>
 *   <ng-template cgiAccordionPanel="1" let-panel>
 *     <my-component [data]="panel"></my-component>
 *   </ng-template>
 * </cgi-accordion>
 */
declare class CgiAccordionPanelDirective {
    templateRef: TemplateRef<any>;
    /**
     * Panel index this template applies to.
     * Can be a number or 'all' to apply to all panels without specific templates.
     */
    panelIndex: number | string;
    constructor(templateRef: TemplateRef<any>);
    static ɵfac: i0.ɵɵFactoryDeclaration<CgiAccordionPanelDirective, never>;
    static ɵdir: i0.ɵɵDirectiveDeclaration<CgiAccordionPanelDirective, "[cgiAccordionPanel]", never, { "panelIndex": { "alias": "cgiAccordionPanel"; "required": false; }; }, {}, never, never, false, never>;
}
/**
 * Directive to define custom header for individual accordion panels.
 *
 * @example
 * <cgi-accordion [panels]="panels">
 *   <ng-template cgiAccordionHeader="0" let-panel let-i="index">
 *     <span class="badge">{{ i + 1 }}</span> {{ panel.title }}
 *   </ng-template>
 * </cgi-accordion>
 */
declare class CgiAccordionHeaderDirective {
    templateRef: TemplateRef<any>;
    /** Panel index this header template applies to */
    panelIndex: number | string;
    constructor(templateRef: TemplateRef<any>);
    static ɵfac: i0.ɵɵFactoryDeclaration<CgiAccordionHeaderDirective, never>;
    static ɵdir: i0.ɵɵDirectiveDeclaration<CgiAccordionHeaderDirective, "[cgiAccordionHeader]", never, { "panelIndex": { "alias": "cgiAccordionHeader"; "required": false; }; }, {}, never, never, false, never>;
}
/**
 * Directive to define custom icon for individual accordion panels.
 *
 * @example
 * <cgi-accordion [panels]="panels">
 *   <ng-template cgiAccordionIcon="0" let-expanded>
 *     <mat-icon>{{ expanded ? 'keyboard_arrow_up' : 'keyboard_arrow_down' }}</mat-icon>
 *   </ng-template>
 * </cgi-accordion>
 */
declare class CgiAccordionIconDirective {
    templateRef: TemplateRef<any>;
    /** Panel index this icon template applies to */
    panelIndex: number | string;
    constructor(templateRef: TemplateRef<any>);
    static ɵfac: i0.ɵɵFactoryDeclaration<CgiAccordionIconDirective, never>;
    static ɵdir: i0.ɵɵDirectiveDeclaration<CgiAccordionIconDirective, "[cgiAccordionIcon]", never, { "panelIndex": { "alias": "cgiAccordionIcon"; "required": false; }; }, {}, never, never, false, never>;
}

/**
 * Accordion panel data interface
 */
interface AccordionPanel {
    /** Panel header title */
    title: string;
    /** Panel body content text */
    content: string;
    /** Optional list items to display under content */
    items?: string[];
    /** Optional: disable this specific panel */
    disabled?: boolean;
}
/**
 * @description Reusable accordion component that supports single/multiple expanded panels
 * with optional table of contents sidebar for anchor scroll navigation.
 *
 * @example
 * // Simple accordion with single panel expanded
 * <cgi-accordion
 *   [step]="step"
 *   [panels]="defaultPanels"
 *   [expandedIndex]="0">
 * </cgi-accordion>
 *
 * // Multiple expanded panels
 * <cgi-accordion
 *   [isOpen]="isOpen"
 *   [panels]="defaultPanels"
 *   [allowMultiple]="true">
 * </cgi-accordion>
 *
 * // With table of contents
 * <cgi-accordion
 *   [step]="step"
 *   [stepIndex]="4"
 *   [panels]="anchorPanels"
 *   [showTableOfContents]="true">
 * </cgi-accordion>
 *
 * // With per-panel content projection
 * <cgi-accordion [panels]="panels">
 *   <ng-template cgiAccordionPanel="0" let-panel>
 *     <custom-component [data]="panel"></custom-component>
 *   </ng-template>
 *   <ng-template cgiAccordionPanel="1" let-panel>
 *     <another-component></another-component>
 *   </ng-template>
 *   <ng-template cgiAccordionHeader="all" let-panel let-i="index">
 *     <span class="badge">{{ i + 1 }}</span> {{ panel.title }}
 *   </ng-template>
 * </cgi-accordion>
 */
declare class CGIAccordionComponent implements OnInit, OnChanges {
    private cdr;
    /** Array to track the current step state of accordions (which panel is open) */
    step: any[];
    /** Array to track open/closed state of accordions for multiple mode (1 = open, 0 = closed) */
    isOpen: any[];
    /** Array of accordion panel configurations */
    panels: AccordionPanel[];
    /** Allow multiple panels to be open simultaneously */
    allowMultiple: boolean;
    /** Index of the initially expanded panel (single-selection mode) */
    expandedIndex: number;
    /** Enable table of contents sidebar for anchor scroll navigation */
    showTableOfContents: boolean;
    /** Step index for tracking state in anchor scroll mode */
    stepIndex: number;
    expandedPanels: number[];
    expandIcon: string;
    collapseIcon: string;
    /** Legacy: Single header template for all panels */
    headerTemplate: TemplateRef<any>;
    /** Legacy: Single content template for all panels */
    contentTemplate: TemplateRef<any>;
    /** Legacy: Single icon template for all panels */
    iconTemplate: TemplateRef<any>;
    /** Collection of per-panel content templates */
    panelTemplates: QueryList<CgiAccordionPanelDirective>;
    /** Collection of per-panel header templates */
    headerTemplates: QueryList<CgiAccordionHeaderDirective>;
    /** Collection of per-panel icon templates */
    iconTemplates: QueryList<CgiAccordionIconDirective>;
    showIcons: boolean;
    headerClass: string;
    panelClass: string;
    /** Emits panel index when a panel is opened (without TOC mode) */
    panelOpened: EventEmitter<number>;
    /** Emits panel index when a panel is closed (without TOC mode) */
    panelClosed: EventEmitter<number>;
    /** Emits step change info (with TOC mode) */
    stepChanged: EventEmitter<{
        index: number;
        panel: any;
    }>;
    /** Internal tracking for expanded panel index (single mode without TOC) */
    private _expandedIndex;
    /** Internal tracking for expanded panels (multiple mode without TOC) */
    private _expandedPanels;
    constructor(cdr: ChangeDetectorRef);
    /**
     * Angular lifecycle hook - called after component initialization
     * Initializes state arrays based on the mode (TOC vs non-TOC)
     */
    ngOnInit(): void;
    /**
     * Angular lifecycle hook - called when input properties change
     * Re-initializes state when relevant inputs change
     */
    ngOnChanges(changes: SimpleChanges): void;
    /**
     * Initialize state arrays based on mode
     *
     * MODE 1: With TOC (showTableOfContents = true)
     *   - Uses step[stepIndex] for tracking single expanded panel
     *   - Initialized with -1 (all collapsed)
     *
     * MODE 2: Without TOC (showTableOfContents = false)
     *   - Single mode (allowMultiple = false): uses _expandedIndex
     *   - Multiple mode (allowMultiple = true): uses _expandedPanels Set and isOpen[]
     *
     * @private
     */
    private initializeState;
    /**
     * Toggle a single accordion panel (single-selection mode)
     * Closing one panel when opening another
     *
     * @param panelIndex - Index of the panel to toggle
     * @param arrayIndex - Index in the step array to modify
     */
    setStep(panelIndex: number, arrayIndex: number): void;
    /**
     * Toggle a panel's open/closed state (multiple-selection mode)
     * Allows multiple panels to be open simultaneously
     *
     * @param panelIndex - Index of the panel to toggle
     */
    setStepData(panelIndex: number): void;
    /**
     * Determine if a panel should be expanded based on current mode
     *
     * WITHOUT TOC MODE:
     *   - Single mode: checks if index matches _expandedIndex
     *   - Multiple mode: checks if index is in _expandedPanels Set
     *
     * @param index - Panel index
     * @returns true if panel should be expanded
     */
    isPanelExpanded(index: number): boolean;
    /**
     * Get the icon name for a panel header
     *
     * WITHOUT TOC MODE:
     *   - Returns collapseIcon if panel is expanded
     *   - Returns expandIcon if panel is collapsed
     *
     * @param index - Panel index
     * @returns Icon name string (e.g., 'remove' or 'add')
     */
    getIcon(index: number): string;
    /**
     * Handler for panel opened event (WITHOUT TOC MODE)
     * Updates internal state and triggers change detection
     *
     * @param index - Index of the opened panel
     */
    onPanelOpened(index: number): void;
    /**
     * Handler for panel closed event (WITHOUT TOC MODE)
     * Updates internal state and triggers change detection
     *
     * @param index - Index of the closed panel
     */
    onPanelClosed(index: number): void;
    /**
     * Get the content template for a specific panel.
     * Priority: panel-specific template > 'all' template > legacy contentTemplate > null
     *
     * @param index - Panel index
     * @returns TemplateRef or null if using default content
     */
    getPanelContentTemplate(index: number): TemplateRef<any> | null;
    /**
     * Get the header template for a specific panel.
     * Priority: panel-specific template > 'all' template > legacy headerTemplate > null
     *
     * @param index - Panel index
     * @returns TemplateRef or null if using default header
     */
    getPanelHeaderTemplate(index: number): TemplateRef<any> | null;
    /**
     * Get the icon template for a specific panel.
     * Priority: panel-specific template > 'all' template > legacy iconTemplate > null
     *
     * @param index - Panel index
     * @returns TemplateRef or null if using default icon
     */
    getPanelIconTemplate(index: number): TemplateRef<any> | null;
    static ɵfac: i0.ɵɵFactoryDeclaration<CGIAccordionComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<CGIAccordionComponent, "cgi-accordion", never, { "step": { "alias": "step"; "required": false; }; "isOpen": { "alias": "isOpen"; "required": false; }; "panels": { "alias": "panels"; "required": false; }; "allowMultiple": { "alias": "allowMultiple"; "required": false; }; "expandedIndex": { "alias": "expandedIndex"; "required": false; }; "showTableOfContents": { "alias": "showTableOfContents"; "required": false; }; "stepIndex": { "alias": "stepIndex"; "required": false; }; "expandedPanels": { "alias": "expandedPanels"; "required": false; }; "expandIcon": { "alias": "expandIcon"; "required": false; }; "collapseIcon": { "alias": "collapseIcon"; "required": false; }; "showIcons": { "alias": "showIcons"; "required": false; }; "headerClass": { "alias": "headerClass"; "required": false; }; "panelClass": { "alias": "panelClass"; "required": false; }; }, { "panelOpened": "panelOpened"; "panelClosed": "panelClosed"; "stepChanged": "stepChanged"; }, ["headerTemplate", "contentTemplate", "iconTemplate", "panelTemplates", "headerTemplates", "iconTemplates"], never, false, never>;
}

/**
 * Module that provides the CGIAccordionComponent and its dependencies.
 *
 * Also exports directives for per-panel template projection:
 * - CgiAccordionPanelDirective: Custom content for individual panels
 * - CgiAccordionHeaderDirective: Custom header for individual panels
 * - CgiAccordionIconDirective: Custom icon for individual panels
 *
 * @example
 * // Basic usage
 * <cgi-accordion [panels]="panels"></cgi-accordion>
 *
 * // With per-panel content projection
 * <cgi-accordion [panels]="panels">
 *   <ng-template cgiAccordionPanel="0" let-panel>
 *     <custom-component [data]="panel"></custom-component>
 *   </ng-template>
 *   <ng-template cgiAccordionPanel="1" let-panel>
 *     <other-component></other-component>
 *   </ng-template>
 * </cgi-accordion>
 */
declare class CGIAccordionModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<CGIAccordionModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<CGIAccordionModule, [typeof CGIAccordionComponent, typeof CgiAccordionPanelDirective, typeof CgiAccordionHeaderDirective, typeof CgiAccordionIconDirective], [typeof i2.CommonModule, typeof i7$1.MatExpansionModule, typeof i3.MatIconModule], [typeof CGIAccordionComponent, typeof CgiAccordionPanelDirective, typeof CgiAccordionHeaderDirective, typeof CgiAccordionIconDirective]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<CGIAccordionModule>;
}

/**
 * Numeric counter input component with increment/decrement controls.
 *
 * Implements Angular's ControlValueAccessor to integrate with reactive forms.
 * Supports min/max boundaries, step size, layout direction, and appearance customization.
 */
declare class CgiCounterComponent implements OnInit, ControlValueAccessor {
    /** Current numeric value of the counter */
    _value: number;
    /** Maximum allowed value for the counter */
    max: number;
    /** Minimum allowed value for the counter */
    min: number;
    /** Amount to increase/decrease the value per click */
    step: number;
    /** Layout orientation of the controls ('horizontal' | 'vertical') */
    direction: string;
    /** Whether to use outlined style for buttons/field */
    outlined: boolean;
    /** Show the value as an editable input field */
    inputCounter: boolean;
    /** Icon style for increment/decrement buttons (e.g., 'chevron') */
    iconType: string;
    /** Angular Material form-field appearance */
    appearance: MatFormFieldAppearance;
    /** Placeholder text when showing the input field */
    placeholder: string;
    /** Label for the counter input */
    label: string;
    /** Emits the new value whenever it changes */
    change: EventEmitter<number>;
    /** Function assigned by Angular forms to propagate value changes */
    propagateChange: (_: any) => void;
    /**
     * Current value accessor
     * @returns The current numeric value
     */
    get value(): number;
    /**
     * Updates the current value and notifies listeners
     * @param val New value to set
     */
    set value(val: number);
    /** Lifecycle hook called after component initialization */
    ngOnInit(): void;
    /** Increments the value by the configured step */
    increment(): void;
    /** Decrements the value by the configured step */
    decrement(): void;
    /**
     * Writes a value from the external form control into the component
     * @param obj Value provided by Angular forms
     */
    writeValue(obj: any): void;
    /**
     * Registers a change handler with Angular forms
     * @param fn Function to call when value changes
     */
    registerOnChange(fn: any): void;
    /** Registers a touched handler (not used) */
    registerOnTouched(fn: any): void;
    /** Sets the disabled state of the component (not used) */
    setDisabledState(isDisabled: boolean): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<CgiCounterComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<CgiCounterComponent, "cgi-counter", never, { "_value": { "alias": "_value"; "required": false; }; "max": { "alias": "max"; "required": false; }; "min": { "alias": "min"; "required": false; }; "step": { "alias": "step"; "required": false; }; "direction": { "alias": "direction"; "required": false; }; "outlined": { "alias": "outlined"; "required": false; }; "inputCounter": { "alias": "inputCounter"; "required": false; }; "iconType": { "alias": "iconType"; "required": false; }; "appearance": { "alias": "appearance"; "required": false; }; "placeholder": { "alias": "placeholder"; "required": false; }; "label": { "alias": "label"; "required": false; }; }, { "change": "change"; }, never, never, false, never>;
}

declare class CGICounterModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<CGICounterModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<CGICounterModule, [typeof CgiCounterComponent], [typeof i2.CommonModule, typeof i3.MatIconModule, typeof i4.MatButtonModule, typeof i3.MatIconModule, typeof i5$3.MatInputModule, typeof i5$1.FormsModule], [typeof CgiCounterComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<CGICounterModule>;
}

declare class CgiLogoComponent {
    /** Logo variant to display */
    logoType: 'original' | 'black';
    /** Optional header text displayed next to the logo */
    header: string | undefined;
    /** Optional subheader text displayed below the header */
    subHeader: string | undefined;
    static ɵfac: i0.ɵɵFactoryDeclaration<CgiLogoComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<CgiLogoComponent, "cgi-logo", never, { "logoType": { "alias": "logoType"; "required": false; }; "header": { "alias": "header"; "required": false; }; "subHeader": { "alias": "subHeader"; "required": false; }; }, {}, never, never, false, never>;
}

declare class CGILogoModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<CGILogoModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<CGILogoModule, [typeof CgiLogoComponent], [typeof i2.CommonModule], [typeof CgiLogoComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<CGILogoModule>;
}

/** @class for explorer list item */
declare class ExplorerListItem {
    /** unique code for item */
    code: string;
    /** name of item */
    name: string;
    /** type of item */
    type: string;
    /** style classes */
    classes: string;
    /** codes of children */
    childCodeList: string[];
    /** codes of parents */
    parentCode: string;
}

/**
 * Interface representing the configuration for an explorer list.
 */
interface ExplorerListConfig {
    /** Display title of the list */
    listTitle: string;
    /** Internal name or identifier of the list */
    listName: string;
    /** Property name representing the item's code in the list */
    listItemCode: string;
    /** Property name representing the item's name in the list */
    listItemName: string;
    /** Type of item in the list (e.g., 'folder', 'file', 'record') */
    listItemType: string;
    /** Type of options enabled for the list (e.g., 'single', 'multiple') */
    enabledOptionType: string;
    /** Optional list of properties used for filtering items */
    filterByProperties?: string[];
}

/**
 * Model representing a label/value pair for the explorer details panel.
 */
declare class ExplorerListDetails {
    /** Display label for the detail entry */
    label: string;
    /** Display value for the detail entry */
    value: string;
}

/**
 * Container component orchestrating multiple explorer list segments.
 *
 * Manages cascaded selections across segments, filters subsequent segments
 * based on parent-child relationships, and exposes a details view with an
 * optional action trigger.
 */
declare class CGIExplorerListContainerComponent implements OnInit {
    /**
   * HostBinding for CSS container class
   */
    isClassContainer: boolean;
    /**
      * Input array of explorer list items
      */
    listData: ExplorerListItem[][];
    /**
     * Input array of explorer list configuration
     */
    listConfigData: ExplorerListConfig[];
    /**
   * Input object for selections state
   */
    selections: any;
    /**
    * Input array of explorer list details
    */
    infoData: ExplorerListDetails[];
    /**
   * Input for test data identifier
   */
    dataTestId: string;
    /**
   * Event emitter for selection changes
   */
    onSelectionChange: EventEmitter<any>;
    /**
   * Event emitter for details actions
   */
    onDetailsAction: EventEmitter<any>;
    /**
   * Reference to scroll container element
   */
    scrollRef: ElementRef<HTMLDivElement>;
    /** Current list of selected items per segment */
    selected: any[];
    /** Most recently updated selection and its segment index */
    currentSelection: any;
    /** Details data currently shown in the info panel */
    viewData: ExplorerListDetails[];
    /** Whether the info action is enabled and visible */
    infoAction: boolean;
    /** Working copy of the segment data after filtering */
    segmentData: ExplorerListItem[][];
    /** Original unfiltered segment data snapshot */
    segmentDataOriginal: ExplorerListItem[][];
    /** Initialize default values */
    ngOnInit(): void;
    /**
     * Update details view when inputs change
     * @param changes Object containing changed input values
     */
    ngOnChanges(changes: SimpleChanges): void;
    /**
     * Computes initial selection for each segment
     * @param data Two-dimensional array of segment items
     * @returns Array of initially selected items per segment
     */
    initialSelected(data: ExplorerListItem[][]): any[];
    /**
     * Handles updates when a new item is selected in a segment
     * @param data Selected item (or fallback)
     * @param index Segment index where selection occurred
     * @emits onSelectionChange Emits updated selection array
     */
    getSelectedEvent(data: any, index: number): void;
    /**
     * Updates the selection array based on the current pick and segment layout
     * @param data The item selected
     * @param index Segment index where selection occurred
     * @param segmentData Working segment data after filters
     * @param currentSelection Previous selection array
     * @returns New selection array
     */
    setListSelection(data: any, index: number, segmentData: any[], currentSelection: any[]): any[];
    /**
     * Walks back through previous segments to align selections with parent-child relationships
     * @param selections Current selection array
     * @param data Current selected item
     * @param index Current segment index
     * @param segmentData Working segment data
     * @returns Updated selections or void
     */
    updatePreviousSegmentData(selections: any[], data: ExplorerListItem, index: number, segmentData: any[]): any[] | void;
    /**
     * Filters a segment to only items with the given parent code
     * @param filterCode Parent code to match
     * @param segmentData Segment items to filter
     * @returns Filtered items for the segment
     */
    filterCurrentSegmentData(filterCode: string, segmentData: ExplorerListItem[]): ExplorerListItem[];
    /**
     * Filters next segment(s) to items whose codes are included in the provided list
     * @param filterCodeList List of codes to include
     * @param data Segment items to filter
     * @returns Filtered items for the next segment(s)
     */
    filteredNextSegmentData(filterCodeList: string[], data: ExplorerListItem[]): ExplorerListItem[];
    /**
     * Indicates if the segment should show an 'All' selection option
     * @param index Segment index
     * @returns True if not the last segment and children exist
     */
    isSelectAll(index: number): boolean;
    /** Emits the current selection for details action consumers */
    triggerDetailsAction(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<CGIExplorerListContainerComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<CGIExplorerListContainerComponent, "cgi-explorer-list-container", never, { "listData": { "alias": "listData"; "required": false; }; "listConfigData": { "alias": "listConfigData"; "required": false; }; "selections": { "alias": "selections"; "required": false; }; "infoData": { "alias": "infoData"; "required": false; }; "dataTestId": { "alias": "dataTestId"; "required": false; }; }, { "onSelectionChange": "onSelectionChange"; "onDetailsAction": "onDetailsAction"; }, never, never, false, never>;
}

declare class CGIExplorerListComponent implements OnInit, OnChanges {
    /** Applies the container CSS class to the host element */
    isClassContainer: boolean;
    /** Full list of items to display */
    list: ExplorerListItem[];
    explorerListConfig: ExplorerListConfig;
    /** Disables interactions when true */
    disabled: boolean;
    /** Currently selected item (or null) */
    selected: ExplorerListItem | null;
    /** Enables the synthetic 'All' selection option */
    isAllOptionEnabled: boolean;
    /** Emits when selection changes */
    selectionChange: EventEmitter<ExplorerListItem>;
    /** Current search string used for filtering */
    searchInput: string;
    /** Items after applying the current filter */
    filteredItems: ExplorerListItem[];
    /** Internal selected item reference */
    selectedItem: ExplorerListItem | any;
    /** initialize component */
    ngOnInit(): void;
    /**
     * Reacts to changes in the search term or the item list
     * @param changes Object containing changed input values
     */
    ngOnChanges(changes: SimpleChanges): void;
    /**
     * Applies the search filter to the list based on configured properties
     */
    applyFilter(): void;
    /**
     * Handles user selection of a specific item
     * @param item The item selected by the user
     * @emits selectionChange Emits the selected item
     */
    handleSelection(item: ExplorerListItem): void;
    /**
     * Selects the synthetic 'All' option and clears the search term
     * @emits selectionChange Emits a synthetic item representing 'All'
     */
    handleSelectAll(): void;
    /**
     * Determines if a given item is currently selected
     * @param item Item to test
     * @returns True if the item matches the current selection
     */
    isSelected(item: ExplorerListItem): boolean;
    /**
     * Indicates if the current selection is the synthetic 'All' option
     * @returns True if 'All' is selected
     */
    isAllSelected(): boolean;
    /**
     * Checks if an item is enabled based on the configured type filter
     * @param item Item to evaluate
     * @returns True if the item type matches the required type or no filter is set
     */
    isOptionEnabledByType(item: ExplorerListItem): boolean;
    static ɵfac: i0.ɵɵFactoryDeclaration<CGIExplorerListComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<CGIExplorerListComponent, "cgi-explorer-list", never, { "list": { "alias": "list"; "required": false; }; "explorerListConfig": { "alias": "explorerListConfig"; "required": false; }; "disabled": { "alias": "disabled"; "required": false; }; "selected": { "alias": "selected"; "required": false; }; "isAllOptionEnabled": { "alias": "isAllOptionEnabled"; "required": false; }; }, { "selectionChange": "selectionChange"; }, never, never, false, never>;
}

/**
 * Displays the details panel for an explorer list selection.
 *
 * Renders a list of detail items and optionally shows an action button
 * that emits selected detail data to the parent component.
 */
declare class CGIExplorerListDetailsComponent implements OnInit, OnChanges {
    /** Applies the container CSS class to the host element */
    isClassContainer: boolean;
    /** List of detail items to render */
    list: ExplorerListDetails[];
    /** Text label for the action button */
    actionText: string;
    /** Controls visibility of the action button */
    isAction: boolean;
    /** Emits the current detail items when an action is triggered */
    action: EventEmitter<ExplorerListDetails[]>;
    /** Internal flag mirroring `isAction` to show/hide the action button */
    isActionVisible: boolean;
    /** Local copy of the detail list used for rendering and emission */
    viewData: ExplorerListDetails[];
    /** initialize component */
    ngOnInit(): void;
    /**
     * Reacts to changes in inputs and updates internal state
     * @param changes Object containing changed input values
     */
    ngOnChanges(changes: SimpleChanges): void;
    /**
     * Handles click on the action button
     * @emits action Emits the current `viewData` list
     */
    handleActionClick(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<CGIExplorerListDetailsComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<CGIExplorerListDetailsComponent, "cgi-explorer-list-details", never, { "list": { "alias": "list"; "required": false; }; "actionText": { "alias": "actionText"; "required": false; }; "isAction": { "alias": "isAction"; "required": false; }; }, { "action": "action"; }, never, never, false, never>;
}

declare class CGIExplorerListContainerBrandModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<CGIExplorerListContainerBrandModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<CGIExplorerListContainerBrandModule, [typeof CGIExplorerListComponent, typeof CGIExplorerListContainerComponent, typeof CGIExplorerListDetailsComponent], [typeof i2.CommonModule, typeof i5$2.MatFormFieldModule, typeof i16.MatListModule, typeof i5$1.FormsModule, typeof i5$3.MatInputModule, typeof i3.MatIconModule, typeof i5$1.ReactiveFormsModule, typeof i4.MatButtonModule], [typeof CGIExplorerListComponent, typeof CGIExplorerListContainerComponent, typeof CGIExplorerListDetailsComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<CGIExplorerListContainerBrandModule>;
}

/**
 * Configuration interface for a drawer section
 * @interface DrawerSection
 */
interface DrawerSection {
    label: string;
    key: string;
    type: 'checkbox' | 'select' | 'date' | 'range' | 'custom';
    options?: string[];
    range?: {
        min: number;
        max: number;
        step?: number;
        unit?: string;
    };
    customTemplate?: TemplateRef<any>;
}

/** Column type definition for dynamic column rendering */
type DatatableColumnType = 'text' | 'number' | 'date' | 'icon' | 'action';
/** Interface for column definition */
interface DatatableColumnDefinition {
    /** Unique key for the column (matches data property) */
    key: string;
    /** Display label for column header */
    header: string;
    /** Type of column for rendering. Defaults to 'text' */
    type?: DatatableColumnType;
    /** Whether the column is sortable. Defaults to true */
    sortable?: boolean;
    /** CSS class for header cell */
    headerClass?: string;
    /** CSS class for data cell */
    cellClass?: string;
    /** Icon name for icon type columns */
    iconName?: string;
    /** Number format for number type columns (e.g., '1.2-2') */
    numberFormat?: string;
    /** Date format for date type columns (e.g., 'MMM d, y') */
    dateFormat?: string;
    /** Property name in row data that contains DatatableActionMenuItem[] (for action type columns) */
    actionsProperty?: string;
}
/** Interface for datatable action menu items */
interface DatatableActionMenuItem {
    /** Label for the menu item */
    label: string;
    /** Icon name (material icons) */
    icon: string;
    /** Action identifier */
    action: string;
}
/**
 * CGI Datatable - A unified data table with integrated filter drawer, search, sorting, and pagination.
 * Combines filtering (standard/accordion modes), text search, column sorting, pagination, and action menus.
 *
 * @selector cgi-datatable
 */
declare class CGIDatatableComponent implements OnInit, OnChanges, OnDestroy, AfterViewInit {
    private fb;
    /** Subscription for form value changes */
    private formValueChangesSub;
    /** Whether the component has completed initial setup */
    private initialized;
    /** Column definitions for dynamic column rendering with type support */
    columnDefinitions: DatatableColumnDefinition[];
    /**
     * Table columns to display (simple mode).
     * @deprecated Use columnDefinitions instead for full type/sort/action support
     */
    displayedColumns: {
        header: string;
        key: string;
    }[];
    /** Table column mapping for mat-table. Auto-generated from columnDefinitions if not provided. */
    columnMapping: string[];
    /** Data to be filtered */
    data: any[];
    /** Action menu items for action columns */
    actionMenuItems: DatatableActionMenuItem[];
    /** Search text for filtering */
    searchText: string;
    /** Search input placeholder */
    searchPlaceholder: string;
    /** Property names to include in text search filtering */
    searchFields: string[];
    /** Whether sorting is enabled on columns */
    enableSort: boolean;
    /** Whether pagination is enabled */
    enablePagination: boolean;
    /** Page size options for paginator */
    pageSizeOptions: number[];
    /** Default page size */
    pageSize: number;
    /** Table header title */
    tableTitle: string;
    /** Controls drawer visibility */
    open: boolean;
    /** Title displayed in drawer header */
    title: string;
    /** Array of filter configurations */
    filters: DrawerSection[];
    /** Active filter values to initialize the form with */
    activeFilters: any;
    /** Display mode for filters */
    filterMode: 'standard' | 'accordion';
    /** Placeholder for accordion search input */
    accordionSearchPlaceholder: string;
    /** Label for Apply button */
    applyButtonLabel: string;
    /** Filter count label */
    filterCountLabel: string;
    /** Clear all filters label */
    clearAllFiltersLabel: string;
    /** Filters button label */
    filtersButtonLabel: string;
    /** Market value range label */
    marketValueRangeLabel: string;
    /** Emits when the Filters button is clicked */
    openDrawer: EventEmitter<void>;
    /** Emits filtered data after filters/search applied */
    filteredData: EventEmitter<any[]>;
    /** Event emitted when action menu item is clicked */
    actionClicked: EventEmitter<{
        action: string;
        row: any;
    }>;
    /** Emits when filter values change */
    filtersChanged: EventEmitter<any>;
    /** Emits when all filters are cleared */
    clearAllFilters: EventEmitter<void>;
    /** Emits when filters are applied */
    onApply: EventEmitter<void>;
    /** Emits when drawer is closed */
    drawerClosed: EventEmitter<void>;
    /** Emits when filter count changes */
    countChange: EventEmitter<number>;
    /** MatTableDataSource for sorting and pagination integration */
    dataSource: MatTableDataSource<any>;
    /** Internal computed column keys for mat-table */
    _columnKeys: string[];
    /** Internal resolved column definitions */
    _resolvedColumns: DatatableColumnDefinition[];
    /** Form group for managing filter controls */
    filterForm: FormGroup;
    /** Controls visibility of selected filters */
    viewSelected: boolean;
    /** Search term for filtering accordions */
    accordionSearch: string;
    /** Cached applied filter count */
    appliedFilterCount: number;
    /** Cached filtered accordions list */
    _cachedFilteredAccordions: DrawerSection[];
    marketValueMin: number;
    marketValueMax: number;
    marketValueStep: number;
    marketValueTickCount: number;
    marketValueMaxLabel: number;
    sort: MatSort;
    paginator: MatPaginator;
    constructor(fb: FormBuilder);
    ngOnInit(): void;
    ngAfterViewInit(): void;
    ngOnChanges(changes: SimpleChanges): void;
    ngOnDestroy(): void;
    private resolveColumns;
    getColumnDef(key: string): DatatableColumnDefinition | undefined;
    getActionsForRow(colDef: DatatableColumnDefinition, row: any): DatatableActionMenuItem[];
    onActionClick(action: string, row: any): void;
    initializeForm(): void;
    clearFilters(): void;
    private updateFilteredData;
    applyFilters(): void;
    onSearchKeyup(): void;
    getFilteredData(): any[];
    getAppliedFilterCount(): number;
    private calculateAppliedFilterCount;
    getFilteredAccordions(): DrawerSection[];
    updateFilteredAccordions(): void;
    private calculateFilteredAccordions;
    trackByKey(index: number, item: {
        key: string;
    }): string;
    trackByOption(index: number, item: string): string;
    trackByAction(index: number, item: DatatableActionMenuItem): string;
    trackByColumn(index: number, item: DatatableColumnDefinition): string;
    onCheckboxChange(key: string, option: string, isChecked: boolean): void;
    getMarketValueDisplay(sliderValue: number): string;
    private getMarketValueConfig;
    static ɵfac: i0.ɵɵFactoryDeclaration<CGIDatatableComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<CGIDatatableComponent, "cgi-datatable", never, { "columnDefinitions": { "alias": "columnDefinitions"; "required": false; }; "displayedColumns": { "alias": "displayedColumns"; "required": false; }; "columnMapping": { "alias": "columnMapping"; "required": false; }; "data": { "alias": "data"; "required": false; }; "actionMenuItems": { "alias": "actionMenuItems"; "required": false; }; "searchText": { "alias": "searchText"; "required": false; }; "searchPlaceholder": { "alias": "searchPlaceholder"; "required": false; }; "searchFields": { "alias": "searchFields"; "required": false; }; "enableSort": { "alias": "enableSort"; "required": false; }; "enablePagination": { "alias": "enablePagination"; "required": false; }; "pageSizeOptions": { "alias": "pageSizeOptions"; "required": false; }; "pageSize": { "alias": "pageSize"; "required": false; }; "tableTitle": { "alias": "tableTitle"; "required": false; }; "open": { "alias": "open"; "required": false; }; "title": { "alias": "title"; "required": false; }; "filters": { "alias": "filters"; "required": false; }; "activeFilters": { "alias": "activeFilters"; "required": false; }; "filterMode": { "alias": "filterMode"; "required": false; }; "accordionSearchPlaceholder": { "alias": "accordionSearchPlaceholder"; "required": false; }; "applyButtonLabel": { "alias": "applyButtonLabel"; "required": false; }; "filterCountLabel": { "alias": "filterCountLabel"; "required": false; }; "clearAllFiltersLabel": { "alias": "clearAllFiltersLabel"; "required": false; }; "filtersButtonLabel": { "alias": "filtersButtonLabel"; "required": false; }; "marketValueRangeLabel": { "alias": "marketValueRangeLabel"; "required": false; }; }, { "openDrawer": "openDrawer"; "filteredData": "filteredData"; "actionClicked": "actionClicked"; "filtersChanged": "filtersChanged"; "clearAllFilters": "clearAllFilters"; "onApply": "onApply"; "drawerClosed": "drawerClosed"; "countChange": "countChange"; }, never, never, false, never>;
}

declare class CgiDatatableModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<CgiDatatableModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<CgiDatatableModule, [typeof CGIDatatableComponent], [typeof i2.CommonModule, typeof i5$1.FormsModule, typeof i5$1.ReactiveFormsModule, typeof i4$4.MatSidenavModule, typeof i5$4.MatSlideToggleModule, typeof i4.MatButtonModule, typeof i3.MatIconModule, typeof i5$3.MatInputModule, typeof i9$2.MatCheckboxModule, typeof i10$2.MatSliderModule, typeof i11.MatDatepickerModule, typeof i12.MatRadioModule, typeof i7$1.MatExpansionModule, typeof i7$2.MatSelectModule, typeof i15.MatOptionModule, typeof i7$4.MatDividerModule, typeof i7.MatMenuModule, typeof i7$5.MatTableModule, typeof i8.MatSortModule, typeof i20.MatPaginatorModule, typeof i5.MatBadgeModule], [typeof CGIDatatableComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<CgiDatatableModule>;
}

/**
 *  Chip Autocomplete Example Component
 */
declare class CGIChipAutocompleteComponent {
    /** Angular input element */
    chipInput: ElementRef<HTMLInputElement>;
    /** Angular autocomplete element  */
    matAutocomplete: MatAutocomplete;
    /** Gets list of all selectable chips */
    allChips: string[];
    /** Gets list of selected chips. Predefined chips should be elements of allChips. */
    selectedChips: string[];
    /** Whether or not the chip is selectable */
    selectable: boolean;
    /** Whether or not the chip is removable */
    removable: boolean;
    /** List of chips filtered by form input value and selectedChips[] */
    filteredChips: string[];
    /** The list of key codes that will trigger a chipEnd event */
    separatorKeysCodes: number[];
    /** Used for accessing properties of the form */
    formCtrl: UntypedFormControl;
    /** Constructor for Chip Autocomplete component */
    constructor();
    /** Event called when all selected chips are cleared */
    clearall(): void;
    /** Event called when a chip is removed */
    remove(chip: string): void;
    /** Event called when a chip is selected from the list */
    selected(event: MatAutocompleteSelectedEvent): void;
    /** Custom filter used to filter chips based on current input and selected chips */
    private _filter;
    /** Applies the filter when valueChanged event occurs in formCtrl */
    private applyFilter;
    static ɵfac: i0.ɵɵFactoryDeclaration<CGIChipAutocompleteComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<CGIChipAutocompleteComponent, "cgi-chip-autocomplete", never, { "allChips": { "alias": "allChips"; "required": false; }; "selectedChips": { "alias": "selectedChips"; "required": false; }; "selectable": { "alias": "selectable"; "required": false; }; "removable": { "alias": "removable"; "required": false; }; }, {}, never, [".clearall"], false, never>;
}

declare class CGIChipAutocompleteModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<CGIChipAutocompleteModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<CGIChipAutocompleteModule, [typeof CGIChipAutocompleteComponent], [typeof i2.CommonModule, typeof i5$2.MatFormFieldModule, typeof i4$5.MatChipsModule, typeof i6.MatAutocompleteModule, typeof i9$2.MatCheckboxModule, typeof i5$1.ReactiveFormsModule, typeof i3.MatIconModule], [typeof CGIChipAutocompleteComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<CGIChipAutocompleteModule>;
}

/**
 * Container component that wraps Angular Material steppers.
 *
 * Applies a standard CSS class to provide consistent CGI branding and styling
 * for stepper components. This component is used internally by the CgiStepperComponent.
 *
 * @example
 * ```html
 * <cgi-stepper-container>
 *   <mat-horizontal-stepper>
 *     <!-- stepper content -->
 *   </mat-horizontal-stepper>
 * </cgi-stepper-container>
 * ```
 */
declare class CgiStepperContainerComponent {
    /**
     * Automatically applies the 'cgi-stepper-container' CSS class to the host element.
     * This enables consistent styling across all stepper instances.
     */
    isClassContainer: boolean;
    static ɵfac: i0.ɵɵFactoryDeclaration<CgiStepperContainerComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<CgiStepperContainerComponent, "cgi-stepper-container", never, {}, {}, never, ["*"], false, never>;
}

/**
 * Interface defining a step configuration
 */
interface StepConfig {
    /** Title displayed in the step header */
    title: string;
    /** Optional subtitle/info displayed below the title (for label-bottom position) */
    subtitle?: string;
    /** Content to display in the step body */
    content?: string;
    /** Whether the step is editable */
    editable?: boolean;
}
/**
 * CGI Stepper Component
 *
 * A reusable stepper component that wraps Angular Material stepper with CGI branding.
 * Supports horizontal and vertical orientations, configurable label positions,
 * and linear/non-linear navigation modes.
 *
 * @example
 * ```html
 * <cgi-stepper
 *   [steps]="stepConfigs"
 *   [orientation]="'horizontal'"
 *   [labelPosition]="'end'"
 *   [linear]="false"
 *   [selectedIndex]="2"
 *   (stepChange)="onStepChange($event)">
 * </cgi-stepper>
 * ```
 */
declare class CgiStepperComponent implements AfterViewInit {
    /**
     * Array of step configurations
     */
    steps: StepConfig[];
    /**
     * Orientation of the stepper: 'horizontal' or 'vertical'
     */
    orientation: 'horizontal' | 'vertical';
    /**
     * Position of step labels: 'end' (side) or 'bottom'
     * Only applies to horizontal steppers
     */
    labelPosition: 'bottom' | 'end';
    /**
     * Whether the stepper requires completing steps in order
     */
    linear: boolean;
    /**
     * Whether to show step content area
     */
    showContent: boolean;
    /**
     * Whether to show navigation buttons (Back, Cancel, Next)
     */
    showNavigation: boolean;
    /**
     * Initial selected step index (0-based)
     */
    selectedIndex: number;
    /**
     * Optional ID for the stepper element
     */
    stepperId: string;
    /**
     * Whether to show label before icon (title first, then icon).
     * Only applies to horizontal steppers with labelPosition 'end'.
     */
    labelFirst: boolean;
    /**
     * Label for the back button
     */
    backLabel: string;
    /**
     * Label for the cancel button
     */
    cancelLabel: string;
    /**
     * Label for the next button
     */
    nextLabel: string;
    /**
     * Label for the reset button (shown on last step)
     */
    resetLabel: string;
    /**
     * Event emitted when the step changes
     */
    stepChange: EventEmitter<number>;
    /**
     * Event emitted when cancel button is clicked
     */
    cancelClick: EventEmitter<void>;
    /**
     * Event emitted when the stepper is reset
     */
    resetClick: EventEmitter<void>;
    /**
     * Reference to the horizontal stepper
     */
    horizontalStepper?: MatStepper;
    /**
     * Reference to the vertical stepper
     */
    verticalStepper?: MatStepper;
    /**
     * Gets the active stepper reference based on orientation
     */
    get activeStepper(): MatStepper | undefined;
    /**
     * Sets the initial selected index after view initialization.
     * Navigates through each step sequentially to properly mark previous steps as completed.
     */
    ngAfterViewInit(): void;
    /**
     * Resets the stepper to the first step
     */
    reset(): void;
    /**
     * Handles step selection change
     * @param index - The index of the selected step
     */
    onStepChange(index: number): void;
    /**
     * Handles cancel button click
     */
    onCancel(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<CgiStepperComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<CgiStepperComponent, "cgi-stepper", never, { "steps": { "alias": "steps"; "required": false; }; "orientation": { "alias": "orientation"; "required": false; }; "labelPosition": { "alias": "labelPosition"; "required": false; }; "linear": { "alias": "linear"; "required": false; }; "showContent": { "alias": "showContent"; "required": false; }; "showNavigation": { "alias": "showNavigation"; "required": false; }; "selectedIndex": { "alias": "selectedIndex"; "required": false; }; "stepperId": { "alias": "stepperId"; "required": false; }; "labelFirst": { "alias": "labelFirst"; "required": false; }; "backLabel": { "alias": "backLabel"; "required": false; }; "cancelLabel": { "alias": "cancelLabel"; "required": false; }; "nextLabel": { "alias": "nextLabel"; "required": false; }; "resetLabel": { "alias": "resetLabel"; "required": false; }; }, { "stepChange": "stepChange"; "cancelClick": "cancelClick"; "resetClick": "resetClick"; }, never, never, false, never>;
}

/**
 * Module for CGI Stepper components.
 *
 * Provides reusable stepper components with CGI branding for displaying
 * progress through multi-step processes.
 *
 * @example
 * ```typescript
 * import { CGISteppersModule } from '@cgi/sentry-angular-components-lib';
 *
 * @NgModule({
 *   imports: [CGISteppersModule]
 * })
 * export class AppModule { }
 * ```
 */
declare class CGISteppersModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<CGISteppersModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<CGISteppersModule, [typeof CgiStepperContainerComponent, typeof CgiStepperComponent], [typeof i2.CommonModule, typeof i4$6.MatStepperModule, typeof i4.MatButtonModule, typeof i3.MatIconModule], [typeof CgiStepperContainerComponent, typeof CgiStepperComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<CGISteppersModule>;
}

/**
 * Snackbar component.
 *
 * Displays brief notification messages at the bottom of the screen.
 * Supports single-line or multi-line text with optional action buttons.
 */
declare class CgiSnackbarComponent {
    private snackBarRef;
    /** Text message to display in the snackbar */
    text: string;
    /** Label text for the action button */
    buttonText: string;
    /** Controls visibility of action buttons */
    showActions: boolean;
    constructor(data: any, snackBarRef: MatSnackBarRef<CgiSnackbarComponent>);
    /** Dismisses the snackbar when action button is clicked */
    dismissSnackbar(): void;
    /** Determines if text is likely single-line based on character count (approximately 50 characters fit in a single line) */
    get isSingleLine(): boolean;
    static ɵfac: i0.ɵɵFactoryDeclaration<CgiSnackbarComponent, [{ optional: true; }, { optional: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<CgiSnackbarComponent, "cgi-snackbar", never, { "text": { "alias": "text"; "required": false; }; "buttonText": { "alias": "buttonText"; "required": false; }; "showActions": { "alias": "showActions"; "required": false; }; }, {}, never, never, false, never>;
}

declare class CGISnackbarBrandModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<CGISnackbarBrandModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<CGISnackbarBrandModule, [typeof CgiSnackbarComponent], [typeof i2.CommonModule, typeof i4.MatButtonModule], [typeof CgiSnackbarComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<CGISnackbarBrandModule>;
}

export { CGIAccordionComponent, CGIAccordionModule, CGIAlertBrandComponent, CGIAlertBrandDirective, CGIAlertComponent, CGIAlertContainerBrandComponent, CGIAlertContainerBrandModule, CGIAlertContainerComponent, CGIAlertContainerModule, CGIAlertDirective, CGIAnchorScrollBrandComponent, CGIAnchorScrollComponent, CGIAnchorScrollContainerBrandComponent, CGIAnchorScrollContainerBrandModule, CGIAnchorScrollContainerComponent, CGIAnchorScrollContainerModule, CGIBreadcrumbItemBrandComponent, CGIBreadcrumbItemComponent, CGIBreadcrumbsBrandComponent, CGIBreadcrumbsBrandModule, CGIBreadcrumbsComponent, CGIBreadcrumbsModule, CGIChipAutocompleteComponent, CGIChipAutocompleteModule, CGIClickOutsideBrandDirective, CGIClickOutsideDirective, CGICounterModule, CGIDatatableComponent, CGIExplorerListComponent, CGIExplorerListContainerBrandModule, CGIExplorerListContainerComponent, CGIExplorerListDetailsComponent, CGIFooterBrandModule, CGIFooterContainerBrandComponent, CGIFooterContainerComponent, CGIFooterModule, CGIGlobalSearchBrandModule, CGIGlobalSearchModule, CGIHeadstoneAccordionBrandComponent, CGIHeadstoneAccordionComponent, CGIHeadstoneBrandComponent, CGIHeadstoneBrandModule, CGIHeadstoneComponent, CGIHeadstoneItemBrandComponent, CGIHeadstoneItemComponent, CGIHeadstoneModule, CGILogoModule, CGIMultiSelectBrandModule, CGIMultiSelectCheckboxesBrandComponent, CGIMultiSelectCheckboxesComponent, CGIMultiSelectHeaderBrandComponent, CGIMultiSelectHeaderComponent, CGIMultiSelectModule, CGINavContainerBrandComponent, CGINavContainerBrandModule, CGINavContainerComponent, CGINavContainerModule, CGINavContentBrandComponent, CGINavContentComponent, CGIPopoverBrandComponent, CGIPopoverBrandModule, CGIPopoverComponent, CGIPopoverContentBrandComponent, CGIPopoverContentComponent, CGIPopoverFooterBrandComponent, CGIPopoverFooterComponent, CGIPopoverHeaderBrandComponent, CGIPopoverHeaderComponent, CGIPopoverModule, CGISelectSearchBrandComponent, CGISelectSearchBrandModule, CGISelectSearchComponent, CGISelectSearchModule, CGISideNavBrandComponent, CGISideNavComponent, CGISideNavItemBrandComponent, CGISideNavItemComponent, CGISkeletonBrandComponent, CGISkeletonBrandModule, CGISkeletonComponent, CGISkeletonModule, CGISnackbarBrandModule, CGISteppersModule, CGITimelineBrandComponent, CGITimelineBrandModule, CGITimelineComponent, CGITimelineEntryAvatarBrandComponent, CGITimelineEntryAvatarComponent, CGITimelineEntryBodyBrandComponent, CGITimelineEntryBodyComponent, CGITimelineEntryBrandComponent, CGITimelineEntryComponent, CGITimelineEntryIconBrandComponent, CGITimelineEntryIconComponent, CGITimelineEntryTitleBrandComponent, CGITimelineEntryTitleComponent, CGITimelineModule, CGITimepickerBrandComponent, CGITimepickerBrandModule, CGITimepickerComponent, CGITimepickerModule, CGIToasterBrandComponent, CGIToasterBrandModule, CGIToasterComponent, CGIToasterModule, CGITopNavBrandComponent, CGITopNavBrandModule, CGITopNavComponent, CGITopNavItemBrandComponent, CGITopNavItemComponent, CGITopNavModule, CgiAccordionHeaderDirective, CgiAccordionIconDirective, CgiAccordionPanelDirective, CgiCounterComponent, CgiDatatableModule, CgiGlobalSearchBrandComponent, CgiGlobalSearchComponent, CgiLogoComponent, CgiSnackbarComponent, CgiStepperComponent, CgiStepperContainerComponent, GlobalSearchBrandCategory, GlobalSearchBrandEntity, GlobalSearchCategory, GlobalSearchEntity, GlobalSearchGroupBrandOptions, GlobalSearchGroupOptions, SideNavBrandItem, SideNavItem };
export type { CGISideNavMode, DatatableActionMenuItem, DatatableColumnDefinition, DatatableColumnType, SelectionBrandSet, SelectionSet, StepConfig };
