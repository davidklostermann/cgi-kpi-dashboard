import * as i1 from '@angular/common';
import { CommonModule, isPlatformBrowser } from '@angular/common';
import * as i0 from '@angular/core';
import { Directive, EventEmitter, ViewChild, Output, Input, Component, HostListener, HostBinding, NgModule, DOCUMENT, Inject, Injectable, ElementRef, Optional, ChangeDetectionStrategy, PLATFORM_ID, ContentChildren, ContentChild, forwardRef } from '@angular/core';
import * as i4 from '@angular/material/button';
import { MatButtonModule } from '@angular/material/button';
import * as i5 from '@angular/material/icon';
import { MatIconModule } from '@angular/material/icon';
import { trigger, state, transition, style, animate } from '@angular/animations';
import * as i2 from '@angular/router';
import { RouterModule, NavigationEnd } from '@angular/router';
import { map, filter, takeWhile, distinctUntilChanged, tap, startWith, debounceTime, takeUntil, take } from 'rxjs/operators';
import * as i1$1 from '@angular/cdk/layout';
import { Subject, BehaviorSubject, timer, of, fromEvent, merge, combineLatest, distinctUntilChanged as distinctUntilChanged$1, Subscription } from 'rxjs';
import * as i3 from '@angular/material/badge';
import { MatBadgeModule } from '@angular/material/badge';
import * as i4$1 from '@angular/material/menu';
import { MatMenuTrigger, MatMenuModule } from '@angular/material/menu';
import * as i2$1 from '@angular/material/toolbar';
import { MatToolbarModule } from '@angular/material/toolbar';
import * as i4$2 from '@angular/material/expansion';
import { MatExpansionModule } from '@angular/material/expansion';
import { coerceBooleanProperty, coerceNumberProperty } from '@angular/cdk/coercion';
import * as i1$2 from '@angular/forms';
import { FormsModule, ReactiveFormsModule, UntypedFormControl, NG_VALUE_ACCESSOR, FormGroup, FormControl } from '@angular/forms';
import * as i6 from '@angular/material/autocomplete';
import { MatAutocompleteTrigger, MatAutocompleteModule } from '@angular/material/autocomplete';
import { MatFormFieldModule } from '@angular/material/form-field';
import * as i4$3 from '@angular/material/input';
import { MatInputModule } from '@angular/material/input';
import * as i9 from '@angular/material/progress-spinner';
import { MatProgressSpinnerModule } from '@angular/material/progress-spinner';
import * as i8 from '@angular/material/select';
import { MatSelectModule, MatSelect } from '@angular/material/select';
import * as i3$1 from '@angular/cdk/overlay';
import { OverlayModule } from '@angular/cdk/overlay';
import * as i1$3 from '@angular/cdk/a11y';
import * as i1$4 from '@angular/material/snack-bar';
import { MAT_SNACK_BAR_DATA } from '@angular/material/snack-bar';
import * as i1$5 from '@angular/material/card';
import { MatCardModule } from '@angular/material/card';
import * as i4$4 from '@angular/material/button-toggle';
import { MatButtonToggleModule } from '@angular/material/button-toggle';
import * as i4$5 from '@angular/material/divider';
import { MatDividerModule } from '@angular/material/divider';
import * as i1$6 from '@angular/material/tooltip';
import { MatTooltipModule } from '@angular/material/tooltip';
import * as i2$2 from '@angular/material/checkbox';
import { MatCheckboxModule } from '@angular/material/checkbox';
import * as i1$7 from '@angular/material/table';
import { MatColumnDef, MatTableModule, MatTableDataSource } from '@angular/material/table';
import * as i16 from '@angular/material/sort';
import { MatSortModule, MatSort } from '@angular/material/sort';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import * as i2$3 from '@angular/platform-browser';
import * as i12 from '@angular/material/list';
import { MatListModule } from '@angular/material/list';
import * as i17 from '@angular/material/paginator';
import { MatPaginator, MatPaginatorModule } from '@angular/material/paginator';
import * as i3$2 from '@angular/material/sidenav';
import { MatSidenavModule } from '@angular/material/sidenav';
import * as i4$6 from '@angular/material/slide-toggle';
import { MatSlideToggleModule } from '@angular/material/slide-toggle';
import * as i10 from '@angular/material/slider';
import { MatSliderModule } from '@angular/material/slider';
import * as i11 from '@angular/material/datepicker';
import { MatDatepickerModule } from '@angular/material/datepicker';
import { MatRadioModule } from '@angular/material/radio';
import { MatOptionModule } from '@angular/material/core';
import { ENTER, COMMA } from '@angular/cdk/keycodes';
import * as i3$3 from '@angular/material/chips';
import { MatChipsModule } from '@angular/material/chips';
import * as i2$4 from '@angular/material/stepper';
import { MatStepperModule } from '@angular/material/stepper';

/**
 * Alert Directive.
 */
class CGIAlertDirective {
    /**
     * Constructor for Alert Directive
     * @param viewContainerRef container reference for alert container
     */
    constructor(viewContainerRef) {
        this.viewContainerRef = viewContainerRef;
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.2", ngImport: i0, type: CGIAlertDirective, deps: [{ token: i0.ViewContainerRef }], target: i0.ɵɵFactoryTarget.Directive }); }
    static { this.ɵdir = i0.ɵɵngDeclareDirective({ minVersion: "14.0.0", version: "20.3.2", type: CGIAlertDirective, isStandalone: false, selector: "[cgiAlertHost]", ngImport: i0 }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.2", ngImport: i0, type: CGIAlertDirective, decorators: [{
            type: Directive,
            args: [{
                    selector: '[cgiAlertHost]',
                    standalone: false
                }]
        }], ctorParameters: () => [{ type: i0.ViewContainerRef }] });

/**
 * Alert Container component.
 *
 * TODO: How to use component and examples.
 */
class CGIAlertContainerComponent {
    /**
     * Constructor for Alert Container Directive
     * @param componentFactoryResolver Factory Resolver for dynamic components
     */
    constructor(componentFactoryResolver) {
        this.componentFactoryResolver = componentFactoryResolver;
        /** Array to store alerts inputted from parent */
        this.alerts = [];
        /** Event Emitter to invoke parent when an action is preformed */
        this.action = new EventEmitter();
    }
    /**
     * Life cycle hook for when the component is first initiated and when there are changes to the component's input.
     */
    ngOnChanges() {
        this.cgiAlertHost.viewContainerRef.clear();
        this.getAlerts();
    }
    /** Load an alert into the container */
    loadAlert(alert) {
        const alertItem = alert;
        const componentFactory = this.componentFactoryResolver.resolveComponentFactory(alertItem.component);
        const viewContainerRef = this.cgiAlertHost.viewContainerRef;
        const componentRef = viewContainerRef.createComponent(componentFactory);
        componentRef.instance.data = alertItem.data;
        componentRef.instance.action.subscribe((e) => {
            this.removeAlert(alertItem);
        });
    }
    /** Remove an alert in the container */
    removeAlert(alertItem) {
        const alertIndex = this.alerts.indexOf(alertItem);
        if (alertIndex !== -1) {
            this.cgiAlertHost.viewContainerRef.remove(alertIndex);
            this.alerts.splice(alertIndex, 1);
            this.action.emit(alertItem);
        }
    }
    /** Get alerts being passed in from parent */
    getAlerts() {
        for (const alert of this.alerts) {
            this.loadAlert(alert);
        }
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.2", ngImport: i0, type: CGIAlertContainerComponent, deps: [{ token: i0.ComponentFactoryResolver }], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "20.3.2", type: CGIAlertContainerComponent, isStandalone: false, selector: "cgi-alert-container", inputs: { alerts: "alerts" }, outputs: { action: "action" }, viewQueries: [{ propertyName: "cgiAlertHost", first: true, predicate: CGIAlertDirective, descendants: true, static: true }], usesOnChanges: true, ngImport: i0, template: "<ng-template cgiAlertHost></ng-template>\n", dependencies: [{ kind: "directive", type: CGIAlertDirective, selector: "[cgiAlertHost]" }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.2", ngImport: i0, type: CGIAlertContainerComponent, decorators: [{
            type: Component,
            args: [{ selector: 'cgi-alert-container', standalone: false, template: "<ng-template cgiAlertHost></ng-template>\n" }]
        }], ctorParameters: () => [{ type: i0.ComponentFactoryResolver }], propDecorators: { alerts: [{
                type: Input
            }], action: [{
                type: Output
            }], cgiAlertHost: [{
                type: ViewChild,
                args: [CGIAlertDirective, { static: true }]
            }] } });

/**
 * Alert component.
 *
 * TODO: How to use component and examples.
 */
class CGIAlertComponent {
    /**
     * Constructor
     */
    constructor() {
        /** Event Emitter to emit custom events back to the parent component */
        this.action = new EventEmitter();
        /** Object to store input data from the parent component */
        this.data = {
            type: null,
            header: null,
            message: null,
            customAction: null,
        };
        /** Boolean for specifying if the alert has a header */
        this.hasHeader = false;
        /** Boolean for specifying if the alert emitted an animation */
        this.actionEmitted = false;
        this.isClassContainer = true;
        this.animationState = 'inactive';
    }
    /**
     * Life cycle hook for when the component is first initiated.
     */
    ngOnInit() {
        if (this.data.header != null) {
            this.hasHeader = true;
        }
        this.setType();
    }
    /** Method that sets the style and icon for the type of alert */
    setType() {
        if (this.data.type === 'warning') {
            this.isWarning = true;
            this.icon = 'fa-exclamation-circle';
        }
        else if (this.data.type === 'success') {
            this.isSuccess = true;
            this.icon = 'fa-check-circle';
        }
        else if (this.data.type === 'error') {
            this.isError = true;
            this.icon = 'fa-times-circle';
        }
        else {
            this.isInfo = true;
            this.icon = 'fa-info-circle';
        }
    }
    /** close method that will initiate the close animation */
    close() {
        this.animationState = 'active';
    }
    /** Listener for when the close animation has finished */
    animationDone() {
        if (this.animationState === 'active') {
            this.action.emit();
            this.actionEmitted = true;
        }
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.2", ngImport: i0, type: CGIAlertComponent, deps: [], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "20.3.2", type: CGIAlertComponent, isStandalone: false, selector: "cgi-alert", inputs: { data: "data" }, outputs: { action: "action" }, host: { listeners: { "@fadeOut.done": "animationDone()" }, properties: { "class.cgi-alert": "this.isClassContainer", "@fadeOut": "this.animationState", "class.cgi-alert-info": "this.isInfo", "class.cgi-alert-warning": "this.isWarning", "class.cgi-alert-success": "this.isSuccess", "class.cgi-alert-error": "this.isError" } }, ngImport: i0, template: "<div class=\"cgi-alert__content\">\n  <div class=\"cgi-alert__icon\">\n    <mat-icon class=\"mat-icon far {{ icon }}\" fontSet=\"far\" fontIcon=\"{{ icon }}\"></mat-icon>\n  </div>\n  <div>\n    <span class=\"cgi-alert__header\" *ngIf=\"hasHeader\">{{ data.header }}</span>\n    <div class=\"cgi-alert__message\" [innerHTML]=\"data.message\"></div>\n  </div>\n</div>\n<span class=\"cgi-alert__spacer\"></span>\n<button *ngIf=\"!data.customAction\" mat-icon-button (click)=\"close()\" aria-label=\"Close Alert\">\n  <mat-icon fontSet=\"fal\" fontIcon=\"fa-times\"></mat-icon>\n</button>\n<button\n  *ngIf=\"data.customAction\"\n  mat-button\n  (click)=\"close()\"\n  [attr.aria-label]=\"data.customAction\"\n>\n  {{ data.customAction }}\n</button>\n", styles: [":host(.cgi-alert){align-items:flex-start;display:flex;font-family:Roboto,Helvetica,Helvetica Neue,Arial,sans-serif;font-size:14px;font-weight:700;line-height:1.5em;margin:16px 0;padding:16px 14px 16px 20px}:host(.cgi-alert) .cgi-alert__content{display:flex}:host(.cgi-alert) .cgi-alert__content div:nth-of-type(2){width:100%}:host(.cgi-alert) .cgi-alert__icon{border-radius:50%;color:#fff;flex-shrink:0;height:25px;margin-right:20px;width:25px}:host(.cgi-alert) .cgi-alert__icon ::ng-deep mat-icon{align-items:center;display:flex;justify-content:center}:host(.cgi-alert) .cgi-alert__icon ::ng-deep mat-icon.fa-exclamation-circle{padding-top:1px}:host(.cgi-alert) .cgi-alert__header{align-items:center;display:flex;font-size:16px}:host(.cgi-alert) .cgi-alert__message{align-items:center;font-weight:400}:host(.cgi-alert) .cgi-alert__spacer{flex:1 1 auto}:host(.cgi-alert) .mat-mdc-icon-button{height:25px;line-height:25px;margin-left:10px;position:absolute;right:0;top:0;width:25px}:host(.cgi-alert) .mat-mdc-icon-button ::ng-deep mat-icon{color:#3c3f40;font-size:18px}\n"], dependencies: [{ kind: "directive", type: i1.NgIf, selector: "[ngIf]", inputs: ["ngIf", "ngIfThen", "ngIfElse"] }, { kind: "component", type: i5.MatIcon, selector: "mat-icon", inputs: ["color", "inline", "svgIcon", "fontSet", "fontIcon"], exportAs: ["matIcon"] }, { kind: "component", type: i4.MatButton, selector: "    button[matButton], a[matButton], button[mat-button], button[mat-raised-button],    button[mat-flat-button], button[mat-stroked-button], a[mat-button], a[mat-raised-button],    a[mat-flat-button], a[mat-stroked-button]  ", inputs: ["matButton"], exportAs: ["matButton", "matAnchor"] }, { kind: "component", type: i4.MatIconButton, selector: "button[mat-icon-button], a[mat-icon-button], button[matIconButton], a[matIconButton]", exportAs: ["matButton", "matAnchor"] }], animations: [
            trigger('fadeOut', [
                state('inactive', style({ transform: 'translateY(0)', opacity: 1 })),
                state('active', style({ transform: 'translateY(-100%)', opacity: 0 })),
                transition('inactive => active', [animate('600ms cubic-bezier(1, 0, 0, 1)')]),
            ]),
        ] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.2", ngImport: i0, type: CGIAlertComponent, decorators: [{
            type: Component,
            args: [{ selector: 'cgi-alert', animations: [
                        trigger('fadeOut', [
                            state('inactive', style({ transform: 'translateY(0)', opacity: 1 })),
                            state('active', style({ transform: 'translateY(-100%)', opacity: 0 })),
                            transition('inactive => active', [animate('600ms cubic-bezier(1, 0, 0, 1)')]),
                        ]),
                    ], standalone: false, template: "<div class=\"cgi-alert__content\">\n  <div class=\"cgi-alert__icon\">\n    <mat-icon class=\"mat-icon far {{ icon }}\" fontSet=\"far\" fontIcon=\"{{ icon }}\"></mat-icon>\n  </div>\n  <div>\n    <span class=\"cgi-alert__header\" *ngIf=\"hasHeader\">{{ data.header }}</span>\n    <div class=\"cgi-alert__message\" [innerHTML]=\"data.message\"></div>\n  </div>\n</div>\n<span class=\"cgi-alert__spacer\"></span>\n<button *ngIf=\"!data.customAction\" mat-icon-button (click)=\"close()\" aria-label=\"Close Alert\">\n  <mat-icon fontSet=\"fal\" fontIcon=\"fa-times\"></mat-icon>\n</button>\n<button\n  *ngIf=\"data.customAction\"\n  mat-button\n  (click)=\"close()\"\n  [attr.aria-label]=\"data.customAction\"\n>\n  {{ data.customAction }}\n</button>\n", styles: [":host(.cgi-alert){align-items:flex-start;display:flex;font-family:Roboto,Helvetica,Helvetica Neue,Arial,sans-serif;font-size:14px;font-weight:700;line-height:1.5em;margin:16px 0;padding:16px 14px 16px 20px}:host(.cgi-alert) .cgi-alert__content{display:flex}:host(.cgi-alert) .cgi-alert__content div:nth-of-type(2){width:100%}:host(.cgi-alert) .cgi-alert__icon{border-radius:50%;color:#fff;flex-shrink:0;height:25px;margin-right:20px;width:25px}:host(.cgi-alert) .cgi-alert__icon ::ng-deep mat-icon{align-items:center;display:flex;justify-content:center}:host(.cgi-alert) .cgi-alert__icon ::ng-deep mat-icon.fa-exclamation-circle{padding-top:1px}:host(.cgi-alert) .cgi-alert__header{align-items:center;display:flex;font-size:16px}:host(.cgi-alert) .cgi-alert__message{align-items:center;font-weight:400}:host(.cgi-alert) .cgi-alert__spacer{flex:1 1 auto}:host(.cgi-alert) .mat-mdc-icon-button{height:25px;line-height:25px;margin-left:10px;position:absolute;right:0;top:0;width:25px}:host(.cgi-alert) .mat-mdc-icon-button ::ng-deep mat-icon{color:#3c3f40;font-size:18px}\n"] }]
        }], ctorParameters: () => [], propDecorators: { isClassContainer: [{
                type: HostBinding,
                args: ['class.cgi-alert']
            }], animationState: [{
                type: HostBinding,
                args: ['@fadeOut']
            }], isInfo: [{
                type: HostBinding,
                args: ['class.cgi-alert-info']
            }], isWarning: [{
                type: HostBinding,
                args: ['class.cgi-alert-warning']
            }], isSuccess: [{
                type: HostBinding,
                args: ['class.cgi-alert-success']
            }], isError: [{
                type: HostBinding,
                args: ['class.cgi-alert-error']
            }], action: [{
                type: Output
            }], data: [{
                type: Input
            }], animationDone: [{
                type: HostListener,
                args: ['@fadeOut.done']
            }] } });

class CGIAlertContainerModule {
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.2", ngImport: i0, type: CGIAlertContainerModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule }); }
    static { this.ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "20.3.2", ngImport: i0, type: CGIAlertContainerModule, declarations: [CGIAlertContainerComponent, CGIAlertComponent, CGIAlertDirective], imports: [CommonModule, MatIconModule, MatButtonModule], exports: [CGIAlertContainerComponent, CGIAlertComponent, CGIAlertDirective] }); }
    static { this.ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "20.3.2", ngImport: i0, type: CGIAlertContainerModule, imports: [CommonModule, MatIconModule, MatButtonModule] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.2", ngImport: i0, type: CGIAlertContainerModule, decorators: [{
            type: NgModule,
            args: [{
                    imports: [CommonModule, MatIconModule, MatButtonModule],
                    declarations: [CGIAlertContainerComponent, CGIAlertComponent, CGIAlertDirective],
                    exports: [CGIAlertContainerComponent, CGIAlertComponent, CGIAlertDirective],
                }]
        }] });

/**
 * Anchor Scroll component.
 */
class CGIAnchorScrollComponent {
    /**
     * Constructor for Anchor Scroll Component
     * @param _element Native anchor scroll HTML Element
     * @param _document Application's HTML Document
     */
    constructor(_element, _document) {
        this._element = _element;
        this._document = _document;
        /** Array to the anchor links */
        this.links = [];
        /** Headers that will be selected as anchor scroll links */
        this.headerSelectors = '.cgi-header-anchor,.cgi-header-anchor-level-2,.cgi-header-anchor-level-3';
        /** Offset in pixels for links to trigger as active */
        this.linkOffset = 20;
        /** On destroy subject */
        this._destroyed = new Subject();
        /** Selected anchor link */
        this._selectedSection = '';
        /** Anchor links container class */
        this._linkContainer = '.cgi-anchor-scroll-container__links';
        /** Class name used to sticky the scroll container */
        this._stickyClass = 'cgi-anchor-scroll-container__links--sticky';
        /** When there is a scroll event */
        this.onScroll = () => {
            this.checkSticky();
            for (let i = 0; i < this.links.length; i++) {
                this.links[i].active = this.isLinkActive(this.links[i], this.links[i + 1]);
            }
        };
        /** When the browser changes size */
        this.adjustWidth = () => {
            const parentwidth = this._document.querySelector('.cgi-anchor-scroll-container__toc').clientWidth;
            if (this._document.querySelector('.' + this._stickyClass)) {
                this._document.querySelector('.' + this._stickyClass).style.width = parentwidth + 'px';
            }
        };
        this._navBar = this._document.querySelector('.cgi-top-nav');
    }
    /**
     * Life cycle hook for when the component is first initiated.
     */
    ngOnInit() { }
    /** Initialization block after view has been rendered */
    ngAfterViewInit() {
        // On init, the sidenav content element doesn't yet exist, so it's not possible
        // to subscribe to its scroll event until next tick (when it does exist).
        Promise.resolve().then(() => {
            this._scrollContainer = this.container
                ? this._document.querySelectorAll(this.container)[0]
                : window;
            window.addEventListener('scroll', this.onScroll, true);
            window.addEventListener('resize', this.adjustWidth, true);
            if (this._scrollContainer) {
                this.links = this.createLinks();
            }
        });
        this.updateScrollPosition();
    }
    /** When Component is destroyed remove event listeners */
    ngOnDestroy() {
        window.removeEventListener('scroll', this.onScroll, true);
        window.removeEventListener('resize', this.adjustWidth, true);
        this._destroyed.next(null);
    }
    /** When changes to inputs are detected */
    ngOnChanges() {
        if (this.errorCounts) {
            this.updateErrors();
        }
    }
    /** Update scroll position when selected link has changed */
    updateScrollPosition() {
        const target = this._document.getElementById(this._selectedSection);
        if (target) {
            target.scrollIntoView();
        }
    }
    /** When a link is selected change the selected link and update scroll position */
    goToSection(id) {
        this._selectedSection = id;
        this.updateScrollPosition();
    }
    /** Gets the scroll offset of the scroll container */
    getScrollOffset() {
        let height = 0;
        if (this._navBar) {
            const navBarBounds = this._navBar.getBoundingClientRect();
            height = navBarBounds.height;
        }
        if (typeof this._scrollContainer.scrollTop !== 'undefined') {
            return this._scrollContainer.scrollTop + height + this.linkOffset;
        }
        else if (typeof this._scrollContainer.pageYOffset !== 'undefined') {
            return this._scrollContainer.pageYOffset + height + this.linkOffset;
        }
    }
    /** Create the links based on the header selectors */
    createLinks() {
        const links = [];
        const parentElement = this._document.querySelector(this.parentClass);
        let headers;
        if (parentElement) {
            headers = parentElement.querySelectorAll(this.headerSelectors);
        }
        else {
            headers = this._document.querySelectorAll(this.headerSelectors);
        }
        if (headers.length) {
            for (const header of headers) {
                const name = header.innerText.trim().replace(/^link/, '');
                const classes = Array.from(header.classList);
                let linkType;
                for (const className of classes) {
                    if (className === 'cgi-header-anchor') {
                        linkType = 'cgi-header-anchor';
                    }
                    else if (className === 'cgi-header-anchor-level-2') {
                        linkType = 'cgi-header-anchor-level-2';
                    }
                    else {
                        linkType = 'cgi-header-anchor-level-3';
                    }
                }
                const { top } = header.getBoundingClientRect();
                const topBound = top;
                links.push({
                    name,
                    type: linkType,
                    top: topBound,
                    id: header.id,
                    active: false,
                    errorCount: 0,
                });
            }
        }
        return links;
    }
    /** Update error counts for each link */
    updateErrors() {
        for (const error of this.errorCounts) {
            const updateLink = this.links.find((i) => i.name === error.id);
            if (updateLink) {
                updateLink.errorCount = error.errors;
            }
        }
        this.links = this.links.slice();
    }
    /** Check to see if link is active or not */
    isLinkActive(currentLink, nextLink) {
        // A link is considered active if the page is scrolled passed the anchor without also
        // being scrolled passed the next link
        const scrollOffset = this.getScrollOffset();
        return (scrollOffset >= Math.floor(currentLink.top) &&
            !(nextLink && Math.floor(nextLink.top) <= scrollOffset));
    }
    /** Check to see if the component should be sticky or not */
    checkSticky() {
        // Anchor Scroll Container
        const container = this._document.querySelector('.cgi-anchor-scroll-container');
        // Anchor Scroll Container Boundaries
        const containerBounds = container.getBoundingClientRect();
        // Scroll Container Boundaries (Entire view)
        let scrollContainerBounds;
        if (typeof this._scrollContainer.pageYOffset !== 'undefined') {
            scrollContainerBounds = this._scrollContainer.document
                .querySelector('body')
                .getBoundingClientRect();
        }
        else {
            scrollContainerBounds = this._scrollContainer.getBoundingClientRect();
        }
        // Anchor Scroll Links Container
        const linksContainer = this._document.querySelector(this._linkContainer);
        // Anchor Scroll Links Content
        const contents = this._document.querySelector('.cgi-anchor-scroll-container__toc');
        // Anchor Scroll Links Boundaries
        const anchorLinkBounds = this._document
            .querySelector('.cgi-anchor-scroll-links')
            .getBoundingClientRect();
        if (Math.ceil(anchorLinkBounds.bottom) === Math.ceil(containerBounds.bottom) &&
            Math.ceil(anchorLinkBounds.top) >= Math.ceil(scrollContainerBounds.top)) {
            // Add Sticky Back
            this.addSticky(linksContainer, scrollContainerBounds);
        }
        else if (Math.ceil(anchorLinkBounds.bottom) >= Math.ceil(containerBounds.bottom)) {
            // Sticky To Bottom
            linksContainer.classList.remove(this._stickyClass);
            const top = Math.ceil(containerBounds.height) - Math.ceil(anchorLinkBounds.height) + 'px';
            contents.style.top = top;
            contents.style.marginTop = top;
        }
        else if (Math.ceil(scrollContainerBounds.top) >= Math.ceil(containerBounds.top)) {
            // Sticky To Top
            this.addSticky(linksContainer, scrollContainerBounds);
        }
        else {
            // Not Sticky
            contents.style.top = '0px';
            contents.style.marginTop = '0px';
            linksContainer.classList.remove(this._stickyClass);
        }
    }
    /** Make component sticky */
    addSticky(linksContainer, scrollContainerBounds) {
        linksContainer.classList.add(this._stickyClass);
        this._document.querySelector('.' + this._stickyClass).style.top =
            scrollContainerBounds.top + 'px';
        this.adjustWidth();
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.2", ngImport: i0, type: CGIAnchorScrollComponent, deps: [{ token: i0.ElementRef }, { token: DOCUMENT }], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "20.3.2", type: CGIAnchorScrollComponent, isStandalone: false, selector: "cgi-anchor-scroll", inputs: { container: "container", parentClass: "parentClass", linkOffset: "linkOffset", errorCounts: "errorCounts" }, usesOnChanges: true, ngImport: i0, template: "<div *ngIf=\"links?.length\" class=\"cgi-anchor-scroll-links\">\n  <nav>\n    <a\n      [routerLink]=\"\"\n      *ngFor=\"let link of links; let i = index\"\n      [matBadge]=\"link.errorCount\"\n      [matBadgeHidden]=\"link.errorCount === 0\"\n      (click)=\"goToSection(link.id)\"\n      class=\"cgi-link link-{{ link.type }}\"\n      [class.active]=\"link.active\"\n    >\n      {{ link.name }}\n    </a>\n  </nav>\n</div>\n", styles: [":host{box-sizing:border-box;display:inline-flex;font-size:13px;padding-left:25px}.cgi-anchor-scroll-links{padding:5px 0 10px 10px}.cgi-anchor-scroll-links a{display:block;font-size:14px;overflow:visible;padding:10px 0;position:relative;text-decoration:underline;text-overflow:ellipsis;width:auto}.cgi-anchor-scroll-links a.active{color:#3d4f68;font-weight:700;text-decoration:none}.link-cgi-header-anchor-level-2{margin-left:20px;width:calc(100% - 20px)}.link-cgi-header-anchor-level-3{margin-left:40px;width:calc(100% - 40px)}.mat-badge-content{background-color:#be2e31}.mat-badge-medium.mat-badge-overlap.mat-badge-after .mat-badge-content{top:-2px}\n"], dependencies: [{ kind: "directive", type: i1.NgForOf, selector: "[ngFor][ngForOf]", inputs: ["ngForOf", "ngForTrackBy", "ngForTemplate"] }, { kind: "directive", type: i1.NgIf, selector: "[ngIf]", inputs: ["ngIf", "ngIfThen", "ngIfElse"] }, { kind: "directive", type: i2.RouterLink, selector: "[routerLink]", inputs: ["target", "queryParams", "fragment", "queryParamsHandling", "state", "info", "relativeTo", "preserveFragment", "skipLocationChange", "replaceUrl", "routerLink"] }, { kind: "directive", type: i3.MatBadge, selector: "[matBadge]", inputs: ["matBadgeColor", "matBadgeOverlap", "matBadgeDisabled", "matBadgePosition", "matBadge", "matBadgeDescription", "matBadgeSize", "matBadgeHidden"] }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.2", ngImport: i0, type: CGIAnchorScrollComponent, decorators: [{
            type: Component,
            args: [{ selector: 'cgi-anchor-scroll', standalone: false, template: "<div *ngIf=\"links?.length\" class=\"cgi-anchor-scroll-links\">\n  <nav>\n    <a\n      [routerLink]=\"\"\n      *ngFor=\"let link of links; let i = index\"\n      [matBadge]=\"link.errorCount\"\n      [matBadgeHidden]=\"link.errorCount === 0\"\n      (click)=\"goToSection(link.id)\"\n      class=\"cgi-link link-{{ link.type }}\"\n      [class.active]=\"link.active\"\n    >\n      {{ link.name }}\n    </a>\n  </nav>\n</div>\n", styles: [":host{box-sizing:border-box;display:inline-flex;font-size:13px;padding-left:25px}.cgi-anchor-scroll-links{padding:5px 0 10px 10px}.cgi-anchor-scroll-links a{display:block;font-size:14px;overflow:visible;padding:10px 0;position:relative;text-decoration:underline;text-overflow:ellipsis;width:auto}.cgi-anchor-scroll-links a.active{color:#3d4f68;font-weight:700;text-decoration:none}.link-cgi-header-anchor-level-2{margin-left:20px;width:calc(100% - 20px)}.link-cgi-header-anchor-level-3{margin-left:40px;width:calc(100% - 40px)}.mat-badge-content{background-color:#be2e31}.mat-badge-medium.mat-badge-overlap.mat-badge-after .mat-badge-content{top:-2px}\n"] }]
        }], ctorParameters: () => [{ type: i0.ElementRef }, { type: undefined, decorators: [{
                    type: Inject,
                    args: [DOCUMENT]
                }] }], propDecorators: { container: [{
                type: Input
            }], parentClass: [{
                type: Input
            }], linkOffset: [{
                type: Input
            }], errorCounts: [{
                type: Input
            }] } });

/**
 * Anchor Scroll Container component.
 *
 * TODO: How to use component and examples.
 */
class CGIAnchorScrollContainerComponent {
    /**
     * Constructor for Anchor Scroll Component
     * @param breakpointObserver Breakpoint Observable for when to remove the anchor scroll component
     */
    constructor(breakpointObserver) {
        /** Class of parent element */
        this.parentClass = 'body';
        /** Offset in pixels for links to trigger as active */
        this.linkOffset = 20;
        this.showAnchor = breakpointObserver
            .observe('(max-width: 1200px)')
            .pipe(map((result) => !result.matches));
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.2", ngImport: i0, type: CGIAnchorScrollContainerComponent, deps: [{ token: i1$1.BreakpointObserver }], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "20.3.2", type: CGIAnchorScrollContainerComponent, isStandalone: false, selector: "cgi-anchor-scroll-container", inputs: { parentClass: "parentClass", linkOffset: "linkOffset", errorCounts: "errorCounts" }, viewQueries: [{ propertyName: "anchorScroll", first: true, predicate: ["anchor"], descendants: true }], ngImport: i0, template: "<div class=\"cgi-anchor-scroll-container\">\n  <div class=\"cgi-anchor-scroll-container__contents\"><ng-content></ng-content></div>\n  <div class=\"cgi-anchor-scroll-container__toc\" *ngIf=\"showAnchor | async\">\n    <div class=\"cgi-anchor-scroll-container__links\">\n      <cgi-anchor-scroll\n        #anchor\n        [errorCounts]=\"errorCounts\"\n        [parentClass]=\"parentClass\"\n        [linkOffset]=\"linkOffset\"\n        container=\".cgi-nav-content\"\n      ></cgi-anchor-scroll>\n    </div>\n  </div>\n</div>\n", styles: [".cgi-anchor-scroll-container{align-items:flex-start;display:flex}.cgi-anchor-scroll-container .cgi-anchor-scroll-container__contents{flex:1 0 75%;width:75%}@media (max-width: 1200){.cgi-anchor-scroll-container .cgi-anchor-scroll-container__contents{flex-direction:column}}.cgi-anchor-scroll-container .cgi-anchor-scroll-container__toc{width:25%}.cgi-anchor-scroll-container .cgi-anchor-scroll-container__links--sticky{position:fixed}cgi-anchor-scroll{top:35px}\n"], dependencies: [{ kind: "directive", type: i1.NgIf, selector: "[ngIf]", inputs: ["ngIf", "ngIfThen", "ngIfElse"] }, { kind: "component", type: CGIAnchorScrollComponent, selector: "cgi-anchor-scroll", inputs: ["container", "parentClass", "linkOffset", "errorCounts"] }, { kind: "pipe", type: i1.AsyncPipe, name: "async" }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.2", ngImport: i0, type: CGIAnchorScrollContainerComponent, decorators: [{
            type: Component,
            args: [{ selector: 'cgi-anchor-scroll-container', standalone: false, template: "<div class=\"cgi-anchor-scroll-container\">\n  <div class=\"cgi-anchor-scroll-container__contents\"><ng-content></ng-content></div>\n  <div class=\"cgi-anchor-scroll-container__toc\" *ngIf=\"showAnchor | async\">\n    <div class=\"cgi-anchor-scroll-container__links\">\n      <cgi-anchor-scroll\n        #anchor\n        [errorCounts]=\"errorCounts\"\n        [parentClass]=\"parentClass\"\n        [linkOffset]=\"linkOffset\"\n        container=\".cgi-nav-content\"\n      ></cgi-anchor-scroll>\n    </div>\n  </div>\n</div>\n", styles: [".cgi-anchor-scroll-container{align-items:flex-start;display:flex}.cgi-anchor-scroll-container .cgi-anchor-scroll-container__contents{flex:1 0 75%;width:75%}@media (max-width: 1200){.cgi-anchor-scroll-container .cgi-anchor-scroll-container__contents{flex-direction:column}}.cgi-anchor-scroll-container .cgi-anchor-scroll-container__toc{width:25%}.cgi-anchor-scroll-container .cgi-anchor-scroll-container__links--sticky{position:fixed}cgi-anchor-scroll{top:35px}\n"] }]
        }], ctorParameters: () => [{ type: i1$1.BreakpointObserver }], propDecorators: { parentClass: [{
                type: Input
            }], linkOffset: [{
                type: Input
            }], errorCounts: [{
                type: Input
            }], anchorScroll: [{
                type: ViewChild,
                args: ['anchor']
            }] } });

class CGIAnchorScrollContainerModule {
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.2", ngImport: i0, type: CGIAnchorScrollContainerModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule }); }
    static { this.ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "20.3.2", ngImport: i0, type: CGIAnchorScrollContainerModule, declarations: [CGIAnchorScrollContainerComponent, CGIAnchorScrollComponent], imports: [CommonModule, RouterModule, MatBadgeModule], exports: [CGIAnchorScrollContainerComponent, CGIAnchorScrollComponent] }); }
    static { this.ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "20.3.2", ngImport: i0, type: CGIAnchorScrollContainerModule, imports: [CommonModule, RouterModule, MatBadgeModule] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.2", ngImport: i0, type: CGIAnchorScrollContainerModule, decorators: [{
            type: NgModule,
            args: [{
                    imports: [CommonModule, RouterModule, MatBadgeModule],
                    declarations: [CGIAnchorScrollContainerComponent, CGIAnchorScrollComponent],
                    exports: [CGIAnchorScrollContainerComponent, CGIAnchorScrollComponent],
                }]
        }] });

/** Service to maintain one true source of whether navigation panel is opened. */
let CGINavContainerService$1 = class CGINavContainerService {
    constructor() {
        /** BehaviourSubject to emit default value of Observable on subscription. */
        this._navOpen = new BehaviorSubject(true);
        /** Convert to public Observable. */
        this.changes = this._navOpen.asObservable();
    }
    /**
     * Toggle value of whether panel is opened.
     * @param isOpen Override for what state the panel should be.
     */
    toggle(isOpen) {
        if (isOpen === undefined) {
            this._navOpen.next(!this._navOpen.getValue());
        }
        else {
            if (isOpen) {
                if (!this._navOpen.getValue()) {
                    this._navOpen.next(isOpen);
                }
            }
            else {
                if (this._navOpen.getValue()) {
                    this._navOpen.next(isOpen);
                }
            }
        }
    }
    /** Getter for private variable _navOpen. */
    getState() {
        return this._navOpen.getValue();
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.2", ngImport: i0, type: CGINavContainerService, deps: [], target: i0.ɵɵFactoryTarget.Injectable }); }
    static { this.ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "20.3.2", ngImport: i0, type: CGINavContainerService }); }
};
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.2", ngImport: i0, type: CGINavContainerService$1, decorators: [{
            type: Injectable
        }] });

/**
 * Navigation item component for the top nav bar.
 */
class CGITopNavItemComponent {
    /** Load for DOM manipulation. */
    constructor(navContainerService) {
        this.navContainerService = navContainerService;
        /** Boolean to toggle the icon */
        this.opened = true;
        this.isClassContainer = true;
    }
    /** Subscribe to service to listen for changes in opened state, used to change icon */
    ngOnInit() { }
    /** Getter for menuItem, used to set style class. */
    get isMenuItem() {
        return this._menuItem;
    }
    /** Getter for _showSearchIcon, used to set style class */
    get isSearchBarItem() {
        return this._showSearchIcon;
    }
    /** Toggle sidebar on click */
    toggleSidebar() {
        this.navContainerService.toggle();
        this.opened = !this.opened;
    }
    /** Setter for menuItem, attribute to be set on the cgi-nav-item element. */
    set menuItem(value) {
        this._menuItem = !value;
    }
    /** Setter for _showSearchIcon, attribute to be set on the cgi-top-nav-item element */
    set showSearchIcon(value) {
        this._showSearchIcon = !value;
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.2", ngImport: i0, type: CGITopNavItemComponent, deps: [{ token: CGINavContainerService$1 }], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "20.3.2", type: CGITopNavItemComponent, isStandalone: false, selector: "cgi-top-nav-item", inputs: { opened: "opened", menuItem: "menuItem", showSearchIcon: "showSearchIcon" }, host: { properties: { "class.cgi-top-nav__item": "this.isClassContainer", "class.cgi-top-nav__menu": "this.isMenuItem", "class.cgi-top-nav__search": "this.isSearchBarItem" } }, ngImport: i0, template: "<ng-content *ngIf=\"!_menuItem\"></ng-content>\n<button *ngIf=\"_menuItem\" aria-label=\"Menu\" mat-button (click)=\"toggleSidebar()\">\n  <mat-icon *ngIf=\"!opened\" fontSet=\"fal\" fontIcon=\"fa-bars\" class=\"menu-icon\"></mat-icon>\n  <mat-icon *ngIf=\"opened\" fontSet=\"fal\" fontIcon=\"fa-times\" class=\"menu-icon\"></mat-icon>\n</button>\n", styles: [":host(.cgi-top-nav__item){align-items:center;display:flex;height:64px;justify-content:center;min-width:4.4rem}:host(.cgi-top-nav__item) ::ng-deep button{color:#006f95}@media (max-width: 599px){:host(.cgi-top-nav__item){height:56px}}:host(.cgi-top-nav__menu) button{color:#000000de;line-height:64px;min-width:4.4rem}:host(.cgi-top-nav__menu) .menu-icon{font-size:24px}@media (max-width: 599px){:host(.cgi-top-nav__menu) button{line-height:56px}}@media (max-width: 959px){:host(.cgi-top-nav__search){margin-left:auto}}\n"], dependencies: [{ kind: "directive", type: i1.NgIf, selector: "[ngIf]", inputs: ["ngIf", "ngIfThen", "ngIfElse"] }, { kind: "component", type: i4.MatButton, selector: "    button[matButton], a[matButton], button[mat-button], button[mat-raised-button],    button[mat-flat-button], button[mat-stroked-button], a[mat-button], a[mat-raised-button],    a[mat-flat-button], a[mat-stroked-button]  ", inputs: ["matButton"], exportAs: ["matButton", "matAnchor"] }, { kind: "component", type: i5.MatIcon, selector: "mat-icon", inputs: ["color", "inline", "svgIcon", "fontSet", "fontIcon"], exportAs: ["matIcon"] }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.2", ngImport: i0, type: CGITopNavItemComponent, decorators: [{
            type: Component,
            args: [{ selector: 'cgi-top-nav-item', standalone: false, template: "<ng-content *ngIf=\"!_menuItem\"></ng-content>\n<button *ngIf=\"_menuItem\" aria-label=\"Menu\" mat-button (click)=\"toggleSidebar()\">\n  <mat-icon *ngIf=\"!opened\" fontSet=\"fal\" fontIcon=\"fa-bars\" class=\"menu-icon\"></mat-icon>\n  <mat-icon *ngIf=\"opened\" fontSet=\"fal\" fontIcon=\"fa-times\" class=\"menu-icon\"></mat-icon>\n</button>\n", styles: [":host(.cgi-top-nav__item){align-items:center;display:flex;height:64px;justify-content:center;min-width:4.4rem}:host(.cgi-top-nav__item) ::ng-deep button{color:#006f95}@media (max-width: 599px){:host(.cgi-top-nav__item){height:56px}}:host(.cgi-top-nav__menu) button{color:#000000de;line-height:64px;min-width:4.4rem}:host(.cgi-top-nav__menu) .menu-icon{font-size:24px}@media (max-width: 599px){:host(.cgi-top-nav__menu) button{line-height:56px}}@media (max-width: 959px){:host(.cgi-top-nav__search){margin-left:auto}}\n"] }]
        }], ctorParameters: () => [{ type: CGINavContainerService$1 }], propDecorators: { opened: [{
                type: Input
            }], isClassContainer: [{
                type: HostBinding,
                args: ['class.cgi-top-nav__item']
            }], isMenuItem: [{
                type: HostBinding,
                args: ['class.cgi-top-nav__menu']
            }], isSearchBarItem: [{
                type: HostBinding,
                args: ['class.cgi-top-nav__search']
            }], menuItem: [{
                type: Input
            }], showSearchIcon: [{
                type: Input
            }] } });

/**
 * General top navigation component.
 *
 * TODO: How to use component and examples.
 */
class CGITopNavComponent {
    /**
     * Empty constructor.
     */
    constructor(document) {
        /** The landmarks to be quickly focused to from the quick-nav dropdown */
        this.landmarks = [];
        /** Quick nav button text */
        this.quickSkipButtonText = 'Skip to:';
        /** Quick nav aria label */
        this.quickSkipAriaLabel = 'skip to landmark dropdown';
        /** Custom aria-label attribute for accessibility. */
        this.ariaLabel = 'Top navigation';
        this._document = document;
        this.isClassContainer = true;
        this.hideButton = true;
    }
    /**
     * Set the default landmarks
     */
    ngOnInit() {
        if (this.landmarks.length === 0) {
            this.landmarks = [
                {
                    label: 'Search',
                    id: "global-search-component" /* PageLandmarks.GLOBAL_SEARCH */,
                },
                {
                    label: 'Content',
                    id: "main-content" /* PageLandmarks.MAIN_CONTENT */,
                },
                {
                    label: 'Navigation',
                    id: "left-nav" /* PageLandmarks.LEFT_NAV */,
                },
            ];
        }
    }
    /** Go (focus) to the specified landmark */
    goToLandmark(landmark) {
        this.matMenu.closeMenu();
        switch (landmark.id) {
            case "global-search-component" /* PageLandmarks.GLOBAL_SEARCH */:
                let globalSearch = this._document.getElementById(landmark.id);
                let globalSearchInput = globalSearch.querySelector('input');
                globalSearchInput.focus();
                globalSearch = globalSearchInput = null;
                break;
            case "left-nav" /* PageLandmarks.LEFT_NAV */:
                let leftNav = this._document.getElementById(landmark.id);
                let firstLink = null;
                if (leftNav.children.length === 1) {
                    firstLink = leftNav.querySelector('a');
                }
                else {
                    firstLink = leftNav.querySelector('li a');
                }
                firstLink.focus();
                leftNav = firstLink = null;
                break;
            case "main-content" /* PageLandmarks.MAIN_CONTENT */:
                let firstFocusableContent = this._document
                    .querySelector('[role="main"]')
                    .querySelector('a, button, input, textarea, select, details, [tabindex]:not([tabindex="-1"])');
                if (firstFocusableContent) {
                    firstFocusableContent.focus();
                }
                firstFocusableContent = null;
                break;
        }
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.2", ngImport: i0, type: CGITopNavComponent, deps: [{ token: DOCUMENT }], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "20.3.2", type: CGITopNavComponent, isStandalone: false, selector: "cgi-top-nav", inputs: { landmarks: "landmarks", quickSkipButtonText: "quickSkipButtonText", quickSkipAriaLabel: "quickSkipAriaLabel", color: "color", ariaLabel: "ariaLabel" }, host: { properties: { "class.cgi-top-nav": "this.isClassContainer" } }, viewQueries: [{ propertyName: "matMenu", first: true, predicate: MatMenuTrigger, descendants: true }], ngImport: i0, template: "<nav attr.aria-label=\"{{ ariaLabel }}\" role=\"navigation\">\n  <mat-toolbar [color]=\"color\">\n    <button\n      id=\"quick-nav\"\n      (focusin)=\"hideButton = false\"\n      (focusout)=\"hideButton = true\"\n      [class.quick-nav--hide]=\"hideButton\"\n      color=\"primary\"\n      mat-flat-button\n      [matMenuTriggerFor]=\"quickNav\"\n      [attr.aria-label]=\"quickSkipAriaLabel\"\n    >\n      {{ quickSkipButtonText }}\n    </button>\n    <mat-menu #quickNav=\"matMenu\">\n      <button\n        *ngFor=\"let landmark of landmarks\"\n        [attr.id]=\"'skip-to-' + landmark.id\"\n        (click)=\"$event.stopPropagation(); goToLandmark(landmark)\"\n        mat-menu-item\n      >\n        {{ landmark.label }}\n      </button>\n    </mat-menu>\n    <ng-content select=\".cgi-top-nav--left\"></ng-content>\n    <ng-content select=\".cgi-top-nav--right\"></ng-content>\n  </mat-toolbar>\n  <!-- #2 -->\n</nav>\n", styles: [".cgi-vertical-spacer-1{height:2rem;width:100%}.cgi-vertical-spacer-2{height:4rem;width:100%}.cgi-vertical-spacer-3{height:6rem;width:100%}.cgi-vertical-spacer-4{height:8rem;width:100%}.cgi-vertical-spacer-5{height:10rem;width:100%}.cgi-vertical-spacer-6{height:12rem;width:100%}.cgi-vertical-spacer-7{height:14rem;width:100%}.cgi-vertical-spacer-8{height:16rem;width:100%}.cgi-vertical-spacer-9{height:18rem;width:100%}.cgi-vertical-spacer-10{height:20rem;width:100%}:host(.cgi-top-nav){position:relative;z-index:10}:host(.cgi-top-nav) mat-toolbar{height:64px;padding:0}:host(.cgi-top-nav) .quick-nav--hide{margin:0;opacity:0;padding:0;position:absolute;width:0}:host(.cgi-top-nav)::ng-deep .cgi-top-nav--left{-moz-box-ordinal-group:0;-ms-flex-order:0;-webkit-box-ordinal-group:0;-webkit-order:0;display:flex;flex-direction:row;margin:0;order:0;width:100%}:host(.cgi-top-nav)::ng-deep .cgi-top-nav--left cgi-top-nav-item:not(.cgi-top-nav__menu):nth-last-child(n+2)>:first-child:first-child,:host(.cgi-top-nav)::ng-deep .cgi-top-nav--left cgi-top-nav-item:not(.cgi-top-nav__menu):nth-last-child(n+2)>:first-child~*:first-child{margin-left:.9rem}:host(.cgi-top-nav)::ng-deep .cgi-top-nav--left cgi-top-nav-item:not(.cgi-top-nav__menu):nth-last-child(1)>:first-child,:host(.cgi-top-nav)::ng-deep .cgi-top-nav--left cgi-top-nav-item:not(.cgi-top-nav__menu):nth-last-child(1)>:first-child~*{margin-left:.9rem}:host(.cgi-top-nav)::ng-deep .cgi-top-nav--right{-moz-box-ordinal-group:2;-ms-flex-order:2;-webkit-box-ordinal-group:2;-webkit-order:2;display:flex;flex-direction:row-reverse;margin:0 0 0 auto;order:2}\n"], dependencies: [{ kind: "directive", type: i1.NgForOf, selector: "[ngFor][ngForOf]", inputs: ["ngForOf", "ngForTrackBy", "ngForTemplate"] }, { kind: "component", type: i2$1.MatToolbar, selector: "mat-toolbar", inputs: ["color"], exportAs: ["matToolbar"] }, { kind: "component", type: i4.MatButton, selector: "    button[matButton], a[matButton], button[mat-button], button[mat-raised-button],    button[mat-flat-button], button[mat-stroked-button], a[mat-button], a[mat-raised-button],    a[mat-flat-button], a[mat-stroked-button]  ", inputs: ["matButton"], exportAs: ["matButton", "matAnchor"] }, { kind: "component", type: i4$1.MatMenu, selector: "mat-menu", inputs: ["backdropClass", "aria-label", "aria-labelledby", "aria-describedby", "xPosition", "yPosition", "overlapTrigger", "hasBackdrop", "class", "classList"], outputs: ["closed", "close"], exportAs: ["matMenu"] }, { kind: "component", type: i4$1.MatMenuItem, selector: "[mat-menu-item]", inputs: ["role", "disabled", "disableRipple"], exportAs: ["matMenuItem"] }, { kind: "directive", type: i4$1.MatMenuTrigger, selector: "[mat-menu-trigger-for], [matMenuTriggerFor]", inputs: ["mat-menu-trigger-for", "matMenuTriggerFor", "matMenuTriggerData", "matMenuTriggerRestoreFocus"], outputs: ["menuOpened", "onMenuOpen", "menuClosed", "onMenuClose"], exportAs: ["matMenuTrigger"] }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.2", ngImport: i0, type: CGITopNavComponent, decorators: [{
            type: Component,
            args: [{ selector: 'cgi-top-nav', standalone: false, template: "<nav attr.aria-label=\"{{ ariaLabel }}\" role=\"navigation\">\n  <mat-toolbar [color]=\"color\">\n    <button\n      id=\"quick-nav\"\n      (focusin)=\"hideButton = false\"\n      (focusout)=\"hideButton = true\"\n      [class.quick-nav--hide]=\"hideButton\"\n      color=\"primary\"\n      mat-flat-button\n      [matMenuTriggerFor]=\"quickNav\"\n      [attr.aria-label]=\"quickSkipAriaLabel\"\n    >\n      {{ quickSkipButtonText }}\n    </button>\n    <mat-menu #quickNav=\"matMenu\">\n      <button\n        *ngFor=\"let landmark of landmarks\"\n        [attr.id]=\"'skip-to-' + landmark.id\"\n        (click)=\"$event.stopPropagation(); goToLandmark(landmark)\"\n        mat-menu-item\n      >\n        {{ landmark.label }}\n      </button>\n    </mat-menu>\n    <ng-content select=\".cgi-top-nav--left\"></ng-content>\n    <ng-content select=\".cgi-top-nav--right\"></ng-content>\n  </mat-toolbar>\n  <!-- #2 -->\n</nav>\n", styles: [".cgi-vertical-spacer-1{height:2rem;width:100%}.cgi-vertical-spacer-2{height:4rem;width:100%}.cgi-vertical-spacer-3{height:6rem;width:100%}.cgi-vertical-spacer-4{height:8rem;width:100%}.cgi-vertical-spacer-5{height:10rem;width:100%}.cgi-vertical-spacer-6{height:12rem;width:100%}.cgi-vertical-spacer-7{height:14rem;width:100%}.cgi-vertical-spacer-8{height:16rem;width:100%}.cgi-vertical-spacer-9{height:18rem;width:100%}.cgi-vertical-spacer-10{height:20rem;width:100%}:host(.cgi-top-nav){position:relative;z-index:10}:host(.cgi-top-nav) mat-toolbar{height:64px;padding:0}:host(.cgi-top-nav) .quick-nav--hide{margin:0;opacity:0;padding:0;position:absolute;width:0}:host(.cgi-top-nav)::ng-deep .cgi-top-nav--left{-moz-box-ordinal-group:0;-ms-flex-order:0;-webkit-box-ordinal-group:0;-webkit-order:0;display:flex;flex-direction:row;margin:0;order:0;width:100%}:host(.cgi-top-nav)::ng-deep .cgi-top-nav--left cgi-top-nav-item:not(.cgi-top-nav__menu):nth-last-child(n+2)>:first-child:first-child,:host(.cgi-top-nav)::ng-deep .cgi-top-nav--left cgi-top-nav-item:not(.cgi-top-nav__menu):nth-last-child(n+2)>:first-child~*:first-child{margin-left:.9rem}:host(.cgi-top-nav)::ng-deep .cgi-top-nav--left cgi-top-nav-item:not(.cgi-top-nav__menu):nth-last-child(1)>:first-child,:host(.cgi-top-nav)::ng-deep .cgi-top-nav--left cgi-top-nav-item:not(.cgi-top-nav__menu):nth-last-child(1)>:first-child~*{margin-left:.9rem}:host(.cgi-top-nav)::ng-deep .cgi-top-nav--right{-moz-box-ordinal-group:2;-ms-flex-order:2;-webkit-box-ordinal-group:2;-webkit-order:2;display:flex;flex-direction:row-reverse;margin:0 0 0 auto;order:2}\n"] }]
        }], ctorParameters: () => [{ type: undefined, decorators: [{
                    type: Inject,
                    args: [DOCUMENT]
                }] }], propDecorators: { isClassContainer: [{
                type: HostBinding,
                args: ['class.cgi-top-nav']
            }], landmarks: [{
                type: Input
            }], quickSkipButtonText: [{
                type: Input
            }], quickSkipAriaLabel: [{
                type: Input
            }], matMenu: [{
                type: ViewChild,
                args: [MatMenuTrigger, { static: false }]
            }], color: [{
                type: Input
            }], ariaLabel: [{
                type: Input
            }] } });

class CGITopNavModule {
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.2", ngImport: i0, type: CGITopNavModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule }); }
    static { this.ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "20.3.2", ngImport: i0, type: CGITopNavModule, declarations: [CGITopNavComponent, CGITopNavItemComponent], imports: [CommonModule, MatToolbarModule, MatButtonModule, MatIconModule, MatMenuModule], exports: [CGITopNavComponent, CGITopNavItemComponent] }); }
    static { this.ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "20.3.2", ngImport: i0, type: CGITopNavModule, imports: [CommonModule, MatToolbarModule, MatButtonModule, MatIconModule, MatMenuModule] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.2", ngImport: i0, type: CGITopNavModule, decorators: [{
            type: NgModule,
            args: [{
                    imports: [CommonModule, MatToolbarModule, MatButtonModule, MatIconModule, MatMenuModule],
                    declarations: [CGITopNavComponent, CGITopNavItemComponent],
                    exports: [CGITopNavComponent, CGITopNavItemComponent],
                }]
        }] });

/**
 * Side Navigation Item data model
 */
class SideNavItem {
    /**
     * Default constructor for SideNavItem
     * @param text Text/Title of side nav item
     * @param link Router link of side nav item
     * @param icon Icon of the side nav item
     * @param subsection Subsection of side nav item if applicable
     * @param state query attributes in navigation url
     * @param params customizable attributes to be added to particular navigation route
     */
    constructor(text = '', link = '', icon, subsection, state, params) {
        this.text = text;
        this.link = link;
        this.icon = icon;
        this.subsection = subsection;
        this.state = state;
        this.queryParams = params;
    }
}

/**
 * General navigation component.
 *
 * TODO: How to use component and examples.
 */
class CGINavContainerComponent {
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.2", ngImport: i0, type: CGINavContainerComponent, deps: [], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "20.3.2", type: CGINavContainerComponent, isStandalone: false, selector: "cgi-nav-container", ngImport: i0, template: "<ng-content></ng-content>\n", styles: [":host{-ms-flex:1 1 auto;-webkit-box-flex:1;box-sizing:border-box;display:flex;display:-webkit-box;display:-ms-flexbox;flex:1 1 auto;position:relative}\n"] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.2", ngImport: i0, type: CGINavContainerComponent, decorators: [{
            type: Component,
            args: [{ selector: 'cgi-nav-container', standalone: false, template: "<ng-content></ng-content>\n", styles: [":host{-ms-flex:1 1 auto;-webkit-box-flex:1;box-sizing:border-box;display:flex;display:-webkit-box;display:-ms-flexbox;flex:1 1 auto;position:relative}\n"] }]
        }] });

/**
 * Content outside of navigation header/sidenav component.
 *
 * TODO: How to use component and examples.
 */
class CGINavContentComponent {
    /** Load renderer, elementRef, and navContainerService for DOM manipulation. */
    constructor(renderer, elRef, navContainerService, router, 
    /** Inject Dom Object  */
    document) {
        this.renderer = renderer;
        this.elRef = elRef;
        this.navContainerService = navContainerService;
        this.router = router;
        this.document = document;
        this.isClassContainer = true;
        this.scrollToTop = this.router.events.pipe(filter((event) => event instanceof NavigationEnd));
        // Scroll to top when route is changed
        this.scrollToTop.subscribe(() => {
            const child = this.document.querySelectorAll('cgi-nav-content > *')[2];
            if (child) {
                child.scrollIntoView();
            }
        });
    }
    /** Close navigation when backdrop is clicked, only available on mobile view. */
    closeNav() {
        this.navContainerService.toggle(false);
        if (!this.navContainerService.getState()) {
            this.renderer.removeClass(this.elRef.nativeElement.parentElement, 'cgi-side-nav--opened');
        }
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.2", ngImport: i0, type: CGINavContentComponent, deps: [{ token: i0.Renderer2 }, { token: i0.ElementRef }, { token: CGINavContainerService$1 }, { token: i2.Router }, { token: DOCUMENT }], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "20.3.2", type: CGINavContentComponent, isStandalone: false, selector: "cgi-nav-content", host: { properties: { "class.cgi-nav-content": "this.isClassContainer" } }, ngImport: i0, template: "<div class=\"cgi-nav-content__backdrop\" (click)=\"closeNav()\"></div>\n<div id=\"before-content\" tabindex=\"-1\"></div>\n<ng-content></ng-content>\n", styles: [":host{display:block;height:100%;left:0;margin-left:4.4rem;overflow:auto;padding:0 1.5vw;position:absolute;right:0;transition:margin-left .2s cubic-bezier(.25,.8,.25,1);z-index:1}.cgi-side-nav--opened :host{margin-left:18rem}:host .cgi-nav-content__backdrop{display:block;height:100%;inset:0;position:fixed;visibility:hidden;width:100%;z-index:2}@media (max-width: 599px){:host{margin-left:0}.cgi-side-nav--opened :host{margin-left:0;overflow:hidden}.cgi-side-nav--opened :host .cgi-nav-content__backdrop{transition:background-color .4s cubic-bezier(.25,.8,.25,1);visibility:visible}}\n"] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.2", ngImport: i0, type: CGINavContentComponent, decorators: [{
            type: Component,
            args: [{ selector: 'cgi-nav-content', standalone: false, template: "<div class=\"cgi-nav-content__backdrop\" (click)=\"closeNav()\"></div>\n<div id=\"before-content\" tabindex=\"-1\"></div>\n<ng-content></ng-content>\n", styles: [":host{display:block;height:100%;left:0;margin-left:4.4rem;overflow:auto;padding:0 1.5vw;position:absolute;right:0;transition:margin-left .2s cubic-bezier(.25,.8,.25,1);z-index:1}.cgi-side-nav--opened :host{margin-left:18rem}:host .cgi-nav-content__backdrop{display:block;height:100%;inset:0;position:fixed;visibility:hidden;width:100%;z-index:2}@media (max-width: 599px){:host{margin-left:0}.cgi-side-nav--opened :host{margin-left:0;overflow:hidden}.cgi-side-nav--opened :host .cgi-nav-content__backdrop{transition:background-color .4s cubic-bezier(.25,.8,.25,1);visibility:visible}}\n"] }]
        }], ctorParameters: () => [{ type: i0.Renderer2 }, { type: i0.ElementRef }, { type: CGINavContainerService$1 }, { type: i2.Router }, { type: undefined, decorators: [{
                    type: Inject,
                    args: [DOCUMENT]
                }] }], propDecorators: { isClassContainer: [{
                type: HostBinding,
                args: ['class.cgi-nav-content']
            }] } });

/**
 * Side navigation item component.
 * Recursive side navigation item component to allow for unlimited submenus (design limit of 3)
 */
class CGISideNavItemComponent {
    /**
     *  Constructor
     * @param _document Application's HTML Document
     */
    constructor(navContainerService, document, router) {
        this.navContainerService = navContainerService;
        this.router = router;
        /** Alive for service checking */
        this.alive = true;
        this._document = document;
    }
    /**
     * Subscribe to navContainerService boolean value as one true source of state.
     */
    ngOnInit() {
        this.level++;
        this.navContainerService.changes.pipe(takeWhile(() => this.alive)).subscribe((res) => {
            this.isOpened = res;
        });
    }
    /** Efficient way of unsubscribing from service session. */
    ngOnDestroy() {
        this.alive = false;
    }
    /** A method to focus to the main content section of the page, after a delay */
    focusToContent() {
        const focusDelay = 200;
        setTimeout(() => {
            let dummyContentElement = this._document.querySelector('#before-content');
            if (dummyContentElement) {
                dummyContentElement.focus();
            }
            dummyContentElement = null;
        }, focusDelay);
    }
    /** A programmatic router navigation method used to fix the links not working as mat-expansion-panel headers */
    goToLink(url) {
        this.router.navigate([url]);
        this.focusToContent();
    }
    /** Converts object to array if given only object */
    convertArray(input) {
        let result;
        result = [];
        if (input) {
            result.push(input);
        }
        return result;
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.2", ngImport: i0, type: CGISideNavItemComponent, deps: [{ token: CGINavContainerService$1 }, { token: DOCUMENT }, { token: i2.Router }], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "20.3.2", type: CGISideNavItemComponent, isStandalone: false, selector: "cgi-side-nav-item", inputs: { links: "links", level: "level" }, ngImport: i0, template: "<mat-accordion [hidden]=\"!isOpened\" class=\"cgi-sidenav-item_{{ level }}\">\n  <ng-container *ngFor=\"let link of links; let k = index\">\n    <div *ngIf=\"!link.subsection\" class=\"cgi-sidenav-item_single-link\">\n      <a\n        routerLinkActive=\"active\"\n        [routerLinkActiveOptions]=\"{ exact: true }\"\n        routerLink=\"{{ link.link }}\"\n        [queryParams]=\"link.params\"\n        [state]=\"link.state\"\n        (click)=\"focusToContent()\"\n        (keydown.enter)=\"goToLink(link.link)\"\n      >\n        <mat-icon fontSet=\"far\" fontIcon=\"{{ link.icon }}\"></mat-icon>\n        <span>{{ link.text }}</span>\n      </a>\n    </div>\n    <mat-expansion-panel *ngIf=\"link.subsection\">\n      <mat-expansion-panel-header expandedHeight=\"50px\" collapsedHeight=\"50px\">\n        <mat-panel-title>\n          <a>\n            <mat-icon fontSet=\"far\" fontIcon=\"{{ link.icon }}\"></mat-icon>\n            <span>{{ link.text }}</span>\n          </a>\n        </mat-panel-title>\n      </mat-expansion-panel-header>\n\n      <div *ngFor=\"let childLink of link.subsection; let j = index\">\n        <a\n          class=\"cgi-side-nav__sublink\"\n          *ngIf=\"!childLink.subsection\"\n          (click)=\"focusToContent()\"\n          routerLinkActive=\"active\"\n          [routerLinkActiveOptions]=\"{ exact: true }\"\n          routerLink=\"{{ childLink.link }}\"\n          [queryParams]=\"link.params\"\n          [state]=\"link.state\"\n        >\n          <span>{{ childLink.text }}</span>\n        </a>\n\n        <cgi-side-nav-item\n          *ngIf=\"childLink.subsection\"\n          [links]=\"convertArray(childLink)\"\n          [level]=\"level\"\n        >\n        </cgi-side-nav-item>\n      </div>\n    </mat-expansion-panel>\n  </ng-container>\n</mat-accordion>\n\n<ul *ngIf=\"!isOpened\">\n  <li *ngFor=\"let link of links; let i = index\">\n    <a\n      routerLinkActive=\"active\"\n      [routerLinkActiveOptions]=\"{ exact: true }\"\n      routerLink=\"{{ link.link }}\"\n      [queryParams]=\"link.params\"\n      [state]=\"link.state\"\n      title=\"index of {{ i }}\"\n      (click)=\"focusToContent()\"\n    >\n      <mat-icon fontSet=\"far\" fontIcon=\"{{ link.icon }}\"></mat-icon>\n    </a>\n  </li>\n</ul>\n", styles: [":host .mat-icon{display:block;float:left;font-size:16px;height:inherit;line-height:50px;margin-left:18px;margin-right:18px;text-align:center;width:20px}\n"], dependencies: [{ kind: "directive", type: i1.NgForOf, selector: "[ngFor][ngForOf]", inputs: ["ngForOf", "ngForTrackBy", "ngForTemplate"] }, { kind: "directive", type: i1.NgIf, selector: "[ngIf]", inputs: ["ngIf", "ngIfThen", "ngIfElse"] }, { kind: "directive", type: i4$2.MatAccordion, selector: "mat-accordion", inputs: ["hideToggle", "displayMode", "togglePosition"], exportAs: ["matAccordion"] }, { kind: "component", type: i4$2.MatExpansionPanel, selector: "mat-expansion-panel", inputs: ["hideToggle", "togglePosition"], outputs: ["afterExpand", "afterCollapse"], exportAs: ["matExpansionPanel"] }, { kind: "component", type: i4$2.MatExpansionPanelHeader, selector: "mat-expansion-panel-header", inputs: ["expandedHeight", "collapsedHeight", "tabIndex"] }, { kind: "directive", type: i4$2.MatExpansionPanelTitle, selector: "mat-panel-title" }, { kind: "component", type: i5.MatIcon, selector: "mat-icon", inputs: ["color", "inline", "svgIcon", "fontSet", "fontIcon"], exportAs: ["matIcon"] }, { kind: "directive", type: i2.RouterLink, selector: "[routerLink]", inputs: ["target", "queryParams", "fragment", "queryParamsHandling", "state", "info", "relativeTo", "preserveFragment", "skipLocationChange", "replaceUrl", "routerLink"] }, { kind: "directive", type: i2.RouterLinkActive, selector: "[routerLinkActive]", inputs: ["routerLinkActiveOptions", "ariaCurrentWhenActive", "routerLinkActive"], outputs: ["isActiveChange"], exportAs: ["routerLinkActive"] }, { kind: "component", type: CGISideNavItemComponent, selector: "cgi-side-nav-item", inputs: ["links", "level"] }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.2", ngImport: i0, type: CGISideNavItemComponent, decorators: [{
            type: Component,
            args: [{ selector: 'cgi-side-nav-item', standalone: false, template: "<mat-accordion [hidden]=\"!isOpened\" class=\"cgi-sidenav-item_{{ level }}\">\n  <ng-container *ngFor=\"let link of links; let k = index\">\n    <div *ngIf=\"!link.subsection\" class=\"cgi-sidenav-item_single-link\">\n      <a\n        routerLinkActive=\"active\"\n        [routerLinkActiveOptions]=\"{ exact: true }\"\n        routerLink=\"{{ link.link }}\"\n        [queryParams]=\"link.params\"\n        [state]=\"link.state\"\n        (click)=\"focusToContent()\"\n        (keydown.enter)=\"goToLink(link.link)\"\n      >\n        <mat-icon fontSet=\"far\" fontIcon=\"{{ link.icon }}\"></mat-icon>\n        <span>{{ link.text }}</span>\n      </a>\n    </div>\n    <mat-expansion-panel *ngIf=\"link.subsection\">\n      <mat-expansion-panel-header expandedHeight=\"50px\" collapsedHeight=\"50px\">\n        <mat-panel-title>\n          <a>\n            <mat-icon fontSet=\"far\" fontIcon=\"{{ link.icon }}\"></mat-icon>\n            <span>{{ link.text }}</span>\n          </a>\n        </mat-panel-title>\n      </mat-expansion-panel-header>\n\n      <div *ngFor=\"let childLink of link.subsection; let j = index\">\n        <a\n          class=\"cgi-side-nav__sublink\"\n          *ngIf=\"!childLink.subsection\"\n          (click)=\"focusToContent()\"\n          routerLinkActive=\"active\"\n          [routerLinkActiveOptions]=\"{ exact: true }\"\n          routerLink=\"{{ childLink.link }}\"\n          [queryParams]=\"link.params\"\n          [state]=\"link.state\"\n        >\n          <span>{{ childLink.text }}</span>\n        </a>\n\n        <cgi-side-nav-item\n          *ngIf=\"childLink.subsection\"\n          [links]=\"convertArray(childLink)\"\n          [level]=\"level\"\n        >\n        </cgi-side-nav-item>\n      </div>\n    </mat-expansion-panel>\n  </ng-container>\n</mat-accordion>\n\n<ul *ngIf=\"!isOpened\">\n  <li *ngFor=\"let link of links; let i = index\">\n    <a\n      routerLinkActive=\"active\"\n      [routerLinkActiveOptions]=\"{ exact: true }\"\n      routerLink=\"{{ link.link }}\"\n      [queryParams]=\"link.params\"\n      [state]=\"link.state\"\n      title=\"index of {{ i }}\"\n      (click)=\"focusToContent()\"\n    >\n      <mat-icon fontSet=\"far\" fontIcon=\"{{ link.icon }}\"></mat-icon>\n    </a>\n  </li>\n</ul>\n", styles: [":host .mat-icon{display:block;float:left;font-size:16px;height:inherit;line-height:50px;margin-left:18px;margin-right:18px;text-align:center;width:20px}\n"] }]
        }], ctorParameters: () => [{ type: CGINavContainerService$1 }, { type: undefined, decorators: [{
                    type: Inject,
                    args: [DOCUMENT]
                }] }, { type: i2.Router }], propDecorators: { links: [{
                type: Input
            }], level: [{
                type: Input
            }] } });

/**
 * Side navigation component.
 */
class CGISideNavComponent {
    /** Load renderer, elementRef, and navContainerService for DOM manipulation. */
    constructor(renderer, elRef, navContainerService) {
        this.renderer = renderer;
        this.elRef = elRef;
        this.navContainerService = navContainerService;
        /** Hovered state. */
        this._mouseOver = false;
        /** To automatically unsubscribe at the end of life of the component. */
        this.alive = true;
        /** Variable for width */
        this.MOBILE_WIDTH = 576;
        /** Variable for delay */
        this.DELAY = 350;
        /** Variable for width */
        this.PUSH_CLASS = 'cgi-side-nav--opened';
        /** Set a timer. */
        this._timer = timer(this.DELAY);
        /** SOURCE: https://stackoverflow.com/a/43834596
         * Determine current window size in Observable to avoid spam of resize events.  */
        this.initial$ = of(!(window.innerWidth > this.MOBILE_WIDTH));
        /** Observable to be aware of when window size changes.  */
        this.resize$ = fromEvent(window, 'resize').pipe(map((event) => {
            return event.target.innerWidth > this.MOBILE_WIDTH ? false : true;
        }));
        /** Observable combined to provide boolean value for when window size is mobile. */
        this.mobile$ = merge(this.resize$, this.initial$).pipe(distinctUntilChanged());
        this.isClassContainer = true;
        this.leftNavId = "left-nav" /* PageLandmarks.LEFT_NAV */;
    }
    /**
     * Subscribe to navContainerService boolean value as one true source of state.
     * Also closes open navigation panel when screen resized to mobile view.
     */
    ngOnInit() {
        this.navContainerService.changes.pipe(takeWhile(() => this.alive)).subscribe((res) => {
            this._open = res;
            if (this._open &&
                !this._mouseOver &&
                !this.elRef.nativeElement.parentElement.classList.contains(this.PUSH_CLASS)) {
                this.renderer.addClass(this.elRef.nativeElement.parentElement, this.PUSH_CLASS);
            }
            else {
                this.renderer.removeClass(this.elRef.nativeElement.parentElement, this.PUSH_CLASS);
            }
        });
        this.mobile$.subscribe((event) => {
            this.mobileView = event;
            if (event) {
                this.closeOnMobile();
            }
        });
    }
    /** Efficient way of unsubscribing from service session. */
    ngOnDestroy() {
        this.alive = false;
    }
    /** Listener for MouseEnter. */
    mouseEnter() {
        if (!this.elRef.nativeElement.parentElement.classList.contains(this.PUSH_CLASS) &&
            !this._mouseOver) {
            this._mouseOver = true;
            this.timerSub = this._timer.subscribe(() => {
                this.open();
            });
        }
    }
    /** Listener for MouseLeave. */
    mouseLeave() {
        if (!this.elRef.nativeElement.parentElement.classList.contains(this.PUSH_CLASS)) {
            this.close();
            this.timerSub.unsubscribe();
            this._mouseOver = false;
        }
    }
    /** Getter to determine whether or not to add opened class to host component. */
    get isOpened() {
        return this._open;
    }
    /** Provide option to set whether sidenav is opened or closed on initialization.  */
    set opened(value) {
        // Need to use boolean converter for undefined values, otherwise, will default to string.
        this.navContainerService.toggle(coerceBooleanProperty(value));
    }
    /** Open this sidenav. */
    open() {
        this.toggle(true);
    }
    /** Close this sidenav. */
    close() {
        this.toggle(false);
    }
    /** Close this sidenav only when in mobile view. */
    // TODO: Include in E2E Test!
    closeOnMobile() {
        if (this.mobileView) {
            this.navContainerService.toggle(false);
            this.renderer.removeClass(this.elRef.nativeElement.parentElement, this.PUSH_CLASS);
        }
    }
    /**
     * Toggle this sidenav. This is equivalent to calling open() when it's already opened, or
     * close() when it's closed.
     * @param isOpen Whether the sidenav should be open.
     * @returns Changes sidenav element width based on boolean value.
     */
    toggle(isOpen = !this._open) {
        this.navContainerService.toggle(isOpen);
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.2", ngImport: i0, type: CGISideNavComponent, deps: [{ token: i0.Renderer2 }, { token: i0.ElementRef }, { token: CGINavContainerService$1 }], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "20.3.2", type: CGISideNavComponent, isStandalone: false, selector: "cgi-side-nav", inputs: { links: "links", opened: "opened" }, host: { listeners: { "mouseenter": "mouseEnter()", "mouseleave": "mouseLeave()" }, properties: { "class.cgi-side-nav": "this.isClassContainer", "class.cgi-side-nav--opened": "this.isOpened" } }, ngImport: i0, template: "<aside>\n  <cgi-side-nav-item [links]=\"links\" [level]=\"0\" [attr.id]=\"leftNavId\"></cgi-side-nav-item>\n</aside>\n", styles: [".cgi-vertical-spacer-1{height:2rem;width:100%}.cgi-vertical-spacer-2{height:4rem;width:100%}.cgi-vertical-spacer-3{height:6rem;width:100%}.cgi-vertical-spacer-4{height:8rem;width:100%}.cgi-vertical-spacer-5{height:10rem;width:100%}.cgi-vertical-spacer-6{height:12rem;width:100%}.cgi-vertical-spacer-7{height:14rem;width:100%}.cgi-vertical-spacer-8{height:16rem;width:100%}.cgi-vertical-spacer-9{height:18rem;width:100%}.cgi-vertical-spacer-10{height:20rem;width:100%}:host(.cgi-side-nav){bottom:0;box-shadow:none;box-sizing:border-box;display:block;height:100%;outline:0;overflow:auto;overflow-x:hidden;position:absolute;top:0;transition:all .3s cubic-bezier(.25,.8,.25,1);width:4.4rem;z-index:9}:host(.cgi-side-nav).cgi-side-nav--shadow{box-shadow:0 1px 25px #0003}:host(.cgi-side-nav) .mat-icon{color:#3d4f68;display:block;float:left;font-size:16px;height:inherit;line-height:50px;margin-left:18px;margin-right:18px;text-align:center;width:20px}@media (max-width: 599px){:host(.cgi-side-nav){box-shadow:none;transform:translate3d(-100%,0,0);transition:transform .3s cubic-bezier(.25,.8,.25,1);width:18rem}}:host(.cgi-side-nav).cgi-side-nav--opened{width:18rem}@media (max-width: 599px){:host(.cgi-side-nav).cgi-side-nav--opened{box-shadow:3px 0 6px #0000003d;transform:translateZ(0)}}:host(.cgi-side-nav--opened)::ng-deep ul>li a>span,:host(.cgi-side-nav--opened)::ng-deep ul>li .cgi-side-nav__title{font-size:inherit;opacity:1;visibility:visible}:host(.cgi-side-nav--opened)::ng-deep .mat-expansion-panel{box-shadow:none!important;border-radius:0!important;margin:0;min-width:18rem}:host(.cgi-side-nav--opened)::ng-deep .mat-expansion-panel a{text-decoration:none}:host(.cgi-side-nav--opened)::ng-deep .mat-expansion-panel a span{line-height:50px}:host(.cgi-side-nav--opened)::ng-deep .mat-expansion-panel a.active{border-left:4px solid;font-weight:700}:host(.cgi-side-nav--opened)::ng-deep .mat-expansion-panel .mat-expansion-panel-header{font-size:15px;font-weight:400;min-height:50px;padding:0 20px 0 0}:host(.cgi-side-nav--opened)::ng-deep .mat-expansion-panel .mat-expansion-panel-body{padding:0}:host(.cgi-side-nav--opened)::ng-deep .mat-expansion-panel .mat-expansion-panel-body .cgi-side-nav__sublink{display:block;height:50px;line-height:50px;text-indent:55px}:host(.cgi-side-nav--opened)::ng-deep .mat-expansion-panel .mat-action-row{border-top-width:0!important;padding:8px 20px 16px!important}:host(.cgi-side-nav--opened)::ng-deep .mat-expansion-panel .mat-action-row .mat-mdc-button,:host(.cgi-side-nav--opened)::ng-deep .mat-expansion-panel .mat-action-row .mat-mdc-raised-button{margin:0 4px!important}:host(.cgi-side-nav--opened)::ng-deep .mat-expansion-panel .mat-action-row .mat-mdc-button:first-child,:host(.cgi-side-nav--opened)::ng-deep .mat-expansion-panel .mat-action-row .mat-mdc-raised-button:first-child{margin-left:0!important;margin-right:0!important}:host::ng-deep .mat-icon{display:block;float:left;font-size:16px;height:inherit;line-height:50px;margin-left:18px;margin-right:18px;text-align:center;width:20px}:host ::ng-deep ul{list-style:none;margin:0;padding-left:0}:host ::ng-deep ul>li{height:50px;margin:0;padding:0}:host ::ng-deep ul>li>a{align-items:center;box-sizing:border-box;display:flex;font-size:16px;height:50px;line-height:50px;text-decoration:none}:host ::ng-deep ul>li>a>mat-icon,:host ::ng-deep ul>li>a .cgi-icon{margin-left:20px;margin-right:20px}:host ::ng-deep ul>li>a>span,:host ::ng-deep ul>li>a .cgi-side-nav__title{font-size:0;opacity:0;transition:opacity 1.2s ease-in-out;visibility:hidden}@media (max-width: 599px){:host ::ng-deep ul>li>a>span,:host ::ng-deep ul>li>a .cgi-side-nav__title{font-size:inherit;opacity:1;visibility:visible}}\n"], dependencies: [{ kind: "component", type: CGISideNavItemComponent, selector: "cgi-side-nav-item", inputs: ["links", "level"] }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.2", ngImport: i0, type: CGISideNavComponent, decorators: [{
            type: Component,
            args: [{ selector: 'cgi-side-nav', standalone: false, template: "<aside>\n  <cgi-side-nav-item [links]=\"links\" [level]=\"0\" [attr.id]=\"leftNavId\"></cgi-side-nav-item>\n</aside>\n", styles: [".cgi-vertical-spacer-1{height:2rem;width:100%}.cgi-vertical-spacer-2{height:4rem;width:100%}.cgi-vertical-spacer-3{height:6rem;width:100%}.cgi-vertical-spacer-4{height:8rem;width:100%}.cgi-vertical-spacer-5{height:10rem;width:100%}.cgi-vertical-spacer-6{height:12rem;width:100%}.cgi-vertical-spacer-7{height:14rem;width:100%}.cgi-vertical-spacer-8{height:16rem;width:100%}.cgi-vertical-spacer-9{height:18rem;width:100%}.cgi-vertical-spacer-10{height:20rem;width:100%}:host(.cgi-side-nav){bottom:0;box-shadow:none;box-sizing:border-box;display:block;height:100%;outline:0;overflow:auto;overflow-x:hidden;position:absolute;top:0;transition:all .3s cubic-bezier(.25,.8,.25,1);width:4.4rem;z-index:9}:host(.cgi-side-nav).cgi-side-nav--shadow{box-shadow:0 1px 25px #0003}:host(.cgi-side-nav) .mat-icon{color:#3d4f68;display:block;float:left;font-size:16px;height:inherit;line-height:50px;margin-left:18px;margin-right:18px;text-align:center;width:20px}@media (max-width: 599px){:host(.cgi-side-nav){box-shadow:none;transform:translate3d(-100%,0,0);transition:transform .3s cubic-bezier(.25,.8,.25,1);width:18rem}}:host(.cgi-side-nav).cgi-side-nav--opened{width:18rem}@media (max-width: 599px){:host(.cgi-side-nav).cgi-side-nav--opened{box-shadow:3px 0 6px #0000003d;transform:translateZ(0)}}:host(.cgi-side-nav--opened)::ng-deep ul>li a>span,:host(.cgi-side-nav--opened)::ng-deep ul>li .cgi-side-nav__title{font-size:inherit;opacity:1;visibility:visible}:host(.cgi-side-nav--opened)::ng-deep .mat-expansion-panel{box-shadow:none!important;border-radius:0!important;margin:0;min-width:18rem}:host(.cgi-side-nav--opened)::ng-deep .mat-expansion-panel a{text-decoration:none}:host(.cgi-side-nav--opened)::ng-deep .mat-expansion-panel a span{line-height:50px}:host(.cgi-side-nav--opened)::ng-deep .mat-expansion-panel a.active{border-left:4px solid;font-weight:700}:host(.cgi-side-nav--opened)::ng-deep .mat-expansion-panel .mat-expansion-panel-header{font-size:15px;font-weight:400;min-height:50px;padding:0 20px 0 0}:host(.cgi-side-nav--opened)::ng-deep .mat-expansion-panel .mat-expansion-panel-body{padding:0}:host(.cgi-side-nav--opened)::ng-deep .mat-expansion-panel .mat-expansion-panel-body .cgi-side-nav__sublink{display:block;height:50px;line-height:50px;text-indent:55px}:host(.cgi-side-nav--opened)::ng-deep .mat-expansion-panel .mat-action-row{border-top-width:0!important;padding:8px 20px 16px!important}:host(.cgi-side-nav--opened)::ng-deep .mat-expansion-panel .mat-action-row .mat-mdc-button,:host(.cgi-side-nav--opened)::ng-deep .mat-expansion-panel .mat-action-row .mat-mdc-raised-button{margin:0 4px!important}:host(.cgi-side-nav--opened)::ng-deep .mat-expansion-panel .mat-action-row .mat-mdc-button:first-child,:host(.cgi-side-nav--opened)::ng-deep .mat-expansion-panel .mat-action-row .mat-mdc-raised-button:first-child{margin-left:0!important;margin-right:0!important}:host::ng-deep .mat-icon{display:block;float:left;font-size:16px;height:inherit;line-height:50px;margin-left:18px;margin-right:18px;text-align:center;width:20px}:host ::ng-deep ul{list-style:none;margin:0;padding-left:0}:host ::ng-deep ul>li{height:50px;margin:0;padding:0}:host ::ng-deep ul>li>a{align-items:center;box-sizing:border-box;display:flex;font-size:16px;height:50px;line-height:50px;text-decoration:none}:host ::ng-deep ul>li>a>mat-icon,:host ::ng-deep ul>li>a .cgi-icon{margin-left:20px;margin-right:20px}:host ::ng-deep ul>li>a>span,:host ::ng-deep ul>li>a .cgi-side-nav__title{font-size:0;opacity:0;transition:opacity 1.2s ease-in-out;visibility:hidden}@media (max-width: 599px){:host ::ng-deep ul>li>a>span,:host ::ng-deep ul>li>a .cgi-side-nav__title{font-size:inherit;opacity:1;visibility:visible}}\n"] }]
        }], ctorParameters: () => [{ type: i0.Renderer2 }, { type: i0.ElementRef }, { type: CGINavContainerService$1 }], propDecorators: { isClassContainer: [{
                type: HostBinding,
                args: ['class.cgi-side-nav']
            }], links: [{
                type: Input
            }], mouseEnter: [{
                type: HostListener,
                args: ['mouseenter']
            }], mouseLeave: [{
                type: HostListener,
                args: ['mouseleave']
            }], isOpened: [{
                type: HostBinding,
                args: ['class.cgi-side-nav--opened']
            }], opened: [{
                type: Input
            }] } });

class CGINavContainerModule {
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.2", ngImport: i0, type: CGINavContainerModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule }); }
    static { this.ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "20.3.2", ngImport: i0, type: CGINavContainerModule, declarations: [CGINavContainerComponent,
            CGISideNavComponent,
            CGISideNavItemComponent,
            CGINavContentComponent], imports: [CommonModule,
            MatToolbarModule,
            MatExpansionModule,
            MatButtonModule,
            MatIconModule,
            RouterModule], exports: [CGINavContainerComponent,
            CGISideNavComponent,
            CGISideNavItemComponent,
            CGINavContentComponent] }); }
    static { this.ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "20.3.2", ngImport: i0, type: CGINavContainerModule, providers: [CGINavContainerService$1], imports: [CommonModule,
            MatToolbarModule,
            MatExpansionModule,
            MatButtonModule,
            MatIconModule,
            RouterModule] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.2", ngImport: i0, type: CGINavContainerModule, decorators: [{
            type: NgModule,
            args: [{
                    imports: [
                        CommonModule,
                        MatToolbarModule,
                        MatExpansionModule,
                        MatButtonModule,
                        MatIconModule,
                        RouterModule,
                    ],
                    declarations: [
                        CGINavContainerComponent,
                        CGISideNavComponent,
                        CGISideNavItemComponent,
                        CGINavContentComponent,
                    ],
                    exports: [
                        CGINavContainerComponent,
                        CGISideNavComponent,
                        CGISideNavItemComponent,
                        CGINavContentComponent,
                    ],
                    providers: [CGINavContainerService$1],
                }]
        }] });

/**
 * Breadcrumbs component.
 *
 * TODO: How to use component and examples.
 */
class CGIBreadcrumbItemComponent {
    /**
     * Empty constructor.
     */
    constructor() {
        this.isClassContainer = true;
    }
    /**
     * Set title property in component.
     */
    ngOnInit() { }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.2", ngImport: i0, type: CGIBreadcrumbItemComponent, deps: [], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "20.3.2", type: CGIBreadcrumbItemComponent, isStandalone: false, selector: "cgi-breadcrumb-item", host: { properties: { "class.cgi-breadcrumb-item": "this.isClassContainer" } }, ngImport: i0, template: "<ul>\n  <li>\n    <ng-content></ng-content>\n  </li>\n</ul>\n", styles: [":host(.cgi-breadcrumb-item) ::ng-deep li,:host(.cgi-breadcrumb-item) ::ng-deep ul{display:inline;padding:0}:host(.cgi-breadcrumb-item) ::ng-deep li a,:host(.cgi-breadcrumb-item) ::ng-deep ul a{font-size:14px;font-weight:400}:host(.cgi-breadcrumb-item) ::ng-deep li a:hover,:host(.cgi-breadcrumb-item) ::ng-deep ul a:hover{opacity:.6}:host(.cgi-breadcrumb-item) ::ng-deep li:last-child{font-size:13px;font-weight:700}:host(.cgi-breadcrumb-item):not(:last-child) li:after{content:url(data:image/svg+xml,%20%3Csvg%20xmlns%3D%22http%3A%2F%2Fwww.w3.org%2F2000%2Fsvg%22%20viewBox%3D%220%200%20320%20512%22%20height%3D%2218%22%20width%3D%2212%22%3E%3Cpath%20d%3D%22M166.9%20264.5l-117.8%20116c-4.7%204.7-12.3%204.7-17%200l-7.1-7.1c-4.7-4.7-4.7-12.3%200-17L127.3%20256%2025.1%20155.6c-4.7-4.7-4.7-12.3%200-17l7.1-7.1c4.7-4.7%2012.3-4.7%2017%200l117.8%20116c4.6%204.7%204.6%2012.3-.1%2017zm128-17l-117.8-116c-4.7-4.7-12.3-4.7-17%200l-7.1%207.1c-4.7%204.7-4.7%2012.3%200%2017L255.3%20256%20153.1%20356.4c-4.7%204.7-4.7%2012.3%200%2017l7.1%207.1c4.7%204.7%2012.3%204.7%2017%200l117.8-116c4.6-4.7%204.6-12.3-.1-17z%22%2F%3E%3C%2Fsvg%3E);display:inline-block;height:20px;margin:0 10px;vertical-align:middle;width:11px}\n"] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.2", ngImport: i0, type: CGIBreadcrumbItemComponent, decorators: [{
            type: Component,
            args: [{ selector: 'cgi-breadcrumb-item', standalone: false, template: "<ul>\n  <li>\n    <ng-content></ng-content>\n  </li>\n</ul>\n", styles: [":host(.cgi-breadcrumb-item) ::ng-deep li,:host(.cgi-breadcrumb-item) ::ng-deep ul{display:inline;padding:0}:host(.cgi-breadcrumb-item) ::ng-deep li a,:host(.cgi-breadcrumb-item) ::ng-deep ul a{font-size:14px;font-weight:400}:host(.cgi-breadcrumb-item) ::ng-deep li a:hover,:host(.cgi-breadcrumb-item) ::ng-deep ul a:hover{opacity:.6}:host(.cgi-breadcrumb-item) ::ng-deep li:last-child{font-size:13px;font-weight:700}:host(.cgi-breadcrumb-item):not(:last-child) li:after{content:url(data:image/svg+xml,%20%3Csvg%20xmlns%3D%22http%3A%2F%2Fwww.w3.org%2F2000%2Fsvg%22%20viewBox%3D%220%200%20320%20512%22%20height%3D%2218%22%20width%3D%2212%22%3E%3Cpath%20d%3D%22M166.9%20264.5l-117.8%20116c-4.7%204.7-12.3%204.7-17%200l-7.1-7.1c-4.7-4.7-4.7-12.3%200-17L127.3%20256%2025.1%20155.6c-4.7-4.7-4.7-12.3%200-17l7.1-7.1c4.7-4.7%2012.3-4.7%2017%200l117.8%20116c4.6%204.7%204.6%2012.3-.1%2017zm128-17l-117.8-116c-4.7-4.7-12.3-4.7-17%200l-7.1%207.1c-4.7%204.7-4.7%2012.3%200%2017L255.3%20256%20153.1%20356.4c-4.7%204.7-4.7%2012.3%200%2017l7.1%207.1c4.7%204.7%2012.3%204.7%2017%200l117.8-116c4.6-4.7%204.6-12.3-.1-17z%22%2F%3E%3C%2Fsvg%3E);display:inline-block;height:20px;margin:0 10px;vertical-align:middle;width:11px}\n"] }]
        }], ctorParameters: () => [], propDecorators: { isClassContainer: [{
                type: HostBinding,
                args: ['class.cgi-breadcrumb-item']
            }] } });

/**
 * Breadcrumbs component.
 *
 * TODO: How to use component and examples.
 */
class CGIBreadcrumbsComponent {
    /**
     * Empty constructor.
     */
    constructor() {
        /** Custom aria-label attribute for accessibility. */
        this.ariaLabel = 'Breadcrumbs';
        this.isClassContainer = true;
    }
    /**
     * Set title property in component.
     */
    ngOnInit() { }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.2", ngImport: i0, type: CGIBreadcrumbsComponent, deps: [], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "20.3.2", type: CGIBreadcrumbsComponent, isStandalone: false, selector: "cgi-breadcrumbs", inputs: { ariaLabel: "ariaLabel" }, host: { properties: { "class.cgi-breadcrumbs": "this.isClassContainer" } }, ngImport: i0, template: "<nav attr.aria-label=\"{{ ariaLabel }}\">\n  <ng-content></ng-content>\n</nav>\n", styles: [":host(.cgi-breadcrumbs) nav{margin:0;padding:15px 15px 10px}\n"] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.2", ngImport: i0, type: CGIBreadcrumbsComponent, decorators: [{
            type: Component,
            args: [{ selector: 'cgi-breadcrumbs', standalone: false, template: "<nav attr.aria-label=\"{{ ariaLabel }}\">\n  <ng-content></ng-content>\n</nav>\n", styles: [":host(.cgi-breadcrumbs) nav{margin:0;padding:15px 15px 10px}\n"] }]
        }], ctorParameters: () => [], propDecorators: { isClassContainer: [{
                type: HostBinding,
                args: ['class.cgi-breadcrumbs']
            }], ariaLabel: [{
                type: Input
            }] } });

class CGIBreadcrumbsModule {
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.2", ngImport: i0, type: CGIBreadcrumbsModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule }); }
    static { this.ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "20.3.2", ngImport: i0, type: CGIBreadcrumbsModule, declarations: [CGIBreadcrumbsComponent, CGIBreadcrumbItemComponent], imports: [CommonModule], exports: [CGIBreadcrumbsComponent, CGIBreadcrumbItemComponent] }); }
    static { this.ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "20.3.2", ngImport: i0, type: CGIBreadcrumbsModule, imports: [CommonModule] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.2", ngImport: i0, type: CGIBreadcrumbsModule, decorators: [{
            type: NgModule,
            args: [{
                    imports: [CommonModule],
                    declarations: [CGIBreadcrumbsComponent, CGIBreadcrumbItemComponent],
                    exports: [CGIBreadcrumbsComponent, CGIBreadcrumbItemComponent],
                }]
        }] });

/** Global Search Component */
class CgiGlobalSearchComponent {
    /** constructor for host binding and form group */
    constructor(fb, router) {
        this.fb = fb;
        this.router = router;
        /** Input - variable for setting aria-label for the select menu : string type and default value */
        this.selectorAriaLabel = 'category selector';
        /** Input - for globalSearchSelect ( drop-down list for Category ) : string type and default value */
        this.globalSearchSelectID = 'cgi-global-search-select';
        /** Input - for  global search input box  ( search section  ) : string type and default value */
        this.globalSearchInputID = 'cgi-global-search-input';
        /** Input - for  global search placeholder ( search section ) : string type and default value */
        this.globalSearchInputPlaceholder = 'Search';
        /** Input - for global search autocomplete ( search result section ) : string type and default value */
        this.globalSearchAutocompleteID = 'cgi-global-search-autocomplete';
        /** Input - for i18n : show more results message */
        this.moreResults = 'Show more results...';
        /** Input - for i18n : no results message */
        this.noResults = 'Sorry, no results have been found.';
        /** Input - specifies the number of results to display in dropdown panel  */
        this.resultLimit = 10;
        /** Output - variable for checking a category is selected or not  */
        this.optionSelected = new EventEmitter();
        /** Output - variable for emitting search to app-shell  */
        this.search = new EventEmitter();
        this.isClassContainer = true;
        this.isSearchToggled = false;
        this.globalSearchId = "global-search-component" /* PageLandmarks.GLOBAL_SEARCH */;
        this.globalSearch = fb.group({
            category: '',
            searchString: '',
        });
    }
    /** when search bar is loaded, displayFn() set up first value in searchString */
    displayFn() {
        return '';
    }
    /** Initialization block when component is loaded */
    ngOnInit() {
        /** setting categories on global search category selection */
        this.globalSearch.get('category').setValue(this.categories[0].value);
    }
    /** Initialization block after view has been rendered */
    ngAfterViewInit() {
        this.globalSearch
            .get('category')
            .valueChanges.pipe(tap(() => {
            this.loadSearchResults();
        }))
            .subscribe();
        this.globalSearch
            .get('searchString')
            .valueChanges.pipe(startWith(''), debounceTime(800), distinctUntilChanged(), tap(() => {
            this.loadSearchResults();
        }))
            .subscribe();
    }
    /**
     * Callback function to call when form values change, and emit the form group as an output
     */
    loadSearchResults() {
        this.search.emit({
            globalSearch: this.globalSearch,
        });
    }
    /**
     * Navigation link for more results button
     */
    gotoLink(link, queryKey = null) {
        if (queryKey) {
            this.router.navigate([link], {
                queryParams: { [queryKey]: this.globalSearch.get('searchString').value },
            });
        }
        else {
            this.router.navigate([link]);
        }
        this.trigger.closePanel();
    }
    /**
     * Callback function for selecting an option from Autocomplete, and return the data in the following format as output
     * {searchText, category, entity, isShowMore}
     * @param category Category selected in the dropdown
     * @param entity Search result selected in the autocomplete
     * @param isShowMore Select to show more results
     */
    onEnter(category, entity, isShowMore = false) {
        const searchText = this.globalSearch.get('searchString').value;
        const event = { searchText, category, entity, isShowMore };
        this.optionSelected.emit(event);
    }
    /**
     * Method for displaying search on small screens
     */
    toggle() {
        this.isSearchToggled = !this.isSearchToggled;
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.2", ngImport: i0, type: CgiGlobalSearchComponent, deps: [{ token: i1$2.UntypedFormBuilder }, { token: i2.Router }], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "20.3.2", type: CgiGlobalSearchComponent, isStandalone: false, selector: "cgi-global-search", inputs: { categories: "categories", enableCategory: "enableCategory", isLoading: "isLoading", globalSearchResult: "globalSearchResult", globalSearchResultSize: "globalSearchResultSize", panelWidth: "panelWidth", selectorAriaLabel: "selectorAriaLabel", globalSearchSelectID: "globalSearchSelectID", globalSearchInputID: "globalSearchInputID", globalSearchInputPlaceholder: "globalSearchInputPlaceholder", globalSearchAutocompleteID: "globalSearchAutocompleteID", moreResults: "moreResults", noResults: "noResults", resultLimit: "resultLimit", subTemplate: "subTemplate" }, outputs: { optionSelected: "optionSelected", search: "search" }, host: { properties: { "class.cgi-global-search": "this.isClassContainer" } }, viewQueries: [{ propertyName: "trigger", first: true, predicate: MatAutocompleteTrigger, descendants: true }], ngImport: i0, template: "<div [attr.id]=\"globalSearchId\" class=\"row cgi-global-search__container\">\n  <button\n    class=\"cgi-global-search__toggle\"\n    aria-label=\"Search Icon\"\n    mat-icon-button\n    (click)=\"toggle()\"\n  >\n    <mat-icon>search</mat-icon>\n  </button>\n  <form\n    [formGroup]=\"globalSearch\"\n    [ngClass]=\"isSearchToggled ? 'cgi-global-search--toggled-on' : 'cgi-global-search--toggled-off'\"\n  >\n    <mat-form-field\n      class=\"col-4 cgi-global-search__category-option\"\n      appearance=\"outline\"\n      *ngIf=\"enableCategory\"\n    >\n      <mat-select\n        formControlName=\"category\"\n        [id]=\"globalSearchSelectID\"\n        [aria-label]=\"selectorAriaLabel\"\n      >\n        <mat-option *ngFor=\"let category of categories\" value=\"{{ category.value }}\">\n          {{ category.name }}</mat-option\n        >\n      </mat-select>\n    </mat-form-field>\n    <!-- flexible search bar size -->\n    <mat-form-field\n      [ngClass]=\"enableCategory ? 'col-8 cgi-global-search__search-section' : 'col-12'\"\n      appearance=\"outline\"\n      floatLabel=\"never\"\n    >\n      <button type=\"submit\" aria-label=\"Search Icon\" mat-icon-button matSuffix disableRipple=\"true\">\n        <mat-icon>search</mat-icon>\n      </button>\n      <input\n        [id]=\"globalSearchInputID\"\n        type=\"text\"\n        matInput\n        [placeholder]=\"globalSearchInputPlaceholder\"\n        formControlName=\"searchString\"\n        [matAutocomplete]=\"searchResults\"\n        aria-label=\"Global Search Field\"\n      />\n      <mat-autocomplete\n        [id]=\"globalSearchAutocompleteID\"\n        #searchResults=\"matAutocomplete\"\n        [displayWith]=\"displayFn\"\n        class=\"cgi-global-search-autocomplete\"\n        [panelWidth]=\"panelWidth\"\n      >\n        <mat-option class=\"cgi-global-search__spinner\" *ngIf=\"isLoading\" disabled=\"true\">\n          <mat-spinner diameter=\"80\"></mat-spinner>\n        </mat-option>\n\n        <mat-option\n          *ngIf=\"\n            globalSearch.get('searchString').value && !isLoading && globalSearchResultSize === 0\n          \"\n          class=\"cgi-global-search__no-results\"\n        >\n          {{ noResults }}\n        </mat-option>\n        <!-- for searching with category -->\n        <ng-container\n          *ngIf=\"globalSearch.get('searchString').value && !isLoading && enableCategory\"\n        >\n          <mat-optgroup *ngFor=\"let group of globalSearchResult\">\n            <mat-icon\n              *ngIf=\"group.category.icon\"\n              fontSet=\"far\"\n              fontIcon=\"{{ group.category.icon }}\"\n            ></mat-icon>\n            {{ group.category.name }}\n            <mat-option\n              *ngFor=\"let content of group.contents | slice : 0 : resultLimit; let i = index\"\n              (onSelectionChange)=\"onEnter(group.category, content)\"\n            >\n              <p>{{ content.name }}</p>\n              <ng-container *ngIf=\"subTemplate; then subTemp; else subCode\"></ng-container>\n\n              <ng-template #subTemp\n                ><ng-container [ngTemplateOutlet]=\"subTemplate\"></ng-container\n              ></ng-template>\n              <ng-template #subCode>\n                <p class=\"cgi-global-search--sub-code\">{{ content.code }}</p>\n              </ng-template>\n            </mat-option>\n            <!-- Result limit on categories -->\n            <ng-container *ngIf=\"group.totalRecords > resultLimit\">\n              <button\n                color=\"accent\"\n                mat-button\n                (click)=\"\n                  group.category.moreResultsLink\n                    ? gotoLink(group.category.moreResultsLink, group.category.queryParamKey)\n                    : (group.expandCategory = !group.expandCategory)\n                \"\n                [class.d-none]=\"group.expandCategory\"\n              >\n                {{ moreResults }}\n              </button>\n            </ng-container>\n            <ng-container *ngIf=\"group.expandCategory\">\n              <mat-option\n                *ngFor=\"let content of group.contents | slice : resultLimit; let i = index\"\n                (onSelectionChange)=\"onEnter(group.category, content, true)\"\n              >\n                <p>{{ content.name }}</p>\n                <ng-container *ngIf=\"subTemplate; then subTemp; else subCode\"></ng-container>\n\n                <ng-template #subTemp\n                  ><ng-container *ngTemplateOutlet=\"subTemplate\"></ng-container\n                ></ng-template>\n                <ng-template #subCode>\n                  <p class=\"cgi-global-search--sub-code\">{{ content.code }}</p>\n                </ng-template>\n              </mat-option>\n            </ng-container>\n            <!-- -->\n          </mat-optgroup>\n        </ng-container>\n        <!-- -->\n        <!-- for searching without category -->\n        <ng-container\n          *ngIf=\"globalSearch.get('searchString').value && !isLoading && !enableCategory\"\n        >\n          <div *ngFor=\"let group of globalSearchResult\">\n            <mat-option\n              *ngFor=\"let content of group.contents\"\n              (onSelectionChange)=\"onEnter(group.category, content)\"\n            >\n              <p class=\"cgi-body-1\">\n                {{ content.name }} &nbsp;\n                <ng-container *ngIf=\"subTemplate; then subTemp; else subCode\"></ng-container>\n              </p>\n\n              <ng-template #subTemp\n                ><ng-template *ngTemplateOutlet=\"subTemplate\"></ng-template\n              ></ng-template>\n              <ng-template #subCode>\n                <span class=\"cgi-body-1 cgi-global-search--sub-code\">{{ content.code }}</span>\n              </ng-template>\n            </mat-option>\n          </div>\n        </ng-container>\n        <!-- -->\n      </mat-autocomplete>\n    </mat-form-field>\n  </form>\n</div>\n", styles: [":host(.cgi-global-search){font-size:13px}:host(.cgi-global-search) ::ng-deep .cgi-global-search__container .cgi-global-search__toggle{display:none}:host(.cgi-global-search) ::ng-deep .cgi-global-search__container .mat-form-field-wrapper{padding-bottom:0}:host(.cgi-global-search) ::ng-deep .cgi-global-search__container .mat-form-field-suffix .mat-mdc-icon-button .mat-icon{color:#3d4f68}:host(.cgi-global-search) ::ng-deep .cgi-global-search__container .cgi-global-search__category-option{padding-right:0}:host(.cgi-global-search) ::ng-deep .cgi-global-search__container .cgi-global-search__category-option .mat-form-field-outline-end{border-radius:0}:host(.cgi-global-search) ::ng-deep .cgi-global-search__container .cgi-global-search__search-section{padding-left:0}:host(.cgi-global-search) ::ng-deep .cgi-global-search__container .cgi-global-search__search-section .mat-form-field-outline-start{border-radius:0}.cgi-nav-content :host(.cgi-global-search) ::ng-deep .cgi-global-search__container .mat-mdc-icon-button{margin:0}@media (max-width: 959px){:host(.cgi-global-search) ::ng-deep .cgi-global-search__container .cgi-global-search__toggle{display:inline-block}:host(.cgi-global-search) ::ng-deep .cgi-global-search__container .cgi-global-search--toggled-off{display:none}:host(.cgi-global-search) ::ng-deep .cgi-global-search__container .cgi-global-search--toggled-on{background-color:#fff;border:1px solid #ced2d4;border-radius:5px;box-shadow:0 2px 5px #696c6e45;display:block;max-width:100vw;padding:4px;position:absolute;right:0;top:64px}:host(.cgi-global-search) ::ng-deep .cgi-global-search__container .cgi-global-search--toggled-on .mat-mdc-form-field{padding:0}:host(.cgi-global-search) ::ng-deep .cgi-global-search__container .cgi-global-search--toggled-on .mat-form-field-wrapper{margin:0}}\n"], dependencies: [{ kind: "directive", type: i1.NgClass, selector: "[ngClass]", inputs: ["class", "ngClass"] }, { kind: "directive", type: i1.NgForOf, selector: "[ngFor][ngForOf]", inputs: ["ngForOf", "ngForTrackBy", "ngForTemplate"] }, { kind: "directive", type: i1.NgIf, selector: "[ngIf]", inputs: ["ngIf", "ngIfThen", "ngIfElse"] }, { kind: "directive", type: i1.NgTemplateOutlet, selector: "[ngTemplateOutlet]", inputs: ["ngTemplateOutletContext", "ngTemplateOutlet", "ngTemplateOutletInjector"] }, { kind: "component", type: i4.MatButton, selector: "    button[matButton], a[matButton], button[mat-button], button[mat-raised-button],    button[mat-flat-button], button[mat-stroked-button], a[mat-button], a[mat-raised-button],    a[mat-flat-button], a[mat-stroked-button]  ", inputs: ["matButton"], exportAs: ["matButton", "matAnchor"] }, { kind: "component", type: i4.MatIconButton, selector: "button[mat-icon-button], a[mat-icon-button], button[matIconButton], a[matIconButton]", exportAs: ["matButton", "matAnchor"] }, { kind: "component", type: i5.MatIcon, selector: "mat-icon", inputs: ["color", "inline", "svgIcon", "fontSet", "fontIcon"], exportAs: ["matIcon"] }, { kind: "directive", type: i1$2.ɵNgNoValidate, selector: "form:not([ngNoForm]):not([ngNativeValidate])" }, { kind: "directive", type: i1$2.DefaultValueAccessor, selector: "input:not([type=checkbox])[formControlName],textarea[formControlName],input:not([type=checkbox])[formControl],textarea[formControl],input:not([type=checkbox])[ngModel],textarea[ngModel],[ngDefaultControl]" }, { kind: "directive", type: i1$2.NgControlStatus, selector: "[formControlName],[ngModel],[formControl]" }, { kind: "directive", type: i1$2.NgControlStatusGroup, selector: "[formGroupName],[formArrayName],[ngModelGroup],[formGroup],form:not([ngNoForm]),[ngForm]" }, { kind: "directive", type: i1$2.FormGroupDirective, selector: "[formGroup]", inputs: ["formGroup"], outputs: ["ngSubmit"], exportAs: ["ngForm"] }, { kind: "directive", type: i1$2.FormControlName, selector: "[formControlName]", inputs: ["formControlName", "disabled", "ngModel"], outputs: ["ngModelChange"] }, { kind: "component", type: i6.MatAutocomplete, selector: "mat-autocomplete", inputs: ["aria-label", "aria-labelledby", "displayWith", "autoActiveFirstOption", "autoSelectActiveOption", "requireSelection", "panelWidth", "disableRipple", "class", "hideSingleSelectionIndicator"], outputs: ["optionSelected", "opened", "closed", "optionActivated"], exportAs: ["matAutocomplete"] }, { kind: "component", type: i6.MatOption, selector: "mat-option", inputs: ["value", "id", "disabled"], outputs: ["onSelectionChange"], exportAs: ["matOption"] }, { kind: "component", type: i6.MatOptgroup, selector: "mat-optgroup", inputs: ["label", "disabled"], exportAs: ["matOptgroup"] }, { kind: "directive", type: i6.MatAutocompleteTrigger, selector: "input[matAutocomplete], textarea[matAutocomplete]", inputs: ["matAutocomplete", "matAutocompletePosition", "matAutocompleteConnectedTo", "autocomplete", "matAutocompleteDisabled"], exportAs: ["matAutocompleteTrigger"] }, { kind: "component", type: i8.MatFormField, selector: "mat-form-field", inputs: ["hideRequiredMarker", "color", "floatLabel", "appearance", "subscriptSizing", "hintLabel"], exportAs: ["matFormField"] }, { kind: "directive", type: i8.MatSuffix, selector: "[matSuffix], [matIconSuffix], [matTextSuffix]", inputs: ["matTextSuffix"] }, { kind: "component", type: i8.MatSelect, selector: "mat-select", inputs: ["aria-describedby", "panelClass", "disabled", "disableRipple", "tabIndex", "hideSingleSelectionIndicator", "placeholder", "required", "multiple", "disableOptionCentering", "compareWith", "value", "aria-label", "aria-labelledby", "errorStateMatcher", "typeaheadDebounceInterval", "sortComparator", "id", "panelWidth", "canSelectNullableOptions"], outputs: ["openedChange", "opened", "closed", "selectionChange", "valueChange"], exportAs: ["matSelect"] }, { kind: "directive", type: i4$3.MatInput, selector: "input[matInput], textarea[matInput], select[matNativeControl],      input[matNativeControl], textarea[matNativeControl]", inputs: ["disabled", "id", "placeholder", "name", "required", "type", "errorStateMatcher", "aria-describedby", "value", "readonly", "disabledInteractive"], exportAs: ["matInput"] }, { kind: "component", type: i9.MatProgressSpinner, selector: "mat-progress-spinner, mat-spinner", inputs: ["color", "mode", "value", "diameter", "strokeWidth"], exportAs: ["matProgressSpinner"] }, { kind: "pipe", type: i1.SlicePipe, name: "slice" }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.2", ngImport: i0, type: CgiGlobalSearchComponent, decorators: [{
            type: Component,
            args: [{ selector: 'cgi-global-search', standalone: false, template: "<div [attr.id]=\"globalSearchId\" class=\"row cgi-global-search__container\">\n  <button\n    class=\"cgi-global-search__toggle\"\n    aria-label=\"Search Icon\"\n    mat-icon-button\n    (click)=\"toggle()\"\n  >\n    <mat-icon>search</mat-icon>\n  </button>\n  <form\n    [formGroup]=\"globalSearch\"\n    [ngClass]=\"isSearchToggled ? 'cgi-global-search--toggled-on' : 'cgi-global-search--toggled-off'\"\n  >\n    <mat-form-field\n      class=\"col-4 cgi-global-search__category-option\"\n      appearance=\"outline\"\n      *ngIf=\"enableCategory\"\n    >\n      <mat-select\n        formControlName=\"category\"\n        [id]=\"globalSearchSelectID\"\n        [aria-label]=\"selectorAriaLabel\"\n      >\n        <mat-option *ngFor=\"let category of categories\" value=\"{{ category.value }}\">\n          {{ category.name }}</mat-option\n        >\n      </mat-select>\n    </mat-form-field>\n    <!-- flexible search bar size -->\n    <mat-form-field\n      [ngClass]=\"enableCategory ? 'col-8 cgi-global-search__search-section' : 'col-12'\"\n      appearance=\"outline\"\n      floatLabel=\"never\"\n    >\n      <button type=\"submit\" aria-label=\"Search Icon\" mat-icon-button matSuffix disableRipple=\"true\">\n        <mat-icon>search</mat-icon>\n      </button>\n      <input\n        [id]=\"globalSearchInputID\"\n        type=\"text\"\n        matInput\n        [placeholder]=\"globalSearchInputPlaceholder\"\n        formControlName=\"searchString\"\n        [matAutocomplete]=\"searchResults\"\n        aria-label=\"Global Search Field\"\n      />\n      <mat-autocomplete\n        [id]=\"globalSearchAutocompleteID\"\n        #searchResults=\"matAutocomplete\"\n        [displayWith]=\"displayFn\"\n        class=\"cgi-global-search-autocomplete\"\n        [panelWidth]=\"panelWidth\"\n      >\n        <mat-option class=\"cgi-global-search__spinner\" *ngIf=\"isLoading\" disabled=\"true\">\n          <mat-spinner diameter=\"80\"></mat-spinner>\n        </mat-option>\n\n        <mat-option\n          *ngIf=\"\n            globalSearch.get('searchString').value && !isLoading && globalSearchResultSize === 0\n          \"\n          class=\"cgi-global-search__no-results\"\n        >\n          {{ noResults }}\n        </mat-option>\n        <!-- for searching with category -->\n        <ng-container\n          *ngIf=\"globalSearch.get('searchString').value && !isLoading && enableCategory\"\n        >\n          <mat-optgroup *ngFor=\"let group of globalSearchResult\">\n            <mat-icon\n              *ngIf=\"group.category.icon\"\n              fontSet=\"far\"\n              fontIcon=\"{{ group.category.icon }}\"\n            ></mat-icon>\n            {{ group.category.name }}\n            <mat-option\n              *ngFor=\"let content of group.contents | slice : 0 : resultLimit; let i = index\"\n              (onSelectionChange)=\"onEnter(group.category, content)\"\n            >\n              <p>{{ content.name }}</p>\n              <ng-container *ngIf=\"subTemplate; then subTemp; else subCode\"></ng-container>\n\n              <ng-template #subTemp\n                ><ng-container [ngTemplateOutlet]=\"subTemplate\"></ng-container\n              ></ng-template>\n              <ng-template #subCode>\n                <p class=\"cgi-global-search--sub-code\">{{ content.code }}</p>\n              </ng-template>\n            </mat-option>\n            <!-- Result limit on categories -->\n            <ng-container *ngIf=\"group.totalRecords > resultLimit\">\n              <button\n                color=\"accent\"\n                mat-button\n                (click)=\"\n                  group.category.moreResultsLink\n                    ? gotoLink(group.category.moreResultsLink, group.category.queryParamKey)\n                    : (group.expandCategory = !group.expandCategory)\n                \"\n                [class.d-none]=\"group.expandCategory\"\n              >\n                {{ moreResults }}\n              </button>\n            </ng-container>\n            <ng-container *ngIf=\"group.expandCategory\">\n              <mat-option\n                *ngFor=\"let content of group.contents | slice : resultLimit; let i = index\"\n                (onSelectionChange)=\"onEnter(group.category, content, true)\"\n              >\n                <p>{{ content.name }}</p>\n                <ng-container *ngIf=\"subTemplate; then subTemp; else subCode\"></ng-container>\n\n                <ng-template #subTemp\n                  ><ng-container *ngTemplateOutlet=\"subTemplate\"></ng-container\n                ></ng-template>\n                <ng-template #subCode>\n                  <p class=\"cgi-global-search--sub-code\">{{ content.code }}</p>\n                </ng-template>\n              </mat-option>\n            </ng-container>\n            <!-- -->\n          </mat-optgroup>\n        </ng-container>\n        <!-- -->\n        <!-- for searching without category -->\n        <ng-container\n          *ngIf=\"globalSearch.get('searchString').value && !isLoading && !enableCategory\"\n        >\n          <div *ngFor=\"let group of globalSearchResult\">\n            <mat-option\n              *ngFor=\"let content of group.contents\"\n              (onSelectionChange)=\"onEnter(group.category, content)\"\n            >\n              <p class=\"cgi-body-1\">\n                {{ content.name }} &nbsp;\n                <ng-container *ngIf=\"subTemplate; then subTemp; else subCode\"></ng-container>\n              </p>\n\n              <ng-template #subTemp\n                ><ng-template *ngTemplateOutlet=\"subTemplate\"></ng-template\n              ></ng-template>\n              <ng-template #subCode>\n                <span class=\"cgi-body-1 cgi-global-search--sub-code\">{{ content.code }}</span>\n              </ng-template>\n            </mat-option>\n          </div>\n        </ng-container>\n        <!-- -->\n      </mat-autocomplete>\n    </mat-form-field>\n  </form>\n</div>\n", styles: [":host(.cgi-global-search){font-size:13px}:host(.cgi-global-search) ::ng-deep .cgi-global-search__container .cgi-global-search__toggle{display:none}:host(.cgi-global-search) ::ng-deep .cgi-global-search__container .mat-form-field-wrapper{padding-bottom:0}:host(.cgi-global-search) ::ng-deep .cgi-global-search__container .mat-form-field-suffix .mat-mdc-icon-button .mat-icon{color:#3d4f68}:host(.cgi-global-search) ::ng-deep .cgi-global-search__container .cgi-global-search__category-option{padding-right:0}:host(.cgi-global-search) ::ng-deep .cgi-global-search__container .cgi-global-search__category-option .mat-form-field-outline-end{border-radius:0}:host(.cgi-global-search) ::ng-deep .cgi-global-search__container .cgi-global-search__search-section{padding-left:0}:host(.cgi-global-search) ::ng-deep .cgi-global-search__container .cgi-global-search__search-section .mat-form-field-outline-start{border-radius:0}.cgi-nav-content :host(.cgi-global-search) ::ng-deep .cgi-global-search__container .mat-mdc-icon-button{margin:0}@media (max-width: 959px){:host(.cgi-global-search) ::ng-deep .cgi-global-search__container .cgi-global-search__toggle{display:inline-block}:host(.cgi-global-search) ::ng-deep .cgi-global-search__container .cgi-global-search--toggled-off{display:none}:host(.cgi-global-search) ::ng-deep .cgi-global-search__container .cgi-global-search--toggled-on{background-color:#fff;border:1px solid #ced2d4;border-radius:5px;box-shadow:0 2px 5px #696c6e45;display:block;max-width:100vw;padding:4px;position:absolute;right:0;top:64px}:host(.cgi-global-search) ::ng-deep .cgi-global-search__container .cgi-global-search--toggled-on .mat-mdc-form-field{padding:0}:host(.cgi-global-search) ::ng-deep .cgi-global-search__container .cgi-global-search--toggled-on .mat-form-field-wrapper{margin:0}}\n"] }]
        }], ctorParameters: () => [{ type: i1$2.UntypedFormBuilder }, { type: i2.Router }], propDecorators: { isClassContainer: [{
                type: HostBinding,
                args: ['class.cgi-global-search']
            }], categories: [{
                type: Input
            }], enableCategory: [{
                type: Input
            }], isLoading: [{
                type: Input
            }], globalSearchResult: [{
                type: Input
            }], globalSearchResultSize: [{
                type: Input
            }], panelWidth: [{
                type: Input
            }], selectorAriaLabel: [{
                type: Input
            }], globalSearchSelectID: [{
                type: Input
            }], globalSearchInputID: [{
                type: Input
            }], globalSearchInputPlaceholder: [{
                type: Input
            }], globalSearchAutocompleteID: [{
                type: Input
            }], moreResults: [{
                type: Input
            }], noResults: [{
                type: Input
            }], resultLimit: [{
                type: Input
            }], subTemplate: [{
                type: Input
            }], optionSelected: [{
                type: Output
            }], search: [{
                type: Output
            }], 
        /** variable for trigger  */
        trigger: [{
                type: ViewChild,
                args: [MatAutocompleteTrigger]
            }] } });

class CGIGlobalSearchModule {
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.2", ngImport: i0, type: CGIGlobalSearchModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule }); }
    static { this.ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "20.3.2", ngImport: i0, type: CGIGlobalSearchModule, declarations: [CgiGlobalSearchComponent], imports: [CommonModule,
            MatButtonModule,
            MatIconModule,
            FormsModule,
            ReactiveFormsModule,
            MatAutocompleteModule,
            MatSelectModule,
            MatFormFieldModule,
            MatInputModule,
            MatProgressSpinnerModule,
            RouterModule], exports: [CgiGlobalSearchComponent] }); }
    static { this.ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "20.3.2", ngImport: i0, type: CGIGlobalSearchModule, imports: [CommonModule,
            MatButtonModule,
            MatIconModule,
            FormsModule,
            ReactiveFormsModule,
            MatAutocompleteModule,
            MatSelectModule,
            MatFormFieldModule,
            MatInputModule,
            MatProgressSpinnerModule,
            RouterModule] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.2", ngImport: i0, type: CGIGlobalSearchModule, decorators: [{
            type: NgModule,
            args: [{
                    imports: [
                        CommonModule,
                        MatButtonModule,
                        MatIconModule,
                        FormsModule,
                        ReactiveFormsModule,
                        MatAutocompleteModule,
                        MatSelectModule,
                        MatFormFieldModule,
                        MatInputModule,
                        MatProgressSpinnerModule,
                        RouterModule,
                    ],
                    declarations: [CgiGlobalSearchComponent],
                    exports: [CgiGlobalSearchComponent],
                }]
        }] });

/**
 * Click Outside Directive that emits an event whenever a target element is clicked.
 */
class CGIClickOutsideDirective {
    /**
     * Constructor for Click Outside Directive
     * @param _elementRef Reference to element the directive is declared in
     */
    constructor(_elementRef) {
        this._elementRef = _elementRef;
        /** Output event for when the user clicks outside the selected element */
        this.cgiClickOutside = new EventEmitter();
        /** Boolean to tell if the overlay has opened yet */
        this.hasOpened = false;
    }
    /** On click function that runs everytime the document is clicked */
    onClick(event, targetElement) {
        if (targetElement) {
            const clickedInside = this._elementRef.nativeElement.contains(targetElement);
            // If the user clicks outside of the target element and the
            // overlay has opened at least once then emit an event to the parent component
            if (!clickedInside && this.hasOpened) {
                this.cgiClickOutside.emit(event);
            }
            // Overlay has opened once so set the boolean to true
            this.hasOpened = true;
        }
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.2", ngImport: i0, type: CGIClickOutsideDirective, deps: [{ token: i0.ElementRef }], target: i0.ɵɵFactoryTarget.Directive }); }
    static { this.ɵdir = i0.ɵɵngDeclareDirective({ minVersion: "14.0.0", version: "20.3.2", type: CGIClickOutsideDirective, isStandalone: false, selector: "[cgiClickOutside]", outputs: { cgiClickOutside: "cgiClickOutside" }, host: { listeners: { "document:click": "onClick($event,$event.target)" } }, ngImport: i0 }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.2", ngImport: i0, type: CGIClickOutsideDirective, decorators: [{
            type: Directive,
            args: [{
                    selector: '[cgiClickOutside]',
                    standalone: false
                }]
        }], ctorParameters: () => [{ type: i0.ElementRef }], propDecorators: { cgiClickOutside: [{
                type: Output
            }], onClick: [{
                type: HostListener,
                args: ['document:click', ['$event', '$event.target']]
            }] } });

/**
 * Popover Content component.
 */
class CGIPopoverContentComponent {
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.2", ngImport: i0, type: CGIPopoverContentComponent, deps: [], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "20.3.2", type: CGIPopoverContentComponent, isStandalone: false, selector: "cgi-popover-content", ngImport: i0, template: "<ng-content></ng-content>\n", styles: [""] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.2", ngImport: i0, type: CGIPopoverContentComponent, decorators: [{
            type: Component,
            args: [{ selector: 'cgi-popover-content', standalone: false, template: "<ng-content></ng-content>\n" }]
        }] });

/**
 * Popover Footer component.
 */
class CGIPopoverFooterComponent {
    /**
     * Constructor for popover footer
     */
    constructor() {
        this.isClassContainer = true;
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.2", ngImport: i0, type: CGIPopoverFooterComponent, deps: [], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "20.3.2", type: CGIPopoverFooterComponent, isStandalone: false, selector: "cgi-popover-footer", host: { properties: { "class.cgi-popover-footer": "this.isClassContainer" } }, ngImport: i0, template: "<div class=\"cgi-popover-footer__button-group\">\n  <ng-content></ng-content>\n</div>\n", styles: [":host(.cgi-popover-footer){display:flex;justify-content:flex-end}\n"] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.2", ngImport: i0, type: CGIPopoverFooterComponent, decorators: [{
            type: Component,
            args: [{ selector: 'cgi-popover-footer', standalone: false, template: "<div class=\"cgi-popover-footer__button-group\">\n  <ng-content></ng-content>\n</div>\n", styles: [":host(.cgi-popover-footer){display:flex;justify-content:flex-end}\n"] }]
        }], ctorParameters: () => [], propDecorators: { isClassContainer: [{
                type: HostBinding,
                args: ['class.cgi-popover-footer']
            }] } });

/**
 * Popover Header component.
 */
class CGIPopoverHeaderComponent {
    /**
     * Constructor for popover header
     */
    constructor() {
        /** Output event for when the popover is closed */
        this.popoverClose = new EventEmitter();
        this.isClassContainer = true;
    }
    /** Close method for when the close button is clicked */
    closePopover() {
        this.popoverClose.emit();
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.2", ngImport: i0, type: CGIPopoverHeaderComponent, deps: [], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "20.3.2", type: CGIPopoverHeaderComponent, isStandalone: false, selector: "cgi-popover-header", outputs: { popoverClose: "popoverClose" }, host: { properties: { "class.cgi-popover-header": "this.isClassContainer" } }, ngImport: i0, template: "<div class=\"cgi-popover-header__title\">\n  <ng-content></ng-content>\n  <span class=\"cgi-popover-header__spacer\"></span>\n  <button\n    mat-icon-button\n    (click)=\"closePopover()\"\n    class=\"cgi-popover-header__close-button\"\n    aria-label=\"Close Popover\"\n    autofocus\n  >\n    <mat-icon>close</mat-icon>\n  </button>\n</div>\n", styles: [":host(.cgi-popover-header) .cgi-popover-header__title{align-items:center;color:#13283e;display:flex;font-size:16px;font-weight:700}:host(.cgi-popover-header) .cgi-popover-header__spacer{flex:1 1 auto}:host(.cgi-popover-header) .cgi-popover-header__close-button{height:18px;line-height:18px;width:18px}:host(.cgi-popover-header) .cgi-popover-header__close-button mat-icon{color:#13283e;font-size:18px;height:18px;line-height:18px;width:18px}\n"], dependencies: [{ kind: "component", type: i4.MatIconButton, selector: "button[mat-icon-button], a[mat-icon-button], button[matIconButton], a[matIconButton]", exportAs: ["matButton", "matAnchor"] }, { kind: "component", type: i5.MatIcon, selector: "mat-icon", inputs: ["color", "inline", "svgIcon", "fontSet", "fontIcon"], exportAs: ["matIcon"] }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.2", ngImport: i0, type: CGIPopoverHeaderComponent, decorators: [{
            type: Component,
            args: [{ selector: 'cgi-popover-header', standalone: false, template: "<div class=\"cgi-popover-header__title\">\n  <ng-content></ng-content>\n  <span class=\"cgi-popover-header__spacer\"></span>\n  <button\n    mat-icon-button\n    (click)=\"closePopover()\"\n    class=\"cgi-popover-header__close-button\"\n    aria-label=\"Close Popover\"\n    autofocus\n  >\n    <mat-icon>close</mat-icon>\n  </button>\n</div>\n", styles: [":host(.cgi-popover-header) .cgi-popover-header__title{align-items:center;color:#13283e;display:flex;font-size:16px;font-weight:700}:host(.cgi-popover-header) .cgi-popover-header__spacer{flex:1 1 auto}:host(.cgi-popover-header) .cgi-popover-header__close-button{height:18px;line-height:18px;width:18px}:host(.cgi-popover-header) .cgi-popover-header__close-button mat-icon{color:#13283e;font-size:18px;height:18px;line-height:18px;width:18px}\n"] }]
        }], ctorParameters: () => [], propDecorators: { isClassContainer: [{
                type: HostBinding,
                args: ['class.cgi-popover-header']
            }], popoverClose: [{
                type: Output
            }] } });

/**
 * Popover component.
 */
class CGIPopoverComponent {
    /** Constructor for Popover Component
     * @param _focusTrapFactory Create focus trap service for a11y
     * @param document Allows for focus trap within the component
     */
    constructor(_focusTrapFactory, document) {
        this._focusTrapFactory = _focusTrapFactory;
        this.document = document;
        /** The width of the popover */
        this.popoverWidth = 300;
        /** Boolean for whether the popover is open or closed */
        this.isPopoverOpen = false;
        /** Output event for when the popover is closed */
        this.popoverClose = new EventEmitter();
        /** variable keeps track of trapping popover */
        this.restoreTrap = true;
        /** Current state of the popover animation. */
        this.popoverAnimationState = 'enter';
        /** Element that was focused before the popover was opened. Save this to restore upon close. */
        this._elementFocusedBeforeDialogWasOpened = null;
    }
    /** called when overlay is attached */
    overlayAttached() {
        this.focusButton();
    }
    /** called when overlay is detached */
    overlayDetached() {
        this.restoreFocus();
    }
    /** Close method for when the popover is closed by clicking outside */
    closePopover() {
        this.isPopoverOpen = false;
        this.popoverClose.emit();
    }
    /** Sets focus to the closing button on popover */
    focusButton() {
        this._elementFocusedBeforeDialogWasOpened = this.document.activeElement;
        this.closeButton = this.document.querySelector('.cgi-popover-header__close-button');
        this.createTrapFocus();
    }
    /** creates focus to the popover that was opened. */
    createTrapFocus() {
        if (!this._focusTrap || this.restoreTrap) {
            this._focusTrap = this._focusTrapFactory.create(this.document.querySelector('.cdk-overlay-pane'));
            this.restoreTrap = false;
        }
    }
    /** Restores focus to the element that was focused before the popover opened. */
    restoreFocus() {
        if (this._elementFocusedBeforeDialogWasOpened) {
            this._elementFocusedBeforeDialogWasOpened.focus();
        }
        if (!this._focusTrap) {
            this.restoreTrap = true;
        }
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.2", ngImport: i0, type: CGIPopoverComponent, deps: [{ token: i1$3.ConfigurableFocusTrapFactory }, { token: DOCUMENT }], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "20.3.2", type: CGIPopoverComponent, isStandalone: false, selector: "cgi-popover", inputs: { popoverName: "popoverName", popoverWidth: "popoverWidth", isPopoverOpen: "isPopoverOpen" }, outputs: { popoverClose: "popoverClose" }, ngImport: i0, template: "<ng-template\n  cdkConnectedOverlay\n  [cdkConnectedOverlayOrigin]=\"popoverName\"\n  [cdkConnectedOverlayWidth]=\"popoverWidth\"\n  [cdkConnectedOverlayOpen]=\"isPopoverOpen\"\n  (attach)=\"overlayAttached()\"\n  (detach)=\"overlayDetached()\"\n>\n  <div\n    role=\"dialog\"\n    *ngIf=\"isPopoverOpen\"\n    [@transformPopover]=\"popoverAnimationState\"\n    class=\"cgi-popover\"\n    (cgiClickOutside)=\"closePopover()\"\n    (keydown.escape)=\"closePopover()\"\n    (blur)=\"closePopover()\"\n  >\n    <ng-content></ng-content>\n  </div>\n</ng-template>\n", styles: [".cgi-popover{background-color:#fff;border-radius:2px;box-shadow:0 0 2px #0000001f,0 2px 2px #0000003d;padding:8px 15px}\n"], dependencies: [{ kind: "directive", type: i1.NgIf, selector: "[ngIf]", inputs: ["ngIf", "ngIfThen", "ngIfElse"] }, { kind: "directive", type: i3$1.CdkConnectedOverlay, selector: "[cdk-connected-overlay], [connected-overlay], [cdkConnectedOverlay]", inputs: ["cdkConnectedOverlayOrigin", "cdkConnectedOverlayPositions", "cdkConnectedOverlayPositionStrategy", "cdkConnectedOverlayOffsetX", "cdkConnectedOverlayOffsetY", "cdkConnectedOverlayWidth", "cdkConnectedOverlayHeight", "cdkConnectedOverlayMinWidth", "cdkConnectedOverlayMinHeight", "cdkConnectedOverlayBackdropClass", "cdkConnectedOverlayPanelClass", "cdkConnectedOverlayViewportMargin", "cdkConnectedOverlayScrollStrategy", "cdkConnectedOverlayOpen", "cdkConnectedOverlayDisableClose", "cdkConnectedOverlayTransformOriginOn", "cdkConnectedOverlayHasBackdrop", "cdkConnectedOverlayLockPosition", "cdkConnectedOverlayFlexibleDimensions", "cdkConnectedOverlayGrowAfterOpen", "cdkConnectedOverlayPush", "cdkConnectedOverlayDisposeOnNavigation"], outputs: ["backdropClick", "positionChange", "attach", "detach", "overlayKeydown", "overlayOutsideClick"], exportAs: ["cdkConnectedOverlay"] }, { kind: "directive", type: CGIClickOutsideDirective, selector: "[cgiClickOutside]", outputs: ["cgiClickOutside"] }], animations: [
            trigger('transformPopover', [
                state('void', style({
                    opacity: 0,
                    transform: 'scale(0.8)',
                })),
                transition('* => void', animate('100ms 25ms linear', style({ opacity: 0 }))),
            ]),
        ] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.2", ngImport: i0, type: CGIPopoverComponent, decorators: [{
            type: Component,
            args: [{ selector: 'cgi-popover', animations: [
                        trigger('transformPopover', [
                            state('void', style({
                                opacity: 0,
                                transform: 'scale(0.8)',
                            })),
                            transition('* => void', animate('100ms 25ms linear', style({ opacity: 0 }))),
                        ]),
                    ], standalone: false, template: "<ng-template\n  cdkConnectedOverlay\n  [cdkConnectedOverlayOrigin]=\"popoverName\"\n  [cdkConnectedOverlayWidth]=\"popoverWidth\"\n  [cdkConnectedOverlayOpen]=\"isPopoverOpen\"\n  (attach)=\"overlayAttached()\"\n  (detach)=\"overlayDetached()\"\n>\n  <div\n    role=\"dialog\"\n    *ngIf=\"isPopoverOpen\"\n    [@transformPopover]=\"popoverAnimationState\"\n    class=\"cgi-popover\"\n    (cgiClickOutside)=\"closePopover()\"\n    (keydown.escape)=\"closePopover()\"\n    (blur)=\"closePopover()\"\n  >\n    <ng-content></ng-content>\n  </div>\n</ng-template>\n", styles: [".cgi-popover{background-color:#fff;border-radius:2px;box-shadow:0 0 2px #0000001f,0 2px 2px #0000003d;padding:8px 15px}\n"] }]
        }], ctorParameters: () => [{ type: i1$3.ConfigurableFocusTrapFactory }, { type: undefined, decorators: [{
                    type: Inject,
                    args: [DOCUMENT]
                }] }], propDecorators: { popoverName: [{
                type: Input
            }], popoverWidth: [{
                type: Input
            }], isPopoverOpen: [{
                type: Input
            }], popoverClose: [{
                type: Output
            }] } });

class CGIPopoverModule {
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.2", ngImport: i0, type: CGIPopoverModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule }); }
    static { this.ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "20.3.2", ngImport: i0, type: CGIPopoverModule, declarations: [CGIPopoverComponent,
            CGIPopoverHeaderComponent,
            CGIPopoverContentComponent,
            CGIPopoverFooterComponent,
            CGIClickOutsideDirective], imports: [CommonModule, OverlayModule, MatButtonModule, MatIconModule], exports: [CGIPopoverComponent,
            CGIPopoverHeaderComponent,
            CGIPopoverContentComponent,
            CGIPopoverFooterComponent,
            CGIClickOutsideDirective] }); }
    static { this.ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "20.3.2", ngImport: i0, type: CGIPopoverModule, imports: [CommonModule, OverlayModule, MatButtonModule, MatIconModule] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.2", ngImport: i0, type: CGIPopoverModule, decorators: [{
            type: NgModule,
            args: [{
                    imports: [CommonModule, OverlayModule, MatButtonModule, MatIconModule],
                    declarations: [
                        CGIPopoverComponent,
                        CGIPopoverHeaderComponent,
                        CGIPopoverContentComponent,
                        CGIPopoverFooterComponent,
                        CGIClickOutsideDirective,
                    ],
                    exports: [
                        CGIPopoverComponent,
                        CGIPopoverHeaderComponent,
                        CGIPopoverContentComponent,
                        CGIPopoverFooterComponent,
                        CGIClickOutsideDirective,
                    ],
                    providers: [],
                }]
        }] });

/** Select Search component */
class CGISelectSearchComponent {
    /** Input - function for getting the filtered values using the search string */
    filterFunction(options, search) {
        return options.filter((option) => option.toLowerCase().includes(search));
    }
    /**
     * Constructor for CGISelectSearch component
     * @param matSelect reference to the MatSelect component paired with CGISelectSearch
     */
    constructor(matSelect) {
        this.matSelect = matSelect;
        /** Input - Placeholder text */
        this.placeholder = 'Search';
        /** Input - text for no results found */
        this.noResultsMessage = 'Sorry, no results were found that matches your search.';
        /** Output - event emitter that emits the filtered options */
        this.filterEvent = new EventEmitter();
        /** form control for the input field */
        this.inputFormControl = new UntypedFormControl();
        /** variable used to determine if no results message should be displayed */
        this.noResultsFound = false;
        /** subject that emits when the component is destroyed */
        this._onDestroy = new Subject();
        this.isClassContainer = true;
    }
    /** Initialization block when component is loaded */
    ngOnInit() {
        if (!this.ariaLabel) {
            this.ariaLabel =
                'Search field for ' + (this.matSelect.ariaLabel ? this.matSelect.ariaLabel : 'select menu');
        }
        this.matSelect.openedChange.pipe(takeUntil(this._onDestroy)).subscribe((opened) => {
            if (opened) {
                this.focus();
            }
            else {
                this.reset();
            }
        });
        if (this.options) {
            this.filterEvent.emit(this.options.slice());
        }
        this.inputFormControl.valueChanges
            .pipe(takeUntil(this._onDestroy), debounceTime(800), distinctUntilChanged())
            .subscribe((value) => this.filterOptions(value));
        this.filterEvent.pipe(takeUntil(this._onDestroy)).subscribe((value) => {
            this.noResultsFound = value.length === 0;
        });
        // when options change (ie. after filter), make the first option active so that keyboard events
        // are still propagated correctly
        this.matSelect.openedChange.pipe(take(1), takeUntil(this._onDestroy)).subscribe(() => {
            this.matSelect.options.changes.subscribe(() => {
                setTimeout(() => {
                    if (this.matSelect.panelOpen) {
                        this.matSelect._keyManager.setFirstItemActive();
                    }
                });
            });
        });
    }
    /** Lifecycle hook for when component is destroyed */
    ngOnDestroy() {
        this._onDestroy.next();
        this._onDestroy.complete();
    }
    /**
     * Intercept keyboard input when search field is active
     * @param event keyboard event
     */
    handleKeyDown(event) {
        // intercept space key to disable selecting an option with space while typing in the search field
        if (event.key === ' ' || event.key === 'Spacebar') {
            event.stopPropagation();
        }
    }
    /**
     * Filter the options list on the value of the search field
     */
    filterOptions(search) {
        if (!this.options) {
            return;
        }
        if (!search || search.length < 2) {
            this.filterEvent.emit(this.options.slice());
        }
        else {
            search = search.toLowerCase();
            this.filterEvent.emit(this.filterFunction(this.options, search));
        }
    }
    /**
     * Apply focus to the search field
     */
    focus() {
        if (!this.selectSearchInput) {
            return;
        }
        this.selectSearchInput.nativeElement.focus();
    }
    /**
     * Reset the value of the search field
     */
    reset() {
        this.inputFormControl.setValue('');
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.2", ngImport: i0, type: CGISelectSearchComponent, deps: [{ token: MatSelect }], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "20.3.2", type: CGISelectSearchComponent, isStandalone: false, selector: "cgi-select-search", inputs: { options: "options", placeholder: "placeholder", ariaLabel: "ariaLabel", noResultsMessage: "noResultsMessage", filterFunction: "filterFunction" }, outputs: { filterEvent: "filterEvent" }, host: { properties: { "class.cgi-select-search": "this.isClassContainer" } }, viewQueries: [{ propertyName: "selectSearchInput", first: true, predicate: ["selectSearchInput"], descendants: true, read: ElementRef }], ngImport: i0, template: "<mat-form-field floatLabel=\"never\">\n  <input\n    type=\"text\"\n    matInput\n    [formControl]=\"inputFormControl\"\n    #selectSearchInput\n    (keydown)=\"handleKeyDown($event)\"\n    [placeholder]=\"placeholder\"\n    [attr.aria-label]=\"ariaLabel\"\n  />\n</mat-form-field>\n<div *ngIf=\"selectSearchInput.value && noResultsFound\" class=\"cgi-select-search__no-results\">\n  {{ noResultsMessage }}\n</div>\n", styles: [":host(.cgi-select-search) .mat-mdc-form-field{width:100%}:host(.cgi-select-search) ::ng-deep .mat-form-field-wrapper{padding-bottom:0}:host(.cgi-select-search) ::ng-deep .mat-form-field-infix{padding-bottom:.6375em;padding-top:.2em}:host(.cgi-select-search) ::ng-deep .mat-form-field-underline{position:static}:host(.cgi-select-search) ::ng-deep .mat-input-element,:host(.cgi-select-search) ::ng-deep .mat-form-field-label{padding:0 16px}:host(.cgi-select-search) ::ng-deep .mat-form-field-underline .mat-form-field-ripple{display:none}:host(.cgi-select-search) ::ng-deep .cgi-select-search__no-results{padding:8px 16px}\n"], dependencies: [{ kind: "directive", type: i1.NgIf, selector: "[ngIf]", inputs: ["ngIf", "ngIfThen", "ngIfElse"] }, { kind: "directive", type: i1$2.DefaultValueAccessor, selector: "input:not([type=checkbox])[formControlName],textarea[formControlName],input:not([type=checkbox])[formControl],textarea[formControl],input:not([type=checkbox])[ngModel],textarea[ngModel],[ngDefaultControl]" }, { kind: "directive", type: i1$2.NgControlStatus, selector: "[formControlName],[ngModel],[formControl]" }, { kind: "directive", type: i1$2.FormControlDirective, selector: "[formControl]", inputs: ["formControl", "disabled", "ngModel"], outputs: ["ngModelChange"], exportAs: ["ngForm"] }, { kind: "component", type: i8.MatFormField, selector: "mat-form-field", inputs: ["hideRequiredMarker", "color", "floatLabel", "appearance", "subscriptSizing", "hintLabel"], exportAs: ["matFormField"] }, { kind: "directive", type: i4$3.MatInput, selector: "input[matInput], textarea[matInput], select[matNativeControl],      input[matNativeControl], textarea[matNativeControl]", inputs: ["disabled", "id", "placeholder", "name", "required", "type", "errorStateMatcher", "aria-describedby", "value", "readonly", "disabledInteractive"], exportAs: ["matInput"] }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.2", ngImport: i0, type: CGISelectSearchComponent, decorators: [{
            type: Component,
            args: [{ selector: 'cgi-select-search', standalone: false, template: "<mat-form-field floatLabel=\"never\">\n  <input\n    type=\"text\"\n    matInput\n    [formControl]=\"inputFormControl\"\n    #selectSearchInput\n    (keydown)=\"handleKeyDown($event)\"\n    [placeholder]=\"placeholder\"\n    [attr.aria-label]=\"ariaLabel\"\n  />\n</mat-form-field>\n<div *ngIf=\"selectSearchInput.value && noResultsFound\" class=\"cgi-select-search__no-results\">\n  {{ noResultsMessage }}\n</div>\n", styles: [":host(.cgi-select-search) .mat-mdc-form-field{width:100%}:host(.cgi-select-search) ::ng-deep .mat-form-field-wrapper{padding-bottom:0}:host(.cgi-select-search) ::ng-deep .mat-form-field-infix{padding-bottom:.6375em;padding-top:.2em}:host(.cgi-select-search) ::ng-deep .mat-form-field-underline{position:static}:host(.cgi-select-search) ::ng-deep .mat-input-element,:host(.cgi-select-search) ::ng-deep .mat-form-field-label{padding:0 16px}:host(.cgi-select-search) ::ng-deep .mat-form-field-underline .mat-form-field-ripple{display:none}:host(.cgi-select-search) ::ng-deep .cgi-select-search__no-results{padding:8px 16px}\n"] }]
        }], ctorParameters: () => [{ type: i8.MatSelect, decorators: [{
                    type: Inject,
                    args: [MatSelect]
                }] }], propDecorators: { isClassContainer: [{
                type: HostBinding,
                args: ['class.cgi-select-search']
            }], options: [{
                type: Input
            }], placeholder: [{
                type: Input
            }], ariaLabel: [{
                type: Input
            }], noResultsMessage: [{
                type: Input
            }], filterEvent: [{
                type: Output
            }], selectSearchInput: [{
                type: ViewChild,
                args: ['selectSearchInput', { read: ElementRef }]
            }], filterFunction: [{
                type: Input
            }] } });

class CGISelectSearchModule {
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.2", ngImport: i0, type: CGISelectSearchModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule }); }
    static { this.ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "20.3.2", ngImport: i0, type: CGISelectSearchModule, declarations: [CGISelectSearchComponent], imports: [CommonModule, ReactiveFormsModule, MatSelectModule, MatInputModule, MatFormFieldModule], exports: [CGISelectSearchComponent] }); }
    static { this.ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "20.3.2", ngImport: i0, type: CGISelectSearchModule, imports: [CommonModule, ReactiveFormsModule, MatSelectModule, MatInputModule, MatFormFieldModule] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.2", ngImport: i0, type: CGISelectSearchModule, decorators: [{
            type: NgModule,
            args: [{
                    imports: [CommonModule, ReactiveFormsModule, MatSelectModule, MatInputModule, MatFormFieldModule],
                    declarations: [CGISelectSearchComponent],
                    exports: [CGISelectSearchComponent],
                }]
        }] });

/**
 * Skeleton component.
 *
 * TODO: How to use component and examples.
 */
class CGISkeletonComponent {
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.2", ngImport: i0, type: CGISkeletonComponent, deps: [], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "20.3.2", type: CGISkeletonComponent, isStandalone: false, selector: "cgi-skeleton", ngImport: i0, template: "<div>\n  <div class=\"cgi-skeleton-heading\"></div>\n  <div class=\"cgi-skeleton-paragraph\"></div>\n  <div class=\"cgi-skeleton-paragraph\"></div>\n  <div class=\"cgi-skeleton-paragraph\"></div>\n  <div class=\"cgi-skeleton-paragraph\"></div>\n</div>\n", styles: [".cgi-skeleton-heading,.cgi-skeleton-paragraph{animation:loading 1.7s infinite linear;background:#f5f8fc;background-image:-webkit-linear-gradient(90deg,#f5f8fc 0,#e9ebed 40%,#f5f8fc 80%,#f5f8fc 100%);background-image:linear-gradient(90deg,#f5f8fc 0,#e9ebed 40%,#f5f8fc 80% 100%);background-repeat:no-repeat;background-size:65%;border-radius:18px;margin-bottom:10px;margin-top:10px}.cgi-skeleton-heading{height:22px;width:200px}.cgi-skeleton-paragraph{height:12px}@keyframes loading{0%{background-position:-400%}to{background-position:275% 0}}\n"] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.2", ngImport: i0, type: CGISkeletonComponent, decorators: [{
            type: Component,
            args: [{ selector: 'cgi-skeleton', standalone: false, template: "<div>\n  <div class=\"cgi-skeleton-heading\"></div>\n  <div class=\"cgi-skeleton-paragraph\"></div>\n  <div class=\"cgi-skeleton-paragraph\"></div>\n  <div class=\"cgi-skeleton-paragraph\"></div>\n  <div class=\"cgi-skeleton-paragraph\"></div>\n</div>\n", styles: [".cgi-skeleton-heading,.cgi-skeleton-paragraph{animation:loading 1.7s infinite linear;background:#f5f8fc;background-image:-webkit-linear-gradient(90deg,#f5f8fc 0,#e9ebed 40%,#f5f8fc 80%,#f5f8fc 100%);background-image:linear-gradient(90deg,#f5f8fc 0,#e9ebed 40%,#f5f8fc 80% 100%);background-repeat:no-repeat;background-size:65%;border-radius:18px;margin-bottom:10px;margin-top:10px}.cgi-skeleton-heading{height:22px;width:200px}.cgi-skeleton-paragraph{height:12px}@keyframes loading{0%{background-position:-400%}to{background-position:275% 0}}\n"] }]
        }] });

class CGISkeletonModule {
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.2", ngImport: i0, type: CGISkeletonModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule }); }
    static { this.ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "20.3.2", ngImport: i0, type: CGISkeletonModule, declarations: [CGISkeletonComponent], imports: [CommonModule, MatIconModule, MatButtonModule], exports: [CGISkeletonComponent] }); }
    static { this.ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "20.3.2", ngImport: i0, type: CGISkeletonModule, imports: [CommonModule, MatIconModule, MatButtonModule] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.2", ngImport: i0, type: CGISkeletonModule, decorators: [{
            type: NgModule,
            args: [{
                    imports: [CommonModule, MatIconModule, MatButtonModule],
                    declarations: [CGISkeletonComponent],
                    exports: [CGISkeletonComponent],
                    providers: [],
                }]
        }] });

/**
 * Toaster component.
 *
 * TODO: How to use component and examples.
 */
class CGIToasterComponent {
    /**
     * Constructor injecting custom snack bar detail for customization
     * @param data for what to display to the user
     * @param snackBarRef Reference to the MatSnackbar of the toaster component
     */
    constructor(data, snackBarRef) {
        this.data = data;
        this.snackBarRef = snackBarRef;
        /** Boolean for specifying if the toaster has a header */
        this.hasHeader = false;
        this.isClassContainer = true;
    }
    /**
     * Life cycle hook for when the component is first initiated.
     */
    ngOnInit() {
        if (this.data.header != null) {
            this.hasHeader = true;
        }
        this.setType();
    }
    /** Method that sets the icon for the type of alert */
    setType() {
        const type = this.data.type;
        if (type === 'cgi-toaster-warning') {
            this.icon = 'fa-exclamation-circle';
        }
        else if (type === 'cgi-toaster-success') {
            this.icon = 'fa-check-circle';
        }
        else if (type === 'cgi-toaster-error') {
            this.icon = 'fa-times-circle';
        }
        else {
            this.icon = 'fa-info-circle';
        }
    }
    /** close method will dismiss snackbar notification */
    close() {
        this.snackBarRef.dismiss();
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.2", ngImport: i0, type: CGIToasterComponent, deps: [{ token: MAT_SNACK_BAR_DATA }, { token: i1$4.MatSnackBarRef }], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "20.3.2", type: CGIToasterComponent, isStandalone: false, selector: "cgi-toaster", host: { properties: { "class.cgi-toaster": "this.isClassContainer" } }, ngImport: i0, template: "<div class=\"cgi-toaster__content\">\n  <div class=\"cgi-toaster__icon\">\n    <mat-icon class=\"mat-icon far {{ icon }}\" fontSet=\"far\" fontIcon=\"{{ icon }}\"></mat-icon>\n  </div>\n  <div>\n    <span class=\"cgi-toaster__header\" *ngIf=\"hasHeader\">{{ data.header }}</span>\n    <div class=\"cgi-toaster__message\" [innerHTML]=\"data.message\"></div>\n  </div>\n</div>\n<span class=\"cgi-toaster__spacer\"></span>\n<button *ngIf=\"!data.action\" mat-icon-button (click)=\"close()\" aria-label=\"Close Alert\">\n  <mat-icon fontSet=\"fal\" fontIcon=\"fa-times\"></mat-icon>\n</button>\n<button *ngIf=\"data.action\" mat-button (click)=\"close()\" [attr.aria-label]=\"data.customAction\">\n  {{ data.action }}\n</button>\n", styles: [":host(.cgi-toaster){align-items:center;display:flex;font-family:Roboto,Helvetica,Helvetica Neue,Arial,sans-serif;font-size:14px;font-weight:700;line-height:1.5em}:host(.cgi-toaster) .cgi-toaster__content{display:flex;margin-right:20px}:host(.cgi-toaster) .cgi-toaster__content div:nth-of-type(2){width:100%}:host(.cgi-toaster) .cgi-toaster__icon{border-radius:50%;color:#fff;flex-shrink:0;height:25px;margin-right:20px;width:25px}:host(.cgi-toaster) .cgi-toaster__icon ::ng-deep mat-icon{align-items:center;display:flex;justify-content:center;padding-left:1px}:host(.cgi-toaster) .cgi-toaster__header{align-items:center;display:flex;font-size:16px}:host(.cgi-toaster) .cgi-toaster__message{align-items:center;font-weight:400}:host(.cgi-toaster) .cgi-toaster__spacer{flex:1 1 auto}:host(.cgi-toaster) .mat-mdc-icon-button{height:25px;line-height:25px;margin-left:10px;position:absolute;right:0;top:0;width:25px}:host(.cgi-toaster) .mat-mdc-icon-button ::ng-deep mat-icon{color:#3c3f40;font-size:18px}:host(.cgi-toaster) .mat-mdc-button{flex-shrink:0}\n"], dependencies: [{ kind: "directive", type: i1.NgIf, selector: "[ngIf]", inputs: ["ngIf", "ngIfThen", "ngIfElse"] }, { kind: "component", type: i5.MatIcon, selector: "mat-icon", inputs: ["color", "inline", "svgIcon", "fontSet", "fontIcon"], exportAs: ["matIcon"] }, { kind: "component", type: i4.MatButton, selector: "    button[matButton], a[matButton], button[mat-button], button[mat-raised-button],    button[mat-flat-button], button[mat-stroked-button], a[mat-button], a[mat-raised-button],    a[mat-flat-button], a[mat-stroked-button]  ", inputs: ["matButton"], exportAs: ["matButton", "matAnchor"] }, { kind: "component", type: i4.MatIconButton, selector: "button[mat-icon-button], a[mat-icon-button], button[matIconButton], a[matIconButton]", exportAs: ["matButton", "matAnchor"] }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.2", ngImport: i0, type: CGIToasterComponent, decorators: [{
            type: Component,
            args: [{ selector: 'cgi-toaster', standalone: false, template: "<div class=\"cgi-toaster__content\">\n  <div class=\"cgi-toaster__icon\">\n    <mat-icon class=\"mat-icon far {{ icon }}\" fontSet=\"far\" fontIcon=\"{{ icon }}\"></mat-icon>\n  </div>\n  <div>\n    <span class=\"cgi-toaster__header\" *ngIf=\"hasHeader\">{{ data.header }}</span>\n    <div class=\"cgi-toaster__message\" [innerHTML]=\"data.message\"></div>\n  </div>\n</div>\n<span class=\"cgi-toaster__spacer\"></span>\n<button *ngIf=\"!data.action\" mat-icon-button (click)=\"close()\" aria-label=\"Close Alert\">\n  <mat-icon fontSet=\"fal\" fontIcon=\"fa-times\"></mat-icon>\n</button>\n<button *ngIf=\"data.action\" mat-button (click)=\"close()\" [attr.aria-label]=\"data.customAction\">\n  {{ data.action }}\n</button>\n", styles: [":host(.cgi-toaster){align-items:center;display:flex;font-family:Roboto,Helvetica,Helvetica Neue,Arial,sans-serif;font-size:14px;font-weight:700;line-height:1.5em}:host(.cgi-toaster) .cgi-toaster__content{display:flex;margin-right:20px}:host(.cgi-toaster) .cgi-toaster__content div:nth-of-type(2){width:100%}:host(.cgi-toaster) .cgi-toaster__icon{border-radius:50%;color:#fff;flex-shrink:0;height:25px;margin-right:20px;width:25px}:host(.cgi-toaster) .cgi-toaster__icon ::ng-deep mat-icon{align-items:center;display:flex;justify-content:center;padding-left:1px}:host(.cgi-toaster) .cgi-toaster__header{align-items:center;display:flex;font-size:16px}:host(.cgi-toaster) .cgi-toaster__message{align-items:center;font-weight:400}:host(.cgi-toaster) .cgi-toaster__spacer{flex:1 1 auto}:host(.cgi-toaster) .mat-mdc-icon-button{height:25px;line-height:25px;margin-left:10px;position:absolute;right:0;top:0;width:25px}:host(.cgi-toaster) .mat-mdc-icon-button ::ng-deep mat-icon{color:#3c3f40;font-size:18px}:host(.cgi-toaster) .mat-mdc-button{flex-shrink:0}\n"] }]
        }], ctorParameters: () => [{ type: undefined, decorators: [{
                    type: Inject,
                    args: [MAT_SNACK_BAR_DATA]
                }] }, { type: i1$4.MatSnackBarRef }], propDecorators: { isClassContainer: [{
                type: HostBinding,
                args: ['class.cgi-toaster']
            }] } });

class CGIToasterModule {
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.2", ngImport: i0, type: CGIToasterModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule }); }
    static { this.ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "20.3.2", ngImport: i0, type: CGIToasterModule, declarations: [CGIToasterComponent], imports: [CommonModule, MatIconModule, MatButtonModule], exports: [CGIToasterComponent] }); }
    static { this.ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "20.3.2", ngImport: i0, type: CGIToasterModule, imports: [CommonModule, MatIconModule, MatButtonModule] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.2", ngImport: i0, type: CGIToasterModule, decorators: [{
            type: NgModule,
            args: [{
                    imports: [CommonModule, MatIconModule, MatButtonModule],
                    declarations: [CGIToasterComponent],
                    exports: [CGIToasterComponent],
                    providers: [],
                }]
        }] });

/** Presentational component for entry avatar */
class CGITimelineEntryAvatarComponent {
    /** Empty constructor */
    constructor() { }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.2", ngImport: i0, type: CGITimelineEntryAvatarComponent, deps: [], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "20.3.2", type: CGITimelineEntryAvatarComponent, isStandalone: false, selector: "cgi-timeline-entry-avatar", ngImport: i0, template: "<div mat-card-avatar class=\"cgi-timeline-entry-avatar\">\n  <ng-content></ng-content>\n</div>\n", styles: [".cgi-timeline-entry-avatar{background:#006f95;color:#fff;line-height:2.5em;margin-left:-15px;margin-right:15px;text-align:center;vertical-align:middle}\n"], dependencies: [{ kind: "directive", type: i1$5.MatCardAvatar, selector: "[mat-card-avatar], [matCardAvatar]" }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.2", ngImport: i0, type: CGITimelineEntryAvatarComponent, decorators: [{
            type: Component,
            args: [{ selector: 'cgi-timeline-entry-avatar', standalone: false, template: "<div mat-card-avatar class=\"cgi-timeline-entry-avatar\">\n  <ng-content></ng-content>\n</div>\n", styles: [".cgi-timeline-entry-avatar{background:#006f95;color:#fff;line-height:2.5em;margin-left:-15px;margin-right:15px;text-align:center;vertical-align:middle}\n"] }]
        }], ctorParameters: () => [] });

/** Presentational Component for entry body */
class CGITimelineEntryBodyComponent {
    /** Empty constructor */
    constructor() { }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.2", ngImport: i0, type: CGITimelineEntryBodyComponent, deps: [], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "20.3.2", type: CGITimelineEntryBodyComponent, isStandalone: false, selector: "cgi-timeline-entry-body", ngImport: i0, template: "<mat-card-subtitle>\n  <ng-content></ng-content>\n</mat-card-subtitle>\n", styles: [":host{margin-top:-8px}:host mat-card-subtitle{font-size:12px;margin-bottom:0}\n"], dependencies: [{ kind: "directive", type: i1$5.MatCardSubtitle, selector: "mat-card-subtitle, [mat-card-subtitle], [matCardSubtitle]" }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.2", ngImport: i0, type: CGITimelineEntryBodyComponent, decorators: [{
            type: Component,
            args: [{ selector: 'cgi-timeline-entry-body', standalone: false, template: "<mat-card-subtitle>\n  <ng-content></ng-content>\n</mat-card-subtitle>\n", styles: [":host{margin-top:-8px}:host mat-card-subtitle{font-size:12px;margin-bottom:0}\n"] }]
        }], ctorParameters: () => [] });

/** Presentational component for timeline entry icon */
class CGITimelineEntryIconComponent {
    /** Empty constructor */
    constructor() { }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.2", ngImport: i0, type: CGITimelineEntryIconComponent, deps: [], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "20.3.2", type: CGITimelineEntryIconComponent, isStandalone: false, selector: "cgi-timeline-entry-icon", ngImport: i0, template: "<ng-content></ng-content>\n", styles: [":host{background:#a5acb0;border-radius:50%;border-style:solid;color:#fff;height:2.375em;left:100%;margin-left:-22px;position:absolute;text-align:center;top:12px;width:38px}:host ::ng-deep mat-icon{line-height:1.6em}\n"] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.2", ngImport: i0, type: CGITimelineEntryIconComponent, decorators: [{
            type: Component,
            args: [{ selector: 'cgi-timeline-entry-icon', standalone: false, template: "<ng-content></ng-content>\n", styles: [":host{background:#a5acb0;border-radius:50%;border-style:solid;color:#fff;height:2.375em;left:100%;margin-left:-22px;position:absolute;text-align:center;top:12px;width:38px}:host ::ng-deep mat-icon{line-height:1.6em}\n"] }]
        }], ctorParameters: () => [] });

/** Presentational component for timeline entry title */
class CGITimelineEntryTitleComponent {
    /** Empty constructor */
    constructor() { }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.2", ngImport: i0, type: CGITimelineEntryTitleComponent, deps: [], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "20.3.2", type: CGITimelineEntryTitleComponent, isStandalone: false, selector: "cgi-timeline-entry-title", ngImport: i0, template: "<mat-card-title>\n  <ng-content></ng-content>\n</mat-card-title>\n", styles: [""], dependencies: [{ kind: "directive", type: i1$5.MatCardTitle, selector: "mat-card-title, [mat-card-title], [matCardTitle]" }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.2", ngImport: i0, type: CGITimelineEntryTitleComponent, decorators: [{
            type: Component,
            args: [{ selector: 'cgi-timeline-entry-title', standalone: false, template: "<mat-card-title>\n  <ng-content></ng-content>\n</mat-card-title>\n" }]
        }], ctorParameters: () => [] });

/** Presentational component to represent unit of timeline entry */
class CGITimelineEntryComponent {
    /** Empty constructor */
    constructor() {
        /** whether the timeline entry is inverted */
        this._inverted = false;
    }
    /** Value of the inverted property. */
    get inverted() {
        return this._inverted;
    }
    /** Set value of the inverted property. */
    set inverted(value) {
        const transformedBool = value === 'true' || value === '';
        if (transformedBool) {
            this._inverted = transformedBool;
        }
        else {
            this._inverted = false;
        }
    }
    /** ngoninignitninitnit */
    ngOnInit() { }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.2", ngImport: i0, type: CGITimelineEntryComponent, deps: [], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "20.3.2", type: CGITimelineEntryComponent, isStandalone: false, selector: "cgi-timeline-entry", inputs: { inverted: "inverted" }, ngImport: i0, template: "<li [ngClass]=\"{ 'timeline-inverted': inverted }\">\n  <ng-content select=\"cgi-timeline-entry-icon\"></ng-content>\n  <div class=\"timeline-entry\">\n    <mat-card appearance=\"outlined\">\n      <mat-card-header>\n        <ng-content select=\"cgi-timeline-entry-avatar\"></ng-content>\n        <div class=\"cgi-timeline-entry-text\">\n          <ng-content select=\"cgi-timeline-entry-title\"></ng-content>\n          <ng-content select=\"cgi-timeline-entry-body\"></ng-content>\n        </div>\n      </mat-card-header>\n    </mat-card>\n    <!--end .card -->\n  </div>\n  <!--end .timeline-entry -->\n</li>\n", styles: [".cgi-vertical-spacer-1{height:2rem;width:100%}.cgi-vertical-spacer-2{height:4rem;width:100%}.cgi-vertical-spacer-3{height:6rem;width:100%}.cgi-vertical-spacer-4{height:8rem;width:100%}.cgi-vertical-spacer-5{height:10rem;width:100%}.cgi-vertical-spacer-6{height:12rem;width:100%}.cgi-vertical-spacer-7{height:14rem;width:100%}.cgi-vertical-spacer-8{height:16rem;width:100%}.cgi-vertical-spacer-9{height:18rem;width:100%}.cgi-vertical-spacer-10{height:20rem;width:100%}:host li{display:block;left:-50%;position:relative;width:50%}:host mat-card{border-radius:12px!important;box-shadow:0 0 10px #00001933!important;padding:15px!important}.cgi-timeline-entry-text{display:flex;flex-direction:column}.timeline-entry{display:inline-block;position:relative;width:100%}.timeline-entry mat-card{margin-right:26px}.timeline-entry mat-card:before{border-color:transparent transparent transparent #000019;border-style:solid;border-width:7px 0 7px 7px;content:\"\";height:0;position:absolute;right:-7px;top:26px;width:0}.timeline-entry mat-card:after{border-color:transparent transparent transparent #ffffff;border-style:solid;border-width:7px 0 7px 7px;content:\"\";height:0;position:absolute;right:-7px;top:26px;width:0}.timeline-inverted .timeline-entry{left:100%}.timeline-inverted .timeline-entry mat-card{margin-left:30px;margin-right:0}.timeline-inverted .timeline-entry mat-card:before{border-color:transparent transparent transparent #000019;border-style:solid;border-width:7px 0 7px 7px;content:\"\";height:0;left:-7px;position:absolute;right:-7px;top:26px;transform:rotate(-180deg);width:0}.timeline-inverted .timeline-entry mat-card:after{border-color:transparent transparent transparent #ffffff;border-style:solid;border-width:7px 0 7px 7px;content:\"\";height:0;left:-7px;position:absolute;right:-7px;top:26px;transform:rotate(-180deg);width:0}\n"], dependencies: [{ kind: "directive", type: i1.NgClass, selector: "[ngClass]", inputs: ["class", "ngClass"] }, { kind: "component", type: i1$5.MatCard, selector: "mat-card", inputs: ["appearance"], exportAs: ["matCard"] }, { kind: "component", type: i1$5.MatCardHeader, selector: "mat-card-header" }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.2", ngImport: i0, type: CGITimelineEntryComponent, decorators: [{
            type: Component,
            args: [{ selector: 'cgi-timeline-entry', standalone: false, template: "<li [ngClass]=\"{ 'timeline-inverted': inverted }\">\n  <ng-content select=\"cgi-timeline-entry-icon\"></ng-content>\n  <div class=\"timeline-entry\">\n    <mat-card appearance=\"outlined\">\n      <mat-card-header>\n        <ng-content select=\"cgi-timeline-entry-avatar\"></ng-content>\n        <div class=\"cgi-timeline-entry-text\">\n          <ng-content select=\"cgi-timeline-entry-title\"></ng-content>\n          <ng-content select=\"cgi-timeline-entry-body\"></ng-content>\n        </div>\n      </mat-card-header>\n    </mat-card>\n    <!--end .card -->\n  </div>\n  <!--end .timeline-entry -->\n</li>\n", styles: [".cgi-vertical-spacer-1{height:2rem;width:100%}.cgi-vertical-spacer-2{height:4rem;width:100%}.cgi-vertical-spacer-3{height:6rem;width:100%}.cgi-vertical-spacer-4{height:8rem;width:100%}.cgi-vertical-spacer-5{height:10rem;width:100%}.cgi-vertical-spacer-6{height:12rem;width:100%}.cgi-vertical-spacer-7{height:14rem;width:100%}.cgi-vertical-spacer-8{height:16rem;width:100%}.cgi-vertical-spacer-9{height:18rem;width:100%}.cgi-vertical-spacer-10{height:20rem;width:100%}:host li{display:block;left:-50%;position:relative;width:50%}:host mat-card{border-radius:12px!important;box-shadow:0 0 10px #00001933!important;padding:15px!important}.cgi-timeline-entry-text{display:flex;flex-direction:column}.timeline-entry{display:inline-block;position:relative;width:100%}.timeline-entry mat-card{margin-right:26px}.timeline-entry mat-card:before{border-color:transparent transparent transparent #000019;border-style:solid;border-width:7px 0 7px 7px;content:\"\";height:0;position:absolute;right:-7px;top:26px;width:0}.timeline-entry mat-card:after{border-color:transparent transparent transparent #ffffff;border-style:solid;border-width:7px 0 7px 7px;content:\"\";height:0;position:absolute;right:-7px;top:26px;width:0}.timeline-inverted .timeline-entry{left:100%}.timeline-inverted .timeline-entry mat-card{margin-left:30px;margin-right:0}.timeline-inverted .timeline-entry mat-card:before{border-color:transparent transparent transparent #000019;border-style:solid;border-width:7px 0 7px 7px;content:\"\";height:0;left:-7px;position:absolute;right:-7px;top:26px;transform:rotate(-180deg);width:0}.timeline-inverted .timeline-entry mat-card:after{border-color:transparent transparent transparent #ffffff;border-style:solid;border-width:7px 0 7px 7px;content:\"\";height:0;left:-7px;position:absolute;right:-7px;top:26px;transform:rotate(-180deg);width:0}\n"] }]
        }], ctorParameters: () => [], propDecorators: { inverted: [{
                type: Input
            }] } });

/** Presentational container for timeline */
class CGITimelineComponent {
    /** Empty constructor */
    constructor() { }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.2", ngImport: i0, type: CGITimelineComponent, deps: [], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "20.3.2", type: CGITimelineComponent, isStandalone: false, selector: "cgi-timeline", ngImport: i0, template: "<!-- BEGIN RESPONSIVE TIMELINE -->\n<ul class=\"timeline collapse-md\">\n  <ng-content></ng-content>\n</ul>\n<!-- END RESPONSIVE TIMELINE -->\n", styles: [".cgi-vertical-spacer-1{height:2rem;width:100%}.cgi-vertical-spacer-2{height:4rem;width:100%}.cgi-vertical-spacer-3{height:6rem;width:100%}.cgi-vertical-spacer-4{height:8rem;width:100%}.cgi-vertical-spacer-5{height:10rem;width:100%}.cgi-vertical-spacer-6{height:12rem;width:100%}.cgi-vertical-spacer-7{height:14rem;width:100%}.cgi-vertical-spacer-8{height:16rem;width:100%}.cgi-vertical-spacer-9{height:18rem;width:100%}.cgi-vertical-spacer-10{height:20rem;width:100%}.timeline{left:50%;padding:20px 0 0;position:relative}.timeline:before{background-color:#000019;bottom:0;content:\" \";left:0;margin-left:-2px;opacity:.15;position:absolute;top:0;width:4px}\n"] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.2", ngImport: i0, type: CGITimelineComponent, decorators: [{
            type: Component,
            args: [{ selector: 'cgi-timeline', standalone: false, template: "<!-- BEGIN RESPONSIVE TIMELINE -->\n<ul class=\"timeline collapse-md\">\n  <ng-content></ng-content>\n</ul>\n<!-- END RESPONSIVE TIMELINE -->\n", styles: [".cgi-vertical-spacer-1{height:2rem;width:100%}.cgi-vertical-spacer-2{height:4rem;width:100%}.cgi-vertical-spacer-3{height:6rem;width:100%}.cgi-vertical-spacer-4{height:8rem;width:100%}.cgi-vertical-spacer-5{height:10rem;width:100%}.cgi-vertical-spacer-6{height:12rem;width:100%}.cgi-vertical-spacer-7{height:14rem;width:100%}.cgi-vertical-spacer-8{height:16rem;width:100%}.cgi-vertical-spacer-9{height:18rem;width:100%}.cgi-vertical-spacer-10{height:20rem;width:100%}.timeline{left:50%;padding:20px 0 0;position:relative}.timeline:before{background-color:#000019;bottom:0;content:\" \";left:0;margin-left:-2px;opacity:.15;position:absolute;top:0;width:4px}\n"] }]
        }], ctorParameters: () => [] });

class CGITimelineModule {
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.2", ngImport: i0, type: CGITimelineModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule }); }
    static { this.ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "20.3.2", ngImport: i0, type: CGITimelineModule, declarations: [CGITimelineComponent,
            CGITimelineEntryComponent,
            CGITimelineEntryTitleComponent,
            CGITimelineEntryIconComponent,
            CGITimelineEntryBodyComponent,
            CGITimelineEntryAvatarComponent], imports: [CommonModule, MatIconModule, MatCardModule], exports: [CGITimelineComponent,
            CGITimelineEntryComponent,
            CGITimelineEntryTitleComponent,
            CGITimelineEntryIconComponent,
            CGITimelineEntryBodyComponent,
            CGITimelineEntryAvatarComponent] }); }
    static { this.ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "20.3.2", ngImport: i0, type: CGITimelineModule, imports: [CommonModule, MatIconModule, MatCardModule] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.2", ngImport: i0, type: CGITimelineModule, decorators: [{
            type: NgModule,
            args: [{
                    imports: [CommonModule, MatIconModule, MatCardModule],
                    declarations: [
                        CGITimelineComponent,
                        CGITimelineEntryComponent,
                        CGITimelineEntryTitleComponent,
                        CGITimelineEntryIconComponent,
                        CGITimelineEntryBodyComponent,
                        CGITimelineEntryAvatarComponent,
                    ],
                    exports: [
                        CGITimelineComponent,
                        CGITimelineEntryComponent,
                        CGITimelineEntryTitleComponent,
                        CGITimelineEntryIconComponent,
                        CGITimelineEntryBodyComponent,
                        CGITimelineEntryAvatarComponent,
                    ],
                }]
        }] });

/** Timepicker component */
class CGITimepickerComponent {
    /**
     * Constructor
     */
    constructor(parentFormGroup) {
        this.parentFormGroup = parentFormGroup;
        /** Input type (string): error message for timepicker */
        this.errorMessage = 'Time is required';
        /** Input type (boolean): If component is required */
        this.required = false;
        /** Input type (boolean): If component is disabled */
        this.disabled = false;
        /** Input type (boolean): If component is read-only */
        this.readonly = false;
        /** Output for time */
        this.timeSelected = new EventEmitter();
        /** Variable to determine if form elements are valid */
        this.valid = false;
        /** Autocomplete options for hours */
        this.hours = this.generateArray(1, 12);
        /** Autocomplete options for minutes */
        this.minutes = this.generateArray(0, 59);
        /** Form Control for hour field */
        this.hourFC = new UntypedFormControl();
        /** Form control for minute field */
        this.minutesFC = new UntypedFormControl();
        /** Form control for AM/PM field */
        this.dayPeriodFC = new UntypedFormControl();
        this.isClassContainer = true;
        if (this.parentFormGroup) {
            this.parentForm = this.parentFormGroup;
        }
        // Assign filtered hours to autocomplete options
        this.filteredHrs = this.hourFC.valueChanges.pipe(startWith(''), map((value) => this.filterList(value, this.hours)));
        // Assign filtered minutes to autocomplete options
        this.filteredMins = this.minutesFC.valueChanges.pipe(startWith(''), map((value) => this.filterList(value, this.minutes)));
    }
    ngOnChanges(changes) {
        // Disable form controls if component is disabled or readonly
        if (this.disabled || this.readonly) {
            this.hourFC.disable();
            this.minutesFC.disable();
            this.dayPeriodFC.disable();
            this.valid = true;
        }
        else if (!this.disabled || !this.readonly) {
            this.hourFC.enable();
            this.minutesFC.enable();
            this.dayPeriodFC.enable();
            this.valid = true;
        }
    }
    /**
     * Generate array for autocomplete options
     */
    generateArray(start, length) {
        const array = [];
        for (let i = start; i <= length; i++) {
            if (i < 10) {
                const value = '0' + i.toString();
                array.push(value);
            }
            else {
                array.push(i.toString());
            }
        }
        return array;
    }
    /**
     * Initialization block when component is loaded
     */
    ngOnInit() {
        // Set time if given a date
        if (this.setDateTime) {
            let hour = this.setDateTime.getHours();
            if (this.setDateTime.getMinutes() < 10) {
                this.minutesFC.setValue('0' + this.setDateTime.getMinutes());
            }
            else {
                this.minutesFC.setValue(this.setDateTime.getMinutes());
            }
            // If given dateTime is midnight
            if (hour === 0) {
                this.hourFC.setValue(12);
                this.dayPeriodFC.setValue('am');
            }
            // If given dateTime is noon
            else if (hour === 12) {
                this.hourFC.setValue(hour);
                this.dayPeriodFC.setValue('pm');
            }
            // If given dateTime is afternoon
            else if (hour > 12) {
                hour = hour - 12;
                this.hourFC.setValue(hour);
                this.dayPeriodFC.setValue('pm');
            }
            // If given dateTime is morning
            else {
                this.hourFC.setValue(hour);
                this.dayPeriodFC.setValue('am');
            }
            this.valid = true;
        }
        // Disable form controls if component is disabled or readonly
        if (this.disabled || this.readonly) {
            this.hourFC.disable();
            this.minutesFC.disable();
            this.dayPeriodFC.disable();
            this.valid = true;
        }
    }
    /**
     * Private function: filter autocomplete lists
     */
    filterList(value, list) {
        return list.filter((option) => option.toLowerCase().includes(value));
    }
    /**
     * Function: updates the timepicker
     */
    updateTime() {
        let time;
        let hour;
        let min;
        // Restrict hour input within limit (1-12)
        if (this.hourFC.value === '' || this.hourFC.value === null) {
            this.hourFC.setValue('');
            hour = null;
        }
        else if (this.hourFC.value > 12) {
            this.hourFC.setValue(12);
            hour = 12;
        }
        else if (this.hourFC.value < 1) {
            this.hourFC.setValue(1);
            hour = 1;
        }
        else {
            hour = Number(this.hourFC.value);
        }
        // Restrict minutes input within limit (0-59)
        if (this.minutesFC.value === '' || this.minutesFC.value === null) {
            this.minutesFC.setValue('');
            min = null;
        }
        else if (this.minutesFC.value > 59) {
            this.minutesFC.setValue(59);
            min = 59;
        }
        else if (this.minutesFC.value <= 0) {
            this.minutesFC.setValue('00');
            min = 0;
        }
        else if (this.minutesFC.value < 10 && this.minutesFC.value > 0) {
            const value = this.minutesFC.value.toString();
            this.minutesFC.setValue(value.padStart(2, 0));
            min = Number(this.minutesFC.value);
        }
        else {
            min = Number(this.minutesFC.value);
        }
        // Only update time when all fields are populated
        if (this.hourFC.value != null &&
            this.minutesFC.value != null &&
            this.dayPeriodFC.value != null) {
            time = new Date();
            // Case 1: it is 12 AM
            if (this.hourFC.value === 12 && this.dayPeriodFC.value === 'am') {
                time.setHours(0, min, 0);
                this.timeSelected.emit(time);
                this.valid = true;
            }
            // Case 2: it is between 12PM to 12AM
            else if (this.dayPeriodFC.value === 'pm' && this.hourFC.value !== 12) {
                time.setHours(hour + 12, min, 0);
                this.timeSelected.emit(time);
                this.valid = true;
            }
            // Case 3: it is between 12AM to 12PM
            else {
                time.setHours(hour, min, 0);
                this.timeSelected.emit(time);
                this.valid = true;
            }
        }
        else {
            this.valid = false;
        }
    }
    /** Get function that returns if form elements in component are valid */
    getValidity() {
        if (!this.required) {
            this.valid = true;
        }
        return this.valid;
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.2", ngImport: i0, type: CGITimepickerComponent, deps: [{ token: i1$2.FormGroupDirective }], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "20.3.2", type: CGITimepickerComponent, isStandalone: false, selector: "cgi-timepicker", inputs: { setDateTime: "setDateTime", errorMessage: "errorMessage", required: "required", disabled: "disabled", readonly: "readonly" }, outputs: { timeSelected: "timeSelected" }, host: { properties: { "class.cgi-timepicker": "this.isClassContainer" } }, usesOnChanges: true, ngImport: i0, template: "<mat-form-field\n  aria-label=\"hour\"\n  appearance=\"outline\"\n  color=\"accent\"\n  floatLabel=\"always\"\n  [ngClass]=\"{\n    'cgi-forms-readonly': readonly,\n    'mat-form-field-invalid':\n      (hourFC.touched && !hourFC.valid) || (minutesFC.touched && !minutesFC.valid)\n  }\"\n>\n  <mat-label>Hr</mat-label>\n  <input\n    matInput\n    type=\"text\"\n    maxlength=\"2\"\n    placeholder=\"00\"\n    [matAutocomplete]=\"cgiTimepickerHour\"\n    [formControl]=\"hourFC\"\n    (change)=\"updateTime()\"\n    [required]=\"required\"\n  />\n  <mat-autocomplete #cgiTimepickerHour=\"matAutocomplete\" (optionSelected)=\"updateTime()\">\n    <mat-option *ngFor=\"let hour of filteredHrs | async\" [value]=\"hour\">\n      {{ hour }}\n    </mat-option>\n  </mat-autocomplete>\n</mat-form-field>\n<span class=\"cgi-timepicker--colon mx-1\">:</span>\n<mat-form-field\n  aria-label=\"minute\"\n  appearance=\"outline\"\n  color=\"accent\"\n  floatLabel=\"always\"\n  [ngClass]=\"{\n    'cgi-timepicker--shift-mins-label': required,\n    'cgi-forms-readonly': readonly,\n    'mat-form-field-invalid':\n      (hourFC.touched && !hourFC.valid) || (minutesFC.touched && !minutesFC.valid)\n  }\"\n>\n  <mat-label>Min</mat-label>\n  <input\n    matInput\n    type=\"text\"\n    maxlength=\"2\"\n    placeholder=\"00\"\n    [matAutocomplete]=\"cgiTimepickerMin\"\n    [formControl]=\"minutesFC\"\n    (change)=\"updateTime()\"\n    [required]=\"required\"\n  />\n  <mat-autocomplete #cgiTimepickerMin=\"matAutocomplete\" (optionActivated)=\"updateTime()\">\n    <mat-option *ngFor=\"let minute of filteredMins | async\" [value]=\"minute\">\n      {{ minute }}\n    </mat-option>\n  </mat-autocomplete>\n</mat-form-field>\n<ng-container *ngIf=\"!readonly\">\n  <mat-button-toggle-group\n    aria-label=\"day period\"\n    class=\"mat-toggle-group\"\n    [formControl]=\"dayPeriodFC\"\n    (change)=\"updateTime()\"\n  >\n    <mat-button-toggle value=\"am\" [disabled]=\"disabled\" aria-label=\"Time picker toggle for AM\">\n      AM\n    </mat-button-toggle>\n    <mat-button-toggle value=\"pm\" [disabled]=\"disabled\" aria-label=\"Time picker toggle for PM\">\n      PM\n    </mat-button-toggle>\n  </mat-button-toggle-group>\n</ng-container>\n<ng-container *ngIf=\"readonly && dayPeriodFC\">\n  <span class=\"cgi-readonly-dayperiod\">{{ dayPeriodFC.value | uppercase }}</span>\n</ng-container>\n<mat-error\n  *ngIf=\"\n    required &&\n    ((hourFC.touched && !hourFC.valid) ||\n      (minutesFC.touched && !minutesFC.valid) ||\n      (!getValidity() && parentForm.submitted))\n  \"\n  >{{ errorMessage }}</mat-error\n>\n", styles: [":host(.cgi-timepicker) .mat-mdc-form-field{width:40px}:host(.cgi-timepicker) .mat-mdc-form-field.mat-form-field-invalid ::ng-deep .mat-form-field-wrapper{margin-bottom:0!important;padding-bottom:0!important}:host(.cgi-timepicker) .mat-toggle-group{margin-left:.75rem;top:-2px}:host(.cgi-timepicker) [class^=cgi-forms-readonly].mat-form-field-disabled ::ng-deep .mat-form-field-outline-start,:host(.cgi-timepicker) [class^=cgi-forms-readonly].mat-form-field-disabled ::ng-deep .mat-form-field-outline-gap,:host(.cgi-timepicker) [class^=cgi-forms-readonly].mat-form-field-disabled ::ng-deep .mat-form-field-outline-end,:host(.cgi-timepicker) [class*=cgi-forms-readonly].mat-form-field-disabled ::ng-deep .mat-form-field-outline-start,:host(.cgi-timepicker) [class*=cgi-forms-readonly].mat-form-field-disabled ::ng-deep .mat-form-field-outline-gap,:host(.cgi-timepicker) [class*=cgi-forms-readonly].mat-form-field-disabled ::ng-deep .mat-form-field-outline-end{border:0}:host(.cgi-timepicker) [class^=cgi-forms-readonly].mat-form-field-disabled .mat-mdc-input-element,:host(.cgi-timepicker) [class*=cgi-forms-readonly].mat-form-field-disabled .mat-mdc-input-element{color:currentColor}:host(.cgi-timepicker) [class^=cgi-forms-readonly] ::ng-deep .mat-form-field-flex,:host(.cgi-timepicker) [class*=cgi-forms-readonly] ::ng-deep .mat-form-field-flex{padding:0!important}:host(.cgi-timepicker) .mat-mdc-form-field-error{font-size:12px}.cdk-overlay-container .cgi-timepicker .mat-toggle-group .mat-button-toggle-label-content,.cgi-nav-content .cgi-timepicker .mat-toggle-group .mat-button-toggle-label-content{line-height:40px}.cgi-timepicker--shift-mins-label.mat-form-field-appearance-outline.mat-form-field-can-float.mat-form-field-should-float ::ng-deep .mat-form-field-label{overflow:visible;transform:translate(-3px) translateY(-1.4em) scale(.75)}.cgi-readonly-dayperiod{color:#888d91}::ng-deep .cgi-forms-readonly-bold .cgi-readonly-dayperiod{font-weight:700}\n"], dependencies: [{ kind: "directive", type: i1.NgClass, selector: "[ngClass]", inputs: ["class", "ngClass"] }, { kind: "directive", type: i1.NgForOf, selector: "[ngFor][ngForOf]", inputs: ["ngForOf", "ngForTrackBy", "ngForTemplate"] }, { kind: "directive", type: i1.NgIf, selector: "[ngIf]", inputs: ["ngIf", "ngIfThen", "ngIfElse"] }, { kind: "component", type: i6.MatAutocomplete, selector: "mat-autocomplete", inputs: ["aria-label", "aria-labelledby", "displayWith", "autoActiveFirstOption", "autoSelectActiveOption", "requireSelection", "panelWidth", "disableRipple", "class", "hideSingleSelectionIndicator"], outputs: ["optionSelected", "opened", "closed", "optionActivated"], exportAs: ["matAutocomplete"] }, { kind: "component", type: i6.MatOption, selector: "mat-option", inputs: ["value", "id", "disabled"], outputs: ["onSelectionChange"], exportAs: ["matOption"] }, { kind: "directive", type: i6.MatAutocompleteTrigger, selector: "input[matAutocomplete], textarea[matAutocomplete]", inputs: ["matAutocomplete", "matAutocompletePosition", "matAutocompleteConnectedTo", "autocomplete", "matAutocompleteDisabled"], exportAs: ["matAutocompleteTrigger"] }, { kind: "directive", type: i4$4.MatButtonToggleGroup, selector: "mat-button-toggle-group", inputs: ["appearance", "name", "vertical", "value", "multiple", "disabled", "disabledInteractive", "hideSingleSelectionIndicator", "hideMultipleSelectionIndicator"], outputs: ["valueChange", "change"], exportAs: ["matButtonToggleGroup"] }, { kind: "component", type: i4$4.MatButtonToggle, selector: "mat-button-toggle", inputs: ["aria-label", "aria-labelledby", "id", "name", "value", "tabIndex", "disableRipple", "appearance", "checked", "disabled", "disabledInteractive"], outputs: ["change"], exportAs: ["matButtonToggle"] }, { kind: "component", type: i8.MatFormField, selector: "mat-form-field", inputs: ["hideRequiredMarker", "color", "floatLabel", "appearance", "subscriptSizing", "hintLabel"], exportAs: ["matFormField"] }, { kind: "directive", type: i8.MatLabel, selector: "mat-label" }, { kind: "directive", type: i8.MatError, selector: "mat-error, [matError]", inputs: ["id"] }, { kind: "directive", type: i1$2.DefaultValueAccessor, selector: "input:not([type=checkbox])[formControlName],textarea[formControlName],input:not([type=checkbox])[formControl],textarea[formControl],input:not([type=checkbox])[ngModel],textarea[ngModel],[ngDefaultControl]" }, { kind: "directive", type: i1$2.NgControlStatus, selector: "[formControlName],[ngModel],[formControl]" }, { kind: "directive", type: i1$2.RequiredValidator, selector: ":not([type=checkbox])[required][formControlName],:not([type=checkbox])[required][formControl],:not([type=checkbox])[required][ngModel]", inputs: ["required"] }, { kind: "directive", type: i1$2.MaxLengthValidator, selector: "[maxlength][formControlName],[maxlength][formControl],[maxlength][ngModel]", inputs: ["maxlength"] }, { kind: "directive", type: i4$3.MatInput, selector: "input[matInput], textarea[matInput], select[matNativeControl],      input[matNativeControl], textarea[matNativeControl]", inputs: ["disabled", "id", "placeholder", "name", "required", "type", "errorStateMatcher", "aria-describedby", "value", "readonly", "disabledInteractive"], exportAs: ["matInput"] }, { kind: "directive", type: i1$2.FormControlDirective, selector: "[formControl]", inputs: ["formControl", "disabled", "ngModel"], outputs: ["ngModelChange"], exportAs: ["ngForm"] }, { kind: "pipe", type: i1.AsyncPipe, name: "async" }, { kind: "pipe", type: i1.UpperCasePipe, name: "uppercase" }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.2", ngImport: i0, type: CGITimepickerComponent, decorators: [{
            type: Component,
            args: [{ selector: 'cgi-timepicker', standalone: false, template: "<mat-form-field\n  aria-label=\"hour\"\n  appearance=\"outline\"\n  color=\"accent\"\n  floatLabel=\"always\"\n  [ngClass]=\"{\n    'cgi-forms-readonly': readonly,\n    'mat-form-field-invalid':\n      (hourFC.touched && !hourFC.valid) || (minutesFC.touched && !minutesFC.valid)\n  }\"\n>\n  <mat-label>Hr</mat-label>\n  <input\n    matInput\n    type=\"text\"\n    maxlength=\"2\"\n    placeholder=\"00\"\n    [matAutocomplete]=\"cgiTimepickerHour\"\n    [formControl]=\"hourFC\"\n    (change)=\"updateTime()\"\n    [required]=\"required\"\n  />\n  <mat-autocomplete #cgiTimepickerHour=\"matAutocomplete\" (optionSelected)=\"updateTime()\">\n    <mat-option *ngFor=\"let hour of filteredHrs | async\" [value]=\"hour\">\n      {{ hour }}\n    </mat-option>\n  </mat-autocomplete>\n</mat-form-field>\n<span class=\"cgi-timepicker--colon mx-1\">:</span>\n<mat-form-field\n  aria-label=\"minute\"\n  appearance=\"outline\"\n  color=\"accent\"\n  floatLabel=\"always\"\n  [ngClass]=\"{\n    'cgi-timepicker--shift-mins-label': required,\n    'cgi-forms-readonly': readonly,\n    'mat-form-field-invalid':\n      (hourFC.touched && !hourFC.valid) || (minutesFC.touched && !minutesFC.valid)\n  }\"\n>\n  <mat-label>Min</mat-label>\n  <input\n    matInput\n    type=\"text\"\n    maxlength=\"2\"\n    placeholder=\"00\"\n    [matAutocomplete]=\"cgiTimepickerMin\"\n    [formControl]=\"minutesFC\"\n    (change)=\"updateTime()\"\n    [required]=\"required\"\n  />\n  <mat-autocomplete #cgiTimepickerMin=\"matAutocomplete\" (optionActivated)=\"updateTime()\">\n    <mat-option *ngFor=\"let minute of filteredMins | async\" [value]=\"minute\">\n      {{ minute }}\n    </mat-option>\n  </mat-autocomplete>\n</mat-form-field>\n<ng-container *ngIf=\"!readonly\">\n  <mat-button-toggle-group\n    aria-label=\"day period\"\n    class=\"mat-toggle-group\"\n    [formControl]=\"dayPeriodFC\"\n    (change)=\"updateTime()\"\n  >\n    <mat-button-toggle value=\"am\" [disabled]=\"disabled\" aria-label=\"Time picker toggle for AM\">\n      AM\n    </mat-button-toggle>\n    <mat-button-toggle value=\"pm\" [disabled]=\"disabled\" aria-label=\"Time picker toggle for PM\">\n      PM\n    </mat-button-toggle>\n  </mat-button-toggle-group>\n</ng-container>\n<ng-container *ngIf=\"readonly && dayPeriodFC\">\n  <span class=\"cgi-readonly-dayperiod\">{{ dayPeriodFC.value | uppercase }}</span>\n</ng-container>\n<mat-error\n  *ngIf=\"\n    required &&\n    ((hourFC.touched && !hourFC.valid) ||\n      (minutesFC.touched && !minutesFC.valid) ||\n      (!getValidity() && parentForm.submitted))\n  \"\n  >{{ errorMessage }}</mat-error\n>\n", styles: [":host(.cgi-timepicker) .mat-mdc-form-field{width:40px}:host(.cgi-timepicker) .mat-mdc-form-field.mat-form-field-invalid ::ng-deep .mat-form-field-wrapper{margin-bottom:0!important;padding-bottom:0!important}:host(.cgi-timepicker) .mat-toggle-group{margin-left:.75rem;top:-2px}:host(.cgi-timepicker) [class^=cgi-forms-readonly].mat-form-field-disabled ::ng-deep .mat-form-field-outline-start,:host(.cgi-timepicker) [class^=cgi-forms-readonly].mat-form-field-disabled ::ng-deep .mat-form-field-outline-gap,:host(.cgi-timepicker) [class^=cgi-forms-readonly].mat-form-field-disabled ::ng-deep .mat-form-field-outline-end,:host(.cgi-timepicker) [class*=cgi-forms-readonly].mat-form-field-disabled ::ng-deep .mat-form-field-outline-start,:host(.cgi-timepicker) [class*=cgi-forms-readonly].mat-form-field-disabled ::ng-deep .mat-form-field-outline-gap,:host(.cgi-timepicker) [class*=cgi-forms-readonly].mat-form-field-disabled ::ng-deep .mat-form-field-outline-end{border:0}:host(.cgi-timepicker) [class^=cgi-forms-readonly].mat-form-field-disabled .mat-mdc-input-element,:host(.cgi-timepicker) [class*=cgi-forms-readonly].mat-form-field-disabled .mat-mdc-input-element{color:currentColor}:host(.cgi-timepicker) [class^=cgi-forms-readonly] ::ng-deep .mat-form-field-flex,:host(.cgi-timepicker) [class*=cgi-forms-readonly] ::ng-deep .mat-form-field-flex{padding:0!important}:host(.cgi-timepicker) .mat-mdc-form-field-error{font-size:12px}.cdk-overlay-container .cgi-timepicker .mat-toggle-group .mat-button-toggle-label-content,.cgi-nav-content .cgi-timepicker .mat-toggle-group .mat-button-toggle-label-content{line-height:40px}.cgi-timepicker--shift-mins-label.mat-form-field-appearance-outline.mat-form-field-can-float.mat-form-field-should-float ::ng-deep .mat-form-field-label{overflow:visible;transform:translate(-3px) translateY(-1.4em) scale(.75)}.cgi-readonly-dayperiod{color:#888d91}::ng-deep .cgi-forms-readonly-bold .cgi-readonly-dayperiod{font-weight:700}\n"] }]
        }], ctorParameters: () => [{ type: i1$2.FormGroupDirective }], propDecorators: { isClassContainer: [{
                type: HostBinding,
                args: ['class.cgi-timepicker']
            }], setDateTime: [{
                type: Input
            }], errorMessage: [{
                type: Input
            }], required: [{
                type: Input
            }], disabled: [{
                type: Input
            }], readonly: [{
                type: Input
            }], timeSelected: [{
                type: Output
            }] } });

class CGITimepickerModule {
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.2", ngImport: i0, type: CGITimepickerModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule }); }
    static { this.ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "20.3.2", ngImport: i0, type: CGITimepickerModule, declarations: [CGITimepickerComponent], imports: [CommonModule,
            MatAutocompleteModule,
            MatButtonToggleModule,
            MatFormFieldModule,
            FormsModule,
            MatInputModule,
            ReactiveFormsModule], exports: [CGITimepickerComponent] }); }
    static { this.ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "20.3.2", ngImport: i0, type: CGITimepickerModule, imports: [CommonModule,
            MatAutocompleteModule,
            MatButtonToggleModule,
            MatFormFieldModule,
            FormsModule,
            MatInputModule,
            ReactiveFormsModule] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.2", ngImport: i0, type: CGITimepickerModule, decorators: [{
            type: NgModule,
            args: [{
                    declarations: [CGITimepickerComponent],
                    imports: [
                        CommonModule,
                        MatAutocompleteModule,
                        MatButtonToggleModule,
                        MatFormFieldModule,
                        FormsModule,
                        MatInputModule,
                        ReactiveFormsModule,
                    ],
                    exports: [CGITimepickerComponent],
                }]
        }] });

/**
 * GlobalSearchGroupOptions class
 */
class GlobalSearchGroupOptions {
    /** constructor
     * @param contents getting GlobalSearchEntity type of array
     * @param totalRecords getting total name of result
     * @param category getting category data ( not necessary )
     */
    constructor(contents, totalRecords, category, expandCategory) {
        this.category = category;
        this.contents = contents || [];
        this.totalRecords = totalRecords || 0;
        this.expandCategory = expandCategory || false;
    }
}

/**
 * GlobalSearchEntity class
 */
class GlobalSearchEntity {
    /**
     * constructor ( it receive variables ( code, name ) and saving )
     * @param code code for content
     * @param name name for content
     */
    constructor(code, name) {
        this.code = code || '';
        this.name = name || '';
    }
}

/**
 * GlobalSearchCategory class
 */
class GlobalSearchCategory {
    /**
     * constructor ( it receive variables ( name, value ) and saving )
     * @param name getting category name
     * @param value getting category value
     * @param icon getting category icon name
     * @param moreResultsLink getting category link for more results
     * @param queryParamKey getting key for queryparams
     */
    constructor(name, value, icon, moreResultsLink, queryParamKey) {
        this.name = name || '';
        this.value = value || '';
        this.icon = icon || '';
        this.moreResultsLink = moreResultsLink || '';
        this.queryParamKey = queryParamKey || null;
    }
}

/**
 * Footer Container component.
 *
 */
class CGIFooterContainerComponent {
    /** constructor for DI */
    constructor(cgiNavContainer, document, breakpointObserver) {
        this.cgiNavContainer = cgiNavContainer;
        this.document = document;
        this.breakpointObserver = breakpointObserver;
        /** footer container css selector */
        this.cgiFooter = '.cgi-footer-container';
    }
    /** subscribes to sidenav value and screen size for footer flexibility  */
    ngOnInit() {
        /** reference to the footer */
        const footer = document.querySelector(this.cgiFooter);
        /** reference to the sidenav */
        const sideNav = document.querySelector('.cgi-side-nav');
        if (footer !== null) {
            this.navBarScreenObservable$ = combineLatest([
                this.cgiNavContainer.changes,
                this.breakpointObserver.observe(['(min-width: 600px)']),
            ]).subscribe(([navOpen, fullScreenSize]) => {
                if (navOpen && fullScreenSize.matches) {
                    footer.classList.add('cgi-footer-container--collapsed');
                }
                else {
                    footer.classList.remove('cgi-footer-container--collapsed');
                }
            });
            /** when sidenav does not exist extend the footer all the way to the left */
            if (!sideNav) {
                footer.classList.add('cgi-footer-container--full-width');
            }
        }
    }
    /** toggles the footer */
    ngOnChanges() {
        /** reference to the footer */
        const footer = document.querySelector(this.cgiFooter);
        if (footer !== null && this.toggle) {
            footer.classList.add('cgi-footer-container--opened');
            footer.setAttribute('aria-hidden', 'false');
        }
        else {
            footer.classList.remove('cgi-footer-container--opened');
            footer.setAttribute('aria-hidden', 'true');
        }
    }
    /** cleaning up observables */
    ngOnDestroy() {
        if (this.navBarScreenObservable$) {
            this.navBarScreenObservable$.unsubscribe();
        }
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.2", ngImport: i0, type: CGIFooterContainerComponent, deps: [{ token: CGINavContainerService$1, optional: true }, { token: DOCUMENT }, { token: i1$1.BreakpointObserver }], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "20.3.2", type: CGIFooterContainerComponent, isStandalone: false, selector: "cgi-footer-container", inputs: { toggle: "toggle" }, usesOnChanges: true, ngImport: i0, template: "<ng-content></ng-content>\n", styles: [":host(.cgi-footer-container){background-color:#f6f7f7;bottom:0;box-shadow:0 -2px 7px #00001940;display:flex;left:4.4rem;position:fixed;right:0;transform:translateY(110%);transition:.2s cubic-bezier(.25,.8,.25,1);visibility:hidden}:host(.cgi-footer-container).cgi-footer-container--opened{transform:translateY(0);visibility:visible}:host(.cgi-footer-container).cgi-footer-container--collapsed{margin-left:13.6rem}:host(.cgi-footer-container).cgi-footer-container--full-width{left:0!important}@media (max-width: 599px){:host(.cgi-footer-container){left:0}}:host(.cgi-footer-container) ::ng-deep .cgi-footer__text{align-self:center;margin:8px 30px}:host(.cgi-footer-container) ::ng-deep .cgi-footer__right-button-group{align-self:center;margin-left:auto;margin-right:22px;white-space:nowrap}\n"] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.2", ngImport: i0, type: CGIFooterContainerComponent, decorators: [{
            type: Component,
            args: [{ selector: 'cgi-footer-container', standalone: false, template: "<ng-content></ng-content>\n", styles: [":host(.cgi-footer-container){background-color:#f6f7f7;bottom:0;box-shadow:0 -2px 7px #00001940;display:flex;left:4.4rem;position:fixed;right:0;transform:translateY(110%);transition:.2s cubic-bezier(.25,.8,.25,1);visibility:hidden}:host(.cgi-footer-container).cgi-footer-container--opened{transform:translateY(0);visibility:visible}:host(.cgi-footer-container).cgi-footer-container--collapsed{margin-left:13.6rem}:host(.cgi-footer-container).cgi-footer-container--full-width{left:0!important}@media (max-width: 599px){:host(.cgi-footer-container){left:0}}:host(.cgi-footer-container) ::ng-deep .cgi-footer__text{align-self:center;margin:8px 30px}:host(.cgi-footer-container) ::ng-deep .cgi-footer__right-button-group{align-self:center;margin-left:auto;margin-right:22px;white-space:nowrap}\n"] }]
        }], ctorParameters: () => [{ type: CGINavContainerService$1, decorators: [{
                    type: Optional
                }] }, { type: undefined, decorators: [{
                    type: Inject,
                    args: [DOCUMENT]
                }] }, { type: i1$1.BreakpointObserver }], propDecorators: { toggle: [{
                type: Input
            }] } });

class CGIFooterModule {
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.2", ngImport: i0, type: CGIFooterModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule }); }
    static { this.ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "20.3.2", ngImport: i0, type: CGIFooterModule, declarations: [CGIFooterContainerComponent], imports: [CommonModule, MatIconModule, MatButtonModule, ReactiveFormsModule], exports: [CGIFooterContainerComponent] }); }
    static { this.ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "20.3.2", ngImport: i0, type: CGIFooterModule, imports: [CommonModule, MatIconModule, MatButtonModule, ReactiveFormsModule] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.2", ngImport: i0, type: CGIFooterModule, decorators: [{
            type: NgModule,
            args: [{
                    imports: [CommonModule, MatIconModule, MatButtonModule, ReactiveFormsModule],
                    declarations: [CGIFooterContainerComponent],
                    exports: [CGIFooterContainerComponent],
                    providers: [],
                }]
        }] });

/**
 *  Headstone Component
 */
class CGIHeadstoneComponent {
    /** Constructor */
    constructor() { }
    /** Life cycle hook for when the component is first initiated. */
    ngOnInit() {
        this.isClassContainer = true;
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.2", ngImport: i0, type: CGIHeadstoneComponent, deps: [], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "20.3.2", type: CGIHeadstoneComponent, isStandalone: false, selector: "cgi-headstone", host: { properties: { "class.cgi-headstone": "this.isClassContainer" } }, ngImport: i0, template: "<mat-card appearance=\"outlined\">\n  <mat-card-content>\n    <div class=\"row no-gutters\">\n      <ng-content></ng-content>\n    </div>\n  </mat-card-content>\n</mat-card>\n<ng-content select=\"cgi-headstone-accordion\"></ng-content>\n", styles: [":host(.cgi-headstone) .mat-mdc-card{background-color:#ebf0fa;padding:8px!important;z-index:2}:host(.cgi-headstone).cgi-headstone--embedded>.mat-mdc-card{background-color:transparent;box-shadow:none!important;padding:0!important}:host(.cgi-headstone).cgi-headstone--dashboard ::ng-deep .cgi-headstone-item{font-size:22px;white-space:nowrap}:host(.cgi-headstone).cgi-headstone--dashboard ::ng-deep .cgi-headstone-item mat-icon{margin-right:5px}@media (min-width: 992px){:host(.cgi-headstone).cgi-headstone--dashboard ::ng-deep .cgi-headstone-item{flex:0 0 16.66666667%;max-width:100%}}@media (max-width: 992px){:host(.cgi-headstone).cgi-headstone--dashboard ::ng-deep .cgi-headstone-item{flex:0 0 50%;max-width:50%}}\n"], dependencies: [{ kind: "component", type: i1$5.MatCard, selector: "mat-card", inputs: ["appearance"], exportAs: ["matCard"] }, { kind: "directive", type: i1$5.MatCardContent, selector: "mat-card-content" }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.2", ngImport: i0, type: CGIHeadstoneComponent, decorators: [{
            type: Component,
            args: [{ selector: 'cgi-headstone', standalone: false, template: "<mat-card appearance=\"outlined\">\n  <mat-card-content>\n    <div class=\"row no-gutters\">\n      <ng-content></ng-content>\n    </div>\n  </mat-card-content>\n</mat-card>\n<ng-content select=\"cgi-headstone-accordion\"></ng-content>\n", styles: [":host(.cgi-headstone) .mat-mdc-card{background-color:#ebf0fa;padding:8px!important;z-index:2}:host(.cgi-headstone).cgi-headstone--embedded>.mat-mdc-card{background-color:transparent;box-shadow:none!important;padding:0!important}:host(.cgi-headstone).cgi-headstone--dashboard ::ng-deep .cgi-headstone-item{font-size:22px;white-space:nowrap}:host(.cgi-headstone).cgi-headstone--dashboard ::ng-deep .cgi-headstone-item mat-icon{margin-right:5px}@media (min-width: 992px){:host(.cgi-headstone).cgi-headstone--dashboard ::ng-deep .cgi-headstone-item{flex:0 0 16.66666667%;max-width:100%}}@media (max-width: 992px){:host(.cgi-headstone).cgi-headstone--dashboard ::ng-deep .cgi-headstone-item{flex:0 0 50%;max-width:50%}}\n"] }]
        }], ctorParameters: () => [], propDecorators: { isClassContainer: [{
                type: HostBinding,
                args: ['class.cgi-headstone']
            }] } });

/**
 * Headstone Accordion component.
 */
class CGIHeadstoneAccordionComponent {
    /** Component Constructor */
    constructor() {
        /** Boolean to toggle Accordion expansion */
        this.accordionExpanded = false;
        this.isClassContainer = true;
    }
    /** Life cycle hook for when the component is first initiated. */
    ngOnInit() { }
    /** Toggle Accordion expansion */
    toggle() {
        this.accordionExpanded = !this.accordionExpanded;
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.2", ngImport: i0, type: CGIHeadstoneAccordionComponent, deps: [], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "20.3.2", type: CGIHeadstoneAccordionComponent, isStandalone: false, selector: "cgi-headstone-accordion", host: { properties: { "class.cgi-headstone-accordion": "this.isClassContainer" } }, ngImport: i0, template: "<mat-expansion-panel [expanded]=\"accordionExpanded\">\n  <ng-content select=\".cgi-headstone-accordion__header\"></ng-content>\n  <mat-divider></mat-divider>\n  <ng-content></ng-content>\n</mat-expansion-panel>\n<mat-card appearance=\"outlined\" class=\"cgi-headstone-accordion__toggle\">\n  <button mat-button color=\"primary\" *ngIf=\"!accordionExpanded\" (click)=\"toggle()\">\n    Show More\n  </button>\n  <button mat-button color=\"primary\" *ngIf=\"accordionExpanded\" (click)=\"toggle()\">Hide</button>\n</mat-card>\n", styles: [":host(.cgi-headstone-accordion){z-index:1}:host(.cgi-headstone-accordion) .cgi-headstone-accordion__toggle{align-items:center;display:flex;justify-content:center;padding:0!important}:host(.cgi-headstone-accordion) .cgi-headstone-accordion__toggle button{background-color:transparent;border:0;color:#006f95;font-size:13px;font-weight:700;line-height:25px;margin:0;padding:0;width:100%}:host(.cgi-headstone-accordion) ::ng-deep .mat-expansion-panel .mat-expansion-panel-body{padding:0}:host(.cgi-headstone-accordion) ::ng-deep .cgi-headstone-accordion__header{align-items:center;display:flex;font-size:20px;font-weight:700;justify-content:space-between;padding:16px 16px 16px 24px}:host(.cgi-headstone-accordion) ::ng-deep button{margin:0}:host(.cgi-headstone-accordion) ::ng-deep button mat-icon{font-size:20px}\n"], dependencies: [{ kind: "directive", type: i1.NgIf, selector: "[ngIf]", inputs: ["ngIf", "ngIfThen", "ngIfElse"] }, { kind: "component", type: i4.MatButton, selector: "    button[matButton], a[matButton], button[mat-button], button[mat-raised-button],    button[mat-flat-button], button[mat-stroked-button], a[mat-button], a[mat-raised-button],    a[mat-flat-button], a[mat-stroked-button]  ", inputs: ["matButton"], exportAs: ["matButton", "matAnchor"] }, { kind: "component", type: i1$5.MatCard, selector: "mat-card", inputs: ["appearance"], exportAs: ["matCard"] }, { kind: "component", type: i4$5.MatDivider, selector: "mat-divider", inputs: ["vertical", "inset"] }, { kind: "component", type: i4$2.MatExpansionPanel, selector: "mat-expansion-panel", inputs: ["hideToggle", "togglePosition"], outputs: ["afterExpand", "afterCollapse"], exportAs: ["matExpansionPanel"] }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.2", ngImport: i0, type: CGIHeadstoneAccordionComponent, decorators: [{
            type: Component,
            args: [{ selector: 'cgi-headstone-accordion', standalone: false, template: "<mat-expansion-panel [expanded]=\"accordionExpanded\">\n  <ng-content select=\".cgi-headstone-accordion__header\"></ng-content>\n  <mat-divider></mat-divider>\n  <ng-content></ng-content>\n</mat-expansion-panel>\n<mat-card appearance=\"outlined\" class=\"cgi-headstone-accordion__toggle\">\n  <button mat-button color=\"primary\" *ngIf=\"!accordionExpanded\" (click)=\"toggle()\">\n    Show More\n  </button>\n  <button mat-button color=\"primary\" *ngIf=\"accordionExpanded\" (click)=\"toggle()\">Hide</button>\n</mat-card>\n", styles: [":host(.cgi-headstone-accordion){z-index:1}:host(.cgi-headstone-accordion) .cgi-headstone-accordion__toggle{align-items:center;display:flex;justify-content:center;padding:0!important}:host(.cgi-headstone-accordion) .cgi-headstone-accordion__toggle button{background-color:transparent;border:0;color:#006f95;font-size:13px;font-weight:700;line-height:25px;margin:0;padding:0;width:100%}:host(.cgi-headstone-accordion) ::ng-deep .mat-expansion-panel .mat-expansion-panel-body{padding:0}:host(.cgi-headstone-accordion) ::ng-deep .cgi-headstone-accordion__header{align-items:center;display:flex;font-size:20px;font-weight:700;justify-content:space-between;padding:16px 16px 16px 24px}:host(.cgi-headstone-accordion) ::ng-deep button{margin:0}:host(.cgi-headstone-accordion) ::ng-deep button mat-icon{font-size:20px}\n"] }]
        }], ctorParameters: () => [], propDecorators: { isClassContainer: [{
                type: HostBinding,
                args: ['class.cgi-headstone-accordion']
            }] } });

/**
 * Headstone Item Component
 */
class CGIHeadstoneItemComponent {
    /** constructor */
    constructor() {
        /** HostBinding for CSS */
        this.class = 'col-6 col-sm-4 col-md-3 col-lg-auto cgi-headstone-item';
    }
    /** Life cycle hook for when the component is first initiated. */
    ngOnInit() { }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.2", ngImport: i0, type: CGIHeadstoneItemComponent, deps: [], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "20.3.2", type: CGIHeadstoneItemComponent, isStandalone: false, selector: "cgi-headstone-item", inputs: { toolTip: "toolTip" }, host: { properties: { "class": "this.class" } }, ngImport: i0, template: "<div\n  class=\"cgi-caption cgi-body-14 cgi-headstone-item__title\"\n  matTooltip=\"{{ toolTip }}\"\n  matTooltipPosition=\"above\"\n>\n  <ng-content select=\"label\"></ng-content>\n</div>\n<ng-content></ng-content>\n<small><ng-content select=\".cgi-headstone-item__footer\"></ng-content></small>\n", styles: [":host(.cgi-headstone-item){color:#13283e;font-size:16px;font-weight:700;padding:8px 16px}:host(.cgi-headstone-item) ::ng-deep a.cgi-link-icon{font-weight:400;margin-left:20px}:host(.cgi-headstone-item) ::ng-deep a.cgi-link-icon>mat-icon{height:18px;width:18px}:host(.cgi-headstone-item) ::ng-deep .cgi-headstone-item__title{font-weight:500}:host(.cgi-headstone-item) ::ng-deep label{margin-bottom:0;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}:host(.cgi-headstone-item) ::ng-deep .cgi-headstone-item__footer{color:#616161;font-size:12px;font-weight:400}@media (max-width: 960px){:host(.cgi-headstone-item) ::ng-deep a.cgi-link-icon{font-size:0;margin-left:5px}:host(.cgi-headstone-item) ::ng-deep a.cgi-link-icon mat-icon{font-size:14px}}\n"], dependencies: [{ kind: "directive", type: i1$6.MatTooltip, selector: "[matTooltip]", inputs: ["matTooltipPosition", "matTooltipPositionAtOrigin", "matTooltipDisabled", "matTooltipShowDelay", "matTooltipHideDelay", "matTooltipTouchGestures", "matTooltip", "matTooltipClass"], exportAs: ["matTooltip"] }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.2", ngImport: i0, type: CGIHeadstoneItemComponent, decorators: [{
            type: Component,
            args: [{ selector: 'cgi-headstone-item', standalone: false, template: "<div\n  class=\"cgi-caption cgi-body-14 cgi-headstone-item__title\"\n  matTooltip=\"{{ toolTip }}\"\n  matTooltipPosition=\"above\"\n>\n  <ng-content select=\"label\"></ng-content>\n</div>\n<ng-content></ng-content>\n<small><ng-content select=\".cgi-headstone-item__footer\"></ng-content></small>\n", styles: [":host(.cgi-headstone-item){color:#13283e;font-size:16px;font-weight:700;padding:8px 16px}:host(.cgi-headstone-item) ::ng-deep a.cgi-link-icon{font-weight:400;margin-left:20px}:host(.cgi-headstone-item) ::ng-deep a.cgi-link-icon>mat-icon{height:18px;width:18px}:host(.cgi-headstone-item) ::ng-deep .cgi-headstone-item__title{font-weight:500}:host(.cgi-headstone-item) ::ng-deep label{margin-bottom:0;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}:host(.cgi-headstone-item) ::ng-deep .cgi-headstone-item__footer{color:#616161;font-size:12px;font-weight:400}@media (max-width: 960px){:host(.cgi-headstone-item) ::ng-deep a.cgi-link-icon{font-size:0;margin-left:5px}:host(.cgi-headstone-item) ::ng-deep a.cgi-link-icon mat-icon{font-size:14px}}\n"] }]
        }], ctorParameters: () => [], propDecorators: { class: [{
                type: HostBinding,
                args: ['class']
            }], toolTip: [{
                type: Input
            }] } });

class CGIHeadstoneModule {
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.2", ngImport: i0, type: CGIHeadstoneModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule }); }
    static { this.ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "20.3.2", ngImport: i0, type: CGIHeadstoneModule, declarations: [CGIHeadstoneComponent, CGIHeadstoneItemComponent, CGIHeadstoneAccordionComponent], imports: [CommonModule,
            MatButtonModule,
            MatCardModule,
            MatDividerModule,
            MatExpansionModule,
            MatTooltipModule], exports: [CGIHeadstoneComponent, CGIHeadstoneItemComponent, CGIHeadstoneAccordionComponent] }); }
    static { this.ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "20.3.2", ngImport: i0, type: CGIHeadstoneModule, imports: [CommonModule,
            MatButtonModule,
            MatCardModule,
            MatDividerModule,
            MatExpansionModule,
            MatTooltipModule] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.2", ngImport: i0, type: CGIHeadstoneModule, decorators: [{
            type: NgModule,
            args: [{
                    imports: [
                        CommonModule,
                        MatButtonModule,
                        MatCardModule,
                        MatDividerModule,
                        MatExpansionModule,
                        MatTooltipModule,
                    ],
                    declarations: [CGIHeadstoneComponent, CGIHeadstoneItemComponent, CGIHeadstoneAccordionComponent],
                    exports: [CGIHeadstoneComponent, CGIHeadstoneItemComponent, CGIHeadstoneAccordionComponent],
                }]
        }] });

class CGIMultiSelectCheckboxesComponent {
    constructor(table, cdRef) {
        this.table = table;
        this.cdRef = cdRef;
        /** Event Emitter to emit the modified selection set back to the parent component */
        this.updatedSelectionSet = new EventEmitter();
        /** Aria labels in HTML */
        this.checkboxLabel = 'multiSelectCheckbox';
        /** flag to keep track of whether the shift key is being held down - defaulted to false */
        this.shiftKeyHeldDown = false;
        /**
         * HostBinding initiate
         */
        this.isClassContainer = true;
    }
    ngAfterViewInit() {
        this.selectionSet.totalSelected = 0;
        this.selectionSet.lastSelected = 0;
    }
    ngOnInit() {
        /** Adds the select column */
        if (this.table) {
            this.cdRef.detectChanges();
            this.table.addColumnDef(this.columnDef);
        }
    }
    /** function: detects when a shift key is clicked - associated with (click) to allow multi select */
    shiftHandler(event) {
        event.stopPropagation();
        // checks if shift key was held during click
        if (event.shiftKey) {
            this.shiftKeyHeldDown = true;
        }
        else {
            this.shiftKeyHeldDown = false;
        }
    }
    /** function: handles a click event for multi-select table - associated with (change) but occurs after (click) */
    clickHandler(row, index, checkboxClicked) {
        // checks if shift key was held during click
        if (this.shiftKeyHeldDown) {
            this.selectRows(index);
        }
        else if (checkboxClicked) {
            this.selectionSet.selection.toggle(row);
            if (this.selectionSet.selection.isSelected(row)) {
                this.selectionSet.totalSelected++;
            }
            else {
                this.selectionSet.totalSelected--;
                if (this.selectionSet.totalSelected === 0) {
                    this.selectionSet.lastSelected = 0;
                }
            }
            this.checkLastSelected();
        }
        this.updatedSelectionSet.emit(this.selectionSet);
    }
    /** function: checks the last data value selected on multi-select table */
    checkLastSelected() {
        let lastSelectedIndex = 0;
        this.dataSourceSorted.forEach((row) => {
            if (this.selectionSet.selection.isSelected(row)) {
                this.selectionSet.lastSelected = lastSelectedIndex;
            }
            lastSelectedIndex++;
        });
    }
    /**  function: selects multiple rows at once on multi-select table */
    selectRows(index) {
        this.checkLastSelected();
        const indexOne = this.selectionSet.lastSelected;
        const indexTwo = index;
        let startIndex;
        let endIndex;
        if (indexOne > indexTwo) {
            // select rows in descending order
            startIndex = indexTwo;
            endIndex = indexOne;
        }
        else {
            // select rows in ascending order
            startIndex = indexOne;
            endIndex = indexTwo;
        }
        let currentIndex = 0;
        this.dataSourceSorted.forEach((row) => {
            if (currentIndex >= startIndex && currentIndex <= endIndex) {
                if (!this.selectionSet.selection.isSelected(row)) {
                    this.selectionSet.totalSelected++;
                }
                this.selectionSet.selection.select(row);
            }
            currentIndex++;
            this.checkLastSelected();
        });
    }
    /** function: checks if all values in multi-select table are selected */
    isAllSelected() {
        const numSelected = this.selectionSet.selection.selected.length;
        const numRows = this.dataSourceSorted.length;
        return numSelected === numRows;
    }
    /** function: selects/deselects all values in multi-select table */
    masterToggle() {
        if (this.isAllSelected()) {
            this.selectionSet.selection.clear();
            this.selectionSet.totalSelected = 0;
        }
        else {
            this.selectionSet.selection.select(...this.dataSourceSorted);
            this.selectionSet.totalSelected = this.dataSourceSorted.length;
        }
        this.selectionSet.lastSelected = 0;
        this.updatedSelectionSet.emit(this.selectionSet);
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.2", ngImport: i0, type: CGIMultiSelectCheckboxesComponent, deps: [{ token: i1$7.MatTable, optional: true }, { token: i0.ChangeDetectorRef }], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "20.3.2", type: CGIMultiSelectCheckboxesComponent, isStandalone: false, selector: "cgi-multi-select-checkboxes", inputs: { selection: "selection", selectionSet: "selectionSet", dataSourceSorted: "dataSourceSorted" }, outputs: { updatedSelectionSet: "updatedSelectionSet" }, host: { properties: { "class.cgi-multi-select-checkboxes": "this.isClassContainer" } }, viewQueries: [{ propertyName: "columnDef", first: true, predicate: MatColumnDef, descendants: true }], ngImport: i0, template: "<ng-container matColumnDef=\"select\">\n  <th mat-header-cell *matHeaderCellDef>\n    <mat-checkbox\n      (change)=\"$event ? masterToggle() : null\"\n      [checked]=\"selectionSet.selection.hasValue() && isAllSelected()\"\n      [indeterminate]=\"selectionSet.selection.hasValue() && !isAllSelected()\"\n      [aria-label]=\"checkboxLabel\"\n    >\n    </mat-checkbox>\n  </th>\n  <td mat-cell *matCellDef=\"let row; let i = index\">\n    <mat-checkbox\n      (click)=\"shiftHandler($event)\"\n      (change)=\"clickHandler(row, i, true)\"\n      [checked]=\"selectionSet.selection.isSelected(row)\"\n      [aria-label]=\"checkboxLabel\"\n    >\n    </mat-checkbox>\n  </td>\n</ng-container>\n", styles: ["::ng-deep label.mat-checkbox-layout{margin-bottom:2px}\n"], dependencies: [{ kind: "directive", type: i1$7.MatHeaderCellDef, selector: "[matHeaderCellDef]" }, { kind: "directive", type: i1$7.MatColumnDef, selector: "[matColumnDef]", inputs: ["matColumnDef"] }, { kind: "directive", type: i1$7.MatCellDef, selector: "[matCellDef]" }, { kind: "directive", type: i1$7.MatHeaderCell, selector: "mat-header-cell, th[mat-header-cell]" }, { kind: "directive", type: i1$7.MatCell, selector: "mat-cell, td[mat-cell]" }, { kind: "component", type: i2$2.MatCheckbox, selector: "mat-checkbox", inputs: ["aria-label", "aria-labelledby", "aria-describedby", "aria-expanded", "aria-controls", "aria-owns", "id", "required", "labelPosition", "name", "value", "disableRipple", "tabIndex", "color", "disabledInteractive", "checked", "disabled", "indeterminate"], outputs: ["change", "indeterminateChange"], exportAs: ["matCheckbox"] }], changeDetection: i0.ChangeDetectionStrategy.OnPush }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.2", ngImport: i0, type: CGIMultiSelectCheckboxesComponent, decorators: [{
            type: Component,
            args: [{ selector: 'cgi-multi-select-checkboxes', changeDetection: ChangeDetectionStrategy.OnPush, standalone: false, template: "<ng-container matColumnDef=\"select\">\n  <th mat-header-cell *matHeaderCellDef>\n    <mat-checkbox\n      (change)=\"$event ? masterToggle() : null\"\n      [checked]=\"selectionSet.selection.hasValue() && isAllSelected()\"\n      [indeterminate]=\"selectionSet.selection.hasValue() && !isAllSelected()\"\n      [aria-label]=\"checkboxLabel\"\n    >\n    </mat-checkbox>\n  </th>\n  <td mat-cell *matCellDef=\"let row; let i = index\">\n    <mat-checkbox\n      (click)=\"shiftHandler($event)\"\n      (change)=\"clickHandler(row, i, true)\"\n      [checked]=\"selectionSet.selection.isSelected(row)\"\n      [aria-label]=\"checkboxLabel\"\n    >\n    </mat-checkbox>\n  </td>\n</ng-container>\n", styles: ["::ng-deep label.mat-checkbox-layout{margin-bottom:2px}\n"] }]
        }], ctorParameters: () => [{ type: i1$7.MatTable, decorators: [{
                    type: Optional
                }] }, { type: i0.ChangeDetectorRef }], propDecorators: { isClassContainer: [{
                type: HostBinding,
                args: ['class.cgi-multi-select-checkboxes']
            }], columnDef: [{
                type: ViewChild,
                args: [MatColumnDef]
            }], selection: [{
                type: Input
            }], selectionSet: [{
                type: Input
            }], dataSourceSorted: [{
                type: Input
            }], updatedSelectionSet: [{
                type: Output
            }] } });

/**
 * Library multi-select header component showing selected row count.
 * Mirrors the brand header but used within the library bundle.
 */
class CGIMultiSelectHeaderComponent {
    constructor() {
        /**
         * HostBinding initiate
         */
        this.isClassContainer = true;
    }
    /** Lifecycle hook called once after first display */
    ngOnInit() { }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.2", ngImport: i0, type: CGIMultiSelectHeaderComponent, deps: [], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "20.3.2", type: CGIMultiSelectHeaderComponent, isStandalone: false, selector: "cgi-multi-select-header", inputs: { totalSelected: "totalSelected" }, host: { properties: { "class.cgi-multi-select-header": "this.isClassContainer" } }, ngImport: i0, template: "<mat-card-header class=\"cgi-multi-select-header__row-margin\">\n  <div class=\"cgi-multi-select-header__row\" *ngIf=\"totalSelected\">\n    <p class=\"cgi-body-1 cgi-multi-select-header__text\">{{ totalSelected }} total selected</p>\n\n    <ng-content></ng-content>\n  </div>\n</mat-card-header>\n", styles: [":host(.cgi-multi-select-header) .cgi-multi-select-header__row{background-color:#ebf0fa;margin:-4px 0 0;padding:0 24px;width:100%}:host(.cgi-multi-select-header) .cgi-multi-select-header__row .cgi-multi-select-header__text{display:inline-block;margin-bottom:0;margin-right:16px}:host(.cgi-multi-select-header) .cgi-multi-select-header__row-margin{margin:0 -15px}\n"], dependencies: [{ kind: "directive", type: i1.NgIf, selector: "[ngIf]", inputs: ["ngIf", "ngIfThen", "ngIfElse"] }, { kind: "component", type: i1$5.MatCardHeader, selector: "mat-card-header" }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.2", ngImport: i0, type: CGIMultiSelectHeaderComponent, decorators: [{
            type: Component,
            args: [{ selector: 'cgi-multi-select-header', standalone: false, template: "<mat-card-header class=\"cgi-multi-select-header__row-margin\">\n  <div class=\"cgi-multi-select-header__row\" *ngIf=\"totalSelected\">\n    <p class=\"cgi-body-1 cgi-multi-select-header__text\">{{ totalSelected }} total selected</p>\n\n    <ng-content></ng-content>\n  </div>\n</mat-card-header>\n", styles: [":host(.cgi-multi-select-header) .cgi-multi-select-header__row{background-color:#ebf0fa;margin:-4px 0 0;padding:0 24px;width:100%}:host(.cgi-multi-select-header) .cgi-multi-select-header__row .cgi-multi-select-header__text{display:inline-block;margin-bottom:0;margin-right:16px}:host(.cgi-multi-select-header) .cgi-multi-select-header__row-margin{margin:0 -15px}\n"] }]
        }], ctorParameters: () => [], propDecorators: { isClassContainer: [{
                type: HostBinding,
                args: ['class.cgi-multi-select-header']
            }], totalSelected: [{
                type: Input
            }] } });

class CGIMultiSelectModule {
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.2", ngImport: i0, type: CGIMultiSelectModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule }); }
    static { this.ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "20.3.2", ngImport: i0, type: CGIMultiSelectModule, declarations: [CGIMultiSelectCheckboxesComponent, CGIMultiSelectHeaderComponent], imports: [CommonModule,
            MatCardModule,
            MatIconModule,
            MatButtonModule,
            MatTableModule,
            MatSortModule,
            MatCheckboxModule,
            BrowserAnimationsModule], exports: [CGIMultiSelectCheckboxesComponent, CGIMultiSelectHeaderComponent] }); }
    static { this.ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "20.3.2", ngImport: i0, type: CGIMultiSelectModule, imports: [CommonModule,
            MatCardModule,
            MatIconModule,
            MatButtonModule,
            MatTableModule,
            MatSortModule,
            MatCheckboxModule,
            BrowserAnimationsModule] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.2", ngImport: i0, type: CGIMultiSelectModule, decorators: [{
            type: NgModule,
            args: [{
                    declarations: [CGIMultiSelectCheckboxesComponent, CGIMultiSelectHeaderComponent],
                    exports: [CGIMultiSelectCheckboxesComponent, CGIMultiSelectHeaderComponent],
                    imports: [
                        CommonModule,
                        MatCardModule,
                        MatIconModule,
                        MatButtonModule,
                        MatTableModule,
                        MatSortModule,
                        MatCheckboxModule,
                        BrowserAnimationsModule,
                    ],
                }]
        }] });

/**
 * Alert Directive.
 */
class CGIAlertBrandDirective {
    /**
     * Constructor for Alert Directive
     * @param viewContainerRef container reference for alert container
     */
    constructor(viewContainerRef) {
        this.viewContainerRef = viewContainerRef;
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.2", ngImport: i0, type: CGIAlertBrandDirective, deps: [{ token: i0.ViewContainerRef }], target: i0.ɵɵFactoryTarget.Directive }); }
    static { this.ɵdir = i0.ɵɵngDeclareDirective({ minVersion: "14.0.0", version: "20.3.2", type: CGIAlertBrandDirective, isStandalone: false, selector: "[cgiAlertHost]", ngImport: i0 }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.2", ngImport: i0, type: CGIAlertBrandDirective, decorators: [{
            type: Directive,
            args: [{
                    selector: '[cgiAlertHost]',
                    standalone: false
                }]
        }], ctorParameters: () => [{ type: i0.ViewContainerRef }] });

/**
 * Alert Container component.
 *
 * TODO: How to use component and examples.
 */
class CGIAlertContainerBrandComponent {
    /**
     * Constructor for Alert Container Directive
     * @param componentFactoryResolver Factory Resolver for dynamic components
     */
    constructor(componentFactoryResolver) {
        this.componentFactoryResolver = componentFactoryResolver;
        /** Array to store alerts inputted from parent */
        this.alerts = [];
        /** Event Emitter to invoke parent when an action is preformed */
        this.action = new EventEmitter();
    }
    /**
     * Life cycle hook for when the component is first initiated and when there are changes to the component's input.
     */
    ngOnChanges() {
        this.cgiAlertHost.viewContainerRef.clear();
        this.getAlerts();
    }
    /** Load an alert into the container */
    loadAlert(alert) {
        const alertItem = alert;
        const componentFactory = this.componentFactoryResolver.resolveComponentFactory(alertItem.component);
        const viewContainerRef = this.cgiAlertHost.viewContainerRef;
        const componentRef = viewContainerRef.createComponent(componentFactory);
        componentRef.instance.data = alertItem.data;
        const subscription = componentRef.instance.action.subscribe((e) => {
            subscription.unsubscribe();
            this.action.emit({
                alertItem: alertItem,
                eventData: e
            });
            this.removeAlert(alertItem);
        });
    }
    /** Remove an alert in the container */
    removeAlert(alertItem) {
        const alertIndex = this.alerts.indexOf(alertItem);
        if (alertIndex !== -1) {
            this.cgiAlertHost.viewContainerRef.remove(alertIndex);
            this.alerts.splice(alertIndex, 1);
            // this.action.emit(alertItem);
        }
    }
    /** Get alerts being passed in from parent */
    getAlerts() {
        for (const alert of this.alerts) {
            this.loadAlert(alert);
        }
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.2", ngImport: i0, type: CGIAlertContainerBrandComponent, deps: [{ token: i0.ComponentFactoryResolver }], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "20.3.2", type: CGIAlertContainerBrandComponent, isStandalone: false, selector: "cgi-alert-container-brand", inputs: { alerts: "alerts" }, outputs: { action: "action" }, viewQueries: [{ propertyName: "cgiAlertHost", first: true, predicate: CGIAlertBrandDirective, descendants: true, static: true }], usesOnChanges: true, ngImport: i0, template: "<ng-template cgiAlertHost></ng-template>\n", dependencies: [{ kind: "directive", type: CGIAlertBrandDirective, selector: "[cgiAlertHost]" }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.2", ngImport: i0, type: CGIAlertContainerBrandComponent, decorators: [{
            type: Component,
            args: [{ selector: 'cgi-alert-container-brand', standalone: false, template: "<ng-template cgiAlertHost></ng-template>\n" }]
        }], ctorParameters: () => [{ type: i0.ComponentFactoryResolver }], propDecorators: { alerts: [{
                type: Input
            }], action: [{
                type: Output
            }], cgiAlertHost: [{
                type: ViewChild,
                args: [CGIAlertBrandDirective, { static: true }]
            }] } });

/**
 * Alert component.
 *
 * TODO: How to use component and examples.
 */
class CGIAlertBrandComponent {
    /**
     * Constructor
     */
    constructor(matIconRegistry, domSanitizer) {
        this.matIconRegistry = matIconRegistry;
        this.domSanitizer = domSanitizer;
        /** Event Emitter to emit custom events back to the parent component */
        this.action = new EventEmitter();
        /** Object to store input data from the parent component */
        this.data = {
            type: null,
            header: null,
            message: null,
            customAction: null,
            actionSmall: null,
            actionBigOne: null,
            actionBigTwo: null,
            icon: true,
            showCloseButton: true,
        };
        /** Boolean for specifying if the alert has a header */
        this.hasHeader = false;
        this.hasIcon = true;
        /** Boolean for specifying if the alert emitted an animation */
        this.actionEmitted = false;
        this.isClassContainer = true;
        this.animationState = 'inactive';
        this.registerCustomIcons();
    }
    /**
     * Life cycle hook for when the component is first initiated.
     */
    ngOnInit() {
        if (this.data.header != null) {
            this.hasHeader = true;
        }
        this.setType();
    }
    registerCustomIcons() {
        // Register info_i icon
        this.matIconRegistry.addSvgIconLiteral('info_i', this.domSanitizer.bypassSecurityTrustHtml(`
        <svg xmlns="http://www.w3.org/2000/svg" height="24px" viewBox="0 -960 960 960" width="24px" fill="#FFFFFF">
          <path d="M480-680q-33 0-56.5-23.5T400-760q0-33 23.5-56.5T480-840q33 0 56.5 23.5T560-760q0 33-23.5 56.5T480-680Zm-60 560v-480h120v480H420Z"/>
        </svg>
      `));
        // Register exclamation icon
        this.matIconRegistry.addSvgIconLiteral('exclamation', this.domSanitizer.bypassSecurityTrustHtml(`
        <svg xmlns="http://www.w3.org/2000/svg" height="24px" viewBox="0 -960 960 960" width="24px" fill="currentColor">
          <path d="M440-400v-360h80v360h-80Zm0 200v-80h80v80h-80Z"/>
        </svg>
      `));
        // Register exclamation icon
        this.matIconRegistry.addSvgIconLiteral('close', this.domSanitizer.bypassSecurityTrustHtml(`
        <svg xmlns="http://www.w3.org/2000/svg" height="24px" viewBox="0 -960 960 960" width="24px" fill="#FFFFFF">
          <path d="m256-200-56-56 224-224-224-224 56-56 224 224 224-224 56 56-224 224 224 224-56 56-224-224-224 224Z"/>
        </svg>
      `));
        // Register exclamation icon
        this.matIconRegistry.addSvgIconLiteral('check', this.domSanitizer.bypassSecurityTrustHtml(`
        <svg xmlns="http://www.w3.org/2000/svg" height="24px" viewBox="0 -960 960 960" width="24px" fill="currentColor">
          <path d="M382-240 154-468l57-57 171 171 367-367 57 57-424 424Z"/>
        </svg>
      `));
    }
    /** Method that sets the style and icon for the type of alert */
    setType() {
        if (this.data.type === 'warning') {
            this.isWarning = true;
            this.icon = 'exclamation';
        }
        else if (this.data.type === 'success') {
            this.isSuccess = true;
            this.icon = 'check';
        }
        else if (this.data.type === 'error') {
            this.isError = true;
            this.icon = 'close';
        }
        else {
            this.isInfo = true;
            this.icon = 'info_i';
        }
    }
    /** close method that will initiate the close animation */
    close() {
        this.animationState = 'active';
    }
    onActionClick(event) {
        this.action.emit(event);
        this.close();
    }
    /** Listener for when the close animation has finished */
    animationDone() {
        if (this.animationState === 'active') {
            this.action.emit();
            this.actionEmitted = true;
        }
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.2", ngImport: i0, type: CGIAlertBrandComponent, deps: [{ token: i5.MatIconRegistry }, { token: i2$3.DomSanitizer }], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "20.3.2", type: CGIAlertBrandComponent, isStandalone: false, selector: "cgi-alert", inputs: { data: "data" }, outputs: { action: "action" }, host: { listeners: { "@fadeOut.done": "animationDone()" }, properties: { "class.cgi-alert": "this.isClassContainer", "@fadeOut": "this.animationState", "class.cgi-alert-info": "this.isInfo", "class.cgi-alert-warning": "this.isWarning", "class.cgi-alert-success": "this.isSuccess", "class.cgi-alert-error": "this.isError" } }, ngImport: i0, template: "<div class=\"cgi-alert-wrapper\">\n  <div class=\"cgi-alert__content\">\n    <div *ngIf=\"data.icon\" class=\"cgi-alert__icon\">\n      <mat-icon [svgIcon]=\"icon\" class=\"material-symbols-outlined\"></mat-icon>\n    </div>\n    <div class=\"cgi-alert-content-body\">\n      <div class=\"cgi-alert__text-body\">\n        <div class=\"title-container\" *ngIf=\"hasHeader\">\n          <h5 class=\"cgi-display-5\" *ngIf=\"hasHeader\">{{ data.header }}</h5>\n        </div>\n        <div class=\"cgi-vertical-spacer-8\" *ngIf=\"data.header\"></div>\n        <p class=\"cgi-body-2 mb-0\" [innerHTML]=\"data.message\"></p>\n      </div>\n      <div class=\"alert-action-container\">\n        <a *ngIf=\"data.actionSmall\" class=\"cgi-link-body-underline-2 action-small\" href=\"javascript:void(0)\" (click)=\"onActionClick({id: 'actionSmall'})\"> {{ data.actionSmall }} </a>\n        <div *ngIf=\"data.showCloseButton !== false\" class=\"alert-close-btn-icon\">\n          <button mat-icon-button (click)=\"close()\" aria-label=\"Close Alert\">\n            <mat-icon class=\"material-icons-outlined\">close</mat-icon>\n          </button>\n        </div>\n      </div>\n    </div>\n  </div>\n  <div *ngIf=\"data.actionBigOne || data.actionBigTwo\" class=\"action-container\">\n    <a *ngIf=\"data.actionBigOne\" class=\"cgi-link-body-underline-2 action-big\" href=\"javascript:void(0)\" (click)=\"onActionClick({id: 'actionBigOne'})\"> {{ data.actionBigOne }} </a>\n    <a *ngIf=\"data.actionBigOne && data.actionBigTwo\" class=\"cgi-link-body-underline-2 action-big-two\" href=\"javascript:void(0)\" (click)=\"onActionClick({id: 'actionBigTwo'})\"> {{\n      data.actionBigTwo }} </a>\n  </div>\n</div>", styles: [":host(.cgi-alert){align-items:flex-start;display:flex;font-family:Source Sans Pro,sans-serif;font-size:14px;font-weight:700;line-height:1.5em;margin:16px 0;padding:16px;gap:16px}:host(.cgi-alert) .cgi-alert-wrapper{display:flex;flex-direction:column;gap:16px;width:100%}:host(.cgi-alert) .cgi-alert__content{display:flex;width:100%;margin-right:0!important;gap:16px}:host(.cgi-alert) .cgi-alert__content .cgi-alert__icon{margin-right:0!important}:host(.cgi-alert) .cgi-alert__content .cgi-alert-content-body{display:flex;gap:16px;justify-content:space-between;width:100%}:host(.cgi-alert) .cgi-alert__content .cgi-alert-content-body .alert-action-container{display:flex;gap:16px;justify-content:flex-end}:host(.cgi-alert) .cgi-alert__icon{border-radius:50%;color:#fff;flex-shrink:0;height:24px;width:24px}:host(.cgi-alert) .cgi-alert__icon ::ng-deep mat-icon{align-items:center;display:flex;justify-content:center;font-size:20px}:host(.cgi-alert) .cgi-alert__icon ::ng-deep mat-icon.fa-exclamation-circle{padding-top:1px}:host(.cgi-alert) .cgi-alert__header{align-items:center;display:flex;font-size:16px}:host(.cgi-alert) .cgi-alert__message{align-items:center;font-weight:400}:host(.cgi-alert) .cgi-alert__spacer{flex:1 1 auto}:host(.cgi-alert) .mat-mdc-icon-button{height:24px;width:24px;line-height:25px;align-self:baseline}:host(.cgi-alert) .mat-mdc-icon-button ::ng-deep mat-icon{color:#151515;line-height:24px}:host(.cgi-alert) .action-big{display:flex;float:right}:host(.cgi-alert) .action-big-two{display:flex;float:right;margin-left:20px}:host(.cgi-alert) .title-container{display:inline-flex;width:100%;justify-content:space-between}:host(.cgi-alert) .action-container{display:inline-flex;width:100%;justify-content:flex-end}\n"], dependencies: [{ kind: "directive", type: i1.NgIf, selector: "[ngIf]", inputs: ["ngIf", "ngIfThen", "ngIfElse"] }, { kind: "component", type: i5.MatIcon, selector: "mat-icon", inputs: ["color", "inline", "svgIcon", "fontSet", "fontIcon"], exportAs: ["matIcon"] }, { kind: "component", type: i4.MatIconButton, selector: "button[mat-icon-button], a[mat-icon-button], button[matIconButton], a[matIconButton]", exportAs: ["matButton", "matAnchor"] }], animations: [
            trigger('fadeOut', [
                state('inactive', style({ transform: 'translateY(0)', opacity: 1 })),
                state('active', style({ transform: 'translateY(-100%)', opacity: 0 })),
                transition('inactive => active', [animate('600ms cubic-bezier(1, 0, 0, 1)')]),
            ]),
        ] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.2", ngImport: i0, type: CGIAlertBrandComponent, decorators: [{
            type: Component,
            args: [{ selector: 'cgi-alert', animations: [
                        trigger('fadeOut', [
                            state('inactive', style({ transform: 'translateY(0)', opacity: 1 })),
                            state('active', style({ transform: 'translateY(-100%)', opacity: 0 })),
                            transition('inactive => active', [animate('600ms cubic-bezier(1, 0, 0, 1)')]),
                        ]),
                    ], standalone: false, template: "<div class=\"cgi-alert-wrapper\">\n  <div class=\"cgi-alert__content\">\n    <div *ngIf=\"data.icon\" class=\"cgi-alert__icon\">\n      <mat-icon [svgIcon]=\"icon\" class=\"material-symbols-outlined\"></mat-icon>\n    </div>\n    <div class=\"cgi-alert-content-body\">\n      <div class=\"cgi-alert__text-body\">\n        <div class=\"title-container\" *ngIf=\"hasHeader\">\n          <h5 class=\"cgi-display-5\" *ngIf=\"hasHeader\">{{ data.header }}</h5>\n        </div>\n        <div class=\"cgi-vertical-spacer-8\" *ngIf=\"data.header\"></div>\n        <p class=\"cgi-body-2 mb-0\" [innerHTML]=\"data.message\"></p>\n      </div>\n      <div class=\"alert-action-container\">\n        <a *ngIf=\"data.actionSmall\" class=\"cgi-link-body-underline-2 action-small\" href=\"javascript:void(0)\" (click)=\"onActionClick({id: 'actionSmall'})\"> {{ data.actionSmall }} </a>\n        <div *ngIf=\"data.showCloseButton !== false\" class=\"alert-close-btn-icon\">\n          <button mat-icon-button (click)=\"close()\" aria-label=\"Close Alert\">\n            <mat-icon class=\"material-icons-outlined\">close</mat-icon>\n          </button>\n        </div>\n      </div>\n    </div>\n  </div>\n  <div *ngIf=\"data.actionBigOne || data.actionBigTwo\" class=\"action-container\">\n    <a *ngIf=\"data.actionBigOne\" class=\"cgi-link-body-underline-2 action-big\" href=\"javascript:void(0)\" (click)=\"onActionClick({id: 'actionBigOne'})\"> {{ data.actionBigOne }} </a>\n    <a *ngIf=\"data.actionBigOne && data.actionBigTwo\" class=\"cgi-link-body-underline-2 action-big-two\" href=\"javascript:void(0)\" (click)=\"onActionClick({id: 'actionBigTwo'})\"> {{\n      data.actionBigTwo }} </a>\n  </div>\n</div>", styles: [":host(.cgi-alert){align-items:flex-start;display:flex;font-family:Source Sans Pro,sans-serif;font-size:14px;font-weight:700;line-height:1.5em;margin:16px 0;padding:16px;gap:16px}:host(.cgi-alert) .cgi-alert-wrapper{display:flex;flex-direction:column;gap:16px;width:100%}:host(.cgi-alert) .cgi-alert__content{display:flex;width:100%;margin-right:0!important;gap:16px}:host(.cgi-alert) .cgi-alert__content .cgi-alert__icon{margin-right:0!important}:host(.cgi-alert) .cgi-alert__content .cgi-alert-content-body{display:flex;gap:16px;justify-content:space-between;width:100%}:host(.cgi-alert) .cgi-alert__content .cgi-alert-content-body .alert-action-container{display:flex;gap:16px;justify-content:flex-end}:host(.cgi-alert) .cgi-alert__icon{border-radius:50%;color:#fff;flex-shrink:0;height:24px;width:24px}:host(.cgi-alert) .cgi-alert__icon ::ng-deep mat-icon{align-items:center;display:flex;justify-content:center;font-size:20px}:host(.cgi-alert) .cgi-alert__icon ::ng-deep mat-icon.fa-exclamation-circle{padding-top:1px}:host(.cgi-alert) .cgi-alert__header{align-items:center;display:flex;font-size:16px}:host(.cgi-alert) .cgi-alert__message{align-items:center;font-weight:400}:host(.cgi-alert) .cgi-alert__spacer{flex:1 1 auto}:host(.cgi-alert) .mat-mdc-icon-button{height:24px;width:24px;line-height:25px;align-self:baseline}:host(.cgi-alert) .mat-mdc-icon-button ::ng-deep mat-icon{color:#151515;line-height:24px}:host(.cgi-alert) .action-big{display:flex;float:right}:host(.cgi-alert) .action-big-two{display:flex;float:right;margin-left:20px}:host(.cgi-alert) .title-container{display:inline-flex;width:100%;justify-content:space-between}:host(.cgi-alert) .action-container{display:inline-flex;width:100%;justify-content:flex-end}\n"] }]
        }], ctorParameters: () => [{ type: i5.MatIconRegistry }, { type: i2$3.DomSanitizer }], propDecorators: { isClassContainer: [{
                type: HostBinding,
                args: ['class.cgi-alert']
            }], animationState: [{
                type: HostBinding,
                args: ['@fadeOut']
            }], isInfo: [{
                type: HostBinding,
                args: ['class.cgi-alert-info']
            }], isWarning: [{
                type: HostBinding,
                args: ['class.cgi-alert-warning']
            }], isSuccess: [{
                type: HostBinding,
                args: ['class.cgi-alert-success']
            }], isError: [{
                type: HostBinding,
                args: ['class.cgi-alert-error']
            }], action: [{
                type: Output
            }], data: [{
                type: Input
            }], animationDone: [{
                type: HostListener,
                args: ['@fadeOut.done']
            }] } });

class CGIAlertContainerBrandModule {
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.2", ngImport: i0, type: CGIAlertContainerBrandModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule }); }
    static { this.ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "20.3.2", ngImport: i0, type: CGIAlertContainerBrandModule, declarations: [CGIAlertContainerBrandComponent, CGIAlertBrandComponent, CGIAlertBrandDirective], imports: [CommonModule, MatIconModule, MatButtonModule], exports: [CGIAlertContainerBrandComponent, CGIAlertBrandComponent, CGIAlertBrandDirective] }); }
    static { this.ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "20.3.2", ngImport: i0, type: CGIAlertContainerBrandModule, imports: [CommonModule, MatIconModule, MatButtonModule] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.2", ngImport: i0, type: CGIAlertContainerBrandModule, decorators: [{
            type: NgModule,
            args: [{
                    imports: [CommonModule, MatIconModule, MatButtonModule],
                    declarations: [CGIAlertContainerBrandComponent, CGIAlertBrandComponent, CGIAlertBrandDirective],
                    exports: [CGIAlertContainerBrandComponent, CGIAlertBrandComponent, CGIAlertBrandDirective],
                }]
        }] });

/**
 * Anchor Scroll component.
 */
class CGIAnchorScrollBrandComponent {
    /**
     * Constructor for Anchor Scroll Component
     * @param _element Native anchor scroll HTML Element
     * @param _document Application's HTML Document
     */
    constructor(_element, _document) {
        this._element = _element;
        this._document = _document;
        /** Array to the anchor links */
        this.links = [];
        /** Headers that will be selected as anchor scroll links */
        this.headerSelectors = '.cgi-header-anchor,.cgi-header-anchor-level-2,.cgi-header-anchor-level-3';
        /** Offset in pixels for links to trigger as active */
        this.linkOffset = 20;
        /** Auto link active on scroll event */
        this.linkActiveOnScroll = true;
        /** Selected section to be active */
        this.selectedSection = '';
        /** Emit the link selection id */
        this.linkClicked = new EventEmitter();
        /** On destroy subject */
        this._destroyed = new Subject();
        /** Selected anchor link */
        this._selectedSection = '';
        /** Anchor links container class */
        this._linkContainer = '.cgi-anchor-scroll-container__links';
        /** Class name used to sticky the scroll container */
        this._stickyClass = 'cgi-anchor-scroll-container__links--sticky';
        /** When there is a scroll event */
        this.onScroll = () => {
            this.checkSticky();
            for (let i = 0; i < this.links.length; i++) {
                this.links[i].active = !this.linkActiveOnScroll ? this.links[i].id === this._selectedSection : this.isLinkActive(this.links[i], this.links[i + 1]);
            }
        };
        /** When the browser changes size */
        this.adjustWidth = () => {
            const parentwidth = this._document.querySelector('.cgi-anchor-scroll-container__toc').clientWidth;
            if (this._document.querySelector('.' + this._stickyClass)) {
                this._document.querySelector('.' + this._stickyClass).style.width = parentwidth + 'px';
            }
        };
        this._navBar = this._document.querySelector('.cgi-top-nav');
    }
    /**
     * Life cycle hook for when the component is first initiated.
     */
    ngOnInit() { }
    /** Initialization block after view has been rendered */
    ngAfterViewInit() {
        // On init, the sidenav content element doesn't yet exist, so it's not possible
        // to subscribe to its scroll event until next tick (when it does exist).
        Promise.resolve().then(() => {
            this._scrollContainer = this.container
                ? this._document.querySelectorAll(this.container)[0]
                : window;
            window.addEventListener('scroll', this.onScroll, true);
            window.addEventListener('resize', this.adjustWidth, true);
            if (this._scrollContainer) {
                this.links = this.createLinks();
                if (this.links.length) {
                    this.links[0].active = true;
                    this._selectedSection = this.links[0].id;
                }
            }
        });
        this.updateScrollPosition();
    }
    /** When Component is destroyed remove event listeners */
    ngOnDestroy() {
        window.removeEventListener('scroll', this.onScroll, true);
        window.removeEventListener('resize', this.adjustWidth, true);
        this._destroyed.next(null);
    }
    /** When changes to inputs are detected */
    ngOnChanges(changes) {
        if (changes['errorCounts'] && changes['errorCounts'].currentValue) {
            this.updateErrors();
        }
        if (changes['selectedSection'] && changes['selectedSection'].currentValue) {
            this._selectedSection = changes['selectedSection'].currentValue;
            this.updateScrollPosition();
        }
    }
    /** Update scroll position when selected link has changed */
    updateScrollPosition() {
        const target = this._document.getElementById(this._selectedSection);
        if (target) {
            target.scrollIntoView({
                behavior: 'smooth',
                block: 'start',
                inline: 'nearest'
            });
        }
    }
    /** When a link is selected change the selected link and update scroll position */
    goToSection(id) {
        this.linkClicked.emit(id);
        this._selectedSection = id;
        this.updateScrollPosition();
    }
    /** Gets the scroll offset of the scroll container */
    getScrollOffset() {
        let height = 0;
        if (this._navBar) {
            const navBarBounds = this._navBar.getBoundingClientRect();
            height = navBarBounds.height;
        }
        if (typeof this._scrollContainer.scrollTop !== 'undefined') {
            return this._scrollContainer.scrollTop + height + this.linkOffset;
        }
        else if (typeof this._scrollContainer.pageYOffset !== 'undefined') {
            return this._scrollContainer.pageYOffset + height + this.linkOffset;
        }
    }
    /** Create the links based on the header selectors */
    createLinks() {
        const links = [];
        const parentElement = this._document.querySelector(this.parentClass);
        let headers;
        if (parentElement) {
            headers = parentElement.querySelectorAll(this.headerSelectors);
        }
        else {
            headers = this._document.querySelectorAll(this.headerSelectors);
        }
        if (headers.length) {
            for (const header of headers) {
                const name = header.innerText.trim().replace(/^link/, '');
                const classes = Array.from(header.classList);
                let linkType;
                for (const className of classes) {
                    if (className === 'cgi-header-anchor') {
                        linkType = 'cgi-header-anchor';
                    }
                    else if (className === 'cgi-header-anchor-level-2') {
                        linkType = 'cgi-header-anchor-level-2';
                    }
                    else {
                        linkType = 'cgi-header-anchor-level-3';
                    }
                }
                const { top } = header.getBoundingClientRect();
                const topBound = top;
                links.push({
                    name,
                    type: linkType,
                    top: topBound,
                    id: header.id,
                    active: false,
                    errorCount: 0,
                });
            }
        }
        return links;
    }
    /** Update error counts for each link */
    updateErrors() {
        for (const error of this.errorCounts) {
            const updateLink = this.links.find((i) => i.name === error.id);
            if (updateLink) {
                updateLink.errorCount = error.errors;
            }
        }
        this.links = this.links.slice();
    }
    /** Check to see if link is active or not */
    isLinkActive(currentLink, nextLink) {
        // A link is considered active if the page is scrolled passed the anchor without also
        // being scrolled passed the next link
        const scrollOffset = this.getScrollOffset();
        // Get current position of the element
        const element = this._document.getElementById(currentLink.id);
        if (!element)
            return false;
        const elementRect = element.getBoundingClientRect();
        const elementTop = elementRect.top + (typeof this._scrollContainer.scrollTop !== 'undefined' ? this._scrollContainer.scrollTop : this._scrollContainer.pageYOffset || 0);
        // Get next element position if it exists
        let nextElementTop = Infinity;
        if (nextLink) {
            const nextElement = this._document.getElementById(nextLink.id);
            if (nextElement) {
                const nextRect = nextElement.getBoundingClientRect();
                nextElementTop = nextRect.top + (typeof this._scrollContainer.scrollTop !== 'undefined' ? this._scrollContainer.scrollTop : this._scrollContainer.pageYOffset || 0);
            }
        }
        return (scrollOffset >= Math.floor(elementTop) &&
            !(nextLink && Math.floor(nextElementTop) <= scrollOffset));
    }
    /** Check to see if the component should be sticky or not */
    checkSticky() {
        // Anchor Scroll Container
        const container = this._document.querySelector('.cgi-anchor-scroll-container');
        // Anchor Scroll Container Boundaries
        const containerBounds = container.getBoundingClientRect();
        // Scroll Container Boundaries (Entire view)
        let scrollContainerBounds;
        if (typeof this._scrollContainer?.pageYOffset !== 'undefined') {
            // When using window as scroll container, return fixed viewport bounds
            scrollContainerBounds = {
                top: 0,
                left: 0,
                right: this._scrollContainer.innerWidth,
                bottom: this._scrollContainer.innerHeight,
                width: this._scrollContainer.innerWidth,
                height: this._scrollContainer.innerHeight,
                x: 0,
                y: 0,
                toJSON: () => { }
            };
        }
        else {
            scrollContainerBounds = this._scrollContainer?.getBoundingClientRect();
        }
        // Anchor Scroll Links Container
        const linksContainer = this._document.querySelector(this._linkContainer);
        // Anchor Scroll Links Content
        const contents = this._document.querySelector('.cgi-anchor-scroll-container__toc');
        // Anchor Scroll Links Boundaries
        const anchorLinkBounds = this._document
            .querySelector('.cgi-anchor-scroll-links')
            .getBoundingClientRect();
        if (Math.ceil(anchorLinkBounds.bottom) === Math.ceil(containerBounds.bottom) &&
            Math.ceil(anchorLinkBounds.top) >= Math.ceil(scrollContainerBounds.top)) {
            // Add Sticky Back
            this.addSticky(linksContainer, scrollContainerBounds);
        }
        else if (Math.ceil(anchorLinkBounds.bottom) >= Math.ceil(containerBounds.bottom)) {
            // Sticky To Bottom
            linksContainer.classList.remove(this._stickyClass);
            const top = Math.ceil(containerBounds.height) - Math.ceil(anchorLinkBounds.height) + 'px';
            contents.style.top = top;
            contents.style.marginTop = top;
        }
        else if (Math.ceil(scrollContainerBounds.top) >= Math.ceil(containerBounds.top)) {
            // Sticky To Top
            this.addSticky(linksContainer, scrollContainerBounds);
        }
        else {
            // Not Sticky
            contents.style.top = '0px';
            contents.style.marginTop = '0px';
            linksContainer.classList.remove(this._stickyClass);
        }
    }
    /** Make component sticky */
    addSticky(linksContainer, scrollContainerBounds) {
        linksContainer.classList.add(this._stickyClass);
        this._document.querySelector('.' + this._stickyClass).style.top =
            scrollContainerBounds.top + 'px';
        this.adjustWidth();
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.2", ngImport: i0, type: CGIAnchorScrollBrandComponent, deps: [{ token: i0.ElementRef }, { token: DOCUMENT }], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "20.3.2", type: CGIAnchorScrollBrandComponent, isStandalone: false, selector: "cgi-anchor-scroll", inputs: { container: "container", parentClass: "parentClass", linkOffset: "linkOffset", errorCounts: "errorCounts", linkActiveOnScroll: "linkActiveOnScroll", selectedSection: "selectedSection" }, outputs: { linkClicked: "linkClicked" }, usesOnChanges: true, ngImport: i0, template: "<div *ngIf=\"links?.length\" class=\"cgi-anchor-scroll-links\">\n  <nav>\n    <a\n      [routerLink]=\"\"\n      *ngFor=\"let link of links; let i = index\"\n      [matBadge]=\"link.errorCount\"\n      [matBadgeHidden]=\"link.errorCount === 0\"\n      (click)=\"goToSection(link.id)\"\n      class=\"cgi-link-body-underline-1 link-{{ link.type }}\"\n      [class.active]=\"link.active\"\n    >\n      {{ link.name }}\n    </a>\n  </nav>\n</div>\n", styles: [":host{box-sizing:border-box;display:inline-flex;font-size:13px;margin-top:-15px}.cgi-anchor-scroll-links{padding:5px 0 10px}.cgi-anchor-scroll-links a{display:block;font-size:14px;overflow:visible;padding:8px 0;position:relative;text-decoration:underline;text-overflow:ellipsis;width:auto;color:#5236ab}.cgi-anchor-scroll-links a.active{color:#200a58;font-weight:700;text-decoration:none}.cgi-anchor-scroll-links a .default{color:#5236ab;font-weight:700;text-decoration:none}.link-cgi-header-anchor-level-2{margin-left:20px;width:calc(100% - 20px)}.link-cgi-header-anchor-level-3{margin-left:40px;width:calc(100% - 40px)}.mat-badge-content{background-color:#c0334d}.mat-badge-medium.mat-badge-overlap.mat-badge-after .mat-badge-content{top:-2px}\n"], dependencies: [{ kind: "directive", type: i1.NgForOf, selector: "[ngFor][ngForOf]", inputs: ["ngForOf", "ngForTrackBy", "ngForTemplate"] }, { kind: "directive", type: i1.NgIf, selector: "[ngIf]", inputs: ["ngIf", "ngIfThen", "ngIfElse"] }, { kind: "directive", type: i2.RouterLink, selector: "[routerLink]", inputs: ["target", "queryParams", "fragment", "queryParamsHandling", "state", "info", "relativeTo", "preserveFragment", "skipLocationChange", "replaceUrl", "routerLink"] }, { kind: "directive", type: i3.MatBadge, selector: "[matBadge]", inputs: ["matBadgeColor", "matBadgeOverlap", "matBadgeDisabled", "matBadgePosition", "matBadge", "matBadgeDescription", "matBadgeSize", "matBadgeHidden"] }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.2", ngImport: i0, type: CGIAnchorScrollBrandComponent, decorators: [{
            type: Component,
            args: [{ selector: 'cgi-anchor-scroll', standalone: false, template: "<div *ngIf=\"links?.length\" class=\"cgi-anchor-scroll-links\">\n  <nav>\n    <a\n      [routerLink]=\"\"\n      *ngFor=\"let link of links; let i = index\"\n      [matBadge]=\"link.errorCount\"\n      [matBadgeHidden]=\"link.errorCount === 0\"\n      (click)=\"goToSection(link.id)\"\n      class=\"cgi-link-body-underline-1 link-{{ link.type }}\"\n      [class.active]=\"link.active\"\n    >\n      {{ link.name }}\n    </a>\n  </nav>\n</div>\n", styles: [":host{box-sizing:border-box;display:inline-flex;font-size:13px;margin-top:-15px}.cgi-anchor-scroll-links{padding:5px 0 10px}.cgi-anchor-scroll-links a{display:block;font-size:14px;overflow:visible;padding:8px 0;position:relative;text-decoration:underline;text-overflow:ellipsis;width:auto;color:#5236ab}.cgi-anchor-scroll-links a.active{color:#200a58;font-weight:700;text-decoration:none}.cgi-anchor-scroll-links a .default{color:#5236ab;font-weight:700;text-decoration:none}.link-cgi-header-anchor-level-2{margin-left:20px;width:calc(100% - 20px)}.link-cgi-header-anchor-level-3{margin-left:40px;width:calc(100% - 40px)}.mat-badge-content{background-color:#c0334d}.mat-badge-medium.mat-badge-overlap.mat-badge-after .mat-badge-content{top:-2px}\n"] }]
        }], ctorParameters: () => [{ type: i0.ElementRef }, { type: undefined, decorators: [{
                    type: Inject,
                    args: [DOCUMENT]
                }] }], propDecorators: { container: [{
                type: Input
            }], parentClass: [{
                type: Input
            }], linkOffset: [{
                type: Input
            }], errorCounts: [{
                type: Input
            }], linkActiveOnScroll: [{
                type: Input
            }], selectedSection: [{
                type: Input
            }], linkClicked: [{
                type: Output
            }] } });

/**
 * Anchor Scroll Container component.
 *
 * TODO: How to use component and examples.
 */
class CGIAnchorScrollContainerBrandComponent {
    /**
     * Constructor for Anchor Scroll Component
     * @param breakpointObserver Breakpoint Observable for when to remove the anchor scroll component
     */
    constructor(breakpointObserver) {
        /** Class of parent element */
        this.parentClass = 'body';
        /** Offset in pixels for links to trigger as active */
        this.linkOffset = 20;
        /** Title of anchor scroll */
        this.title = '';
        /** Auto link active on scroll event */
        this.linkActiveOnScroll = true;
        /** Selected section to be active */
        this.selectedSection = '';
        /** Emitt the link selection id */
        this.linkSection = new EventEmitter();
        const isStorybook = typeof window !== 'undefined' &&
            (window.location?.pathname?.includes('iframe.html') ||
                window.location?.search?.includes('path=/') ||
                (typeof document !== 'undefined' && !!document.getElementById('storybook-root')));
        this.showAnchor = isStorybook
            ? of(true)
            : breakpointObserver
                .observe('(max-width: 1200px)')
                .pipe(map((result) => !result.matches));
    }
    linkSectionEvent(id) {
        this.linkSection.emit(id);
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.2", ngImport: i0, type: CGIAnchorScrollContainerBrandComponent, deps: [{ token: i1$1.BreakpointObserver }], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "20.3.2", type: CGIAnchorScrollContainerBrandComponent, isStandalone: false, selector: "cgi-anchor-scroll-container", inputs: { parentClass: "parentClass", linkOffset: "linkOffset", errorCounts: "errorCounts", title: "title", linkActiveOnScroll: "linkActiveOnScroll", selectedSection: "selectedSection", container: "container" }, outputs: { linkSection: "linkSection" }, viewQueries: [{ propertyName: "anchorScroll", first: true, predicate: ["anchor"], descendants: true }], ngImport: i0, template: "<div class=\"cgi-anchor-scroll-container\">\n  <div class=\"cgi-anchor-scroll-container__toc\" *ngIf=\"showAnchor | async\">\n    <div class=\"cgi-anchor-scroll-container__links\">\n      <h4 class=\"cgi-anchor-scroll-container__title\">{{ title }}</h4>\n      <cgi-anchor-scroll\n        #anchor\n        [errorCounts]=\"errorCounts\"\n        [parentClass]=\"parentClass\"\n        [linkOffset]=\"linkOffset\"\n        [selectedSection]=\"selectedSection\"\n        [container]=\"container\"\n        [title]=\"title\"\n        (linkClicked)=\"linkSectionEvent($event)\"\n        [linkActiveOnScroll]=\"linkActiveOnScroll\"\n      ></cgi-anchor-scroll>\n    </div>\n  </div>\n  <div class=\"cgi-anchor-scroll-container__contents\"><ng-content></ng-content></div>\n</div>\n<!-- icon changes -->\n", styles: [".cgi-anchor-scroll-container{align-items:flex-start;display:flex;gap:48px}@media (max-width: 1200px){.cgi-anchor-scroll-container .cgi-anchor-scroll-container__contents{flex-direction:column}}.cgi-anchor-scroll-container .cgi-anchor-scroll-container__toc{flex:0 0 16%}.cgi-anchor-scroll-container .cgi-anchor-scroll-container__links--sticky{position:fixed}.cgi-anchor-scroll-container .cgi-anchor-scroll-container__title{color:#333;font-family:Source Sans Pro,sans-serif;font-size:14px}cgi-anchor-scroll{top:35px}\n"], dependencies: [{ kind: "directive", type: i1.NgIf, selector: "[ngIf]", inputs: ["ngIf", "ngIfThen", "ngIfElse"] }, { kind: "component", type: CGIAnchorScrollBrandComponent, selector: "cgi-anchor-scroll", inputs: ["container", "parentClass", "linkOffset", "errorCounts", "linkActiveOnScroll", "selectedSection"], outputs: ["linkClicked"] }, { kind: "pipe", type: i1.AsyncPipe, name: "async" }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.2", ngImport: i0, type: CGIAnchorScrollContainerBrandComponent, decorators: [{
            type: Component,
            args: [{ selector: 'cgi-anchor-scroll-container', standalone: false, template: "<div class=\"cgi-anchor-scroll-container\">\n  <div class=\"cgi-anchor-scroll-container__toc\" *ngIf=\"showAnchor | async\">\n    <div class=\"cgi-anchor-scroll-container__links\">\n      <h4 class=\"cgi-anchor-scroll-container__title\">{{ title }}</h4>\n      <cgi-anchor-scroll\n        #anchor\n        [errorCounts]=\"errorCounts\"\n        [parentClass]=\"parentClass\"\n        [linkOffset]=\"linkOffset\"\n        [selectedSection]=\"selectedSection\"\n        [container]=\"container\"\n        [title]=\"title\"\n        (linkClicked)=\"linkSectionEvent($event)\"\n        [linkActiveOnScroll]=\"linkActiveOnScroll\"\n      ></cgi-anchor-scroll>\n    </div>\n  </div>\n  <div class=\"cgi-anchor-scroll-container__contents\"><ng-content></ng-content></div>\n</div>\n<!-- icon changes -->\n", styles: [".cgi-anchor-scroll-container{align-items:flex-start;display:flex;gap:48px}@media (max-width: 1200px){.cgi-anchor-scroll-container .cgi-anchor-scroll-container__contents{flex-direction:column}}.cgi-anchor-scroll-container .cgi-anchor-scroll-container__toc{flex:0 0 16%}.cgi-anchor-scroll-container .cgi-anchor-scroll-container__links--sticky{position:fixed}.cgi-anchor-scroll-container .cgi-anchor-scroll-container__title{color:#333;font-family:Source Sans Pro,sans-serif;font-size:14px}cgi-anchor-scroll{top:35px}\n"] }]
        }], ctorParameters: () => [{ type: i1$1.BreakpointObserver }], propDecorators: { parentClass: [{
                type: Input
            }], linkOffset: [{
                type: Input
            }], errorCounts: [{
                type: Input
            }], title: [{
                type: Input
            }], linkActiveOnScroll: [{
                type: Input
            }], selectedSection: [{
                type: Input
            }], container: [{
                type: Input
            }], linkSection: [{
                type: Output
            }], anchorScroll: [{
                type: ViewChild,
                args: ['anchor']
            }] } });

class CGIAnchorScrollContainerBrandModule {
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.2", ngImport: i0, type: CGIAnchorScrollContainerBrandModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule }); }
    static { this.ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "20.3.2", ngImport: i0, type: CGIAnchorScrollContainerBrandModule, declarations: [CGIAnchorScrollContainerBrandComponent, CGIAnchorScrollBrandComponent], imports: [CommonModule, RouterModule, MatBadgeModule], exports: [CGIAnchorScrollContainerBrandComponent, CGIAnchorScrollBrandComponent] }); }
    static { this.ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "20.3.2", ngImport: i0, type: CGIAnchorScrollContainerBrandModule, imports: [CommonModule, RouterModule, MatBadgeModule] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.2", ngImport: i0, type: CGIAnchorScrollContainerBrandModule, decorators: [{
            type: NgModule,
            args: [{
                    imports: [CommonModule, RouterModule, MatBadgeModule],
                    declarations: [CGIAnchorScrollContainerBrandComponent, CGIAnchorScrollBrandComponent],
                    exports: [CGIAnchorScrollContainerBrandComponent, CGIAnchorScrollBrandComponent],
                }]
        }] });

/**
 * Enum for top-nav-item display modes
 */
var TopNavItemMode;
(function (TopNavItemMode) {
    /** Default mode - displays ng-content */
    TopNavItemMode["DEFAULT"] = "default";
    /** Menu mode - displays hamburger menu button */
    TopNavItemMode["MENU"] = "menu";
    /** Logo mode - displays logo and title */
    TopNavItemMode["LOGO"] = "logo";
    /** Search mode - displays search bar */
    TopNavItemMode["SEARCH"] = "search";
    /** Dropdown mode - displays dropdown selector */
    TopNavItemMode["DROPDOWN"] = "dropdown";
    /** Notification mode - displays notification icon */
    TopNavItemMode["NOTIFICATION"] = "notification";
})(TopNavItemMode || (TopNavItemMode = {}));

/**
 * Service to maintain a single source of truth for whether the navigation
 * panel is opened. Shared between `cgi-side-nav`, `cgi-nav-content`,
 * `cgi-top-nav` and `cgi-footer-container`.
 */
class CGINavContainerService {
    constructor() {
        /** BehaviourSubject backing the public observable. Default: opened. */
        this._navOpen = new BehaviorSubject(true);
        /**
         * Public stream of the panel's opened state.
         * Kept named `changes` for backwards compatibility.
         */
        this.changes = this._navOpen.asObservable().pipe(distinctUntilChanged$1());
    }
    /**
     * Toggle the panel state.
     * @param isOpen Optional explicit state. If omitted, the current value is flipped.
     *               If provided and equal to the current value, the call is a no-op.
     */
    toggle(isOpen) {
        const current = this._navOpen.getValue();
        const next = isOpen === undefined ? !current : isOpen;
        if (next !== current) {
            this._navOpen.next(next);
        }
    }
    /** Force open. Convenience wrapper around `toggle(true)`. */
    open() {
        this.toggle(true);
    }
    /** Force close. Convenience wrapper around `toggle(false)`. */
    close() {
        this.toggle(false);
    }
    /** Synchronous getter for the current opened state. */
    getState() {
        return this._navOpen.getValue();
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.2", ngImport: i0, type: CGINavContainerService, deps: [], target: i0.ɵɵFactoryTarget.Injectable }); }
    static { this.ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "20.3.2", ngImport: i0, type: CGINavContainerService }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.2", ngImport: i0, type: CGINavContainerService, decorators: [{
            type: Injectable
        }] });

// import { DropdownItem, TopNavItemMode } from './models';
/**
 * Navigation item component for the top nav bar.
 * This component can display different elements based on its mode:
 * - Default: displays ng-content
 * - Menu: displays hamburger menu button
 * - Logo: displays logo and title
 * - Search: displays search bar
 * - Dropdown: displays dropdown selector
 */
class CGITopNavItemBrandComponent {
    /** @deprecated Use mode = TopNavItemMode.MENU instead */
    // @Input() set menuItem(value: boolean) {
    //   if (value) {
    //     this.mode = TopNavItemMode.MENU;
    //   }
    // }
    /** @deprecated Use mode = TopNavItemMode.SEARCH instead */
    set _showSearchBar(value) {
        if (value) {
            this.mode = TopNavItemMode.SEARCH;
        }
    }
    /** @deprecated Use mode = TopNavItemMode.LOGO instead */
    set _showLogo(value) {
        if (value) {
            this.mode = TopNavItemMode.LOGO;
        }
    }
    /** @deprecated Use mode = TopNavItemMode.DROPDOWN instead */
    set _showFrameworkSelector(value) {
        if (value) {
            this.mode = TopNavItemMode.DROPDOWN;
            this._legacyFrameworkMode = true;
        }
    }
    /** @deprecated Use mode = TopNavItemMode.DROPDOWN instead */
    set _showDropdownSelector(value) {
        if (value) {
            this.mode = TopNavItemMode.DROPDOWN;
            this._legacyFrameworkMode = false;
        }
    }
    /** Host listener for window resize events */
    onResize(event) {
        this.showSearch = event.target.innerWidth >= this.MOBILE_BREAKPOINT;
        const currentWidth = event.target.innerWidth;
        // Check if we switched from desktop to mobile or vice versa
        const wasMobile = this.previousWidth < 768; // Adjust breakpoint as needed
        const isMobile = currentWidth < 768;
        if (wasMobile !== isMobile && this.opened) {
            // Reset the drawer state when switching between mobile/desktop
            this.opened = false;
        }
        this.previousWidth = currentWidth;
    }
    /** @deprecated Use dropdownItems instead */
    set frameworks(value) {
        this.dropdownItems = value;
    }
    /** @deprecated Use dropdownItems instead */
    get frameworks() {
        return this.dropdownItems;
    }
    /** @deprecated Use selectedDropdownItem instead */
    set selectedFramework(value) {
        this.selectedDropdownItem = value;
    }
    /** @deprecated Use selectedDropdownItem instead */
    get selectedFramework() {
        return this.selectedDropdownItem;
    }
    get isMenuItem() {
        return this._menuItem;
    }
    set menuItem(value) {
        this._menuItem = !value;
    }
    /** Binding for menu class */
    // @HostBinding('class.cgi-top-nav__menu')
    // get isMenuItem(): boolean {
    //   return this.mode === TopNavItemMode.MENU;
    // }
    /** Binding for search class */
    get isSearchBarItem() {
        return this.mode === TopNavItemMode.SEARCH;
    }
    // #endregion
    /**
     * Constructor
     */
    constructor(navContainerService, fb, router) {
        this.navContainerService = navContainerService;
        this.fb = fb;
        this.router = router;
        this.previousWidth = window.innerWidth;
        // #region Mode Properties
        /** The display mode of the component */
        this.mode = TopNavItemMode.DEFAULT;
        this.lists = [
            {
                icon: 'arrow_right',
                name: 'List item 1',
                isClick: true,
            },
            {
                icon: 'arrow_right',
                name: 'List item 2',
                isClick: false,
            },
            {
                icon: 'arrow_right',
                name: 'List item 3',
                isClick: true,
            },
        ];
        /** Helper property for backward compatibility */
        this._legacyFrameworkMode = false;
        /** Screen size breakpoint for search toggle behavior */
        this.MOBILE_BREAKPOINT = 768;
        /** Initialize search toggle state based on screen size */
        this.showSearch = false;
        /** Whether to show the divider after the logo */
        this.showDivider = true;
        // #endregion
        // #region Dropdown Properties
        /** Array of dropdown items to display in the selector */
        this.dropdownItems = [];
        /** Selected dropdown item value */
        this.selectedDropdownItem = '';
        /** Whether the dropdown is disabled */
        this.dropdownDisabled = false;
        /** Aria label for the dropdown */
        this.dropdownAriaLabel = 'Select an option';
        /** CSS class for the option labels */
        this.optionLabelClass = '';
        /** Whether to show descriptions for options */
        this.showDescriptions = false;
        /** Event emitted when a dropdown item is selected */
        this.dropdownItemSelected = new EventEmitter();
        /** @deprecated Use dropdownItemSelected instead */
        this.frameworkSelected = new EventEmitter();
        // #endregion
        // #region Menu Properties
        /** Boolean to toggle the menu icon */
        this.opened = true;
        /** variable for toggling display of search component on small screens */
        this.isSearchToggled = false;
        this.showNotificationCard = false;
        /** Search categories */
        this.categories = [];
        /** Whether to enable category selection */
        this.enableCategory = false;
        /** Whether search is loading */
        this.isLoading = false;
        /** Search results */
        this.globalSearchResult = [];
        /** Total number of search results */
        this.globalSearchResultSize = 0;
        /** Aria label for the category selector */
        this.selectorAriaLabel = 'category selector';
        /** ID for the category select element */
        this.globalSearchSelectID = 'cgi-global-search-select';
        /** ID for the search input element */
        this.globalSearchInputID = 'cgi-global-search-input';
        /** Placeholder for the search input */
        this.globalSearchInputPlaceholder = 'Search';
        /** ID for the autocomplete element */
        this.globalSearchAutocompleteID = 'cgi-global-search-autocomplete';
        /** Message for showing more results */
        this.moreResults = 'Show more results...';
        /** Message for no results */
        this.noResults = 'Sorry, no results have been found.';
        /** Number of results to display */
        this.resultLimit = 10;
        /** Event emitted when a search result is selected */
        this.optionSelected = new EventEmitter();
        /** Event emitted when search is performed */
        this.search = new EventEmitter();
        // #endregion
        // #region Styling Properties
        /** @deprecated Use mode instead */
        // get _menuItem(): boolean {
        //   return this.mode === TopNavItemMode.MENU;
        // }
        /** @deprecated Use mode instead */
        // set _menuItem(value: boolean) {
        //   if (value) {
        //     this.mode = TopNavItemMode.MENU;
        //   }
        // }
        /** @deprecated - Unused property */
        this._showSearchIcon = false;
        /** Binding for container class */
        this.isClassContainer = true;
        this.globalSearchId = "global-search-component" /* PageLandmarks.GLOBAL_SEARCH */;
        this.globalSearch = fb.group({
            category: '',
            searchString: '',
        });
    }
    /**
     * Angular lifecycle hook
     */
    ngOnInit() {
        // Initialize showSearch based on current window size
        this.showSearch = window.innerWidth >= this.MOBILE_BREAKPOINT;
        this.previousWidth = window.innerWidth;
        if (this.categories && this.categories.length > 0) {
            this.globalSearch.get('category')?.setValue(this.categories[0].value);
        }
        // Map legacy events to new events for backward compatibility
        this.dropdownItemSelected.subscribe((item) => {
            if (this._legacyFrameworkMode) {
                this.frameworkSelected.emit(item);
            }
        });
    }
    /**
     * Angular lifecycle hook
     */
    ngAfterViewInit() {
        this.globalSearch
            .get('category')
            ?.valueChanges.pipe(tap(() => {
            this.loadSearchResults();
        }))
            .subscribe();
        this.globalSearch
            .get('searchString')
            ?.valueChanges.pipe(startWith(''), debounceTime(800), distinctUntilChanged(), tap(() => {
            this.loadSearchResults();
        }))
            .subscribe();
    }
    /**
     * Toggle sidebar
     */
    toggleSidebar() {
        this.navContainerService.toggle();
        this.opened = !this.opened;
    }
    /**
     * Toggle search
     */
    toggle() {
        this.isSearchToggled = !this.isSearchToggled;
    }
    /**
     * Empty display function for autocomplete
     */
    displayFn() {
        return '';
    }
    /**
     * Load search results
     */
    loadSearchResults() {
        this.search.emit({
            globalSearch: this.globalSearch,
        });
    }
    /**
     * Navigate to a link
     */
    gotoLink(link, queryKey = null) {
        if (queryKey) {
            this.router.navigate([link], {
                queryParams: { [queryKey]: this.globalSearch.get('searchString')?.value },
            });
        }
        else {
            this.router.navigate([link]);
        }
        this.trigger?.closePanel();
    }
    /**
     * Handle search option selection
     */
    onEnter(category, entity, isShowMore = false) {
        const searchText = this.globalSearch.get('searchString')?.value;
        const event = { searchText, category, entity, isShowMore };
        this.optionSelected.emit(event);
    }
    /**
     * Get the selected dropdown item
     */
    getSelectedItem() {
        if (this._legacyFrameworkMode) {
            return this.getSelectedFramework();
        }
        else {
            return this.getSelectedDropdownItem();
        }
    }
    /**
     * Get the selected dropdown item
     */
    getSelectedDropdownItem() {
        if (!this.dropdownItems || !this.selectedDropdownItem)
            return null;
        return this.dropdownItems.find((item) => item.value === this.selectedDropdownItem) || null;
    }
    /**
     * @deprecated Use getSelectedDropdownItem instead
     */
    getSelectedFramework() {
        return this.getSelectedDropdownItem();
    }
    /**
     * Handle dropdown item selection
     */
    navigateToItem(item) {
        this.dropdownItemSelected.emit(item);
        // If URL is provided, navigate directly
        if (item.url) {
            window.location.href = item.url;
        }
    }
    /**
     * @deprecated Use navigateToItem instead
     */
    navigateToFramework(item, event) {
        this.frameworkSelected.emit({ ...item, event });
    }
    /**
     * @deprecated Use mode instead
     */
    set showSearchIcon(value) {
        this._showSearchIcon = !value;
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.2", ngImport: i0, type: CGITopNavItemBrandComponent, deps: [{ token: CGINavContainerService }, { token: i1$2.UntypedFormBuilder }, { token: i2.Router }], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "20.3.2", type: CGITopNavItemBrandComponent, isStandalone: false, selector: "cgi-top-nav-item", inputs: { mode: "mode", _showSearchBar: "_showSearchBar", _showLogo: "_showLogo", _showFrameworkSelector: "_showFrameworkSelector", _showDropdownSelector: "_showDropdownSelector", lists: "lists", logoSrc: "logoSrc", logoAlt: "logoAlt", title: "title", showDivider: "showDivider", dropdownItems: "dropdownItems", selectedDropdownItem: "selectedDropdownItem", dropdownClass: "dropdownClass", dropdownWidth: "dropdownWidth", dropdownPanelClass: "dropdownPanelClass", dropdownPlaceholder: "dropdownPlaceholder", dropdownDisabled: "dropdownDisabled", dropdownAriaLabel: "dropdownAriaLabel", optionLabelClass: "optionLabelClass", showDescriptions: "showDescriptions", frameworks: "frameworks", selectedFramework: "selectedFramework", opened: "opened", categories: "categories", enableCategory: "enableCategory", isLoading: "isLoading", globalSearchResult: "globalSearchResult", globalSearchResultSize: "globalSearchResultSize", panelWidth: "panelWidth", selectorAriaLabel: "selectorAriaLabel", globalSearchSelectID: "globalSearchSelectID", globalSearchInputID: "globalSearchInputID", globalSearchInputPlaceholder: "globalSearchInputPlaceholder", globalSearchAutocompleteID: "globalSearchAutocompleteID", moreResults: "moreResults", noResults: "noResults", resultLimit: "resultLimit", subTemplate: "subTemplate", menuItem: "menuItem", showSearchIcon: "showSearchIcon" }, outputs: { dropdownItemSelected: "dropdownItemSelected", frameworkSelected: "frameworkSelected", optionSelected: "optionSelected", search: "search" }, host: { listeners: { "window:resize": "onResize($event)" }, properties: { "class.cgi-top-nav__item": "this.isClassContainer", "class.cgi-top-nav__menu": "this.isMenuItem", "class.cgi-top-nav__search": "this.isSearchBarItem" } }, viewQueries: [{ propertyName: "trigger", first: true, predicate: MatAutocompleteTrigger, descendants: true }], ngImport: i0, template: "<ng-content *ngIf=\"!_menuItem\"></ng-content>\n<button *ngIf=\"_menuItem\" aria-label=\"Menu\" mat-button (click)=\"toggleSidebar()\">\n  <mat-icon *ngIf=\"!opened\" class=\"menu-icon material-icons-outlined\">menu</mat-icon>\n  <mat-icon *ngIf=\"opened\" class=\"menu-icon material-icons-outlined\">menu_open</mat-icon>\n</button>\n\n<!-- Search mode -->\n\n<div\n  *ngIf=\"mode === 'search' && showSearch\"\n  [attr.id]=\"globalSearchId\"\n  class=\"row ml-0 cgi-global-search__container\"\n>\n  <button\n    type=\"button\"\n    (click)=\"showSearch = false\"\n    aria-label=\"Search Icon\"\n    mat-icon-button\n    matSuffix\n    disableRipple=\"true\"\n    class=\"back-arrow-btn\"\n  >\n    <mat-icon>search</mat-icon>\n  </button>\n  <form\n    [formGroup]=\"globalSearch\"\n    [ngClass]=\"isSearchToggled ? 'cgi-global-search--toggled-on' : 'cgi-global-search--toggled-off'\"\n  >\n    <mat-form-field\n      class=\"col-4 cgi-global-search__category-option\"\n      appearance=\"outline\"\n      *ngIf=\"enableCategory\"\n    >\n      <mat-select\n        formControlName=\"category\"\n        [id]=\"globalSearchSelectID\"\n        [aria-label]=\"selectorAriaLabel\"\n        panelClass=\"mat-select-panal-list\"\n      >\n        <mat-option\n          class=\"body_style\"\n          *ngFor=\"let category of categories\"\n          value=\"{{ category.value }}\"\n        >\n          {{ category.name }}</mat-option\n        >\n      </mat-select>\n    </mat-form-field>\n    <!-- flexible search bar size -->\n    <mat-form-field\n      [ngClass]=\"\n        enableCategory\n          ? 'cgi-global-search__search-section'\n          : 'col-12 cgi-global-search__search-section-1'\n      \"\n      appearance=\"outline\"\n      floatLabel=\"never\"\n    >\n      <button\n        type=\"submit\"\n        class=\"search-icon-inside-textbox\"\n        aria-label=\"Search Icon\"\n        mat-icon-button\n        matSuffix\n        disableRipple=\"true\"\n      >\n        <mat-icon>search</mat-icon>\n      </button>\n      <input\n        [id]=\"globalSearchInputID\"\n        type=\"text\"\n        matInput\n        [placeholder]=\"globalSearchInputPlaceholder\"\n        formControlName=\"searchString\"\n        [matAutocomplete]=\"searchResults\"\n        aria-label=\"Global Search Field\"\n      />\n      <mat-autocomplete\n        [id]=\"globalSearchAutocompleteID\"\n        #searchResults=\"matAutocomplete\"\n        [displayWith]=\"displayFn\"\n        class=\"cgi-global-search-autocomplete\"\n        [panelWidth]=\"panelWidth || 405\"\n      >\n        <mat-option class=\"cgi-global-search__spinner\" *ngIf=\"isLoading\">\n          <mat-spinner diameter=\"80\"></mat-spinner>\n        </mat-option>\n        <mat-option\n          *ngIf=\"\n            globalSearch.get('searchString')?.value && !isLoading && globalSearchResultSize === 0\n          \"\n          class=\"cgi-global-search__no-results\"\n        >\n          {{ noResults }}\n        </mat-option>\n        <!-- for searching with category -->\n        <ng-container\n          *ngIf=\"globalSearch.get('searchString')?.value && !isLoading && enableCategory\"\n        >\n          <mat-optgroup *ngFor=\"let group of globalSearchResult\">\n            {{ group.category.name }}\n            <mat-option\n              *ngFor=\"let content of group.contents | slice : 0 : resultLimit; let i = index\"\n              (onSelectionChange)=\"onEnter(group.category, content)\"\n            >\n              <p class=\"cgi-body-2\">{{ content.name }}</p>\n              <ng-container *ngIf=\"subTemplate; then subTemp; else subCode\"></ng-container>\n\n              <ng-template #subTemp\n                ><ng-container [ngTemplateOutlet]=\"subTemplate\"></ng-container\n              ></ng-template>\n              <ng-template #subCode>\n                <p class=\"cgi-body-1 cgi-global-search--sub-code\">{{ content.code }}</p>\n              </ng-template>\n            </mat-option>\n            <!-- Result limit on categories -->\n            <ng-container *ngIf=\"group.totalRecords > resultLimit\">\n              <button\n                color=\"primary\"\n                mat-button\n                (click)=\"\n                  group.category.moreResultsLink\n                    ? gotoLink(group.category.moreResultsLink, group.category.queryParamKey)\n                    : (group.expandCategory = !group.expandCategory)\n                \"\n                [class.d-none]=\"group.expandCategory\"\n              >\n                {{ moreResults }}\n              </button>\n            </ng-container>\n            <ng-container *ngIf=\"group.expandCategory\">\n              <mat-option\n                *ngFor=\"let content of group.contents | slice : resultLimit; let i = index\"\n                (onSelectionChange)=\"onEnter(group.category, content, true)\"\n              >\n                <p>{{ content.name }}</p>\n                <ng-container *ngIf=\"subTemplate; then subTemp; else subCode\"></ng-container>\n\n                <ng-template #subTemp\n                  ><ng-container *ngTemplateOutlet=\"subTemplate\"></ng-container\n                ></ng-template>\n                <ng-template #subCode>\n                  <p class=\"cgi-global-search--sub-code\">{{ content.code }}</p>\n                </ng-template>\n              </mat-option>\n            </ng-container>\n          </mat-optgroup>\n        </ng-container>\n      </mat-autocomplete>\n    </mat-form-field>\n  </form>\n</div>\n<button\n  type=\"button\"\n  (click)=\"showSearch = true\"\n  aria-label=\"Search Icon\"\n  mat-icon-button\n  matSuffix\n  disableRipple=\"true\"\n  class=\"icon-btn-outside\"\n  *ngIf=\"mode === 'search' && !showSearch\"\n>\n  <mat-icon>search</mat-icon>\n</button>\n<button\n  type=\"button\"\n  (click)=\"showNotificationCard = true\"\n  aria-label=\"Search Icon\"\n  mat-icon-button\n  matSuffix\n  disableRipple=\"true\"\n  class=\"icon-btn-outside\"\n  *ngIf=\"mode === 'notification' && !showSearch && !showNotificationCard\"\n>\n  <mat-icon>notifications</mat-icon>\n</button>\n<mat-card\n  appearance=\"outlined\"\n  *ngIf=\"showNotificationCard\"\n  class=\"cgi-lists-style--card-size-3 cgi-top-nav--notification-card\"\n>\n  <mat-card-header>\n    <mat-card-title>\n      <button\n        type=\"button\"\n        (click)=\"showNotificationCard = false\"\n        aria-label=\"Search Icon\"\n        mat-icon-button\n        matSuffix\n        disableRipple=\"true\"\n        class=\"back-arrow-btn\"\n      >\n        <mat-icon>arrow_back</mat-icon>\n      </button>\n      <h2 class=\"cgi-display-6\">Notifications</h2>\n    </mat-card-title>\n  </mat-card-header>\n  <mat-card-content>\n    <div>\n      <mat-list class=\"cgi-lists-style--list-size\">\n        <mat-list-item class=\"cgi-lists-content-3\" *ngFor=\"let list of lists\">\n          <div class=\"list-img\">\n            <mat-icon class=\"cgi-usage--card-icons material-icons-outlined cgi-lists-style--icon\"\n              >person</mat-icon\n            >\n          </div>\n          <div class=\"d-inline cgi-lists-icon-text\">\n            <h6 class=\"cgi-display-6 space_bottom mb-0\">{{ list.name }}</h6>\n            <p class=\"cgi-body-1\">Description text lorem ipsum dolor sit amet.</p>\n          </div>\n        </mat-list-item>\n      </mat-list>\n    </div>\n  </mat-card-content>\n</mat-card>\n<!-- Dropdown mode -->\n<div *ngIf=\"mode === 'dropdown'\" class=\"cgi-dropdown-container\">\n  <mat-form-field\n    appearance=\"outline\"\n    [class]=\"dropdownClass || 'navigate-select'\"\n    [style.width]=\"dropdownWidth\"\n  >\n    <mat-select\n      class=\"dropdown-select-control angular-icon\"\n      [value]=\"_legacyFrameworkMode ? selectedFramework : selectedDropdownItem\"\n      [panelClass]=\"dropdownPanelClass || 'select-panel'\"\n      [placeholder]=\"dropdownPlaceholder\"\n      [disabled]=\"dropdownDisabled\"\n      [attr.aria-label]=\"dropdownAriaLabel\"\n    >\n      <!-- Custom trigger to display icon with selected value -->\n      <mat-select-trigger>\n        <div class=\"option-container\">\n          <img\n            *ngIf=\"getSelectedItem()?.iconPath\"\n            width=\"20\"\n            height=\"20\"\n            class=\"option-icon\"\n            [src]=\"getSelectedItem()?.iconPath\"\n            [alt]=\"getSelectedItem()?.name || ''\"\n          />\n          <span [class]=\"optionLabelClass\">{{ getSelectedItem()?.name }}</span>\n          <ng-container *ngIf=\"getSelectedItem()?.description && showDescriptions\">\n            <span class=\"option-description\">{{ getSelectedItem()?.description }}</span>\n          </ng-container>\n        </div>\n      </mat-select-trigger>\n\n      <mat-option\n        *ngFor=\"let item of _legacyFrameworkMode ? frameworks : dropdownItems\"\n        [value]=\"item.value\"\n        (click)=\"_legacyFrameworkMode ? navigateToFramework(item, $event) : navigateToItem(item)\"\n        [disabled]=\"item.disabled\"\n      >\n        <img\n          *ngIf=\"item.iconPath\"\n          width=\"20\"\n          height=\"20\"\n          class=\"option-icon\"\n          [src]=\"item.iconPath\"\n          [alt]=\"item.name\"\n        />\n        {{ item.name }}\n      </mat-option>\n    </mat-select>\n  </mat-form-field>\n</div>\n", styles: [":host(.cgi-top-nav__item){align-items:center;display:flex;height:64px;justify-content:center;min-width:4.4rem}@media (max-width: 599px){:host(.cgi-top-nav__item){height:56px}}:host(.cgi-top-nav__item) .mat-mdc-select-panel{border-radius:0!important}:host(.cgi-top-nav__item) ::ng-deep .cdk-overlay-container .cdk-overlay-pane.mat-autocomplete-panel-above{width:414px!important}:host(.cgi-top-nav__item) ::ng-deep .cgi-global-search__container .cgi-global-search__toggle{display:none}:host(.cgi-top-nav__item) ::ng-deep .cgi-global-search__container .mat-form-field-wrapper{padding-bottom:0}:host(.cgi-top-nav__item) ::ng-deep .cgi-global-search__container .mat-form-field-suffix .mat-mdc-icon-button .mat-icon{color:#151515}:host(.cgi-top-nav__item) ::ng-deep .cgi-global-search__container .cgi-global-search__category-option{width:145px!important;height:48px!important;padding-right:0;padding-left:0}:host(.cgi-top-nav__item) ::ng-deep .cgi-global-search__container .cgi-global-search__category-option .mat-form-field-infix{padding:12px 0!important;bottom:5px}:host(.cgi-top-nav__item) ::ng-deep .cgi-global-search__container .cgi-global-search__category-option .mat-form-field-flex{height:48px!important;padding:12px!important}:host(.cgi-top-nav__item) ::ng-deep .cgi-global-search__container .cgi-global-search__category-option .mat-form-field-outline-end{border-radius:0}:host(.cgi-top-nav__item) ::ng-deep .cgi-global-search__container .cgi-global-search__search-section{padding-right:0;width:420px!important;height:48px!important;padding-left:0}:host(.cgi-top-nav__item) ::ng-deep .cgi-global-search__container .cgi-global-search__search-section .mat-mdc-form-field-infix{padding:12px 0!important}:host(.cgi-top-nav__item) ::ng-deep .cgi-global-search__container .cgi-global-search__search-section .mat-mdc-form-field-flex{height:48px!important;padding:12px!important;width:405px}:host(.cgi-top-nav__item) ::ng-deep .cgi-global-search__container .cgi-global-search__search-section .mat-form-field-outline-start{border-radius:0}:host(.cgi-top-nav__item) ::ng-deep .cgi-global-search__container .cgi-global-search__search-section-1{padding-right:0;width:435px!important;height:48px!important;padding-left:0}:host(.cgi-top-nav__item) ::ng-deep .cgi-global-search__container .cgi-global-search__search-section-1 .mat-mdc-form-field-infix{padding:12px 0!important;height:48px}:host(.cgi-top-nav__item) ::ng-deep .cgi-global-search__container .cgi-global-search__search-section-1 .mat-mdc-form-field-flex{height:48px!important;padding:12px!important;width:405px!important}:host(.cgi-top-nav__item) ::ng-deep .cgi-global-search__container .cgi-global-search__search-section-1 .mat-form-field-outline-start{border-radius:0}:host(.cgi-top-nav__item) ::ng-deep .cgi-global-search__container .col-12 .mat-form-field-outline-start,:host(.cgi-top-nav__item) ::ng-deep .cgi-global-search__container .col-12 .mat-form-field-outline-end{width:549px!important}.cgi-nav-content :host(.cgi-top-nav__item) ::ng-deep .cgi-global-search__container .mat-mdc-icon-button{margin:0 -12px 0 0;top:3px}:host(.cgi-top-nav__item) ::ng-deep .mat-mdc-form-field.cgi-global-search__search-section .mat-mdc-text-field-wrapper.mdc-text-field--outlined .mdc-notched-outline{border-bottom-left-radius:0;border-top-left-radius:0}:host(.cgi-top-nav__item) ::ng-deep .mat-mdc-form-field.cgi-global-search__category-option .mat-mdc-text-field-wrapper.mdc-text-field--outlined .mdc-notched-outline{border-bottom-right-radius:0;border-top-right-radius:0}:host(.cgi-top-nav__item) .navigate-select{width:172px!important}:host(.cgi-top-nav__item) .cgi-navigation-style--image-size{height:30px}:host(.cgi-top-nav__item) .cgi-navigation-logo-container{display:flex;flex-direction:row;align-items:center;height:100%;margin-right:16px}:host(.cgi-top-nav__item) .cgi-navigation-style--image-size{height:40px;margin-right:12px}:host(.cgi-top-nav__item) .logo-divider{height:32px;margin:0 12px}:host(.cgi-top-nav__item) .cgi-navigation-title{display:flex;align-items:center;height:100%}:host(.cgi-top-nav__item) .cgi-navigation-title h4.cgi-display-4{margin:0;padding:0;font-size:18px;font-weight:500}:host(.cgi-top-nav__item) .framework-option-container{display:flex;align-items:center}:host(.cgi-top-nav__item) .option-container{display:flex;flex-direction:row;align-items:center;width:100%}:host(.cgi-top-nav__item) .option-icon{flex-shrink:0;margin-right:12px;width:20px;height:20px;object-fit:contain}:host(.cgi-top-nav__item) .option-text-container{display:flex;flex-direction:column;flex:1;min-width:0}:host(.cgi-top-nav__item) .option-description{font-size:12px;color:#0009;line-height:1.2}:host(.cgi-top-nav__item) ::ng-deep .mat-mdc-option .mdc-list-item__primary-text{display:flex;width:100%}:host(.cgi-top-nav__item) ::ng-deep .mat-mdc-select-trigger{display:flex;align-items:center}:host(.cgi-top-nav__item) .cgi-dropdown-container mat-form-field{width:100%}:host(.cgi-top-nav__item) ::ng-deep .dropdown-select-control .mat-mdc-select-value{display:flex;align-items:center}:host(.cgi-top-nav__item) ::ng-deep .dropdown-select-control .mat-mdc-select-arrow-wrapper{transform:translateY(0)}:host(.cgi-top-nav__item) ::ng-deep .dropdown-select-control .mdc-list-item__primary-text{width:100%}:host(.cgi-top-nav__item) ::ng-deep .mat-mdc-select-panel .mat-mdc-option{min-height:48px;height:auto;line-height:normal;padding:8px 16px}:host(.cgi-top-nav__item) ::ng-deep .mat-mdc-select-panel .mat-mdc-option.mat-mdc-option-multiple{padding-left:16px}:host(.cgi-top-nav__item) .option-container .option-text-container{overflow:hidden;text-overflow:ellipsis}:host(.cgi-top-nav__item) .option-container .option-text-container span{white-space:normal;line-height:1.2}:host(.cgi-top-nav__menu) button{color:#000000de;line-height:64px;min-width:4.4rem}:host(.cgi-top-nav__menu) .menu-icon{font-size:24px}@media (max-width: 599px){:host(.cgi-top-nav__menu) button{line-height:56px}}.back-arrow-btn{display:none!important}@media (max-width: 768px){.cgi-global-search__container{flex-wrap:nowrap;position:absolute;left:0;background:#fff;z-index:9999}.cgi-global-search__container .cgi-global-search__search-section{width:350px!important}.cgi-global-search__category-option{display:none!important;width:200px!important}.back-arrow-btn{display:block!important;background-color:#fff}.search-icon-inside-textbox{display:none!important}.icon-btn-outside{position:absolute;z-index:99999;right:0}.cgi-dropdown-container{display:none!important}.cgi-top-nav--notification-card{position:absolute;top:0;right:0;width:100%!important;border-radius:0!important;height:100vh!important;z-index:9999}.cgi-top-nav--notification-card .mat-mdc-card-header{background:#fff}.cgi-top-nav--notification-card .mat-mdc-card-header .mat-mdc-card-title{display:flex;align-items:end;gap:10px}.cgi-top-nav--notification-card .mat-mdc-card-header .mat-mdc-card-title .back-arrow-btn{padding-bottom:0;padding-top:20px}}\n"], dependencies: [{ kind: "directive", type: i1.NgClass, selector: "[ngClass]", inputs: ["class", "ngClass"] }, { kind: "directive", type: i1.NgForOf, selector: "[ngFor][ngForOf]", inputs: ["ngForOf", "ngForTrackBy", "ngForTemplate"] }, { kind: "directive", type: i1.NgIf, selector: "[ngIf]", inputs: ["ngIf", "ngIfThen", "ngIfElse"] }, { kind: "directive", type: i1.NgTemplateOutlet, selector: "[ngTemplateOutlet]", inputs: ["ngTemplateOutletContext", "ngTemplateOutlet", "ngTemplateOutletInjector"] }, { kind: "component", type: i4.MatButton, selector: "    button[matButton], a[matButton], button[mat-button], button[mat-raised-button],    button[mat-flat-button], button[mat-stroked-button], a[mat-button], a[mat-raised-button],    a[mat-flat-button], a[mat-stroked-button]  ", inputs: ["matButton"], exportAs: ["matButton", "matAnchor"] }, { kind: "component", type: i4.MatIconButton, selector: "button[mat-icon-button], a[mat-icon-button], button[matIconButton], a[matIconButton]", exportAs: ["matButton", "matAnchor"] }, { kind: "component", type: i5.MatIcon, selector: "mat-icon", inputs: ["color", "inline", "svgIcon", "fontSet", "fontIcon"], exportAs: ["matIcon"] }, { kind: "component", type: i6.MatAutocomplete, selector: "mat-autocomplete", inputs: ["aria-label", "aria-labelledby", "displayWith", "autoActiveFirstOption", "autoSelectActiveOption", "requireSelection", "panelWidth", "disableRipple", "class", "hideSingleSelectionIndicator"], outputs: ["optionSelected", "opened", "closed", "optionActivated"], exportAs: ["matAutocomplete"] }, { kind: "component", type: i6.MatOption, selector: "mat-option", inputs: ["value", "id", "disabled"], outputs: ["onSelectionChange"], exportAs: ["matOption"] }, { kind: "component", type: i6.MatOptgroup, selector: "mat-optgroup", inputs: ["label", "disabled"], exportAs: ["matOptgroup"] }, { kind: "directive", type: i6.MatAutocompleteTrigger, selector: "input[matAutocomplete], textarea[matAutocomplete]", inputs: ["matAutocomplete", "matAutocompletePosition", "matAutocompleteConnectedTo", "autocomplete", "matAutocompleteDisabled"], exportAs: ["matAutocompleteTrigger"] }, { kind: "component", type: i8.MatFormField, selector: "mat-form-field", inputs: ["hideRequiredMarker", "color", "floatLabel", "appearance", "subscriptSizing", "hintLabel"], exportAs: ["matFormField"] }, { kind: "directive", type: i8.MatSuffix, selector: "[matSuffix], [matIconSuffix], [matTextSuffix]", inputs: ["matTextSuffix"] }, { kind: "component", type: i8.MatSelect, selector: "mat-select", inputs: ["aria-describedby", "panelClass", "disabled", "disableRipple", "tabIndex", "hideSingleSelectionIndicator", "placeholder", "required", "multiple", "disableOptionCentering", "compareWith", "value", "aria-label", "aria-labelledby", "errorStateMatcher", "typeaheadDebounceInterval", "sortComparator", "id", "panelWidth", "canSelectNullableOptions"], outputs: ["openedChange", "opened", "closed", "selectionChange", "valueChange"], exportAs: ["matSelect"] }, { kind: "directive", type: i8.MatSelectTrigger, selector: "mat-select-trigger" }, { kind: "directive", type: i4$3.MatInput, selector: "input[matInput], textarea[matInput], select[matNativeControl],      input[matNativeControl], textarea[matNativeControl]", inputs: ["disabled", "id", "placeholder", "name", "required", "type", "errorStateMatcher", "aria-describedby", "value", "readonly", "disabledInteractive"], exportAs: ["matInput"] }, { kind: "directive", type: i1$2.ɵNgNoValidate, selector: "form:not([ngNoForm]):not([ngNativeValidate])" }, { kind: "directive", type: i1$2.DefaultValueAccessor, selector: "input:not([type=checkbox])[formControlName],textarea[formControlName],input:not([type=checkbox])[formControl],textarea[formControl],input:not([type=checkbox])[ngModel],textarea[ngModel],[ngDefaultControl]" }, { kind: "directive", type: i1$2.NgControlStatus, selector: "[formControlName],[ngModel],[formControl]" }, { kind: "directive", type: i1$2.NgControlStatusGroup, selector: "[formGroupName],[formArrayName],[ngModelGroup],[formGroup],form:not([ngNoForm]),[ngForm]" }, { kind: "directive", type: i1$2.FormGroupDirective, selector: "[formGroup]", inputs: ["formGroup"], outputs: ["ngSubmit"], exportAs: ["ngForm"] }, { kind: "directive", type: i1$2.FormControlName, selector: "[formControlName]", inputs: ["formControlName", "disabled", "ngModel"], outputs: ["ngModelChange"] }, { kind: "component", type: i9.MatProgressSpinner, selector: "mat-progress-spinner, mat-spinner", inputs: ["color", "mode", "value", "diameter", "strokeWidth"], exportAs: ["matProgressSpinner"] }, { kind: "component", type: i1$5.MatCard, selector: "mat-card", inputs: ["appearance"], exportAs: ["matCard"] }, { kind: "directive", type: i1$5.MatCardContent, selector: "mat-card-content" }, { kind: "component", type: i1$5.MatCardHeader, selector: "mat-card-header" }, { kind: "directive", type: i1$5.MatCardTitle, selector: "mat-card-title, [mat-card-title], [matCardTitle]" }, { kind: "component", type: i12.MatList, selector: "mat-list", exportAs: ["matList"] }, { kind: "component", type: i12.MatListItem, selector: "mat-list-item, a[mat-list-item], button[mat-list-item]", inputs: ["activated"], exportAs: ["matListItem"] }, { kind: "pipe", type: i1.SlicePipe, name: "slice" }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.2", ngImport: i0, type: CGITopNavItemBrandComponent, decorators: [{
            type: Component,
            args: [{ selector: 'cgi-top-nav-item', standalone: false, template: "<ng-content *ngIf=\"!_menuItem\"></ng-content>\n<button *ngIf=\"_menuItem\" aria-label=\"Menu\" mat-button (click)=\"toggleSidebar()\">\n  <mat-icon *ngIf=\"!opened\" class=\"menu-icon material-icons-outlined\">menu</mat-icon>\n  <mat-icon *ngIf=\"opened\" class=\"menu-icon material-icons-outlined\">menu_open</mat-icon>\n</button>\n\n<!-- Search mode -->\n\n<div\n  *ngIf=\"mode === 'search' && showSearch\"\n  [attr.id]=\"globalSearchId\"\n  class=\"row ml-0 cgi-global-search__container\"\n>\n  <button\n    type=\"button\"\n    (click)=\"showSearch = false\"\n    aria-label=\"Search Icon\"\n    mat-icon-button\n    matSuffix\n    disableRipple=\"true\"\n    class=\"back-arrow-btn\"\n  >\n    <mat-icon>search</mat-icon>\n  </button>\n  <form\n    [formGroup]=\"globalSearch\"\n    [ngClass]=\"isSearchToggled ? 'cgi-global-search--toggled-on' : 'cgi-global-search--toggled-off'\"\n  >\n    <mat-form-field\n      class=\"col-4 cgi-global-search__category-option\"\n      appearance=\"outline\"\n      *ngIf=\"enableCategory\"\n    >\n      <mat-select\n        formControlName=\"category\"\n        [id]=\"globalSearchSelectID\"\n        [aria-label]=\"selectorAriaLabel\"\n        panelClass=\"mat-select-panal-list\"\n      >\n        <mat-option\n          class=\"body_style\"\n          *ngFor=\"let category of categories\"\n          value=\"{{ category.value }}\"\n        >\n          {{ category.name }}</mat-option\n        >\n      </mat-select>\n    </mat-form-field>\n    <!-- flexible search bar size -->\n    <mat-form-field\n      [ngClass]=\"\n        enableCategory\n          ? 'cgi-global-search__search-section'\n          : 'col-12 cgi-global-search__search-section-1'\n      \"\n      appearance=\"outline\"\n      floatLabel=\"never\"\n    >\n      <button\n        type=\"submit\"\n        class=\"search-icon-inside-textbox\"\n        aria-label=\"Search Icon\"\n        mat-icon-button\n        matSuffix\n        disableRipple=\"true\"\n      >\n        <mat-icon>search</mat-icon>\n      </button>\n      <input\n        [id]=\"globalSearchInputID\"\n        type=\"text\"\n        matInput\n        [placeholder]=\"globalSearchInputPlaceholder\"\n        formControlName=\"searchString\"\n        [matAutocomplete]=\"searchResults\"\n        aria-label=\"Global Search Field\"\n      />\n      <mat-autocomplete\n        [id]=\"globalSearchAutocompleteID\"\n        #searchResults=\"matAutocomplete\"\n        [displayWith]=\"displayFn\"\n        class=\"cgi-global-search-autocomplete\"\n        [panelWidth]=\"panelWidth || 405\"\n      >\n        <mat-option class=\"cgi-global-search__spinner\" *ngIf=\"isLoading\">\n          <mat-spinner diameter=\"80\"></mat-spinner>\n        </mat-option>\n        <mat-option\n          *ngIf=\"\n            globalSearch.get('searchString')?.value && !isLoading && globalSearchResultSize === 0\n          \"\n          class=\"cgi-global-search__no-results\"\n        >\n          {{ noResults }}\n        </mat-option>\n        <!-- for searching with category -->\n        <ng-container\n          *ngIf=\"globalSearch.get('searchString')?.value && !isLoading && enableCategory\"\n        >\n          <mat-optgroup *ngFor=\"let group of globalSearchResult\">\n            {{ group.category.name }}\n            <mat-option\n              *ngFor=\"let content of group.contents | slice : 0 : resultLimit; let i = index\"\n              (onSelectionChange)=\"onEnter(group.category, content)\"\n            >\n              <p class=\"cgi-body-2\">{{ content.name }}</p>\n              <ng-container *ngIf=\"subTemplate; then subTemp; else subCode\"></ng-container>\n\n              <ng-template #subTemp\n                ><ng-container [ngTemplateOutlet]=\"subTemplate\"></ng-container\n              ></ng-template>\n              <ng-template #subCode>\n                <p class=\"cgi-body-1 cgi-global-search--sub-code\">{{ content.code }}</p>\n              </ng-template>\n            </mat-option>\n            <!-- Result limit on categories -->\n            <ng-container *ngIf=\"group.totalRecords > resultLimit\">\n              <button\n                color=\"primary\"\n                mat-button\n                (click)=\"\n                  group.category.moreResultsLink\n                    ? gotoLink(group.category.moreResultsLink, group.category.queryParamKey)\n                    : (group.expandCategory = !group.expandCategory)\n                \"\n                [class.d-none]=\"group.expandCategory\"\n              >\n                {{ moreResults }}\n              </button>\n            </ng-container>\n            <ng-container *ngIf=\"group.expandCategory\">\n              <mat-option\n                *ngFor=\"let content of group.contents | slice : resultLimit; let i = index\"\n                (onSelectionChange)=\"onEnter(group.category, content, true)\"\n              >\n                <p>{{ content.name }}</p>\n                <ng-container *ngIf=\"subTemplate; then subTemp; else subCode\"></ng-container>\n\n                <ng-template #subTemp\n                  ><ng-container *ngTemplateOutlet=\"subTemplate\"></ng-container\n                ></ng-template>\n                <ng-template #subCode>\n                  <p class=\"cgi-global-search--sub-code\">{{ content.code }}</p>\n                </ng-template>\n              </mat-option>\n            </ng-container>\n          </mat-optgroup>\n        </ng-container>\n      </mat-autocomplete>\n    </mat-form-field>\n  </form>\n</div>\n<button\n  type=\"button\"\n  (click)=\"showSearch = true\"\n  aria-label=\"Search Icon\"\n  mat-icon-button\n  matSuffix\n  disableRipple=\"true\"\n  class=\"icon-btn-outside\"\n  *ngIf=\"mode === 'search' && !showSearch\"\n>\n  <mat-icon>search</mat-icon>\n</button>\n<button\n  type=\"button\"\n  (click)=\"showNotificationCard = true\"\n  aria-label=\"Search Icon\"\n  mat-icon-button\n  matSuffix\n  disableRipple=\"true\"\n  class=\"icon-btn-outside\"\n  *ngIf=\"mode === 'notification' && !showSearch && !showNotificationCard\"\n>\n  <mat-icon>notifications</mat-icon>\n</button>\n<mat-card\n  appearance=\"outlined\"\n  *ngIf=\"showNotificationCard\"\n  class=\"cgi-lists-style--card-size-3 cgi-top-nav--notification-card\"\n>\n  <mat-card-header>\n    <mat-card-title>\n      <button\n        type=\"button\"\n        (click)=\"showNotificationCard = false\"\n        aria-label=\"Search Icon\"\n        mat-icon-button\n        matSuffix\n        disableRipple=\"true\"\n        class=\"back-arrow-btn\"\n      >\n        <mat-icon>arrow_back</mat-icon>\n      </button>\n      <h2 class=\"cgi-display-6\">Notifications</h2>\n    </mat-card-title>\n  </mat-card-header>\n  <mat-card-content>\n    <div>\n      <mat-list class=\"cgi-lists-style--list-size\">\n        <mat-list-item class=\"cgi-lists-content-3\" *ngFor=\"let list of lists\">\n          <div class=\"list-img\">\n            <mat-icon class=\"cgi-usage--card-icons material-icons-outlined cgi-lists-style--icon\"\n              >person</mat-icon\n            >\n          </div>\n          <div class=\"d-inline cgi-lists-icon-text\">\n            <h6 class=\"cgi-display-6 space_bottom mb-0\">{{ list.name }}</h6>\n            <p class=\"cgi-body-1\">Description text lorem ipsum dolor sit amet.</p>\n          </div>\n        </mat-list-item>\n      </mat-list>\n    </div>\n  </mat-card-content>\n</mat-card>\n<!-- Dropdown mode -->\n<div *ngIf=\"mode === 'dropdown'\" class=\"cgi-dropdown-container\">\n  <mat-form-field\n    appearance=\"outline\"\n    [class]=\"dropdownClass || 'navigate-select'\"\n    [style.width]=\"dropdownWidth\"\n  >\n    <mat-select\n      class=\"dropdown-select-control angular-icon\"\n      [value]=\"_legacyFrameworkMode ? selectedFramework : selectedDropdownItem\"\n      [panelClass]=\"dropdownPanelClass || 'select-panel'\"\n      [placeholder]=\"dropdownPlaceholder\"\n      [disabled]=\"dropdownDisabled\"\n      [attr.aria-label]=\"dropdownAriaLabel\"\n    >\n      <!-- Custom trigger to display icon with selected value -->\n      <mat-select-trigger>\n        <div class=\"option-container\">\n          <img\n            *ngIf=\"getSelectedItem()?.iconPath\"\n            width=\"20\"\n            height=\"20\"\n            class=\"option-icon\"\n            [src]=\"getSelectedItem()?.iconPath\"\n            [alt]=\"getSelectedItem()?.name || ''\"\n          />\n          <span [class]=\"optionLabelClass\">{{ getSelectedItem()?.name }}</span>\n          <ng-container *ngIf=\"getSelectedItem()?.description && showDescriptions\">\n            <span class=\"option-description\">{{ getSelectedItem()?.description }}</span>\n          </ng-container>\n        </div>\n      </mat-select-trigger>\n\n      <mat-option\n        *ngFor=\"let item of _legacyFrameworkMode ? frameworks : dropdownItems\"\n        [value]=\"item.value\"\n        (click)=\"_legacyFrameworkMode ? navigateToFramework(item, $event) : navigateToItem(item)\"\n        [disabled]=\"item.disabled\"\n      >\n        <img\n          *ngIf=\"item.iconPath\"\n          width=\"20\"\n          height=\"20\"\n          class=\"option-icon\"\n          [src]=\"item.iconPath\"\n          [alt]=\"item.name\"\n        />\n        {{ item.name }}\n      </mat-option>\n    </mat-select>\n  </mat-form-field>\n</div>\n", styles: [":host(.cgi-top-nav__item){align-items:center;display:flex;height:64px;justify-content:center;min-width:4.4rem}@media (max-width: 599px){:host(.cgi-top-nav__item){height:56px}}:host(.cgi-top-nav__item) .mat-mdc-select-panel{border-radius:0!important}:host(.cgi-top-nav__item) ::ng-deep .cdk-overlay-container .cdk-overlay-pane.mat-autocomplete-panel-above{width:414px!important}:host(.cgi-top-nav__item) ::ng-deep .cgi-global-search__container .cgi-global-search__toggle{display:none}:host(.cgi-top-nav__item) ::ng-deep .cgi-global-search__container .mat-form-field-wrapper{padding-bottom:0}:host(.cgi-top-nav__item) ::ng-deep .cgi-global-search__container .mat-form-field-suffix .mat-mdc-icon-button .mat-icon{color:#151515}:host(.cgi-top-nav__item) ::ng-deep .cgi-global-search__container .cgi-global-search__category-option{width:145px!important;height:48px!important;padding-right:0;padding-left:0}:host(.cgi-top-nav__item) ::ng-deep .cgi-global-search__container .cgi-global-search__category-option .mat-form-field-infix{padding:12px 0!important;bottom:5px}:host(.cgi-top-nav__item) ::ng-deep .cgi-global-search__container .cgi-global-search__category-option .mat-form-field-flex{height:48px!important;padding:12px!important}:host(.cgi-top-nav__item) ::ng-deep .cgi-global-search__container .cgi-global-search__category-option .mat-form-field-outline-end{border-radius:0}:host(.cgi-top-nav__item) ::ng-deep .cgi-global-search__container .cgi-global-search__search-section{padding-right:0;width:420px!important;height:48px!important;padding-left:0}:host(.cgi-top-nav__item) ::ng-deep .cgi-global-search__container .cgi-global-search__search-section .mat-mdc-form-field-infix{padding:12px 0!important}:host(.cgi-top-nav__item) ::ng-deep .cgi-global-search__container .cgi-global-search__search-section .mat-mdc-form-field-flex{height:48px!important;padding:12px!important;width:405px}:host(.cgi-top-nav__item) ::ng-deep .cgi-global-search__container .cgi-global-search__search-section .mat-form-field-outline-start{border-radius:0}:host(.cgi-top-nav__item) ::ng-deep .cgi-global-search__container .cgi-global-search__search-section-1{padding-right:0;width:435px!important;height:48px!important;padding-left:0}:host(.cgi-top-nav__item) ::ng-deep .cgi-global-search__container .cgi-global-search__search-section-1 .mat-mdc-form-field-infix{padding:12px 0!important;height:48px}:host(.cgi-top-nav__item) ::ng-deep .cgi-global-search__container .cgi-global-search__search-section-1 .mat-mdc-form-field-flex{height:48px!important;padding:12px!important;width:405px!important}:host(.cgi-top-nav__item) ::ng-deep .cgi-global-search__container .cgi-global-search__search-section-1 .mat-form-field-outline-start{border-radius:0}:host(.cgi-top-nav__item) ::ng-deep .cgi-global-search__container .col-12 .mat-form-field-outline-start,:host(.cgi-top-nav__item) ::ng-deep .cgi-global-search__container .col-12 .mat-form-field-outline-end{width:549px!important}.cgi-nav-content :host(.cgi-top-nav__item) ::ng-deep .cgi-global-search__container .mat-mdc-icon-button{margin:0 -12px 0 0;top:3px}:host(.cgi-top-nav__item) ::ng-deep .mat-mdc-form-field.cgi-global-search__search-section .mat-mdc-text-field-wrapper.mdc-text-field--outlined .mdc-notched-outline{border-bottom-left-radius:0;border-top-left-radius:0}:host(.cgi-top-nav__item) ::ng-deep .mat-mdc-form-field.cgi-global-search__category-option .mat-mdc-text-field-wrapper.mdc-text-field--outlined .mdc-notched-outline{border-bottom-right-radius:0;border-top-right-radius:0}:host(.cgi-top-nav__item) .navigate-select{width:172px!important}:host(.cgi-top-nav__item) .cgi-navigation-style--image-size{height:30px}:host(.cgi-top-nav__item) .cgi-navigation-logo-container{display:flex;flex-direction:row;align-items:center;height:100%;margin-right:16px}:host(.cgi-top-nav__item) .cgi-navigation-style--image-size{height:40px;margin-right:12px}:host(.cgi-top-nav__item) .logo-divider{height:32px;margin:0 12px}:host(.cgi-top-nav__item) .cgi-navigation-title{display:flex;align-items:center;height:100%}:host(.cgi-top-nav__item) .cgi-navigation-title h4.cgi-display-4{margin:0;padding:0;font-size:18px;font-weight:500}:host(.cgi-top-nav__item) .framework-option-container{display:flex;align-items:center}:host(.cgi-top-nav__item) .option-container{display:flex;flex-direction:row;align-items:center;width:100%}:host(.cgi-top-nav__item) .option-icon{flex-shrink:0;margin-right:12px;width:20px;height:20px;object-fit:contain}:host(.cgi-top-nav__item) .option-text-container{display:flex;flex-direction:column;flex:1;min-width:0}:host(.cgi-top-nav__item) .option-description{font-size:12px;color:#0009;line-height:1.2}:host(.cgi-top-nav__item) ::ng-deep .mat-mdc-option .mdc-list-item__primary-text{display:flex;width:100%}:host(.cgi-top-nav__item) ::ng-deep .mat-mdc-select-trigger{display:flex;align-items:center}:host(.cgi-top-nav__item) .cgi-dropdown-container mat-form-field{width:100%}:host(.cgi-top-nav__item) ::ng-deep .dropdown-select-control .mat-mdc-select-value{display:flex;align-items:center}:host(.cgi-top-nav__item) ::ng-deep .dropdown-select-control .mat-mdc-select-arrow-wrapper{transform:translateY(0)}:host(.cgi-top-nav__item) ::ng-deep .dropdown-select-control .mdc-list-item__primary-text{width:100%}:host(.cgi-top-nav__item) ::ng-deep .mat-mdc-select-panel .mat-mdc-option{min-height:48px;height:auto;line-height:normal;padding:8px 16px}:host(.cgi-top-nav__item) ::ng-deep .mat-mdc-select-panel .mat-mdc-option.mat-mdc-option-multiple{padding-left:16px}:host(.cgi-top-nav__item) .option-container .option-text-container{overflow:hidden;text-overflow:ellipsis}:host(.cgi-top-nav__item) .option-container .option-text-container span{white-space:normal;line-height:1.2}:host(.cgi-top-nav__menu) button{color:#000000de;line-height:64px;min-width:4.4rem}:host(.cgi-top-nav__menu) .menu-icon{font-size:24px}@media (max-width: 599px){:host(.cgi-top-nav__menu) button{line-height:56px}}.back-arrow-btn{display:none!important}@media (max-width: 768px){.cgi-global-search__container{flex-wrap:nowrap;position:absolute;left:0;background:#fff;z-index:9999}.cgi-global-search__container .cgi-global-search__search-section{width:350px!important}.cgi-global-search__category-option{display:none!important;width:200px!important}.back-arrow-btn{display:block!important;background-color:#fff}.search-icon-inside-textbox{display:none!important}.icon-btn-outside{position:absolute;z-index:99999;right:0}.cgi-dropdown-container{display:none!important}.cgi-top-nav--notification-card{position:absolute;top:0;right:0;width:100%!important;border-radius:0!important;height:100vh!important;z-index:9999}.cgi-top-nav--notification-card .mat-mdc-card-header{background:#fff}.cgi-top-nav--notification-card .mat-mdc-card-header .mat-mdc-card-title{display:flex;align-items:end;gap:10px}.cgi-top-nav--notification-card .mat-mdc-card-header .mat-mdc-card-title .back-arrow-btn{padding-bottom:0;padding-top:20px}}\n"] }]
        }], ctorParameters: () => [{ type: CGINavContainerService }, { type: i1$2.UntypedFormBuilder }, { type: i2.Router }], propDecorators: { mode: [{
                type: Input
            }], _showSearchBar: [{
                type: Input
            }], _showLogo: [{
                type: Input
            }], _showFrameworkSelector: [{
                type: Input
            }], _showDropdownSelector: [{
                type: Input
            }], lists: [{
                type: Input
            }], onResize: [{
                type: HostListener,
                args: ['window:resize', ['$event']]
            }], logoSrc: [{
                type: Input
            }], logoAlt: [{
                type: Input
            }], title: [{
                type: Input
            }], showDivider: [{
                type: Input
            }], dropdownItems: [{
                type: Input
            }], selectedDropdownItem: [{
                type: Input
            }], dropdownClass: [{
                type: Input
            }], dropdownWidth: [{
                type: Input
            }], dropdownPanelClass: [{
                type: Input
            }], dropdownPlaceholder: [{
                type: Input
            }], dropdownDisabled: [{
                type: Input
            }], dropdownAriaLabel: [{
                type: Input
            }], optionLabelClass: [{
                type: Input
            }], showDescriptions: [{
                type: Input
            }], dropdownItemSelected: [{
                type: Output
            }], frameworks: [{
                type: Input
            }], selectedFramework: [{
                type: Input
            }], frameworkSelected: [{
                type: Output
            }], opened: [{
                type: Input
            }], categories: [{
                type: Input
            }], enableCategory: [{
                type: Input
            }], isLoading: [{
                type: Input
            }], globalSearchResult: [{
                type: Input
            }], globalSearchResultSize: [{
                type: Input
            }], panelWidth: [{
                type: Input
            }], selectorAriaLabel: [{
                type: Input
            }], globalSearchSelectID: [{
                type: Input
            }], globalSearchInputID: [{
                type: Input
            }], globalSearchInputPlaceholder: [{
                type: Input
            }], globalSearchAutocompleteID: [{
                type: Input
            }], moreResults: [{
                type: Input
            }], noResults: [{
                type: Input
            }], resultLimit: [{
                type: Input
            }], subTemplate: [{
                type: Input
            }], optionSelected: [{
                type: Output
            }], search: [{
                type: Output
            }], trigger: [{
                type: ViewChild,
                args: [MatAutocompleteTrigger]
            }], isClassContainer: [{
                type: HostBinding,
                args: ['class.cgi-top-nav__item']
            }], isMenuItem: [{
                type: HostBinding,
                args: ['class.cgi-top-nav__menu']
            }], menuItem: [{
                type: Input
            }], isSearchBarItem: [{
                type: HostBinding,
                args: ['class.cgi-top-nav__search']
            }], showSearchIcon: [{
                type: Input
            }] } });

/**
 * General top navigation component.
 *
 * TODO: How to use component and examples.
 */
class CGITopNavBrandComponent {
    /**
     * Empty constructor.
     */
    constructor(document) {
        /** The landmarks to be quickly focused to from the quick-nav dropdown */
        this.landmarks = [];
        /** Quick nav button text */
        this.quickSkipButtonText = 'Skip to:';
        /** Quick nav aria label */
        this.quickSkipAriaLabel = 'skip to landmark dropdown';
        /** Custom aria-label attribute for accessibility. */
        this.ariaLabel = 'Top navigation';
        this._document = document;
        this.isClassContainer = true;
        this.hideButton = true;
    }
    /**
     * Set the default landmarks
     */
    ngOnInit() {
        if (this.landmarks.length === 0) {
            this.landmarks = [
                {
                    label: 'Search',
                    id: "global-search-component" /* PageLandmarks.GLOBAL_SEARCH */,
                },
                {
                    label: 'Content',
                    id: "main-content" /* PageLandmarks.MAIN_CONTENT */,
                },
                {
                    label: 'Navigation',
                    id: "left-nav" /* PageLandmarks.LEFT_NAV */,
                },
            ];
        }
    }
    /** Go (focus) to the specified landmark */
    goToLandmark(landmark) {
        this.matMenu.closeMenu();
        switch (landmark.id) {
            case "global-search-component" /* PageLandmarks.GLOBAL_SEARCH */:
                let globalSearch = this._document.getElementById(landmark.id);
                let globalSearchInput = globalSearch.querySelector('input');
                globalSearchInput.focus();
                globalSearch = globalSearchInput = null;
                break;
            case "left-nav" /* PageLandmarks.LEFT_NAV */:
                let leftNav = this._document.getElementById(landmark.id);
                let firstLink = null;
                if (leftNav.children.length === 1) {
                    firstLink = leftNav.querySelector('a');
                }
                else {
                    firstLink = leftNav.querySelector('li a');
                }
                firstLink.focus();
                leftNav = firstLink = null;
                break;
            case "main-content" /* PageLandmarks.MAIN_CONTENT */:
                let firstFocusableContent = this._document
                    .querySelector('[role="main"]')
                    .querySelector('a, button, input, textarea, select, details, [tabindex]:not([tabindex="-1"])');
                if (firstFocusableContent) {
                    firstFocusableContent.focus();
                }
                firstFocusableContent = null;
                break;
        }
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.2", ngImport: i0, type: CGITopNavBrandComponent, deps: [{ token: DOCUMENT }], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "20.3.2", type: CGITopNavBrandComponent, isStandalone: false, selector: "cgi-top-nav", inputs: { landmarks: "landmarks", quickSkipButtonText: "quickSkipButtonText", quickSkipAriaLabel: "quickSkipAriaLabel", color: "color", ariaLabel: "ariaLabel" }, host: { properties: { "class.cgi-top-nav": "this.isClassContainer" } }, viewQueries: [{ propertyName: "matMenu", first: true, predicate: MatMenuTrigger, descendants: true }], ngImport: i0, template: "<nav attr.aria-label=\"{{ ariaLabel }}\" role=\"navigation\">\n  <mat-toolbar [color]=\"color\">\n    <button\n      id=\"quick-nav\"\n      (focusin)=\"hideButton = false\"\n      (focusout)=\"hideButton = true\"\n      [class.quick-nav--hide]=\"hideButton\"\n      color=\"secondary\"\n      mat-flat-button\n      [matMenuTriggerFor]=\"quickNav\"\n      [attr.aria-label]=\"quickSkipAriaLabel\"\n    >\n      {{ quickSkipButtonText }}\n    </button>\n    <mat-menu #quickNav=\"matMenu\">\n      <button\n        *ngFor=\"let landmark of landmarks\"\n        [attr.id]=\"'skip-to-' + landmark.id\"\n        (click)=\"$event.stopPropagation(); goToLandmark(landmark)\"\n        mat-menu-item\n      >\n        {{ landmark.label }}\n      </button>\n    </mat-menu>\n    <ng-content select=\".cgi-top-nav--left\"></ng-content>\n    <ng-content select=\".cgi-top-nav--right\"></ng-content>\n  </mat-toolbar>\n  <!-- #2 -->\n</nav>\n", styles: [".cgi-vertical-spacer-1{height:2rem;width:100%}.cgi-vertical-spacer-2{height:4rem;width:100%}.cgi-vertical-spacer-3{height:6rem;width:100%}.cgi-vertical-spacer-4{height:8rem;width:100%}.cgi-vertical-spacer-5{height:10rem;width:100%}.cgi-vertical-spacer-6{height:12rem;width:100%}.cgi-vertical-spacer-7{height:14rem;width:100%}.cgi-vertical-spacer-8{height:16rem;width:100%}.cgi-vertical-spacer-9{height:18rem;width:100%}.cgi-vertical-spacer-10{height:20rem;width:100%}:host(.cgi-top-nav){position:relative;z-index:10}:host(.cgi-top-nav) mat-toolbar{height:64px;padding:0}:host(.cgi-top-nav) .quick-nav--hide{margin:0;opacity:0;padding:0;position:absolute;width:0}:host(.cgi-top-nav)::ng-deep .cgi-top-nav--left{-moz-box-ordinal-group:0;-ms-flex-order:0;-webkit-box-ordinal-group:0;-webkit-order:0;display:flex;flex-direction:row;margin:0;order:0;width:100%}:host(.cgi-top-nav)::ng-deep .cgi-top-nav--left cgi-top-nav-item:not(.cgi-top-nav__menu):nth-last-child(n+2)>:first-child:first-child,:host(.cgi-top-nav)::ng-deep .cgi-top-nav--left cgi-top-nav-item:not(.cgi-top-nav__menu):nth-last-child(n+2)>:first-child~*:first-child{margin-left:.9rem}:host(.cgi-top-nav)::ng-deep .cgi-top-nav--left cgi-top-nav-item:not(.cgi-top-nav__menu):nth-last-child(1)>:first-child,:host(.cgi-top-nav)::ng-deep .cgi-top-nav--left cgi-top-nav-item:not(.cgi-top-nav__menu):nth-last-child(1)>:first-child~*{margin-left:.9rem}:host(.cgi-top-nav)::ng-deep .cgi-top-nav--right{-moz-box-ordinal-group:2;-ms-flex-order:2;-webkit-box-ordinal-group:2;-webkit-order:2;display:flex;margin:0 0 0 auto;order:2}:host(.cgi-top-nav)::ng-deep .base-button{display:flex!important;align-items:center;justify-content:center;padding:12px;width:100%;height:100%;min-width:20px!important;color:#333!important;border-top:4px solid #A8A8A8!important}:host(.cgi-top-nav)::ng-deep .base-button span{display:block}:host(.cgi-top-nav)::ng-deep .icon-button{width:auto!important;padding:12px!important;border:none!important;font-weight:700!important;font-size:14px!important;height:max-content!important}:host(.cgi-top-nav)::ng-deep .icon-button .material-icons-outlined{font-size:16px!important;width:16px;height:16px!important;margin-left:16px!important}:host(.cgi-top-nav)::ng-deep .item-divider{height:40px;border-right-width:1px!important;border-right-color:#333!important}\n"], dependencies: [{ kind: "directive", type: i1.NgForOf, selector: "[ngFor][ngForOf]", inputs: ["ngForOf", "ngForTrackBy", "ngForTemplate"] }, { kind: "component", type: i2$1.MatToolbar, selector: "mat-toolbar", inputs: ["color"], exportAs: ["matToolbar"] }, { kind: "component", type: i4.MatButton, selector: "    button[matButton], a[matButton], button[mat-button], button[mat-raised-button],    button[mat-flat-button], button[mat-stroked-button], a[mat-button], a[mat-raised-button],    a[mat-flat-button], a[mat-stroked-button]  ", inputs: ["matButton"], exportAs: ["matButton", "matAnchor"] }, { kind: "component", type: i4$1.MatMenu, selector: "mat-menu", inputs: ["backdropClass", "aria-label", "aria-labelledby", "aria-describedby", "xPosition", "yPosition", "overlapTrigger", "hasBackdrop", "class", "classList"], outputs: ["closed", "close"], exportAs: ["matMenu"] }, { kind: "component", type: i4$1.MatMenuItem, selector: "[mat-menu-item]", inputs: ["role", "disabled", "disableRipple"], exportAs: ["matMenuItem"] }, { kind: "directive", type: i4$1.MatMenuTrigger, selector: "[mat-menu-trigger-for], [matMenuTriggerFor]", inputs: ["mat-menu-trigger-for", "matMenuTriggerFor", "matMenuTriggerData", "matMenuTriggerRestoreFocus"], outputs: ["menuOpened", "onMenuOpen", "menuClosed", "onMenuClose"], exportAs: ["matMenuTrigger"] }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.2", ngImport: i0, type: CGITopNavBrandComponent, decorators: [{
            type: Component,
            args: [{ selector: 'cgi-top-nav', standalone: false, template: "<nav attr.aria-label=\"{{ ariaLabel }}\" role=\"navigation\">\n  <mat-toolbar [color]=\"color\">\n    <button\n      id=\"quick-nav\"\n      (focusin)=\"hideButton = false\"\n      (focusout)=\"hideButton = true\"\n      [class.quick-nav--hide]=\"hideButton\"\n      color=\"secondary\"\n      mat-flat-button\n      [matMenuTriggerFor]=\"quickNav\"\n      [attr.aria-label]=\"quickSkipAriaLabel\"\n    >\n      {{ quickSkipButtonText }}\n    </button>\n    <mat-menu #quickNav=\"matMenu\">\n      <button\n        *ngFor=\"let landmark of landmarks\"\n        [attr.id]=\"'skip-to-' + landmark.id\"\n        (click)=\"$event.stopPropagation(); goToLandmark(landmark)\"\n        mat-menu-item\n      >\n        {{ landmark.label }}\n      </button>\n    </mat-menu>\n    <ng-content select=\".cgi-top-nav--left\"></ng-content>\n    <ng-content select=\".cgi-top-nav--right\"></ng-content>\n  </mat-toolbar>\n  <!-- #2 -->\n</nav>\n", styles: [".cgi-vertical-spacer-1{height:2rem;width:100%}.cgi-vertical-spacer-2{height:4rem;width:100%}.cgi-vertical-spacer-3{height:6rem;width:100%}.cgi-vertical-spacer-4{height:8rem;width:100%}.cgi-vertical-spacer-5{height:10rem;width:100%}.cgi-vertical-spacer-6{height:12rem;width:100%}.cgi-vertical-spacer-7{height:14rem;width:100%}.cgi-vertical-spacer-8{height:16rem;width:100%}.cgi-vertical-spacer-9{height:18rem;width:100%}.cgi-vertical-spacer-10{height:20rem;width:100%}:host(.cgi-top-nav){position:relative;z-index:10}:host(.cgi-top-nav) mat-toolbar{height:64px;padding:0}:host(.cgi-top-nav) .quick-nav--hide{margin:0;opacity:0;padding:0;position:absolute;width:0}:host(.cgi-top-nav)::ng-deep .cgi-top-nav--left{-moz-box-ordinal-group:0;-ms-flex-order:0;-webkit-box-ordinal-group:0;-webkit-order:0;display:flex;flex-direction:row;margin:0;order:0;width:100%}:host(.cgi-top-nav)::ng-deep .cgi-top-nav--left cgi-top-nav-item:not(.cgi-top-nav__menu):nth-last-child(n+2)>:first-child:first-child,:host(.cgi-top-nav)::ng-deep .cgi-top-nav--left cgi-top-nav-item:not(.cgi-top-nav__menu):nth-last-child(n+2)>:first-child~*:first-child{margin-left:.9rem}:host(.cgi-top-nav)::ng-deep .cgi-top-nav--left cgi-top-nav-item:not(.cgi-top-nav__menu):nth-last-child(1)>:first-child,:host(.cgi-top-nav)::ng-deep .cgi-top-nav--left cgi-top-nav-item:not(.cgi-top-nav__menu):nth-last-child(1)>:first-child~*{margin-left:.9rem}:host(.cgi-top-nav)::ng-deep .cgi-top-nav--right{-moz-box-ordinal-group:2;-ms-flex-order:2;-webkit-box-ordinal-group:2;-webkit-order:2;display:flex;margin:0 0 0 auto;order:2}:host(.cgi-top-nav)::ng-deep .base-button{display:flex!important;align-items:center;justify-content:center;padding:12px;width:100%;height:100%;min-width:20px!important;color:#333!important;border-top:4px solid #A8A8A8!important}:host(.cgi-top-nav)::ng-deep .base-button span{display:block}:host(.cgi-top-nav)::ng-deep .icon-button{width:auto!important;padding:12px!important;border:none!important;font-weight:700!important;font-size:14px!important;height:max-content!important}:host(.cgi-top-nav)::ng-deep .icon-button .material-icons-outlined{font-size:16px!important;width:16px;height:16px!important;margin-left:16px!important}:host(.cgi-top-nav)::ng-deep .item-divider{height:40px;border-right-width:1px!important;border-right-color:#333!important}\n"] }]
        }], ctorParameters: () => [{ type: undefined, decorators: [{
                    type: Inject,
                    args: [DOCUMENT]
                }] }], propDecorators: { isClassContainer: [{
                type: HostBinding,
                args: ['class.cgi-top-nav']
            }], landmarks: [{
                type: Input
            }], quickSkipButtonText: [{
                type: Input
            }], quickSkipAriaLabel: [{
                type: Input
            }], matMenu: [{
                type: ViewChild,
                args: [MatMenuTrigger, { static: false }]
            }], color: [{
                type: Input
            }], ariaLabel: [{
                type: Input
            }] } });

class CGITopNavBrandModule {
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.2", ngImport: i0, type: CGITopNavBrandModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule }); }
    static { this.ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "20.3.2", ngImport: i0, type: CGITopNavBrandModule, declarations: [CGITopNavBrandComponent, CGITopNavItemBrandComponent], imports: [CommonModule,
            MatToolbarModule,
            MatButtonModule,
            MatIconModule,
            MatMenuModule,
            MatAutocompleteModule,
            MatSelectModule,
            MatFormFieldModule,
            MatInputModule,
            FormsModule,
            ReactiveFormsModule,
            MatProgressSpinnerModule,
            MatDividerModule,
            MatCardModule,
            MatListModule], exports: [CGITopNavBrandComponent, CGITopNavItemBrandComponent] }); }
    static { this.ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "20.3.2", ngImport: i0, type: CGITopNavBrandModule, imports: [CommonModule,
            MatToolbarModule,
            MatButtonModule,
            MatIconModule,
            MatMenuModule,
            MatAutocompleteModule,
            MatSelectModule,
            MatFormFieldModule,
            MatInputModule,
            FormsModule,
            ReactiveFormsModule,
            MatProgressSpinnerModule,
            MatDividerModule,
            MatCardModule,
            MatListModule] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.2", ngImport: i0, type: CGITopNavBrandModule, decorators: [{
            type: NgModule,
            args: [{
                    imports: [
                        CommonModule,
                        MatToolbarModule,
                        MatButtonModule,
                        MatIconModule,
                        MatMenuModule,
                        MatAutocompleteModule,
                        MatSelectModule,
                        MatFormFieldModule,
                        MatInputModule,
                        FormsModule,
                        ReactiveFormsModule,
                        MatProgressSpinnerModule,
                        MatDividerModule,
                        MatCardModule,
                        MatListModule,
                    ],
                    declarations: [CGITopNavBrandComponent, CGITopNavItemBrandComponent],
                    exports: [CGITopNavBrandComponent, CGITopNavItemBrandComponent],
                }]
        }] });

/**
 * Side Navigation Item data model
 */
class SideNavBrandItem {
    /**
     * Default constructor for SideNavItem
     * @param text Text/Title of side nav item
     * @param link Router link of side nav item
     * @param icon Icon of the side nav item
     * @param subsection Subsection of side nav item if applicable
     * @param state query attributes in navigation url
     * @param params customizable attributes to be added to particular navigation route
     */
    constructor(text = '', link = '', icon, subsection, state, params) {
        this.text = text;
        this.link = link;
        this.icon = icon;
        this.subsection = subsection;
        this.state = state;
        this.queryParams = params;
    }
}

/**
 * Top-level layout container for the CGI navigation system.
 *
 * Wraps `cgi-side-nav` and `cgi-nav-content` and acts as the positioning
 * context for the navigation panel. The container is self-sizing — no extra
 * `position: absolute; inset: 0` boilerplate is required in the consuming
 * component. For full-screen app shells use `[fillViewport]="true"`.
 *
 * ```html
 * <cgi-nav-container fillViewport>
 *   <cgi-side-nav [links]="links" opened></cgi-side-nav>
 *   <cgi-nav-content>...</cgi-nav-content>
 * </cgi-nav-container>
 * ```
 */
class CGINavContainerBrandComponent {
    /**
     * When true, the container stretches to the full browser viewport
     * (`100dvh` / `100vh`). Useful for app shells.
     */
    set fillViewport(value) {
        this._fillViewport = coerceBooleanProperty(value);
    }
    get fillViewport() {
        return this._fillViewport;
    }
    /**
     * When true, pins the container to the viewport (`position: fixed`).
     * Mirrors `MatSidenavContainer.fixedInViewport`. Combine with
     * `[fixedTopGap]` / `[fixedBottomGap]` for fixed app bars/footers.
     */
    set fixedInViewport(value) {
        this._fixedInViewport = coerceBooleanProperty(value);
    }
    get fixedInViewport() {
        return this._fixedInViewport;
    }
    /** Pixels of empty space at the top of the viewport (for fixed top bars). */
    set fixedTopGap(value) {
        this._fixedTopGap = coerceNumberProperty(value, 0);
    }
    get fixedTopGap() {
        return this._fixedTopGap;
    }
    /** Pixels of empty space at the bottom of the viewport (for fixed footers). */
    set fixedBottomGap(value) {
        this._fixedBottomGap = coerceNumberProperty(value, 0);
    }
    get fixedBottomGap() {
        return this._fixedBottomGap;
    }
    /**
     * When true (default), pressing `Escape` while the side-nav is opened in
     * mobile/over mode will close it. Mirrors `MatSidenav.disableClose` (inverted).
     */
    set disableClose(value) {
        this._disableClose = coerceBooleanProperty(value);
    }
    get disableClose() {
        return this._disableClose;
    }
    get fillViewportClass() {
        return this._fillViewport;
    }
    get fixedClass() {
        return this._fixedInViewport;
    }
    get topGapVar() {
        return this._fixedInViewport ? `${this._fixedTopGap}px` : null;
    }
    get bottomGapVar() {
        return this._fixedInViewport ? `${this._fixedBottomGap}px` : null;
    }
    get backgroundStyle() {
        return this.backgroundColor ?? null;
    }
    constructor(navContainerService) {
        this.navContainerService = navContainerService;
        this._fillViewport = false;
        this._fixedInViewport = false;
        this._fixedTopGap = 0;
        this._fixedBottomGap = 0;
        this._disableClose = false;
    }
    /** Close the side-nav with `Escape` (unless `[disableClose]="true"`). */
    handleEscape(event) {
        if (this._disableClose || !this.navContainerService) {
            return;
        }
        if (this.navContainerService.getState()) {
            this.navContainerService.close();
            event.stopPropagation();
        }
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.2", ngImport: i0, type: CGINavContainerBrandComponent, deps: [{ token: CGINavContainerService, optional: true }], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "20.3.2", type: CGINavContainerBrandComponent, isStandalone: false, selector: "cgi-nav-container", inputs: { fillViewport: "fillViewport", fixedInViewport: "fixedInViewport", fixedTopGap: "fixedTopGap", fixedBottomGap: "fixedBottomGap", backgroundColor: "backgroundColor", disableClose: "disableClose" }, host: { listeners: { "keydown.escape": "handleEscape($event)" }, properties: { "class.cgi-nav-container--fill-viewport": "this.fillViewportClass", "class.cgi-nav-container--fixed": "this.fixedClass", "style.--cgi-nav-container-top-gap": "this.topGapVar", "style.--cgi-nav-container-bottom-gap": "this.bottomGapVar", "style.background": "this.backgroundStyle" } }, ngImport: i0, template: "<ng-content></ng-content>\n", styles: [":host{-ms-flex:1 1 auto;-webkit-box-flex:1;box-sizing:border-box;display:flex;display:-webkit-box;display:-ms-flexbox;flex:1 1 auto;flex-direction:column;height:auto;min-height:0;overflow:hidden;position:relative;width:100%}:host(:only-child){height:100%;min-height:100%}:host(.cgi-nav-container--fill-viewport){height:100vh;height:100dvh;min-height:100vh;min-height:100dvh}:host(.cgi-nav-container--fixed){position:fixed;top:var(--cgi-nav-container-top-gap, 0);bottom:var(--cgi-nav-container-bottom-gap, 0);left:0;right:0;height:auto}\n"], changeDetection: i0.ChangeDetectionStrategy.OnPush }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.2", ngImport: i0, type: CGINavContainerBrandComponent, decorators: [{
            type: Component,
            args: [{ selector: 'cgi-nav-container', standalone: false, changeDetection: ChangeDetectionStrategy.OnPush, template: "<ng-content></ng-content>\n", styles: [":host{-ms-flex:1 1 auto;-webkit-box-flex:1;box-sizing:border-box;display:flex;display:-webkit-box;display:-ms-flexbox;flex:1 1 auto;flex-direction:column;height:auto;min-height:0;overflow:hidden;position:relative;width:100%}:host(:only-child){height:100%;min-height:100%}:host(.cgi-nav-container--fill-viewport){height:100vh;height:100dvh;min-height:100vh;min-height:100dvh}:host(.cgi-nav-container--fixed){position:fixed;top:var(--cgi-nav-container-top-gap, 0);bottom:var(--cgi-nav-container-bottom-gap, 0);left:0;right:0;height:auto}\n"] }]
        }], ctorParameters: () => [{ type: CGINavContainerService, decorators: [{
                    type: Optional
                }] }], propDecorators: { fillViewport: [{
                type: Input
            }], fixedInViewport: [{
                type: Input
            }], fixedTopGap: [{
                type: Input
            }], fixedBottomGap: [{
                type: Input
            }], backgroundColor: [{
                type: Input
            }], disableClose: [{
                type: Input
            }], fillViewportClass: [{
                type: HostBinding,
                args: ['class.cgi-nav-container--fill-viewport']
            }], fixedClass: [{
                type: HostBinding,
                args: ['class.cgi-nav-container--fixed']
            }], topGapVar: [{
                type: HostBinding,
                args: ['style.--cgi-nav-container-top-gap']
            }], bottomGapVar: [{
                type: HostBinding,
                args: ['style.--cgi-nav-container-bottom-gap']
            }], backgroundStyle: [{
                type: HostBinding,
                args: ['style.background']
            }], handleEscape: [{
                type: HostListener,
                args: ['keydown.escape', ['$event']]
            }] } });

/**
 * Content host that sits next to `cgi-side-nav` inside `cgi-nav-container`.
 * Responsibilities:
 *  - Provides the projection slot for application content.
 *  - Scrolls back to the top of the projected content on route changes.
 *  - Closes the side nav when the mobile backdrop is clicked.
 */
class CGINavContentBrandComponent {
    constructor(renderer, elRef, navContainerService, router, document) {
        this.renderer = renderer;
        this.elRef = elRef;
        this.navContainerService = navContainerService;
        this.router = router;
        this.document = document;
        /** Boolean variable to set the container class="cgi-nav-content" */
        this.isClassContainer = true;
        /** Notifier used to tear down subscriptions on destroy. */
        this.destroy$ = new Subject();
        this.scrollToTop = this.router.events.pipe(filter((event) => event instanceof NavigationEnd));
    }
    ngOnInit() {
        this.scrollToTop.pipe(takeUntil(this.destroy$)).subscribe(() => this.scrollContentToTop());
    }
    ngOnDestroy() {
        this.destroy$.next();
        this.destroy$.complete();
    }
    /** Close navigation when backdrop is clicked, only available on mobile view. */
    closeNav() {
        this.navContainerService.toggle(false);
        if (!this.navContainerService.getState()) {
            const parent = this.elRef.nativeElement.parentElement;
            if (parent) {
                this.renderer.removeClass(parent, 'cgi-side-nav--opened');
            }
        }
    }
    /**
     * Resets the scroll position of the content host on route change.
     *
     * Important: we use `scrollTo({ top: 0 })` on the host element rather than
     * `Element.scrollIntoView()` on a child, because `scrollIntoView` scrolls
     * EVERY scrollable ancestor (including `window`/the iframe). That caused
     * the page to jump and the top nav to slide out of view on every click.
     */
    scrollContentToTop() {
        const host = this.elRef.nativeElement;
        if (typeof host.scrollTo === 'function') {
            host.scrollTo({ top: 0, left: 0 });
        }
        else {
            host.scrollTop = 0;
            host.scrollLeft = 0;
        }
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.2", ngImport: i0, type: CGINavContentBrandComponent, deps: [{ token: i0.Renderer2 }, { token: i0.ElementRef }, { token: CGINavContainerService }, { token: i2.Router }, { token: DOCUMENT }], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "20.3.2", type: CGINavContentBrandComponent, isStandalone: false, selector: "cgi-nav-content", host: { properties: { "class.cgi-nav-content": "this.isClassContainer" } }, ngImport: i0, template: "<div\n  class=\"cgi-nav-content__backdrop\"\n  role=\"button\"\n  tabindex=\"-1\"\n  aria-label=\"Close navigation\"\n  (click)=\"closeNav()\"\n  (keyup.enter)=\"closeNav()\"\n></div>\n<div id=\"before-content\" tabindex=\"-1\"></div>\n<ng-content></ng-content>\n", styles: [":host{display:block;height:100%;left:0;margin-left:0rem;overflow-x:hidden;overflow-y:auto;padding:0;position:absolute;right:0;transition:margin-left .2s cubic-bezier(.25,.8,.25,1);z-index:1}.cgi-side-nav--opened :host{margin-left:18rem}:has(.cgi-side-nav--mode-over)>:host{margin-left:0}:has(.cgi-side-nav--mode-side)>:host{margin-left:18rem}:host .cgi-nav-content__backdrop{display:block;height:100%;inset:0;position:absolute;visibility:hidden;width:100%;z-index:2}:has(.cgi-side-nav--mode-over.cgi-side-nav--opened)>:host .cgi-nav-content__backdrop{background-color:#00000052;transition:background-color .4s cubic-bezier(.25,.8,.25,1);visibility:visible}@media (max-width: 599px){:host{margin-left:0}.cgi-side-nav--opened :host{margin-left:0;overflow:hidden}.cgi-side-nav--opened :host .cgi-nav-content__backdrop{transition:background-color .4s cubic-bezier(.25,.8,.25,1);visibility:visible}}\n"], changeDetection: i0.ChangeDetectionStrategy.OnPush }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.2", ngImport: i0, type: CGINavContentBrandComponent, decorators: [{
            type: Component,
            args: [{ selector: 'cgi-nav-content', standalone: false, changeDetection: ChangeDetectionStrategy.OnPush, template: "<div\n  class=\"cgi-nav-content__backdrop\"\n  role=\"button\"\n  tabindex=\"-1\"\n  aria-label=\"Close navigation\"\n  (click)=\"closeNav()\"\n  (keyup.enter)=\"closeNav()\"\n></div>\n<div id=\"before-content\" tabindex=\"-1\"></div>\n<ng-content></ng-content>\n", styles: [":host{display:block;height:100%;left:0;margin-left:0rem;overflow-x:hidden;overflow-y:auto;padding:0;position:absolute;right:0;transition:margin-left .2s cubic-bezier(.25,.8,.25,1);z-index:1}.cgi-side-nav--opened :host{margin-left:18rem}:has(.cgi-side-nav--mode-over)>:host{margin-left:0}:has(.cgi-side-nav--mode-side)>:host{margin-left:18rem}:host .cgi-nav-content__backdrop{display:block;height:100%;inset:0;position:absolute;visibility:hidden;width:100%;z-index:2}:has(.cgi-side-nav--mode-over.cgi-side-nav--opened)>:host .cgi-nav-content__backdrop{background-color:#00000052;transition:background-color .4s cubic-bezier(.25,.8,.25,1);visibility:visible}@media (max-width: 599px){:host{margin-left:0}.cgi-side-nav--opened :host{margin-left:0;overflow:hidden}.cgi-side-nav--opened :host .cgi-nav-content__backdrop{transition:background-color .4s cubic-bezier(.25,.8,.25,1);visibility:visible}}\n"] }]
        }], ctorParameters: () => [{ type: i0.Renderer2 }, { type: i0.ElementRef }, { type: CGINavContainerService }, { type: i2.Router }, { type: Document, decorators: [{
                    type: Inject,
                    args: [DOCUMENT]
                }] }], propDecorators: { isClassContainer: [{
                type: HostBinding,
                args: ['class.cgi-nav-content']
            }] } });

/** Delay (ms) before moving focus to the main content region. */
const FOCUS_DELAY_MS = 200;
/**
 * Side navigation item component.
 *
 * Recursive renderer for `SideNavBrandItem` trees. Design supports up to
 * three levels of nesting; deeper structures are rendered but not styled.
 */
class CGISideNavItemBrandComponent {
    constructor(navContainerService, _document, router) {
        this.navContainerService = navContainerService;
        this._document = _document;
        this.router = router;
        /** Whether the parent side-nav is opened. */
        this.isOpened = false;
        /** Current nesting level (0-based at the root, incremented for children). */
        this.level = 0;
        /** Notifier used to tear down subscriptions on destroy. */
        this.destroy$ = new Subject();
    }
    /** Subscribe to navContainerService boolean value as one true source of state. */
    ngOnInit() {
        this.level++;
        this.navContainerService.changes.pipe(takeUntil(this.destroy$)).subscribe((res) => {
            this.isOpened = res;
        });
    }
    /** Cleanup subscriptions. */
    ngOnDestroy() {
        this.destroy$.next();
        this.destroy$.complete();
    }
    /** Move focus to the main content region after a short delay. */
    focusToContent() {
        setTimeout(() => {
            const dummyContentElement = this._document.querySelector('#before-content');
            dummyContentElement?.focus();
        }, FOCUS_DELAY_MS);
    }
    /** Programmatic router navigation used to make mat-expansion-panel headers keyboard-activatable. */
    goToLink(url) {
        if (!url) {
            return;
        }
        this.router.navigate([url]);
        this.focusToContent();
    }
    /** Wraps a single item in an array; returns an empty array for nullish input. */
    convertArray(input) {
        return input ? [input] : [];
    }
    /** Stable identity for *ngFor to avoid re-rendering on reference changes. */
    trackByLink(_index, item) {
        return item?.link ?? _index;
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.2", ngImport: i0, type: CGISideNavItemBrandComponent, deps: [{ token: CGINavContainerService }, { token: DOCUMENT }, { token: i2.Router }], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "20.3.2", type: CGISideNavItemBrandComponent, isStandalone: false, selector: "cgi-side-nav-item", inputs: { links: "links", level: "level" }, ngImport: i0, template: "<mat-accordion [hidden]=\"!isOpened\" class=\"cgi-sidenav-item_{{ level }}\">\n  <ng-container *ngFor=\"let link of links; let k = index; trackBy: trackByLink\">\n    <div *ngIf=\"!link.subsection\" class=\"cgi-sidenav-item_single-link\">\n      <a\n        routerLinkActive=\"active\"\n        [routerLinkActiveOptions]=\"{ exact: true }\"\n        routerLink=\"{{ link.link }}\"\n        [queryParams]=\"link.queryParams\"\n        [state]=\"link.state\"\n        [attr.aria-label]=\"link.text\"\n        (click)=\"focusToContent()\"\n        (keydown.enter)=\"goToLink(link.link)\"\n      >\n        <mat-icon *ngIf=\"link.icon\" class=\"material-symbols-outlined\" aria-hidden=\"true\">{{\n          link.icon\n          }}</mat-icon>\n        <h5 class=\"cgi-display-5\">{{ link.text }}</h5>\n      </a>\n    </div>\n    <mat-expansion-panel *ngIf=\"link.subsection\">\n      <mat-expansion-panel-header expandedHeight=\"64px\" collapsedHeight=\"64px\" [attr.aria-label]=\"link.text\">\n        <mat-panel-title style=\"margin-right: 10px\">\n          <a>\n            <mat-icon *ngIf=\"link.icon\" class=\"material-symbols-outlined\" aria-hidden=\"true\">{{\n              link.icon\n              }}</mat-icon>\n            <h5 class=\"cgi-display-5 mb-0\">{{ link.text }}</h5>\n          </a>\n        </mat-panel-title>\n      </mat-expansion-panel-header>\n\n      <div *ngFor=\"let childLink of link.subsection; let j = index; trackBy: trackByLink\">\n        <a\n          class=\"cgi-side-nav__sublink\"\n          *ngIf=\"!childLink.subsection\"\n          (click)=\"focusToContent()\"\n          routerLinkActive=\"active\"\n          [routerLinkActiveOptions]=\"{ exact: true }\"\n          routerLink=\"{{ childLink.link }}\"\n          [queryParams]=\"childLink.queryParams\"\n          [state]=\"childLink.state\"\n          [attr.aria-label]=\"childLink.text\"\n        >\n          <p class=\"cgi-body-2\">{{ childLink.text }}</p>\n        </a>\n\n        <cgi-side-nav-item\n          *ngIf=\"childLink.subsection\"\n          [links]=\"convertArray(childLink)\"\n          [level]=\"level\"\n        >\n        </cgi-side-nav-item>\n      </div>\n    </mat-expansion-panel>\n  </ng-container>\n</mat-accordion>\n\n<ul *ngIf=\"!isOpened\">\n  <li *ngFor=\"let link of links; let i = index; trackBy: trackByLink\">\n    <a\n      routerLinkActive=\"active\"\n      [routerLinkActiveOptions]=\"{ exact: true }\"\n      routerLink=\"{{ link.link }}\"\n      [queryParams]=\"link.queryParams\"\n      [state]=\"link.state\"\n      [title]=\"link.text || 'index of ' + i\"\n      [attr.aria-label]=\"link.text\"\n      (click)=\"focusToContent()\"\n    >\n    </a>\n  </li>\n</ul>\n", styles: [":host .mat-accordion .cgi-display-5{color:#333}:host ::ng-deep a>mat-icon,:host ::ng-deep a>h5.cgi-display-5{transition:opacity .25s cubic-bezier(.25,.8,.25,1),transform .25s cubic-bezier(.25,.8,.25,1)}:host-context(.cgi-side-nav):not(.cgi-side-nav--opened) ::ng-deep a>mat-icon,:host-context(.cgi-side-nav):not(.cgi-side-nav--opened) ::ng-deep a>h5.cgi-display-5{opacity:0;transform:translate(-16px);pointer-events:none}:host-context(.cgi-side-nav.cgi-side-nav--opened) ::ng-deep a>mat-icon,:host-context(.cgi-side-nav.cgi-side-nav--opened) ::ng-deep a>h5.cgi-display-5{opacity:1;transform:translate(0);pointer-events:auto}\n"], dependencies: [{ kind: "directive", type: i1.NgForOf, selector: "[ngFor][ngForOf]", inputs: ["ngForOf", "ngForTrackBy", "ngForTemplate"] }, { kind: "directive", type: i1.NgIf, selector: "[ngIf]", inputs: ["ngIf", "ngIfThen", "ngIfElse"] }, { kind: "directive", type: i4$2.MatAccordion, selector: "mat-accordion", inputs: ["hideToggle", "displayMode", "togglePosition"], exportAs: ["matAccordion"] }, { kind: "component", type: i4$2.MatExpansionPanel, selector: "mat-expansion-panel", inputs: ["hideToggle", "togglePosition"], outputs: ["afterExpand", "afterCollapse"], exportAs: ["matExpansionPanel"] }, { kind: "component", type: i4$2.MatExpansionPanelHeader, selector: "mat-expansion-panel-header", inputs: ["expandedHeight", "collapsedHeight", "tabIndex"] }, { kind: "directive", type: i4$2.MatExpansionPanelTitle, selector: "mat-panel-title" }, { kind: "component", type: i5.MatIcon, selector: "mat-icon", inputs: ["color", "inline", "svgIcon", "fontSet", "fontIcon"], exportAs: ["matIcon"] }, { kind: "directive", type: i2.RouterLink, selector: "[routerLink]", inputs: ["target", "queryParams", "fragment", "queryParamsHandling", "state", "info", "relativeTo", "preserveFragment", "skipLocationChange", "replaceUrl", "routerLink"] }, { kind: "directive", type: i2.RouterLinkActive, selector: "[routerLinkActive]", inputs: ["routerLinkActiveOptions", "ariaCurrentWhenActive", "routerLinkActive"], outputs: ["isActiveChange"], exportAs: ["routerLinkActive"] }, { kind: "component", type: CGISideNavItemBrandComponent, selector: "cgi-side-nav-item", inputs: ["links", "level"] }], changeDetection: i0.ChangeDetectionStrategy.OnPush }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.2", ngImport: i0, type: CGISideNavItemBrandComponent, decorators: [{
            type: Component,
            args: [{ selector: 'cgi-side-nav-item', standalone: false, changeDetection: ChangeDetectionStrategy.OnPush, template: "<mat-accordion [hidden]=\"!isOpened\" class=\"cgi-sidenav-item_{{ level }}\">\n  <ng-container *ngFor=\"let link of links; let k = index; trackBy: trackByLink\">\n    <div *ngIf=\"!link.subsection\" class=\"cgi-sidenav-item_single-link\">\n      <a\n        routerLinkActive=\"active\"\n        [routerLinkActiveOptions]=\"{ exact: true }\"\n        routerLink=\"{{ link.link }}\"\n        [queryParams]=\"link.queryParams\"\n        [state]=\"link.state\"\n        [attr.aria-label]=\"link.text\"\n        (click)=\"focusToContent()\"\n        (keydown.enter)=\"goToLink(link.link)\"\n      >\n        <mat-icon *ngIf=\"link.icon\" class=\"material-symbols-outlined\" aria-hidden=\"true\">{{\n          link.icon\n          }}</mat-icon>\n        <h5 class=\"cgi-display-5\">{{ link.text }}</h5>\n      </a>\n    </div>\n    <mat-expansion-panel *ngIf=\"link.subsection\">\n      <mat-expansion-panel-header expandedHeight=\"64px\" collapsedHeight=\"64px\" [attr.aria-label]=\"link.text\">\n        <mat-panel-title style=\"margin-right: 10px\">\n          <a>\n            <mat-icon *ngIf=\"link.icon\" class=\"material-symbols-outlined\" aria-hidden=\"true\">{{\n              link.icon\n              }}</mat-icon>\n            <h5 class=\"cgi-display-5 mb-0\">{{ link.text }}</h5>\n          </a>\n        </mat-panel-title>\n      </mat-expansion-panel-header>\n\n      <div *ngFor=\"let childLink of link.subsection; let j = index; trackBy: trackByLink\">\n        <a\n          class=\"cgi-side-nav__sublink\"\n          *ngIf=\"!childLink.subsection\"\n          (click)=\"focusToContent()\"\n          routerLinkActive=\"active\"\n          [routerLinkActiveOptions]=\"{ exact: true }\"\n          routerLink=\"{{ childLink.link }}\"\n          [queryParams]=\"childLink.queryParams\"\n          [state]=\"childLink.state\"\n          [attr.aria-label]=\"childLink.text\"\n        >\n          <p class=\"cgi-body-2\">{{ childLink.text }}</p>\n        </a>\n\n        <cgi-side-nav-item\n          *ngIf=\"childLink.subsection\"\n          [links]=\"convertArray(childLink)\"\n          [level]=\"level\"\n        >\n        </cgi-side-nav-item>\n      </div>\n    </mat-expansion-panel>\n  </ng-container>\n</mat-accordion>\n\n<ul *ngIf=\"!isOpened\">\n  <li *ngFor=\"let link of links; let i = index; trackBy: trackByLink\">\n    <a\n      routerLinkActive=\"active\"\n      [routerLinkActiveOptions]=\"{ exact: true }\"\n      routerLink=\"{{ link.link }}\"\n      [queryParams]=\"link.queryParams\"\n      [state]=\"link.state\"\n      [title]=\"link.text || 'index of ' + i\"\n      [attr.aria-label]=\"link.text\"\n      (click)=\"focusToContent()\"\n    >\n    </a>\n  </li>\n</ul>\n", styles: [":host .mat-accordion .cgi-display-5{color:#333}:host ::ng-deep a>mat-icon,:host ::ng-deep a>h5.cgi-display-5{transition:opacity .25s cubic-bezier(.25,.8,.25,1),transform .25s cubic-bezier(.25,.8,.25,1)}:host-context(.cgi-side-nav):not(.cgi-side-nav--opened) ::ng-deep a>mat-icon,:host-context(.cgi-side-nav):not(.cgi-side-nav--opened) ::ng-deep a>h5.cgi-display-5{opacity:0;transform:translate(-16px);pointer-events:none}:host-context(.cgi-side-nav.cgi-side-nav--opened) ::ng-deep a>mat-icon,:host-context(.cgi-side-nav.cgi-side-nav--opened) ::ng-deep a>h5.cgi-display-5{opacity:1;transform:translate(0);pointer-events:auto}\n"] }]
        }], ctorParameters: () => [{ type: CGINavContainerService }, { type: Document, decorators: [{
                    type: Inject,
                    args: [DOCUMENT]
                }] }, { type: i2.Router }], propDecorators: { links: [{
                type: Input
            }], level: [{
                type: Input
            }] } });

/**
 * Side navigation component.
 *
 * Renders a collapsible vertical navigation rail. State (opened/closed) is
 * coordinated through `CGINavContainerService` so siblings (top-nav, content,
 * footer) react consistently.
 *
 * Features:
 *  - Two-way binding via `[(opened)]` (use `openedChange` output).
 *  - Configurable `mobileBreakpoint` and `hoverDelay` for tuning per app.
 *  - SSR-safe (no `window` access during server rendering).
 *  - `OnPush` change detection.
 */
class CGISideNavBrandComponent {
    get modeRailClass() {
        return this._mode === 'rail';
    }
    get modeSideClass() {
        return this._mode === 'side';
    }
    get modeOverClass() {
        return this._mode === 'over';
    }
    /**
     * Display mode (`rail` | `side` | `over`). Defaults to `rail` to preserve
     * legacy behaviour. `side` disables hover-to-peek and keeps the nav open.
     * `over` overlays content with a backdrop (the existing `cgi-nav-content`
     * backdrop already renders in mobile/over states).
     */
    set mode(value) {
        const previous = this._mode;
        this._mode = value || 'rail';
        // When switching INTO side mode, force the nav fully opened so
        // labels/width are correct. When switching OUT of side mode, leave
        // the state alone so consumers can collapse via the menu toggle.
        if (this._mode === 'side' && previous !== 'side' && this.navContainerService) {
            this.navContainerService.toggle(true);
        }
    }
    get mode() {
        return this._mode;
    }
    /** When true, disables hover-to-open behaviour. Auto-true for `side` mode. */
    set disableHover(value) {
        this._disableHover = coerceBooleanProperty(value);
    }
    get disableHover() {
        return this._disableHover || this._mode === 'side';
    }
    constructor(renderer, elRef, navContainerService, platformId) {
        this.renderer = renderer;
        this.elRef = elRef;
        this.navContainerService = navContainerService;
        /** Boolean variable to set the container class="cgi-side-nav" */
        this.isClassContainer = true;
        /** Accessible label for the navigation landmark. */
        this.ariaLabel = 'Primary navigation';
        /** Pixel width below which the nav switches to "mobile" behaviour. */
        this.mobileBreakpoint = 599;
        /** Delay (ms) before opening the panel on hover. */
        this.hoverDelay = 350;
        this._mode = 'rail';
        this._disableHover = false;
        /** Emits whenever the opened state changes (supports `[(opened)]`). */
        this.openedChange = new EventEmitter();
        /** Current opened state. */
        this._open = false;
        /** Hovered state. */
        this._mouseOver = false;
        /** True when viewport is at or below mobile width. */
        this.mobileView = false;
        /** Pending hover-open timer. */
        this.timerSub = null;
        /** Notifier for cleaning up subscriptions. */
        this.destroy$ = new Subject();
        /** CSS class toggled on the parent container when the nav is opened. */
        this.PUSH_CLASS = 'cgi-side-nav--opened';
        /** An id for targeting the left nav. */
        this.leftNavId = "left-nav" /* PageLandmarks.LEFT_NAV */;
        this.isBrowser = isPlatformBrowser(platformId);
        if (this.isBrowser) {
            const initial$ = of(window.innerWidth <= this.mobileBreakpoint);
            const resize$ = fromEvent(window, 'resize').pipe(map(() => window.innerWidth <= this.mobileBreakpoint));
            this.mobile$ = merge(initial$, resize$).pipe(distinctUntilChanged());
        }
        else {
            this.mobile$ = of(false);
        }
    }
    /**
     * Subscribe to navContainerService boolean value as one true source of state.
     * Also closes open navigation panel when screen resized to mobile view.
     */
    ngOnInit() {
        // In `side` mode the nav stays open and never collapses on hover.
        if (this._mode === 'side') {
            this.navContainerService.toggle(true);
        }
        this.navContainerService.changes.pipe(takeUntil(this.destroy$)).subscribe((res) => {
            // In `side` mode the nav stays open regardless of external toggle
            // sources (e.g. top-nav menu button). If something flipped it to
            // closed, snap it back to open.
            if (this._mode === 'side' && !res) {
                this.navContainerService.toggle(true);
                return;
            }
            const previous = this._open;
            this._open = res;
            const parent = this.elRef.nativeElement.parentElement;
            if (parent) {
                if (res && !this._mouseOver && !parent.classList.contains(this.PUSH_CLASS)) {
                    this.renderer.addClass(parent, this.PUSH_CLASS);
                }
                else if (!res) {
                    this.renderer.removeClass(parent, this.PUSH_CLASS);
                }
            }
            if (previous !== res) {
                this.openedChange.emit(res);
            }
        });
        this.mobile$.pipe(takeUntil(this.destroy$)).subscribe((isMobile) => {
            this.mobileView = isMobile;
            if (isMobile) {
                this.closeOnMobile();
            }
        });
    }
    /** Cleanup all subscriptions. */
    ngOnDestroy() {
        this.cancelHoverTimer();
        this.destroy$.next();
        this.destroy$.complete();
    }
    /** Listener for MouseEnter. */
    mouseEnter() {
        if (this.disableHover) {
            return;
        }
        const parent = this.elRef.nativeElement.parentElement;
        if (parent?.classList.contains(this.PUSH_CLASS) || this._mouseOver) {
            return;
        }
        this._mouseOver = true;
        this.cancelHoverTimer();
        this.timerSub = new Subscription();
        const handle = setTimeout(() => this.open(), this.hoverDelay);
        this.timerSub.add(() => clearTimeout(handle));
    }
    /** Listener for MouseLeave. */
    mouseLeave() {
        if (this.disableHover) {
            return;
        }
        const parent = this.elRef.nativeElement.parentElement;
        if (parent?.classList.contains(this.PUSH_CLASS)) {
            return;
        }
        this.close();
        this.cancelHoverTimer();
        this._mouseOver = false;
    }
    /** Getter to determine whether or not to add opened class to host component. */
    get isOpened() {
        return this._open;
    }
    /** Provide option to set whether sidenav is opened or closed on initialization.  */
    set opened(value) {
        // Need to use boolean converter for undefined values, otherwise, will default to string.
        this.navContainerService.toggle(coerceBooleanProperty(value));
    }
    get opened() {
        return this._open;
    }
    /** Open this sidenav. */
    open() {
        this.toggle(true);
    }
    /** Close this sidenav. */
    close() {
        this.toggle(false);
    }
    /** Close this sidenav only when in mobile view. */
    closeOnMobile() {
        if (!this.mobileView) {
            return;
        }
        this.navContainerService.toggle(false);
        const parent = this.elRef.nativeElement.parentElement;
        if (parent) {
            this.renderer.removeClass(parent, this.PUSH_CLASS);
        }
    }
    /**
     * Toggle this sidenav. Equivalent to `open()` when closed and `close()` when opened.
     * In `side` mode the nav is pinned open — toggle calls are ignored to
     * prevent the layout from collapsing into a half-rendered rail.
     * @param isOpen Whether the sidenav should be open. Defaults to inverse of current state.
     */
    toggle(isOpen = !this._open) {
        if (this._mode === 'side') {
            // Side mode is always open; ignore any attempt to close it.
            this.navContainerService.toggle(true);
            return;
        }
        this.navContainerService.toggle(isOpen);
    }
    /** Cancels any pending hover-open timer. */
    cancelHoverTimer() {
        if (this.timerSub) {
            this.timerSub.unsubscribe();
            this.timerSub = null;
        }
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.2", ngImport: i0, type: CGISideNavBrandComponent, deps: [{ token: i0.Renderer2 }, { token: i0.ElementRef }, { token: CGINavContainerService }, { token: PLATFORM_ID }], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "20.3.2", type: CGISideNavBrandComponent, isStandalone: false, selector: "cgi-side-nav", inputs: { links: "links", ariaLabel: "ariaLabel", mobileBreakpoint: "mobileBreakpoint", hoverDelay: "hoverDelay", mode: "mode", disableHover: "disableHover", opened: "opened" }, outputs: { openedChange: "openedChange" }, host: { attributes: { "role": "navigation" }, listeners: { "mouseenter": "mouseEnter()", "mouseleave": "mouseLeave()" }, properties: { "attr.aria-label": "ariaLabel", "attr.aria-expanded": "isOpened", "class.cgi-side-nav": "this.isClassContainer", "class.cgi-side-nav--mode-rail": "this.modeRailClass", "class.cgi-side-nav--mode-side": "this.modeSideClass", "class.cgi-side-nav--mode-over": "this.modeOverClass", "class.cgi-side-nav--opened": "this.isOpened" } }, ngImport: i0, template: "<aside>\n  <cgi-side-nav-item [links]=\"links\" [level]=\"0\" [attr.id]=\"leftNavId\"></cgi-side-nav-item>\n</aside>\n<ng-content select=\"[cgiSideNavFooter]\"></ng-content>\n", styles: [".cgi-vertical-spacer-1{height:2rem;width:100%}.cgi-vertical-spacer-2{height:4rem;width:100%}.cgi-vertical-spacer-3{height:6rem;width:100%}.cgi-vertical-spacer-4{height:8rem;width:100%}.cgi-vertical-spacer-5{height:10rem;width:100%}.cgi-vertical-spacer-6{height:12rem;width:100%}.cgi-vertical-spacer-7{height:14rem;width:100%}.cgi-vertical-spacer-8{height:16rem;width:100%}.cgi-vertical-spacer-9{height:18rem;width:100%}.cgi-vertical-spacer-10{height:20rem;width:100%}:host(.cgi-side-nav.cgi-side-nav--mode-side){width:18rem!important}:host(.cgi-side-nav--mode-side) ::ng-deep ul>li>a>span,:host(.cgi-side-nav--mode-side) ::ng-deep .cgi-side-nav__title{font-size:inherit!important;opacity:1!important;visibility:visible!important}:host(.cgi-side-nav--mode-side) ::ng-deep .mat-expansion-panel{min-width:18rem}:host(.cgi-side-nav.cgi-side-nav--mode-over){box-shadow:0 8px 24px #0000002e;z-index:11}:host(.cgi-side-nav){bottom:0;box-shadow:none;box-sizing:border-box;display:flex;flex-direction:column;height:100%;outline:0;overflow:hidden;position:absolute;top:0;transition:all .3s cubic-bezier(.25,.8,.25,1);width:0rem;z-index:9}:host(.cgi-side-nav) aside{flex:1 1 auto;overflow-y:auto;overflow-x:hidden;min-height:0;padding-bottom:8px}:host(.cgi-side-nav).cgi-side-nav--shadow{box-shadow:0 1px 25px #0003}:host(.cgi-side-nav) .mat-icon{color:#3d4f68;display:block;float:left;font-size:16px;height:inherit;line-height:50px;margin-left:18px;margin-right:18px;text-align:center;width:20px}@media (max-width: 599px){:host(.cgi-side-nav){box-shadow:none;transform:translate3d(-100%,0,0);transition:transform .3s cubic-bezier(.25,.8,.25,1);width:18rem}}:host(.cgi-side-nav).cgi-side-nav--opened{width:18rem}@media (max-width: 599px){:host(.cgi-side-nav).cgi-side-nav--opened{box-shadow:3px 0 6px #0000003d;transform:translateZ(0)}}:host(.cgi-side-nav--opened)::ng-deep ul>li a>span,:host(.cgi-side-nav--opened)::ng-deep ul>li .cgi-side-nav__title{font-size:inherit;opacity:1;visibility:visible}:host(.cgi-side-nav--opened)::ng-deep .mat-expansion-panel{box-shadow:none!important;border-radius:0!important;margin:0;min-width:18rem}:host(.cgi-side-nav--opened)::ng-deep .mat-expansion-panel a{text-decoration:none}:host(.cgi-side-nav--opened)::ng-deep .mat-expansion-panel a span{line-height:50px}:host(.cgi-side-nav--opened)::ng-deep .mat-expansion-panel a.active{border-left:4px solid;font-weight:700}:host(.cgi-side-nav--opened)::ng-deep .mat-expansion-panel .mat-expansion-panel-header{font-size:15px;font-weight:400;min-height:50px;padding:0 20px 0 0}:host(.cgi-side-nav--opened)::ng-deep .mat-expansion-panel .mat-expansion-panel-body{padding:0}:host(.cgi-side-nav--opened)::ng-deep .mat-expansion-panel .mat-expansion-panel-body .cgi-side-nav__sublink{display:block;height:48px;line-height:48px;text-indent:55px}:host(.cgi-side-nav--opened)::ng-deep .mat-expansion-panel .mat-action-row{border-top-width:0!important;padding:8px 20px 16px!important}:host(.cgi-side-nav--opened)::ng-deep .mat-expansion-panel .mat-action-row .mat-mdc-button,:host(.cgi-side-nav--opened)::ng-deep .mat-expansion-panel .mat-action-row .mat-mdc-raised-button{margin:0 4px!important}:host(.cgi-side-nav--opened)::ng-deep .mat-expansion-panel .mat-action-row .mat-mdc-button:first-child,:host(.cgi-side-nav--opened)::ng-deep .mat-expansion-panel .mat-action-row .mat-mdc-raised-button:first-child{margin-left:0!important;margin-right:0!important}:host::ng-deep .mat-icon{display:block;float:left;margin-right:18px;color:#333!important;text-align:center}:host ::ng-deep ul{list-style:none;margin:0;padding-left:0}:host ::ng-deep ul>li{height:50px;margin:0;padding:0}:host ::ng-deep ul>li>a{align-items:center;box-sizing:border-box;display:flex;font-size:16px;height:50px;line-height:50px;text-decoration:none}:host ::ng-deep ul>li>a>mat-icon,:host ::ng-deep ul>li>a .cgi-icon{margin-left:20px;margin-right:20px}:host ::ng-deep ul>li>a>span,:host ::ng-deep ul>li>a .cgi-side-nav__title{font-size:0;opacity:0;transition:opacity 1.2s ease-in-out;visibility:hidden}@media (max-width: 599px){:host ::ng-deep ul>li>a>span,:host ::ng-deep ul>li>a .cgi-side-nav__title{font-size:inherit;opacity:1;visibility:visible}}\n"], dependencies: [{ kind: "component", type: CGISideNavItemBrandComponent, selector: "cgi-side-nav-item", inputs: ["links", "level"] }], changeDetection: i0.ChangeDetectionStrategy.OnPush }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.2", ngImport: i0, type: CGISideNavBrandComponent, decorators: [{
            type: Component,
            args: [{ selector: 'cgi-side-nav', standalone: false, changeDetection: ChangeDetectionStrategy.OnPush, host: {
                        role: 'navigation',
                        '[attr.aria-label]': 'ariaLabel',
                        '[attr.aria-expanded]': 'isOpened',
                    }, template: "<aside>\n  <cgi-side-nav-item [links]=\"links\" [level]=\"0\" [attr.id]=\"leftNavId\"></cgi-side-nav-item>\n</aside>\n<ng-content select=\"[cgiSideNavFooter]\"></ng-content>\n", styles: [".cgi-vertical-spacer-1{height:2rem;width:100%}.cgi-vertical-spacer-2{height:4rem;width:100%}.cgi-vertical-spacer-3{height:6rem;width:100%}.cgi-vertical-spacer-4{height:8rem;width:100%}.cgi-vertical-spacer-5{height:10rem;width:100%}.cgi-vertical-spacer-6{height:12rem;width:100%}.cgi-vertical-spacer-7{height:14rem;width:100%}.cgi-vertical-spacer-8{height:16rem;width:100%}.cgi-vertical-spacer-9{height:18rem;width:100%}.cgi-vertical-spacer-10{height:20rem;width:100%}:host(.cgi-side-nav.cgi-side-nav--mode-side){width:18rem!important}:host(.cgi-side-nav--mode-side) ::ng-deep ul>li>a>span,:host(.cgi-side-nav--mode-side) ::ng-deep .cgi-side-nav__title{font-size:inherit!important;opacity:1!important;visibility:visible!important}:host(.cgi-side-nav--mode-side) ::ng-deep .mat-expansion-panel{min-width:18rem}:host(.cgi-side-nav.cgi-side-nav--mode-over){box-shadow:0 8px 24px #0000002e;z-index:11}:host(.cgi-side-nav){bottom:0;box-shadow:none;box-sizing:border-box;display:flex;flex-direction:column;height:100%;outline:0;overflow:hidden;position:absolute;top:0;transition:all .3s cubic-bezier(.25,.8,.25,1);width:0rem;z-index:9}:host(.cgi-side-nav) aside{flex:1 1 auto;overflow-y:auto;overflow-x:hidden;min-height:0;padding-bottom:8px}:host(.cgi-side-nav).cgi-side-nav--shadow{box-shadow:0 1px 25px #0003}:host(.cgi-side-nav) .mat-icon{color:#3d4f68;display:block;float:left;font-size:16px;height:inherit;line-height:50px;margin-left:18px;margin-right:18px;text-align:center;width:20px}@media (max-width: 599px){:host(.cgi-side-nav){box-shadow:none;transform:translate3d(-100%,0,0);transition:transform .3s cubic-bezier(.25,.8,.25,1);width:18rem}}:host(.cgi-side-nav).cgi-side-nav--opened{width:18rem}@media (max-width: 599px){:host(.cgi-side-nav).cgi-side-nav--opened{box-shadow:3px 0 6px #0000003d;transform:translateZ(0)}}:host(.cgi-side-nav--opened)::ng-deep ul>li a>span,:host(.cgi-side-nav--opened)::ng-deep ul>li .cgi-side-nav__title{font-size:inherit;opacity:1;visibility:visible}:host(.cgi-side-nav--opened)::ng-deep .mat-expansion-panel{box-shadow:none!important;border-radius:0!important;margin:0;min-width:18rem}:host(.cgi-side-nav--opened)::ng-deep .mat-expansion-panel a{text-decoration:none}:host(.cgi-side-nav--opened)::ng-deep .mat-expansion-panel a span{line-height:50px}:host(.cgi-side-nav--opened)::ng-deep .mat-expansion-panel a.active{border-left:4px solid;font-weight:700}:host(.cgi-side-nav--opened)::ng-deep .mat-expansion-panel .mat-expansion-panel-header{font-size:15px;font-weight:400;min-height:50px;padding:0 20px 0 0}:host(.cgi-side-nav--opened)::ng-deep .mat-expansion-panel .mat-expansion-panel-body{padding:0}:host(.cgi-side-nav--opened)::ng-deep .mat-expansion-panel .mat-expansion-panel-body .cgi-side-nav__sublink{display:block;height:48px;line-height:48px;text-indent:55px}:host(.cgi-side-nav--opened)::ng-deep .mat-expansion-panel .mat-action-row{border-top-width:0!important;padding:8px 20px 16px!important}:host(.cgi-side-nav--opened)::ng-deep .mat-expansion-panel .mat-action-row .mat-mdc-button,:host(.cgi-side-nav--opened)::ng-deep .mat-expansion-panel .mat-action-row .mat-mdc-raised-button{margin:0 4px!important}:host(.cgi-side-nav--opened)::ng-deep .mat-expansion-panel .mat-action-row .mat-mdc-button:first-child,:host(.cgi-side-nav--opened)::ng-deep .mat-expansion-panel .mat-action-row .mat-mdc-raised-button:first-child{margin-left:0!important;margin-right:0!important}:host::ng-deep .mat-icon{display:block;float:left;margin-right:18px;color:#333!important;text-align:center}:host ::ng-deep ul{list-style:none;margin:0;padding-left:0}:host ::ng-deep ul>li{height:50px;margin:0;padding:0}:host ::ng-deep ul>li>a{align-items:center;box-sizing:border-box;display:flex;font-size:16px;height:50px;line-height:50px;text-decoration:none}:host ::ng-deep ul>li>a>mat-icon,:host ::ng-deep ul>li>a .cgi-icon{margin-left:20px;margin-right:20px}:host ::ng-deep ul>li>a>span,:host ::ng-deep ul>li>a .cgi-side-nav__title{font-size:0;opacity:0;transition:opacity 1.2s ease-in-out;visibility:hidden}@media (max-width: 599px){:host ::ng-deep ul>li>a>span,:host ::ng-deep ul>li>a .cgi-side-nav__title{font-size:inherit;opacity:1;visibility:visible}}\n"] }]
        }], ctorParameters: () => [{ type: i0.Renderer2 }, { type: i0.ElementRef }, { type: CGINavContainerService }, { type: undefined, decorators: [{
                    type: Inject,
                    args: [PLATFORM_ID]
                }] }], propDecorators: { isClassContainer: [{
                type: HostBinding,
                args: ['class.cgi-side-nav']
            }], modeRailClass: [{
                type: HostBinding,
                args: ['class.cgi-side-nav--mode-rail']
            }], modeSideClass: [{
                type: HostBinding,
                args: ['class.cgi-side-nav--mode-side']
            }], modeOverClass: [{
                type: HostBinding,
                args: ['class.cgi-side-nav--mode-over']
            }], links: [{
                type: Input
            }], ariaLabel: [{
                type: Input
            }], mobileBreakpoint: [{
                type: Input
            }], hoverDelay: [{
                type: Input
            }], mode: [{
                type: Input
            }], disableHover: [{
                type: Input
            }], openedChange: [{
                type: Output
            }], mouseEnter: [{
                type: HostListener,
                args: ['mouseenter']
            }], mouseLeave: [{
                type: HostListener,
                args: ['mouseleave']
            }], isOpened: [{
                type: HostBinding,
                args: ['class.cgi-side-nav--opened']
            }], opened: [{
                type: Input
            }] } });

class CGINavContainerBrandModule {
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.2", ngImport: i0, type: CGINavContainerBrandModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule }); }
    static { this.ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "20.3.2", ngImport: i0, type: CGINavContainerBrandModule, declarations: [CGINavContainerBrandComponent,
            CGISideNavBrandComponent,
            CGISideNavItemBrandComponent,
            CGINavContentBrandComponent], imports: [CommonModule,
            MatToolbarModule,
            MatExpansionModule,
            MatButtonModule,
            MatIconModule,
            RouterModule], exports: [CGINavContainerBrandComponent,
            CGISideNavBrandComponent,
            CGISideNavItemBrandComponent,
            CGINavContentBrandComponent] }); }
    static { this.ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "20.3.2", ngImport: i0, type: CGINavContainerBrandModule, providers: [CGINavContainerService], imports: [CommonModule,
            MatToolbarModule,
            MatExpansionModule,
            MatButtonModule,
            MatIconModule,
            RouterModule] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.2", ngImport: i0, type: CGINavContainerBrandModule, decorators: [{
            type: NgModule,
            args: [{
                    imports: [
                        CommonModule,
                        MatToolbarModule,
                        MatExpansionModule,
                        MatButtonModule,
                        MatIconModule,
                        RouterModule,
                    ],
                    declarations: [
                        CGINavContainerBrandComponent,
                        CGISideNavBrandComponent,
                        CGISideNavItemBrandComponent,
                        CGINavContentBrandComponent,
                    ],
                    exports: [
                        CGINavContainerBrandComponent,
                        CGISideNavBrandComponent,
                        CGISideNavItemBrandComponent,
                        CGINavContentBrandComponent,
                    ],
                    providers: [CGINavContainerService],
                }]
        }] });

/**
 * Breadcrumbs component.
 *
 * TODO: How to use component and examples.
 */
class CGIBreadcrumbItemBrandComponent {
    /**
     * Empty constructor.
     */
    constructor() {
        this.isClassContainer = true;
    }
    /**
     * Set title property in component.
     */
    ngOnInit() { }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.2", ngImport: i0, type: CGIBreadcrumbItemBrandComponent, deps: [], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "20.3.2", type: CGIBreadcrumbItemBrandComponent, isStandalone: false, selector: "cgi-breadcrumb-item", host: { properties: { "class.cgi-breadcrumb-item": "this.isClassContainer" } }, ngImport: i0, template: "<ul>\n  <li>\n    <ng-content></ng-content>\n  </li>\n</ul>\n", styles: [":host(.cgi-breadcrumb-item) ::ng-deep li,:host(.cgi-breadcrumb-item) ::ng-deep ul{display:inline;padding:0}:host(.cgi-breadcrumb-item) ::ng-deep li a,:host(.cgi-breadcrumb-item) ::ng-deep ul a{font-size:14px;font-weight:400;display:inline}:host(.cgi-breadcrumb-item) ::ng-deep li a.cgi-link-body-underline-1:hover,:host(.cgi-breadcrumb-item) ::ng-deep ul a.cgi-link-body-underline-1:hover{color:#200a58}:host(.cgi-breadcrumb-item) ::ng-deep li a.cgi-link-body-1,:host(.cgi-breadcrumb-item) ::ng-deep ul a.cgi-link-body-1{color:#333}:host(.cgi-breadcrumb-item) ::ng-deep li a.cgi-link-body-1:hover,:host(.cgi-breadcrumb-item) ::ng-deep ul a.cgi-link-body-1:hover{color:#5236ab}:host(.cgi-breadcrumb-item) ::ng-deep li a:hover,:host(.cgi-breadcrumb-item) ::ng-deep ul a:hover{opacity:1}:host(.cgi-breadcrumb-item) ::ng-deep li:last-child{font-size:14px;line-height:17px;font-weight:700}:host(.cgi-breadcrumb-item):not(:last-child) li:after{content:url('data:image/svg+xml,<?xml version=\"1.0\" ?><svg enable-background=\"new 0 0 32 32\" height=\"5px\" id=\"svg2\" version=\"1.1\" viewBox=\"0 0 32 32\" width=\"5px\" xml:space=\"preserve\" xmlns=\"http://www.w3.org/2000/svg\" xmlns:cc=\"http://creativecommons.org/ns%23\" xmlns:dc=\"http://purl.org/dc/elements/1.1/\" xmlns:inkscape=\"http://www.inkscape.org/namespaces/inkscape\" xmlns:rdf=\"http://www.w3.org/1999/02/22-rdf-syntax-ns%23\" xmlns:sodipodi=\"http://sodipodi.sourceforge.net/DTD/sodipodi-0.dtd\" xmlns:svg=\"http://www.w3.org/2000/svg\"><g id=\"background\"><rect fill=\"none\" height=\"32\" width=\"32\"/></g><g id=\"arrow_x5F_right\"><polygon points=\"10,2.001 24,16 10,30  \"/></g></svg>');display:inline-block;height:20px;margin:0 10px;vertical-align:middle;width:11px}\n"] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.2", ngImport: i0, type: CGIBreadcrumbItemBrandComponent, decorators: [{
            type: Component,
            args: [{ selector: 'cgi-breadcrumb-item', standalone: false, template: "<ul>\n  <li>\n    <ng-content></ng-content>\n  </li>\n</ul>\n", styles: [":host(.cgi-breadcrumb-item) ::ng-deep li,:host(.cgi-breadcrumb-item) ::ng-deep ul{display:inline;padding:0}:host(.cgi-breadcrumb-item) ::ng-deep li a,:host(.cgi-breadcrumb-item) ::ng-deep ul a{font-size:14px;font-weight:400;display:inline}:host(.cgi-breadcrumb-item) ::ng-deep li a.cgi-link-body-underline-1:hover,:host(.cgi-breadcrumb-item) ::ng-deep ul a.cgi-link-body-underline-1:hover{color:#200a58}:host(.cgi-breadcrumb-item) ::ng-deep li a.cgi-link-body-1,:host(.cgi-breadcrumb-item) ::ng-deep ul a.cgi-link-body-1{color:#333}:host(.cgi-breadcrumb-item) ::ng-deep li a.cgi-link-body-1:hover,:host(.cgi-breadcrumb-item) ::ng-deep ul a.cgi-link-body-1:hover{color:#5236ab}:host(.cgi-breadcrumb-item) ::ng-deep li a:hover,:host(.cgi-breadcrumb-item) ::ng-deep ul a:hover{opacity:1}:host(.cgi-breadcrumb-item) ::ng-deep li:last-child{font-size:14px;line-height:17px;font-weight:700}:host(.cgi-breadcrumb-item):not(:last-child) li:after{content:url('data:image/svg+xml,<?xml version=\"1.0\" ?><svg enable-background=\"new 0 0 32 32\" height=\"5px\" id=\"svg2\" version=\"1.1\" viewBox=\"0 0 32 32\" width=\"5px\" xml:space=\"preserve\" xmlns=\"http://www.w3.org/2000/svg\" xmlns:cc=\"http://creativecommons.org/ns%23\" xmlns:dc=\"http://purl.org/dc/elements/1.1/\" xmlns:inkscape=\"http://www.inkscape.org/namespaces/inkscape\" xmlns:rdf=\"http://www.w3.org/1999/02/22-rdf-syntax-ns%23\" xmlns:sodipodi=\"http://sodipodi.sourceforge.net/DTD/sodipodi-0.dtd\" xmlns:svg=\"http://www.w3.org/2000/svg\"><g id=\"background\"><rect fill=\"none\" height=\"32\" width=\"32\"/></g><g id=\"arrow_x5F_right\"><polygon points=\"10,2.001 24,16 10,30  \"/></g></svg>');display:inline-block;height:20px;margin:0 10px;vertical-align:middle;width:11px}\n"] }]
        }], ctorParameters: () => [], propDecorators: { isClassContainer: [{
                type: HostBinding,
                args: ['class.cgi-breadcrumb-item']
            }] } });

/**
 * Breadcrumbs component.
 *
 * TODO: How to use component and examples.
 */
class CGIBreadcrumbsBrandComponent {
    /**
     * Empty constructor.
     */
    constructor() {
        /** Custom aria-label attribute for accessibility. */
        this.ariaLabel = 'Breadcrumbs';
        this.isClassContainer = true;
    }
    /**
     * Set title property in component.
     */
    ngOnInit() { }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.2", ngImport: i0, type: CGIBreadcrumbsBrandComponent, deps: [], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "20.3.2", type: CGIBreadcrumbsBrandComponent, isStandalone: false, selector: "cgi-breadcrumbs", inputs: { ariaLabel: "ariaLabel" }, host: { properties: { "class.cgi-breadcrumbs": "this.isClassContainer" } }, ngImport: i0, template: "<nav attr.aria-label=\"{{ ariaLabel }}\">\n  <ng-content></ng-content>\n</nav>\n", styles: [":host(.cgi-breadcrumbs){display:flex}:host(.cgi-breadcrumbs) nav{display:flex;justify-content:space-evenly;margin:0}\n"] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.2", ngImport: i0, type: CGIBreadcrumbsBrandComponent, decorators: [{
            type: Component,
            args: [{ selector: 'cgi-breadcrumbs', standalone: false, template: "<nav attr.aria-label=\"{{ ariaLabel }}\">\n  <ng-content></ng-content>\n</nav>\n", styles: [":host(.cgi-breadcrumbs){display:flex}:host(.cgi-breadcrumbs) nav{display:flex;justify-content:space-evenly;margin:0}\n"] }]
        }], ctorParameters: () => [], propDecorators: { isClassContainer: [{
                type: HostBinding,
                args: ['class.cgi-breadcrumbs']
            }], ariaLabel: [{
                type: Input
            }] } });

class CGIBreadcrumbsBrandModule {
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.2", ngImport: i0, type: CGIBreadcrumbsBrandModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule }); }
    static { this.ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "20.3.2", ngImport: i0, type: CGIBreadcrumbsBrandModule, declarations: [CGIBreadcrumbsBrandComponent, CGIBreadcrumbItemBrandComponent], imports: [CommonModule], exports: [CGIBreadcrumbsBrandComponent, CGIBreadcrumbItemBrandComponent] }); }
    static { this.ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "20.3.2", ngImport: i0, type: CGIBreadcrumbsBrandModule, imports: [CommonModule] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.2", ngImport: i0, type: CGIBreadcrumbsBrandModule, decorators: [{
            type: NgModule,
            args: [{
                    imports: [CommonModule],
                    declarations: [CGIBreadcrumbsBrandComponent, CGIBreadcrumbItemBrandComponent],
                    exports: [CGIBreadcrumbsBrandComponent, CGIBreadcrumbItemBrandComponent],
                }]
        }] });

/** Global Search Component */
class CgiGlobalSearchBrandComponent {
    /** constructor for host binding and form group */
    constructor(fb, router) {
        this.fb = fb;
        this.router = router;
        /** Input - variable for setting aria-label for the select menu : string type and default value */
        this.selectorAriaLabel = 'category selector';
        /** Input - for globalSearchSelect ( drop-down list for Category ) : string type and default value */
        this.globalSearchSelectID = 'cgi-global-search-select';
        /** Input - for  global search input box  ( search section  ) : string type and default value */
        this.globalSearchInputID = 'cgi-global-search-input';
        /** Input - for  global search placeholder ( search section ) : string type and default value */
        this.globalSearchInputPlaceholder = 'Search';
        /** Input - for global search autocomplete ( search result section ) : string type and default value */
        this.globalSearchAutocompleteID = 'cgi-global-search-autocomplete';
        /** Input - for i18n : show more results message */
        this.moreResults = 'Show more results...';
        /** Input - for i18n : no results message */
        this.noResults = 'Sorry, no results have been found.';
        /** Input - specifies the number of results to display in dropdown panel  */
        this.resultLimit = 10;
        /** Output - variable for checking a category is selected or not  */
        this.optionSelected = new EventEmitter();
        /** Output - variable for emitting search to app-shell  */
        this.search = new EventEmitter();
        this.isClassContainer = true;
        this.isSearchToggled = false;
        this.globalSearchId = "global-search-component" /* PageLandmarks.GLOBAL_SEARCH */;
        this.globalSearch = fb.group({
            category: '',
            searchString: '',
        });
    }
    /** when search bar is loaded, displayFn() set up first value in searchString */
    displayFn() {
        return '';
    }
    /** Initialization block when component is loaded */
    ngOnInit() {
        /** setting categories on global search category selection */
        this.globalSearch.get('category').setValue(this.categories[0].value);
    }
    /** Initialization block after view has been rendered */
    ngAfterViewInit() {
        this.globalSearch
            .get('category')
            .valueChanges.pipe(tap(() => {
            this.loadSearchResults();
        }))
            .subscribe();
        this.globalSearch
            .get('searchString')
            .valueChanges.pipe(startWith(''), debounceTime(800), distinctUntilChanged(), tap(() => {
            this.loadSearchResults();
        }))
            .subscribe();
    }
    /**
     * Callback function to call when form values change, and emit the form group as an output
     */
    loadSearchResults() {
        this.search.emit({
            globalSearch: this.globalSearch,
        });
    }
    /**
     * Navigation link for more results button
     */
    gotoLink(link, queryKey = null) {
        if (queryKey) {
            this.router.navigate([link], {
                queryParams: { [queryKey]: this.globalSearch.get('searchString').value },
            });
        }
        else {
            this.router.navigate([link]);
        }
        this.trigger.closePanel();
    }
    /**
     * Callback function for selecting an option from Autocomplete, and return the data in the following format as output
     * {searchText, category, entity, isShowMore}
     * @param category Category selected in the dropdown
     * @param entity Search result selected in the autocomplete
     * @param isShowMore Select to show more results
     */
    onEnter(category, entity, isShowMore = false) {
        const searchText = this.globalSearch.get('searchString').value;
        const event = { searchText, category, entity, isShowMore };
        this.optionSelected.emit(event);
    }
    /**
     * Method for displaying search on small screens
     */
    toggle() {
        this.isSearchToggled = !this.isSearchToggled;
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.2", ngImport: i0, type: CgiGlobalSearchBrandComponent, deps: [{ token: i1$2.UntypedFormBuilder }, { token: i2.Router }], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "20.3.2", type: CgiGlobalSearchBrandComponent, isStandalone: false, selector: "cgi-global-search", inputs: { categories: "categories", enableCategory: "enableCategory", isLoading: "isLoading", globalSearchResult: "globalSearchResult", globalSearchResultSize: "globalSearchResultSize", panelWidth: "panelWidth", selectorAriaLabel: "selectorAriaLabel", globalSearchSelectID: "globalSearchSelectID", globalSearchInputID: "globalSearchInputID", globalSearchInputPlaceholder: "globalSearchInputPlaceholder", globalSearchAutocompleteID: "globalSearchAutocompleteID", moreResults: "moreResults", noResults: "noResults", resultLimit: "resultLimit", subTemplate: "subTemplate" }, outputs: { optionSelected: "optionSelected", search: "search" }, host: { properties: { "class.cgi-global-search": "this.isClassContainer" } }, viewQueries: [{ propertyName: "trigger", first: true, predicate: MatAutocompleteTrigger, descendants: true }], ngImport: i0, template: "<div [attr.id]=\"globalSearchId\" class=\"row ms-0 cgi-global-search__container\">\n  <button\n    class=\"cgi-global-search__toggle\"\n    aria-label=\"Search Icon\"\n    mat-icon-button\n    (click)=\"toggle()\"\n  >\n    <mat-icon>search</mat-icon>\n  </button>\n  <form\n    [formGroup]=\"globalSearch\"\n    class=\"px-0\"\n    [ngClass]=\"isSearchToggled ? 'cgi-global-search--toggled-on' : 'cgi-global-search--toggled-off'\"\n  >\n    <mat-form-field\n      class=\"col-4 cgi-global-search__category-option\"\n      appearance=\"outline\"\n      *ngIf=\"enableCategory\"\n    >\n      <mat-select\n        formControlName=\"category\"\n        [id]=\"globalSearchSelectID\"\n        [aria-label]=\"selectorAriaLabel\"\n        panelClass=\"mat-select-panal-list\"\n      >\n        <mat-option\n          class=\"body_style\"\n          *ngFor=\"let category of categories\"\n          value=\"{{ category.value }}\"\n        >\n          {{ category.name }}</mat-option\n        >\n      </mat-select>\n    </mat-form-field>\n    <!-- flexible search bar size -->\n    <mat-form-field\n      [ngClass]=\"\n        enableCategory\n          ? 'cgi-global-search__search-section'\n          : 'col-12 cgi-global-search__search-section-1'\n      \"\n      appearance=\"outline\"\n      floatLabel=\"never\"\n    >\n      <button type=\"submit\" aria-label=\"Search Icon\" mat-icon-button matSuffix disableRipple=\"true\">\n        <mat-icon>search</mat-icon>\n      </button>\n      <input\n        [id]=\"globalSearchInputID\"\n        type=\"text\"\n        matInput\n        [placeholder]=\"globalSearchInputPlaceholder\"\n        formControlName=\"searchString\"\n        [matAutocomplete]=\"searchResults\"\n        aria-label=\"Global Search Field\"\n      />\n      <mat-autocomplete\n        [id]=\"globalSearchAutocompleteID\"\n        #searchResults=\"matAutocomplete\"\n        [displayWith]=\"displayFn\"\n        class=\"cgi-global-search-autocomplete\"\n        [panelWidth]=\"405\"\n      >\n        <mat-option class=\"cgi-global-search__spinner\" *ngIf=\"isLoading\">\n          <mat-spinner diameter=\"80\"></mat-spinner>\n        </mat-option>\n        <mat-option\n          *ngIf=\"\n            globalSearch.get('searchString').value && !isLoading && globalSearchResultSize === 0\n          \"\n          class=\"cgi-global-search__no-results\"\n        >\n          {{ noResults }}\n        </mat-option>\n        <!-- for searching with category -->\n        <ng-container\n          *ngIf=\"globalSearch.get('searchString').value && !isLoading && enableCategory\"\n        >\n          <mat-optgroup *ngFor=\"let group of globalSearchResult\">\n            <!-- <mat-icon *ngIf=\"group.category.icon\" fontSet=\"far\" fontIcon=\"{{ group.category.icon }}\"></mat-icon> -->\n            {{ group.category.name }}\n            <mat-option\n              *ngFor=\"let content of group.contents | slice : 0 : resultLimit; let i = index\"\n              (onSelectionChange)=\"onEnter(group.category, content)\"\n            >\n              <p class=\"cgi-body-2\">{{ content.name }}</p>\n              <ng-container *ngIf=\"subTemplate; then subTemp; else subCode\"></ng-container>\n\n              <ng-template #subTemp\n                ><ng-container [ngTemplateOutlet]=\"subTemplate\"></ng-container\n              ></ng-template>\n              <ng-template #subCode>\n                <p class=\"cgi-body-1 cgi-global-search--sub-code\">{{ content.code }}</p>\n              </ng-template>\n            </mat-option>\n            <!-- Result limit on categories -->\n            <ng-container *ngIf=\"group.totalRecords > resultLimit\">\n              <button\n                color=\"primary\"\n                mat-button\n                (click)=\"\n                  group.category.moreResultsLink\n                    ? gotoLink(group.category.moreResultsLink, group.category.queryParamKey)\n                    : (group.expandCategory = !group.expandCategory)\n                \"\n                [class.d-none]=\"group.expandCategory\"\n              >\n                {{ moreResults }}\n              </button>\n            </ng-container>\n            <ng-container *ngIf=\"group.expandCategory\">\n              <mat-option\n                *ngFor=\"let content of group.contents | slice : resultLimit; let i = index\"\n                (onSelectionChange)=\"onEnter(group.category, content, true)\"\n              >\n                <p>{{ content.name }}</p>\n                <ng-container *ngIf=\"subTemplate; then subTemp; else subCode\"></ng-container>\n\n                <ng-template #subTemp\n                  ><ng-container *ngTemplateOutlet=\"subTemplate\"></ng-container\n                ></ng-template>\n                <ng-template #subCode>\n                  <p class=\"cgi-global-search--sub-code\">{{ content.code }}</p>\n                </ng-template>\n              </mat-option>\n            </ng-container>\n            <!-- -->\n          </mat-optgroup>\n        </ng-container>\n        <!-- -->\n        <!-- for searching without category -->\n        <ng-container\n          *ngIf=\"globalSearch.get('searchString').value && !isLoading && !enableCategory\"\n        >\n          <div *ngFor=\"let group of globalSearchResult\">\n            <mat-option\n              *ngFor=\"let content of group.contents\"\n              (onSelectionChange)=\"onEnter(group.category, content)\"\n            >\n              <p class=\"cgi-body-2\">\n                {{ content.name }} &nbsp;\n                <ng-container *ngIf=\"subTemplate; then subTemp; else subCode\"></ng-container>\n              </p>\n\n              <ng-template #subTemp\n                ><ng-template *ngTemplateOutlet=\"subTemplate\"></ng-template\n              ></ng-template>\n              <ng-template #subCode>\n                <p class=\"cgi-global-search--sub-code\">{{ content.code }}</p>\n              </ng-template>\n            </mat-option>\n          </div>\n        </ng-container>\n        <!-- -->\n      </mat-autocomplete>\n    </mat-form-field>\n  </form>\n</div>\n", styles: [":host(.cgi-global-search){font-size:13px}:host(.cgi-global-search) .mat-mdc-select-panel{border-radius:0!important}:host(.cgi-global-search) ::ng-deep .cdk-overlay-container .cdk-overlay-pane.mat-autocomplete-panel-above{width:414px!important}:host(.cgi-global-search) ::ng-deep .cgi-global-search__container .cgi-global-search__toggle{display:none}:host(.cgi-global-search) ::ng-deep .cgi-global-search__container .mat-form-field-wrapper{padding-bottom:0}:host(.cgi-global-search) ::ng-deep .cgi-global-search__container .mat-form-field-suffix .mat-mdc-icon-button .mat-icon{color:#151515}:host(.cgi-global-search) ::ng-deep .cgi-global-search__container .cgi-global-search__category-option{width:145px!important;height:48px!important;padding-right:0;padding-left:0}:host(.cgi-global-search) ::ng-deep .cgi-global-search__container .cgi-global-search__category-option .mat-form-field-infix{padding:12px 0!important;bottom:5px}:host(.cgi-global-search) ::ng-deep .cgi-global-search__container .cgi-global-search__category-option .mat-form-field-flex{height:48px!important;padding:12px!important}:host(.cgi-global-search) ::ng-deep .cgi-global-search__container .cgi-global-search__category-option .mat-form-field-outline-end{border-radius:0}:host(.cgi-global-search) ::ng-deep .cgi-global-search__container .cgi-global-search__search-section{padding-right:0;width:420px!important;height:48px!important;padding-left:0}:host(.cgi-global-search) ::ng-deep .cgi-global-search__container .cgi-global-search__search-section .mat-mdc-form-field-infix{padding:12px 0!important}:host(.cgi-global-search) ::ng-deep .cgi-global-search__container .cgi-global-search__search-section .mat-mdc-form-field-flex{height:48px!important;padding:12px!important;width:405px}:host(.cgi-global-search) ::ng-deep .cgi-global-search__container .cgi-global-search__search-section .mat-form-field-outline-start{border-radius:0}:host(.cgi-global-search) ::ng-deep .cgi-global-search__container .cgi-global-search__search-section-1{padding-right:0;width:435px!important;height:48px!important;padding-left:0}:host(.cgi-global-search) ::ng-deep .cgi-global-search__container .cgi-global-search__search-section-1 .mat-mdc-form-field-infix{padding:12px 0!important;height:48px}:host(.cgi-global-search) ::ng-deep .cgi-global-search__container .cgi-global-search__search-section-1 .mat-mdc-form-field-flex{height:48px!important;padding:12px!important;width:405px!important}:host(.cgi-global-search) ::ng-deep .cgi-global-search__container .cgi-global-search__search-section-1 .mat-form-field-outline-start{border-radius:0}:host(.cgi-global-search) ::ng-deep .cgi-global-search__container .col-12 .mat-form-field-outline-start,:host(.cgi-global-search) ::ng-deep .cgi-global-search__container .col-12 .mat-form-field-outline-end{width:549px!important}.cgi-nav-content :host(.cgi-global-search) ::ng-deep .cgi-global-search__container .mat-mdc-icon-button{margin:0 -12px 0 0;top:3px}:host(.cgi-global-search) ::ng-deep .mat-mdc-form-field.cgi-global-search__search-section .mat-mdc-text-field-wrapper.mdc-text-field--outlined .mdc-notched-outline{border-bottom-left-radius:0;border-top-left-radius:0}:host(.cgi-global-search) ::ng-deep .mat-mdc-form-field.cgi-global-search__category-option .mat-mdc-text-field-wrapper.mdc-text-field--outlined .mdc-notched-outline{border-bottom-right-radius:0;border-top-right-radius:0}#global-search-filter-panel{border-radius:0!important}.body_style{color:#333;font-family:Source Sans Pro,sans-serif;font-weight:400;font-size:14px;line-height:16px}::placeholder{color:#333;font-family:Source Sans Pro,sans-serif;font-weight:400;font-size:14px;line-height:16px}@media (max-width: 959px){:host(.cgi-global-search) ::ng-deep .cgi-global-search__container .cgi-global-search__toggle{display:inline-block}:host(.cgi-global-search) ::ng-deep .cgi-global-search__container .cgi-global-search--toggled-off{display:none}:host(.cgi-global-search) ::ng-deep .cgi-global-search__container .cgi-global-search--toggled-on{background-color:#fff;border:1px solid #F5F7F9;border-radius:5px;box-shadow:0 2px 5px #696c6e45;display:block;max-width:100vw;padding:4px;position:absolute;right:0;top:64px}:host(.cgi-global-search) ::ng-deep .cgi-global-search__container .cgi-global-search--toggled-on .mat-mdc-form-field{padding:0}:host(.cgi-global-search) ::ng-deep .cgi-global-search__container .cgi-global-search--toggled-on .mat-mdc-form-field .mat-mdc-form-field-icon-suffix .mdc-icon-button{display:inline-block!important;padding:0;height:24px;width:22px}:host(.cgi-global-search) ::ng-deep .cgi-global-search__container .cgi-global-search--toggled-on .mat-form-field-wrapper{margin:0}}\n"], dependencies: [{ kind: "directive", type: i1.NgClass, selector: "[ngClass]", inputs: ["class", "ngClass"] }, { kind: "directive", type: i1.NgForOf, selector: "[ngFor][ngForOf]", inputs: ["ngForOf", "ngForTrackBy", "ngForTemplate"] }, { kind: "directive", type: i1.NgIf, selector: "[ngIf]", inputs: ["ngIf", "ngIfThen", "ngIfElse"] }, { kind: "directive", type: i1.NgTemplateOutlet, selector: "[ngTemplateOutlet]", inputs: ["ngTemplateOutletContext", "ngTemplateOutlet", "ngTemplateOutletInjector"] }, { kind: "component", type: i4.MatButton, selector: "    button[matButton], a[matButton], button[mat-button], button[mat-raised-button],    button[mat-flat-button], button[mat-stroked-button], a[mat-button], a[mat-raised-button],    a[mat-flat-button], a[mat-stroked-button]  ", inputs: ["matButton"], exportAs: ["matButton", "matAnchor"] }, { kind: "component", type: i4.MatIconButton, selector: "button[mat-icon-button], a[mat-icon-button], button[matIconButton], a[matIconButton]", exportAs: ["matButton", "matAnchor"] }, { kind: "component", type: i5.MatIcon, selector: "mat-icon", inputs: ["color", "inline", "svgIcon", "fontSet", "fontIcon"], exportAs: ["matIcon"] }, { kind: "directive", type: i1$2.ɵNgNoValidate, selector: "form:not([ngNoForm]):not([ngNativeValidate])" }, { kind: "directive", type: i1$2.DefaultValueAccessor, selector: "input:not([type=checkbox])[formControlName],textarea[formControlName],input:not([type=checkbox])[formControl],textarea[formControl],input:not([type=checkbox])[ngModel],textarea[ngModel],[ngDefaultControl]" }, { kind: "directive", type: i1$2.NgControlStatus, selector: "[formControlName],[ngModel],[formControl]" }, { kind: "directive", type: i1$2.NgControlStatusGroup, selector: "[formGroupName],[formArrayName],[ngModelGroup],[formGroup],form:not([ngNoForm]),[ngForm]" }, { kind: "directive", type: i1$2.FormGroupDirective, selector: "[formGroup]", inputs: ["formGroup"], outputs: ["ngSubmit"], exportAs: ["ngForm"] }, { kind: "directive", type: i1$2.FormControlName, selector: "[formControlName]", inputs: ["formControlName", "disabled", "ngModel"], outputs: ["ngModelChange"] }, { kind: "component", type: i6.MatAutocomplete, selector: "mat-autocomplete", inputs: ["aria-label", "aria-labelledby", "displayWith", "autoActiveFirstOption", "autoSelectActiveOption", "requireSelection", "panelWidth", "disableRipple", "class", "hideSingleSelectionIndicator"], outputs: ["optionSelected", "opened", "closed", "optionActivated"], exportAs: ["matAutocomplete"] }, { kind: "component", type: i6.MatOption, selector: "mat-option", inputs: ["value", "id", "disabled"], outputs: ["onSelectionChange"], exportAs: ["matOption"] }, { kind: "component", type: i6.MatOptgroup, selector: "mat-optgroup", inputs: ["label", "disabled"], exportAs: ["matOptgroup"] }, { kind: "directive", type: i6.MatAutocompleteTrigger, selector: "input[matAutocomplete], textarea[matAutocomplete]", inputs: ["matAutocomplete", "matAutocompletePosition", "matAutocompleteConnectedTo", "autocomplete", "matAutocompleteDisabled"], exportAs: ["matAutocompleteTrigger"] }, { kind: "component", type: i8.MatFormField, selector: "mat-form-field", inputs: ["hideRequiredMarker", "color", "floatLabel", "appearance", "subscriptSizing", "hintLabel"], exportAs: ["matFormField"] }, { kind: "directive", type: i8.MatSuffix, selector: "[matSuffix], [matIconSuffix], [matTextSuffix]", inputs: ["matTextSuffix"] }, { kind: "component", type: i8.MatSelect, selector: "mat-select", inputs: ["aria-describedby", "panelClass", "disabled", "disableRipple", "tabIndex", "hideSingleSelectionIndicator", "placeholder", "required", "multiple", "disableOptionCentering", "compareWith", "value", "aria-label", "aria-labelledby", "errorStateMatcher", "typeaheadDebounceInterval", "sortComparator", "id", "panelWidth", "canSelectNullableOptions"], outputs: ["openedChange", "opened", "closed", "selectionChange", "valueChange"], exportAs: ["matSelect"] }, { kind: "directive", type: i4$3.MatInput, selector: "input[matInput], textarea[matInput], select[matNativeControl],      input[matNativeControl], textarea[matNativeControl]", inputs: ["disabled", "id", "placeholder", "name", "required", "type", "errorStateMatcher", "aria-describedby", "value", "readonly", "disabledInteractive"], exportAs: ["matInput"] }, { kind: "component", type: i9.MatProgressSpinner, selector: "mat-progress-spinner, mat-spinner", inputs: ["color", "mode", "value", "diameter", "strokeWidth"], exportAs: ["matProgressSpinner"] }, { kind: "pipe", type: i1.SlicePipe, name: "slice" }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.2", ngImport: i0, type: CgiGlobalSearchBrandComponent, decorators: [{
            type: Component,
            args: [{ selector: 'cgi-global-search', standalone: false, template: "<div [attr.id]=\"globalSearchId\" class=\"row ms-0 cgi-global-search__container\">\n  <button\n    class=\"cgi-global-search__toggle\"\n    aria-label=\"Search Icon\"\n    mat-icon-button\n    (click)=\"toggle()\"\n  >\n    <mat-icon>search</mat-icon>\n  </button>\n  <form\n    [formGroup]=\"globalSearch\"\n    class=\"px-0\"\n    [ngClass]=\"isSearchToggled ? 'cgi-global-search--toggled-on' : 'cgi-global-search--toggled-off'\"\n  >\n    <mat-form-field\n      class=\"col-4 cgi-global-search__category-option\"\n      appearance=\"outline\"\n      *ngIf=\"enableCategory\"\n    >\n      <mat-select\n        formControlName=\"category\"\n        [id]=\"globalSearchSelectID\"\n        [aria-label]=\"selectorAriaLabel\"\n        panelClass=\"mat-select-panal-list\"\n      >\n        <mat-option\n          class=\"body_style\"\n          *ngFor=\"let category of categories\"\n          value=\"{{ category.value }}\"\n        >\n          {{ category.name }}</mat-option\n        >\n      </mat-select>\n    </mat-form-field>\n    <!-- flexible search bar size -->\n    <mat-form-field\n      [ngClass]=\"\n        enableCategory\n          ? 'cgi-global-search__search-section'\n          : 'col-12 cgi-global-search__search-section-1'\n      \"\n      appearance=\"outline\"\n      floatLabel=\"never\"\n    >\n      <button type=\"submit\" aria-label=\"Search Icon\" mat-icon-button matSuffix disableRipple=\"true\">\n        <mat-icon>search</mat-icon>\n      </button>\n      <input\n        [id]=\"globalSearchInputID\"\n        type=\"text\"\n        matInput\n        [placeholder]=\"globalSearchInputPlaceholder\"\n        formControlName=\"searchString\"\n        [matAutocomplete]=\"searchResults\"\n        aria-label=\"Global Search Field\"\n      />\n      <mat-autocomplete\n        [id]=\"globalSearchAutocompleteID\"\n        #searchResults=\"matAutocomplete\"\n        [displayWith]=\"displayFn\"\n        class=\"cgi-global-search-autocomplete\"\n        [panelWidth]=\"405\"\n      >\n        <mat-option class=\"cgi-global-search__spinner\" *ngIf=\"isLoading\">\n          <mat-spinner diameter=\"80\"></mat-spinner>\n        </mat-option>\n        <mat-option\n          *ngIf=\"\n            globalSearch.get('searchString').value && !isLoading && globalSearchResultSize === 0\n          \"\n          class=\"cgi-global-search__no-results\"\n        >\n          {{ noResults }}\n        </mat-option>\n        <!-- for searching with category -->\n        <ng-container\n          *ngIf=\"globalSearch.get('searchString').value && !isLoading && enableCategory\"\n        >\n          <mat-optgroup *ngFor=\"let group of globalSearchResult\">\n            <!-- <mat-icon *ngIf=\"group.category.icon\" fontSet=\"far\" fontIcon=\"{{ group.category.icon }}\"></mat-icon> -->\n            {{ group.category.name }}\n            <mat-option\n              *ngFor=\"let content of group.contents | slice : 0 : resultLimit; let i = index\"\n              (onSelectionChange)=\"onEnter(group.category, content)\"\n            >\n              <p class=\"cgi-body-2\">{{ content.name }}</p>\n              <ng-container *ngIf=\"subTemplate; then subTemp; else subCode\"></ng-container>\n\n              <ng-template #subTemp\n                ><ng-container [ngTemplateOutlet]=\"subTemplate\"></ng-container\n              ></ng-template>\n              <ng-template #subCode>\n                <p class=\"cgi-body-1 cgi-global-search--sub-code\">{{ content.code }}</p>\n              </ng-template>\n            </mat-option>\n            <!-- Result limit on categories -->\n            <ng-container *ngIf=\"group.totalRecords > resultLimit\">\n              <button\n                color=\"primary\"\n                mat-button\n                (click)=\"\n                  group.category.moreResultsLink\n                    ? gotoLink(group.category.moreResultsLink, group.category.queryParamKey)\n                    : (group.expandCategory = !group.expandCategory)\n                \"\n                [class.d-none]=\"group.expandCategory\"\n              >\n                {{ moreResults }}\n              </button>\n            </ng-container>\n            <ng-container *ngIf=\"group.expandCategory\">\n              <mat-option\n                *ngFor=\"let content of group.contents | slice : resultLimit; let i = index\"\n                (onSelectionChange)=\"onEnter(group.category, content, true)\"\n              >\n                <p>{{ content.name }}</p>\n                <ng-container *ngIf=\"subTemplate; then subTemp; else subCode\"></ng-container>\n\n                <ng-template #subTemp\n                  ><ng-container *ngTemplateOutlet=\"subTemplate\"></ng-container\n                ></ng-template>\n                <ng-template #subCode>\n                  <p class=\"cgi-global-search--sub-code\">{{ content.code }}</p>\n                </ng-template>\n              </mat-option>\n            </ng-container>\n            <!-- -->\n          </mat-optgroup>\n        </ng-container>\n        <!-- -->\n        <!-- for searching without category -->\n        <ng-container\n          *ngIf=\"globalSearch.get('searchString').value && !isLoading && !enableCategory\"\n        >\n          <div *ngFor=\"let group of globalSearchResult\">\n            <mat-option\n              *ngFor=\"let content of group.contents\"\n              (onSelectionChange)=\"onEnter(group.category, content)\"\n            >\n              <p class=\"cgi-body-2\">\n                {{ content.name }} &nbsp;\n                <ng-container *ngIf=\"subTemplate; then subTemp; else subCode\"></ng-container>\n              </p>\n\n              <ng-template #subTemp\n                ><ng-template *ngTemplateOutlet=\"subTemplate\"></ng-template\n              ></ng-template>\n              <ng-template #subCode>\n                <p class=\"cgi-global-search--sub-code\">{{ content.code }}</p>\n              </ng-template>\n            </mat-option>\n          </div>\n        </ng-container>\n        <!-- -->\n      </mat-autocomplete>\n    </mat-form-field>\n  </form>\n</div>\n", styles: [":host(.cgi-global-search){font-size:13px}:host(.cgi-global-search) .mat-mdc-select-panel{border-radius:0!important}:host(.cgi-global-search) ::ng-deep .cdk-overlay-container .cdk-overlay-pane.mat-autocomplete-panel-above{width:414px!important}:host(.cgi-global-search) ::ng-deep .cgi-global-search__container .cgi-global-search__toggle{display:none}:host(.cgi-global-search) ::ng-deep .cgi-global-search__container .mat-form-field-wrapper{padding-bottom:0}:host(.cgi-global-search) ::ng-deep .cgi-global-search__container .mat-form-field-suffix .mat-mdc-icon-button .mat-icon{color:#151515}:host(.cgi-global-search) ::ng-deep .cgi-global-search__container .cgi-global-search__category-option{width:145px!important;height:48px!important;padding-right:0;padding-left:0}:host(.cgi-global-search) ::ng-deep .cgi-global-search__container .cgi-global-search__category-option .mat-form-field-infix{padding:12px 0!important;bottom:5px}:host(.cgi-global-search) ::ng-deep .cgi-global-search__container .cgi-global-search__category-option .mat-form-field-flex{height:48px!important;padding:12px!important}:host(.cgi-global-search) ::ng-deep .cgi-global-search__container .cgi-global-search__category-option .mat-form-field-outline-end{border-radius:0}:host(.cgi-global-search) ::ng-deep .cgi-global-search__container .cgi-global-search__search-section{padding-right:0;width:420px!important;height:48px!important;padding-left:0}:host(.cgi-global-search) ::ng-deep .cgi-global-search__container .cgi-global-search__search-section .mat-mdc-form-field-infix{padding:12px 0!important}:host(.cgi-global-search) ::ng-deep .cgi-global-search__container .cgi-global-search__search-section .mat-mdc-form-field-flex{height:48px!important;padding:12px!important;width:405px}:host(.cgi-global-search) ::ng-deep .cgi-global-search__container .cgi-global-search__search-section .mat-form-field-outline-start{border-radius:0}:host(.cgi-global-search) ::ng-deep .cgi-global-search__container .cgi-global-search__search-section-1{padding-right:0;width:435px!important;height:48px!important;padding-left:0}:host(.cgi-global-search) ::ng-deep .cgi-global-search__container .cgi-global-search__search-section-1 .mat-mdc-form-field-infix{padding:12px 0!important;height:48px}:host(.cgi-global-search) ::ng-deep .cgi-global-search__container .cgi-global-search__search-section-1 .mat-mdc-form-field-flex{height:48px!important;padding:12px!important;width:405px!important}:host(.cgi-global-search) ::ng-deep .cgi-global-search__container .cgi-global-search__search-section-1 .mat-form-field-outline-start{border-radius:0}:host(.cgi-global-search) ::ng-deep .cgi-global-search__container .col-12 .mat-form-field-outline-start,:host(.cgi-global-search) ::ng-deep .cgi-global-search__container .col-12 .mat-form-field-outline-end{width:549px!important}.cgi-nav-content :host(.cgi-global-search) ::ng-deep .cgi-global-search__container .mat-mdc-icon-button{margin:0 -12px 0 0;top:3px}:host(.cgi-global-search) ::ng-deep .mat-mdc-form-field.cgi-global-search__search-section .mat-mdc-text-field-wrapper.mdc-text-field--outlined .mdc-notched-outline{border-bottom-left-radius:0;border-top-left-radius:0}:host(.cgi-global-search) ::ng-deep .mat-mdc-form-field.cgi-global-search__category-option .mat-mdc-text-field-wrapper.mdc-text-field--outlined .mdc-notched-outline{border-bottom-right-radius:0;border-top-right-radius:0}#global-search-filter-panel{border-radius:0!important}.body_style{color:#333;font-family:Source Sans Pro,sans-serif;font-weight:400;font-size:14px;line-height:16px}::placeholder{color:#333;font-family:Source Sans Pro,sans-serif;font-weight:400;font-size:14px;line-height:16px}@media (max-width: 959px){:host(.cgi-global-search) ::ng-deep .cgi-global-search__container .cgi-global-search__toggle{display:inline-block}:host(.cgi-global-search) ::ng-deep .cgi-global-search__container .cgi-global-search--toggled-off{display:none}:host(.cgi-global-search) ::ng-deep .cgi-global-search__container .cgi-global-search--toggled-on{background-color:#fff;border:1px solid #F5F7F9;border-radius:5px;box-shadow:0 2px 5px #696c6e45;display:block;max-width:100vw;padding:4px;position:absolute;right:0;top:64px}:host(.cgi-global-search) ::ng-deep .cgi-global-search__container .cgi-global-search--toggled-on .mat-mdc-form-field{padding:0}:host(.cgi-global-search) ::ng-deep .cgi-global-search__container .cgi-global-search--toggled-on .mat-mdc-form-field .mat-mdc-form-field-icon-suffix .mdc-icon-button{display:inline-block!important;padding:0;height:24px;width:22px}:host(.cgi-global-search) ::ng-deep .cgi-global-search__container .cgi-global-search--toggled-on .mat-form-field-wrapper{margin:0}}\n"] }]
        }], ctorParameters: () => [{ type: i1$2.UntypedFormBuilder }, { type: i2.Router }], propDecorators: { isClassContainer: [{
                type: HostBinding,
                args: ['class.cgi-global-search']
            }], categories: [{
                type: Input
            }], enableCategory: [{
                type: Input
            }], isLoading: [{
                type: Input
            }], globalSearchResult: [{
                type: Input
            }], globalSearchResultSize: [{
                type: Input
            }], panelWidth: [{
                type: Input
            }], selectorAriaLabel: [{
                type: Input
            }], globalSearchSelectID: [{
                type: Input
            }], globalSearchInputID: [{
                type: Input
            }], globalSearchInputPlaceholder: [{
                type: Input
            }], globalSearchAutocompleteID: [{
                type: Input
            }], moreResults: [{
                type: Input
            }], noResults: [{
                type: Input
            }], resultLimit: [{
                type: Input
            }], subTemplate: [{
                type: Input
            }], optionSelected: [{
                type: Output
            }], search: [{
                type: Output
            }], 
        /** variable for trigger  */
        trigger: [{
                type: ViewChild,
                args: [MatAutocompleteTrigger]
            }] } });

class CGIGlobalSearchBrandModule {
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.2", ngImport: i0, type: CGIGlobalSearchBrandModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule }); }
    static { this.ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "20.3.2", ngImport: i0, type: CGIGlobalSearchBrandModule, declarations: [CgiGlobalSearchBrandComponent], imports: [CommonModule,
            MatButtonModule,
            MatIconModule,
            FormsModule,
            ReactiveFormsModule,
            MatAutocompleteModule,
            MatSelectModule,
            MatFormFieldModule,
            MatInputModule,
            MatProgressSpinnerModule,
            RouterModule], exports: [CgiGlobalSearchBrandComponent] }); }
    static { this.ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "20.3.2", ngImport: i0, type: CGIGlobalSearchBrandModule, imports: [CommonModule,
            MatButtonModule,
            MatIconModule,
            FormsModule,
            ReactiveFormsModule,
            MatAutocompleteModule,
            MatSelectModule,
            MatFormFieldModule,
            MatInputModule,
            MatProgressSpinnerModule,
            RouterModule] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.2", ngImport: i0, type: CGIGlobalSearchBrandModule, decorators: [{
            type: NgModule,
            args: [{
                    imports: [
                        CommonModule,
                        MatButtonModule,
                        MatIconModule,
                        FormsModule,
                        ReactiveFormsModule,
                        MatAutocompleteModule,
                        MatSelectModule,
                        MatFormFieldModule,
                        MatInputModule,
                        MatProgressSpinnerModule,
                        RouterModule,
                    ],
                    declarations: [CgiGlobalSearchBrandComponent],
                    exports: [CgiGlobalSearchBrandComponent],
                }]
        }] });

/**
 * Click Outside Directive that emits an event whenever a target element is clicked.
 */
class CGIClickOutsideBrandDirective {
    /**
     * Constructor for Click Outside Directive
     * @param _elementRef Reference to element the directive is declared in
     */
    constructor(_elementRef) {
        this._elementRef = _elementRef;
        /** Output event for when the user clicks outside the selected element */
        this.cgiClickOutside = new EventEmitter();
        /** Boolean to tell if the overlay has opened yet */
        this.hasOpened = false;
    }
    /** On click function that runs everytime the document is clicked */
    onClick(event, targetElement) {
        if (targetElement) {
            const clickedInside = this._elementRef.nativeElement.contains(targetElement);
            // If the user clicks outside of the target element and the
            // overlay has opened at least once then emit an event to the parent component
            if (!clickedInside && this.hasOpened) {
                this.cgiClickOutside.emit(event);
            }
            // Overlay has opened once so set the boolean to true
            this.hasOpened = true;
        }
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.2", ngImport: i0, type: CGIClickOutsideBrandDirective, deps: [{ token: i0.ElementRef }], target: i0.ɵɵFactoryTarget.Directive }); }
    static { this.ɵdir = i0.ɵɵngDeclareDirective({ minVersion: "14.0.0", version: "20.3.2", type: CGIClickOutsideBrandDirective, isStandalone: false, selector: "[cgiClickOutside]", outputs: { cgiClickOutside: "cgiClickOutside" }, host: { listeners: { "document:click": "onClick($event,$event.target)" } }, ngImport: i0 }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.2", ngImport: i0, type: CGIClickOutsideBrandDirective, decorators: [{
            type: Directive,
            args: [{
                    selector: '[cgiClickOutside]',
                    standalone: false
                }]
        }], ctorParameters: () => [{ type: i0.ElementRef }], propDecorators: { cgiClickOutside: [{
                type: Output
            }], onClick: [{
                type: HostListener,
                args: ['document:click', ['$event', '$event.target']]
            }] } });

/**
 * Popover Content component.
 */
class CGIPopoverContentBrandComponent {
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.2", ngImport: i0, type: CGIPopoverContentBrandComponent, deps: [], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "20.3.2", type: CGIPopoverContentBrandComponent, isStandalone: false, selector: "cgi-popover-content", ngImport: i0, template: "<div class=\"cgi-body-1\">\n    <ng-content></ng-content>\n</div>", styles: [""] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.2", ngImport: i0, type: CGIPopoverContentBrandComponent, decorators: [{
            type: Component,
            args: [{ selector: 'cgi-popover-content', standalone: false, template: "<div class=\"cgi-body-1\">\n    <ng-content></ng-content>\n</div>" }]
        }] });

/**
 * Popover Footer component.
 */
class CGIPopoverFooterBrandComponent {
    /**
     * Constructor for popover footer
     */
    constructor() {
        this.isClassContainer = true;
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.2", ngImport: i0, type: CGIPopoverFooterBrandComponent, deps: [], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "20.3.2", type: CGIPopoverFooterBrandComponent, isStandalone: false, selector: "cgi-popover-footer", host: { properties: { "class.cgi-popover-footer": "this.isClassContainer" } }, ngImport: i0, template: "<div class=\"cgi-popover-footer__button-group\">\n  <ng-content></ng-content>\n</div>\n", styles: [":host(.cgi-popover-footer){display:flex;justify-content:flex-end}\n"] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.2", ngImport: i0, type: CGIPopoverFooterBrandComponent, decorators: [{
            type: Component,
            args: [{ selector: 'cgi-popover-footer', standalone: false, template: "<div class=\"cgi-popover-footer__button-group\">\n  <ng-content></ng-content>\n</div>\n", styles: [":host(.cgi-popover-footer){display:flex;justify-content:flex-end}\n"] }]
        }], ctorParameters: () => [], propDecorators: { isClassContainer: [{
                type: HostBinding,
                args: ['class.cgi-popover-footer']
            }] } });

/**
 * Popover Header component.
 */
class CGIPopoverHeaderBrandComponent {
    /**
     * Constructor for popover header
     */
    constructor() {
        /** Output event for when the popover is closed */
        this.popoverClose = new EventEmitter();
        this.isClassContainer = true;
    }
    /** Close method for when the close button is clicked */
    closePopover() {
        this.popoverClose.emit();
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.2", ngImport: i0, type: CGIPopoverHeaderBrandComponent, deps: [], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "20.3.2", type: CGIPopoverHeaderBrandComponent, isStandalone: false, selector: "cgi-popover-header", outputs: { popoverClose: "popoverClose" }, host: { properties: { "class.cgi-popover-header": "this.isClassContainer" } }, ngImport: i0, template: "<div class=\"cgi-popover-header__title\">\n  <ng-content></ng-content>\n  <span class=\"cgi-popover-header__spacer\"></span>\n  <button\n    mat-icon-button\n    (click)=\"closePopover()\"\n    class=\"cgi-popover-header__close-button\"\n    aria-label=\"Close Popover\"\n    autofocus\n  >\n  <mat-icon>close</mat-icon>\n  </button>\n</div>\n", styles: [":host(.cgi-popover-header) .cgi-popover-header__title{align-items:center;color:#5236ab;display:flex;font-size:16px;font-weight:700}:host(.cgi-popover-header) .cgi-popover-header__spacer{flex:1 1 auto}:host(.cgi-popover-header) .cgi-popover-header__close-button{line-height:18px;padding:0!important;height:24px!important;width:24px!important}:host(.cgi-popover-header) .cgi-popover-header__close-button mat-icon{color:#151515}\n"], dependencies: [{ kind: "component", type: i4.MatIconButton, selector: "button[mat-icon-button], a[mat-icon-button], button[matIconButton], a[matIconButton]", exportAs: ["matButton", "matAnchor"] }, { kind: "component", type: i5.MatIcon, selector: "mat-icon", inputs: ["color", "inline", "svgIcon", "fontSet", "fontIcon"], exportAs: ["matIcon"] }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.2", ngImport: i0, type: CGIPopoverHeaderBrandComponent, decorators: [{
            type: Component,
            args: [{ selector: 'cgi-popover-header', standalone: false, template: "<div class=\"cgi-popover-header__title\">\n  <ng-content></ng-content>\n  <span class=\"cgi-popover-header__spacer\"></span>\n  <button\n    mat-icon-button\n    (click)=\"closePopover()\"\n    class=\"cgi-popover-header__close-button\"\n    aria-label=\"Close Popover\"\n    autofocus\n  >\n  <mat-icon>close</mat-icon>\n  </button>\n</div>\n", styles: [":host(.cgi-popover-header) .cgi-popover-header__title{align-items:center;color:#5236ab;display:flex;font-size:16px;font-weight:700}:host(.cgi-popover-header) .cgi-popover-header__spacer{flex:1 1 auto}:host(.cgi-popover-header) .cgi-popover-header__close-button{line-height:18px;padding:0!important;height:24px!important;width:24px!important}:host(.cgi-popover-header) .cgi-popover-header__close-button mat-icon{color:#151515}\n"] }]
        }], ctorParameters: () => [], propDecorators: { isClassContainer: [{
                type: HostBinding,
                args: ['class.cgi-popover-header']
            }], popoverClose: [{
                type: Output
            }] } });

/**
 * Popover component.
 */
class CGIPopoverBrandComponent {
    /** Constructor for Popover Component
     * @param _focusTrapFactory Create focus trap service for a11y
     * @param document Allows for focus trap within the component
     */
    constructor(_focusTrapFactory, document) {
        this._focusTrapFactory = _focusTrapFactory;
        this.document = document;
        /** The width of the popover */
        this.popoverWidth = 300;
        /** Boolean for whether the popover is open or closed */
        this.isPopoverOpen = false;
        /** Output event for when the popover is closed */
        this.popoverClose = new EventEmitter();
        /** variable keeps track of trapping popover */
        this.restoreTrap = true;
        /** Current state of the popover animation. */
        this.popoverAnimationState = 'enter';
        /** Element that was focused before the popover was opened. Save this to restore upon close. */
        this._elementFocusedBeforeDialogWasOpened = null;
    }
    /** called when overlay is attached */
    overlayAttached() {
        this.focusButton();
    }
    /** called when overlay is detached */
    overlayDetached() {
        this.restoreFocus();
    }
    /** Close method for when the popover is closed by clicking outside */
    closePopover() {
        this.isPopoverOpen = false;
        this.popoverClose.emit();
    }
    /** Sets focus to the closing button on popover */
    focusButton() {
        this._elementFocusedBeforeDialogWasOpened = this.document.activeElement;
        this.closeButton = this.document.querySelector('.cgi-popover-header__close-button');
        this.createTrapFocus();
    }
    /** creates focus to the popover that was opened. */
    createTrapFocus() {
        if (!this._focusTrap || this.restoreTrap) {
            this._focusTrap = this._focusTrapFactory.create(this.document.querySelector('.cdk-overlay-pane'));
            this.restoreTrap = false;
        }
    }
    /** Restores focus to the element that was focused before the popover opened. */
    restoreFocus() {
        if (this._elementFocusedBeforeDialogWasOpened) {
            this._elementFocusedBeforeDialogWasOpened.focus();
        }
        if (!this._focusTrap) {
            this.restoreTrap = true;
        }
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.2", ngImport: i0, type: CGIPopoverBrandComponent, deps: [{ token: i1$3.ConfigurableFocusTrapFactory }, { token: DOCUMENT }], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "20.3.2", type: CGIPopoverBrandComponent, isStandalone: false, selector: "cgi-popover", inputs: { popoverName: "popoverName", popoverWidth: "popoverWidth", isPopoverOpen: "isPopoverOpen", panelClass: "panelClass" }, outputs: { popoverClose: "popoverClose" }, ngImport: i0, template: "<ng-template\n  cdkConnectedOverlay\n  [cdkConnectedOverlayOrigin]=\"popoverName\"\n  [cdkConnectedOverlayWidth]=\"popoverWidth\"\n  [cdkConnectedOverlayOpen]=\"isPopoverOpen\"\n  [cdkConnectedOverlayPanelClass]=\"panelClass\"\n  (attach)=\"overlayAttached()\"\n  (detach)=\"overlayDetached()\"\n>\n  <div\n    role=\"dialog\"\n    *ngIf=\"isPopoverOpen\"\n    [@transformPopover]=\"popoverAnimationState\"\n    class=\"cgi-popover\"\n    (cgiClickOutside)=\"closePopover()\"\n    (keydown.escape)=\"closePopover()\"\n    (blur)=\"closePopover()\"\n  >\n    <ng-content></ng-content>\n  </div>\n</ng-template>\n", styles: [".cgi-popover{background-color:#fff;border-radius:4px;box-shadow:0 4px 14px #00000085;padding:16px}\n"], dependencies: [{ kind: "directive", type: i1.NgIf, selector: "[ngIf]", inputs: ["ngIf", "ngIfThen", "ngIfElse"] }, { kind: "directive", type: i3$1.CdkConnectedOverlay, selector: "[cdk-connected-overlay], [connected-overlay], [cdkConnectedOverlay]", inputs: ["cdkConnectedOverlayOrigin", "cdkConnectedOverlayPositions", "cdkConnectedOverlayPositionStrategy", "cdkConnectedOverlayOffsetX", "cdkConnectedOverlayOffsetY", "cdkConnectedOverlayWidth", "cdkConnectedOverlayHeight", "cdkConnectedOverlayMinWidth", "cdkConnectedOverlayMinHeight", "cdkConnectedOverlayBackdropClass", "cdkConnectedOverlayPanelClass", "cdkConnectedOverlayViewportMargin", "cdkConnectedOverlayScrollStrategy", "cdkConnectedOverlayOpen", "cdkConnectedOverlayDisableClose", "cdkConnectedOverlayTransformOriginOn", "cdkConnectedOverlayHasBackdrop", "cdkConnectedOverlayLockPosition", "cdkConnectedOverlayFlexibleDimensions", "cdkConnectedOverlayGrowAfterOpen", "cdkConnectedOverlayPush", "cdkConnectedOverlayDisposeOnNavigation"], outputs: ["backdropClick", "positionChange", "attach", "detach", "overlayKeydown", "overlayOutsideClick"], exportAs: ["cdkConnectedOverlay"] }, { kind: "directive", type: CGIClickOutsideBrandDirective, selector: "[cgiClickOutside]", outputs: ["cgiClickOutside"] }], animations: [
            trigger('transformPopover', [
                state('void', style({
                    opacity: 0,
                    transform: 'scale(0.8)',
                })),
                transition('* => void', animate('100ms 25ms linear', style({ opacity: 0 }))),
            ]),
        ] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.2", ngImport: i0, type: CGIPopoverBrandComponent, decorators: [{
            type: Component,
            args: [{ selector: 'cgi-popover', animations: [
                        trigger('transformPopover', [
                            state('void', style({
                                opacity: 0,
                                transform: 'scale(0.8)',
                            })),
                            transition('* => void', animate('100ms 25ms linear', style({ opacity: 0 }))),
                        ]),
                    ], standalone: false, template: "<ng-template\n  cdkConnectedOverlay\n  [cdkConnectedOverlayOrigin]=\"popoverName\"\n  [cdkConnectedOverlayWidth]=\"popoverWidth\"\n  [cdkConnectedOverlayOpen]=\"isPopoverOpen\"\n  [cdkConnectedOverlayPanelClass]=\"panelClass\"\n  (attach)=\"overlayAttached()\"\n  (detach)=\"overlayDetached()\"\n>\n  <div\n    role=\"dialog\"\n    *ngIf=\"isPopoverOpen\"\n    [@transformPopover]=\"popoverAnimationState\"\n    class=\"cgi-popover\"\n    (cgiClickOutside)=\"closePopover()\"\n    (keydown.escape)=\"closePopover()\"\n    (blur)=\"closePopover()\"\n  >\n    <ng-content></ng-content>\n  </div>\n</ng-template>\n", styles: [".cgi-popover{background-color:#fff;border-radius:4px;box-shadow:0 4px 14px #00000085;padding:16px}\n"] }]
        }], ctorParameters: () => [{ type: i1$3.ConfigurableFocusTrapFactory }, { type: undefined, decorators: [{
                    type: Inject,
                    args: [DOCUMENT]
                }] }], propDecorators: { popoverName: [{
                type: Input
            }], popoverWidth: [{
                type: Input
            }], isPopoverOpen: [{
                type: Input
            }], popoverClose: [{
                type: Output
            }], panelClass: [{
                type: Input
            }] } });

class CGIPopoverBrandModule {
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.2", ngImport: i0, type: CGIPopoverBrandModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule }); }
    static { this.ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "20.3.2", ngImport: i0, type: CGIPopoverBrandModule, declarations: [CGIPopoverBrandComponent,
            CGIPopoverHeaderBrandComponent,
            CGIPopoverContentBrandComponent,
            CGIPopoverFooterBrandComponent,
            CGIClickOutsideBrandDirective], imports: [CommonModule, OverlayModule, MatButtonModule, MatIconModule], exports: [CGIPopoverBrandComponent,
            CGIPopoverHeaderBrandComponent,
            CGIPopoverContentBrandComponent,
            CGIPopoverFooterBrandComponent,
            CGIClickOutsideBrandDirective] }); }
    static { this.ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "20.3.2", ngImport: i0, type: CGIPopoverBrandModule, imports: [CommonModule, OverlayModule, MatButtonModule, MatIconModule] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.2", ngImport: i0, type: CGIPopoverBrandModule, decorators: [{
            type: NgModule,
            args: [{
                    imports: [CommonModule, OverlayModule, MatButtonModule, MatIconModule],
                    declarations: [
                        CGIPopoverBrandComponent,
                        CGIPopoverHeaderBrandComponent,
                        CGIPopoverContentBrandComponent,
                        CGIPopoverFooterBrandComponent,
                        CGIClickOutsideBrandDirective,
                    ],
                    exports: [
                        CGIPopoverBrandComponent,
                        CGIPopoverHeaderBrandComponent,
                        CGIPopoverContentBrandComponent,
                        CGIPopoverFooterBrandComponent,
                        CGIClickOutsideBrandDirective,
                    ],
                    providers: [],
                }]
        }] });

/** Select Search component */
class CGISelectSearchBrandComponent {
    /** Input - function for getting the filtered values using the search string */
    filterFunction(options, search) {
        return options.filter((option) => option.toLowerCase().includes(search));
    }
    /**
     * Constructor for CGISelectSearch component
     * @param matSelect reference to the MatSelect component paired with CGISelectSearch
     */
    constructor(matSelect) {
        this.matSelect = matSelect;
        /** Input - Placeholder text */
        this.placeholder = 'Search';
        /** Input - text for no results found */
        this.noResultsMessage = 'Sorry, no results were found that matches your search.';
        /** Output - event emitter that emits the filtered options */
        this.filterEvent = new EventEmitter();
        /** form control for the input field */
        this.inputFormControl = new UntypedFormControl();
        /** variable used to determine if no results message should be displayed */
        this.noResultsFound = false;
        /** subject that emits when the component is destroyed */
        this._onDestroy = new Subject();
        this.isClassContainer = true;
    }
    /** Initialization block when component is loaded */
    ngOnInit() {
        if (!this.ariaLabel) {
            this.ariaLabel =
                'Search field for ' + (this.matSelect.ariaLabel ? this.matSelect.ariaLabel : 'select menu');
        }
        this.matSelect.openedChange.pipe(takeUntil(this._onDestroy)).subscribe((opened) => {
            if (opened) {
                this.focus();
            }
            else {
                this.reset();
            }
        });
        if (this.options) {
            this.filterEvent.emit(this.options.slice());
        }
        this.inputFormControl.valueChanges
            .pipe(takeUntil(this._onDestroy), debounceTime(800), distinctUntilChanged())
            .subscribe((value) => this.filterOptions(value));
        this.filterEvent.pipe(takeUntil(this._onDestroy)).subscribe((value) => {
            this.noResultsFound = value.length === 0;
        });
        // when options change (ie. after filter), make the first option active so that keyboard events
        // are still propagated correctly
        this.matSelect.openedChange.pipe(take(1), takeUntil(this._onDestroy)).subscribe(() => {
            this.matSelect.options.changes.subscribe(() => {
                setTimeout(() => {
                    if (this.matSelect.panelOpen) {
                        this.matSelect._keyManager.setFirstItemActive();
                    }
                });
            });
        });
    }
    /** Lifecycle hook for when component is destroyed */
    ngOnDestroy() {
        this._onDestroy.next();
        this._onDestroy.complete();
    }
    /**
     * Intercept keyboard input when search field is active
     * @param event keyboard event
     */
    handleKeyDown(event) {
        // intercept space key to disable selecting an option with space while typing in the search field
        if (event.key === ' ' || event.key === 'Spacebar') {
            event.stopPropagation();
        }
    }
    /**
     * Filter the options list on the value of the search field
     */
    filterOptions(search) {
        if (!this.options) {
            return;
        }
        if (!search || search.length < 2) {
            this.filterEvent.emit(this.options.slice());
        }
        else {
            search = search.toLowerCase();
            this.filterEvent.emit(this.filterFunction(this.options, search));
        }
    }
    /**
     * Apply focus to the search field
     */
    focus() {
        if (!this.selectSearchInput) {
            return;
        }
        this.selectSearchInput.nativeElement.focus();
    }
    /**
     * Reset the value of the search field
     */
    reset() {
        this.inputFormControl.setValue('');
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.2", ngImport: i0, type: CGISelectSearchBrandComponent, deps: [{ token: MatSelect }], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "20.3.2", type: CGISelectSearchBrandComponent, isStandalone: false, selector: "cgi-select-search", inputs: { options: "options", placeholder: "placeholder", ariaLabel: "ariaLabel", noResultsMessage: "noResultsMessage", filterFunction: "filterFunction" }, outputs: { filterEvent: "filterEvent" }, host: { properties: { "class.cgi-select-search": "this.isClassContainer" } }, viewQueries: [{ propertyName: "selectSearchInput", first: true, predicate: ["selectSearchInput"], descendants: true, read: ElementRef }], ngImport: i0, template: "<mat-form-field floatLabel=\"never\">\n  <input\n    type=\"text\"\n    matInput\n    [formControl]=\"inputFormControl\"\n    #selectSearchInput\n    (keydown)=\"handleKeyDown($event)\"\n    [placeholder]=\"placeholder\"\n    [attr.aria-label]=\"ariaLabel\"\n  />\n</mat-form-field>\n<div *ngIf=\"selectSearchInput.value && noResultsFound\" class=\"cgi-select-search__no-results\">\n  {{ noResultsMessage }}\n</div>\n", styles: [":host(.cgi-select-search) .mat-mdc-form-field{width:100%}:host(.cgi-select-search) ::ng-deep .mat-form-field-wrapper{padding-bottom:0}:host(.cgi-select-search) ::ng-deep .mat-form-field-infix{padding-bottom:.6375em;padding-top:.2em}:host(.cgi-select-search) ::ng-deep .mat-form-field-underline{position:static}:host(.cgi-select-search) ::ng-deep .mat-input-element,:host(.cgi-select-search) ::ng-deep .mat-form-field-label{padding:0 16px}:host(.cgi-select-search) ::ng-deep .mat-form-field-underline .mat-form-field-ripple{display:none}:host(.cgi-select-search) ::ng-deep .cgi-select-search__no-results{padding:8px 16px}\n"], dependencies: [{ kind: "directive", type: i1.NgIf, selector: "[ngIf]", inputs: ["ngIf", "ngIfThen", "ngIfElse"] }, { kind: "directive", type: i1$2.DefaultValueAccessor, selector: "input:not([type=checkbox])[formControlName],textarea[formControlName],input:not([type=checkbox])[formControl],textarea[formControl],input:not([type=checkbox])[ngModel],textarea[ngModel],[ngDefaultControl]" }, { kind: "directive", type: i1$2.NgControlStatus, selector: "[formControlName],[ngModel],[formControl]" }, { kind: "directive", type: i1$2.FormControlDirective, selector: "[formControl]", inputs: ["formControl", "disabled", "ngModel"], outputs: ["ngModelChange"], exportAs: ["ngForm"] }, { kind: "component", type: i8.MatFormField, selector: "mat-form-field", inputs: ["hideRequiredMarker", "color", "floatLabel", "appearance", "subscriptSizing", "hintLabel"], exportAs: ["matFormField"] }, { kind: "directive", type: i4$3.MatInput, selector: "input[matInput], textarea[matInput], select[matNativeControl],      input[matNativeControl], textarea[matNativeControl]", inputs: ["disabled", "id", "placeholder", "name", "required", "type", "errorStateMatcher", "aria-describedby", "value", "readonly", "disabledInteractive"], exportAs: ["matInput"] }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.2", ngImport: i0, type: CGISelectSearchBrandComponent, decorators: [{
            type: Component,
            args: [{ selector: 'cgi-select-search', standalone: false, template: "<mat-form-field floatLabel=\"never\">\n  <input\n    type=\"text\"\n    matInput\n    [formControl]=\"inputFormControl\"\n    #selectSearchInput\n    (keydown)=\"handleKeyDown($event)\"\n    [placeholder]=\"placeholder\"\n    [attr.aria-label]=\"ariaLabel\"\n  />\n</mat-form-field>\n<div *ngIf=\"selectSearchInput.value && noResultsFound\" class=\"cgi-select-search__no-results\">\n  {{ noResultsMessage }}\n</div>\n", styles: [":host(.cgi-select-search) .mat-mdc-form-field{width:100%}:host(.cgi-select-search) ::ng-deep .mat-form-field-wrapper{padding-bottom:0}:host(.cgi-select-search) ::ng-deep .mat-form-field-infix{padding-bottom:.6375em;padding-top:.2em}:host(.cgi-select-search) ::ng-deep .mat-form-field-underline{position:static}:host(.cgi-select-search) ::ng-deep .mat-input-element,:host(.cgi-select-search) ::ng-deep .mat-form-field-label{padding:0 16px}:host(.cgi-select-search) ::ng-deep .mat-form-field-underline .mat-form-field-ripple{display:none}:host(.cgi-select-search) ::ng-deep .cgi-select-search__no-results{padding:8px 16px}\n"] }]
        }], ctorParameters: () => [{ type: i8.MatSelect, decorators: [{
                    type: Inject,
                    args: [MatSelect]
                }] }], propDecorators: { isClassContainer: [{
                type: HostBinding,
                args: ['class.cgi-select-search']
            }], options: [{
                type: Input
            }], placeholder: [{
                type: Input
            }], ariaLabel: [{
                type: Input
            }], noResultsMessage: [{
                type: Input
            }], filterEvent: [{
                type: Output
            }], selectSearchInput: [{
                type: ViewChild,
                args: ['selectSearchInput', { read: ElementRef }]
            }], filterFunction: [{
                type: Input
            }] } });

class CGISelectSearchBrandModule {
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.2", ngImport: i0, type: CGISelectSearchBrandModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule }); }
    static { this.ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "20.3.2", ngImport: i0, type: CGISelectSearchBrandModule, declarations: [CGISelectSearchBrandComponent], imports: [CommonModule, ReactiveFormsModule, MatSelectModule, MatInputModule, MatFormFieldModule], exports: [CGISelectSearchBrandComponent] }); }
    static { this.ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "20.3.2", ngImport: i0, type: CGISelectSearchBrandModule, imports: [CommonModule, ReactiveFormsModule, MatSelectModule, MatInputModule, MatFormFieldModule] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.2", ngImport: i0, type: CGISelectSearchBrandModule, decorators: [{
            type: NgModule,
            args: [{
                    imports: [CommonModule, ReactiveFormsModule, MatSelectModule, MatInputModule, MatFormFieldModule],
                    declarations: [CGISelectSearchBrandComponent],
                    exports: [CGISelectSearchBrandComponent],
                }]
        }] });

/**
 * Skeleton component.
 *
 * TODO: How to use component and examples.
 */
class CGISkeletonBrandComponent {
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.2", ngImport: i0, type: CGISkeletonBrandComponent, deps: [], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "20.3.2", type: CGISkeletonBrandComponent, isStandalone: false, selector: "cgi-skeleton", ngImport: i0, template: "<div>\n  <div class=\"cgi-skeleton-heading\"></div>\n  <div class=\"cgi-skeleton-sub-heading\"></div>\n  <div class=\"cgi-skeleton-paragraph\"></div>\n  <div class=\"cgi-skeleton-paragraph\"></div>\n  <div class=\"cgi-skeleton-paragraph\"></div>\n  <div class=\"cgi-skeleton-sub-heading\"></div>\n  <div class=\"cgi-skeleton-paragraph\"></div>\n  <div class=\"cgi-skeleton-paragraph\"></div>\n  <div class=\"cgi-skeleton-paragraph\"></div>\n  <div class=\"cgi-skeleton-sub-heading\"></div>\n  <div class=\"cgi-skeleton-sub-paragraph\"></div>\n  <div class=\"cgi-skeleton-sub-paragraph\"></div>\n  <div class=\"cgi-skeleton-sub-paragraph\"></div>\n</div>\n", styles: [".cgi-skeleton-heading,.cgi-skeleton-sub-heading,.cgi-skeleton-paragraph,.cgi-skeleton-sub-paragraph{animation:loading 1.7s infinite linear;background:#a8a8a8;background-image:-webkit-linear-gradient(90deg,#A8A8A8 7.89%,#e8e8e8 58.9%);background-image:linear-gradient(90deg,#a8a8a8 7.89%,#e8e8e8 58.9%);background-repeat:no-repeat;background-size:65%;margin-bottom:10px;margin-top:10px}.cgi-skeleton-heading{width:50%;height:25px}.cgi-skeleton-sub-heading{width:25%;height:25px}.cgi-skeleton-sub-paragraph{width:75%;height:4px}.cgi-skeleton-paragraph{height:4px}@keyframes loading{0%{background-position:-400%}to{background-position:275% 0}}\n"] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.2", ngImport: i0, type: CGISkeletonBrandComponent, decorators: [{
            type: Component,
            args: [{ selector: 'cgi-skeleton', standalone: false, template: "<div>\n  <div class=\"cgi-skeleton-heading\"></div>\n  <div class=\"cgi-skeleton-sub-heading\"></div>\n  <div class=\"cgi-skeleton-paragraph\"></div>\n  <div class=\"cgi-skeleton-paragraph\"></div>\n  <div class=\"cgi-skeleton-paragraph\"></div>\n  <div class=\"cgi-skeleton-sub-heading\"></div>\n  <div class=\"cgi-skeleton-paragraph\"></div>\n  <div class=\"cgi-skeleton-paragraph\"></div>\n  <div class=\"cgi-skeleton-paragraph\"></div>\n  <div class=\"cgi-skeleton-sub-heading\"></div>\n  <div class=\"cgi-skeleton-sub-paragraph\"></div>\n  <div class=\"cgi-skeleton-sub-paragraph\"></div>\n  <div class=\"cgi-skeleton-sub-paragraph\"></div>\n</div>\n", styles: [".cgi-skeleton-heading,.cgi-skeleton-sub-heading,.cgi-skeleton-paragraph,.cgi-skeleton-sub-paragraph{animation:loading 1.7s infinite linear;background:#a8a8a8;background-image:-webkit-linear-gradient(90deg,#A8A8A8 7.89%,#e8e8e8 58.9%);background-image:linear-gradient(90deg,#a8a8a8 7.89%,#e8e8e8 58.9%);background-repeat:no-repeat;background-size:65%;margin-bottom:10px;margin-top:10px}.cgi-skeleton-heading{width:50%;height:25px}.cgi-skeleton-sub-heading{width:25%;height:25px}.cgi-skeleton-sub-paragraph{width:75%;height:4px}.cgi-skeleton-paragraph{height:4px}@keyframes loading{0%{background-position:-400%}to{background-position:275% 0}}\n"] }]
        }] });

class CGISkeletonBrandModule {
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.2", ngImport: i0, type: CGISkeletonBrandModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule }); }
    static { this.ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "20.3.2", ngImport: i0, type: CGISkeletonBrandModule, declarations: [CGISkeletonBrandComponent], imports: [CommonModule, MatIconModule, MatButtonModule], exports: [CGISkeletonBrandComponent] }); }
    static { this.ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "20.3.2", ngImport: i0, type: CGISkeletonBrandModule, imports: [CommonModule, MatIconModule, MatButtonModule] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.2", ngImport: i0, type: CGISkeletonBrandModule, decorators: [{
            type: NgModule,
            args: [{
                    imports: [CommonModule, MatIconModule, MatButtonModule],
                    declarations: [CGISkeletonBrandComponent],
                    exports: [CGISkeletonBrandComponent],
                    providers: [],
                }]
        }] });

/**
 * Toaster component.
 *
 * TODO: How to use component and examples.
 */
class CGIToasterBrandComponent {
    /**
     * Constructor injecting custom snack bar detail for customization
     * @param data for what to display to the user
     * @param snackBarRef Reference to the MatSnackbar of the toaster component
     */
    constructor(data, snackBarRef) {
        this.data = data;
        this.snackBarRef = snackBarRef;
        /** Boolean for specifying if the toaster has a header */
        this.hasHeader = false;
        this.isClassContainer = true;
    }
    /**
     * Life cycle hook for when the component is first initiated.
     */
    ngOnInit() {
        if (this.data.header != null) {
            this.hasHeader = true;
        }
        this.setType();
    }
    /** Method that sets the icon for the type of alert */
    setType() {
        const type = this.data.type;
        if (type === 'cgi-toaster-warning') {
            this.icon = 'info_i';
        }
        else if (type === 'cgi-toaster-success') {
            this.icon = 'check';
        }
        else if (type === 'cgi-toaster-error') {
            this.icon = 'info_i';
        }
        else {
            this.icon = 'info_i';
        }
    }
    /** close method will dismiss snackbar notification */
    close() {
        this.snackBarRef.dismiss();
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.2", ngImport: i0, type: CGIToasterBrandComponent, deps: [{ token: MAT_SNACK_BAR_DATA }, { token: i1$4.MatSnackBarRef }], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "20.3.2", type: CGIToasterBrandComponent, isStandalone: false, selector: "cgi-toaster", host: { properties: { "class.cgi-toaster": "this.isClassContainer" } }, ngImport: i0, template: "<div class=\"cgi-toaster__content\">\n  <div class=\"cgi-toaster__icon\">\n    <mat-icon class=\"material-symbols-outlined\">{{ icon }}</mat-icon>\n  </div>\n  <div>\n    <h5 class=\"cgi-display-5\" *ngIf=\"hasHeader\">{{ data.header }}</h5>\n    <div class=\"cgi-toaster__message\" [innerHTML]=\"data.message\"></div>\n  </div>\n</div>\n<span class=\"cgi-toaster__spacer\"></span>\n<button *ngIf=\"!data.action\" mat-icon-button (click)=\"close()\" aria-label=\"Close Alert\">\n  <mat-icon class=\"material-icons-outlined\">close</mat-icon>\n</button>\n<button *ngIf=\"data.action\" mat-button (click)=\"close()\" [attr.aria-label]=\"data.customAction\">\n  {{ data.action }}\n</button>", styles: [":host(.cgi-toaster){align-items:center;display:flex;font-family:Source Sans Pro,sans-serif;font-size:14px;font-weight:700;line-height:1.5em;gap:16px;padding:16px}:host(.cgi-toaster) .cgi-toaster__content{display:flex;gap:16px}:host(.cgi-toaster) .cgi-toaster__icon{border-radius:50%;color:#fff;flex-shrink:0;height:24px;width:24px}:host(.cgi-toaster) .cgi-toaster__icon ::ng-deep mat-icon{align-items:center;display:flex;justify-content:center;font-size:20px}:host(.cgi-toaster) .cgi-toaster__header{align-items:center;display:flex;font-size:16px}:host(.cgi-toaster) .cgi-toaster__message{align-items:center;font-weight:400;font-size:16px}:host(.cgi-toaster) .cgi-toaster__spacer{flex:1 1 auto}:host(.cgi-toaster) .mat-mdc-icon-button{height:24px;line-height:25px;width:24px}:host(.cgi-toaster) .mat-mdc-icon-button ::ng-deep mat-icon{color:#3c3f40;font-size:24px}:host(.cgi-toaster) .mat-mdc-button{flex-shrink:0}\n"], dependencies: [{ kind: "directive", type: i1.NgIf, selector: "[ngIf]", inputs: ["ngIf", "ngIfThen", "ngIfElse"] }, { kind: "component", type: i5.MatIcon, selector: "mat-icon", inputs: ["color", "inline", "svgIcon", "fontSet", "fontIcon"], exportAs: ["matIcon"] }, { kind: "component", type: i4.MatButton, selector: "    button[matButton], a[matButton], button[mat-button], button[mat-raised-button],    button[mat-flat-button], button[mat-stroked-button], a[mat-button], a[mat-raised-button],    a[mat-flat-button], a[mat-stroked-button]  ", inputs: ["matButton"], exportAs: ["matButton", "matAnchor"] }, { kind: "component", type: i4.MatIconButton, selector: "button[mat-icon-button], a[mat-icon-button], button[matIconButton], a[matIconButton]", exportAs: ["matButton", "matAnchor"] }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.2", ngImport: i0, type: CGIToasterBrandComponent, decorators: [{
            type: Component,
            args: [{ selector: 'cgi-toaster', standalone: false, template: "<div class=\"cgi-toaster__content\">\n  <div class=\"cgi-toaster__icon\">\n    <mat-icon class=\"material-symbols-outlined\">{{ icon }}</mat-icon>\n  </div>\n  <div>\n    <h5 class=\"cgi-display-5\" *ngIf=\"hasHeader\">{{ data.header }}</h5>\n    <div class=\"cgi-toaster__message\" [innerHTML]=\"data.message\"></div>\n  </div>\n</div>\n<span class=\"cgi-toaster__spacer\"></span>\n<button *ngIf=\"!data.action\" mat-icon-button (click)=\"close()\" aria-label=\"Close Alert\">\n  <mat-icon class=\"material-icons-outlined\">close</mat-icon>\n</button>\n<button *ngIf=\"data.action\" mat-button (click)=\"close()\" [attr.aria-label]=\"data.customAction\">\n  {{ data.action }}\n</button>", styles: [":host(.cgi-toaster){align-items:center;display:flex;font-family:Source Sans Pro,sans-serif;font-size:14px;font-weight:700;line-height:1.5em;gap:16px;padding:16px}:host(.cgi-toaster) .cgi-toaster__content{display:flex;gap:16px}:host(.cgi-toaster) .cgi-toaster__icon{border-radius:50%;color:#fff;flex-shrink:0;height:24px;width:24px}:host(.cgi-toaster) .cgi-toaster__icon ::ng-deep mat-icon{align-items:center;display:flex;justify-content:center;font-size:20px}:host(.cgi-toaster) .cgi-toaster__header{align-items:center;display:flex;font-size:16px}:host(.cgi-toaster) .cgi-toaster__message{align-items:center;font-weight:400;font-size:16px}:host(.cgi-toaster) .cgi-toaster__spacer{flex:1 1 auto}:host(.cgi-toaster) .mat-mdc-icon-button{height:24px;line-height:25px;width:24px}:host(.cgi-toaster) .mat-mdc-icon-button ::ng-deep mat-icon{color:#3c3f40;font-size:24px}:host(.cgi-toaster) .mat-mdc-button{flex-shrink:0}\n"] }]
        }], ctorParameters: () => [{ type: undefined, decorators: [{
                    type: Inject,
                    args: [MAT_SNACK_BAR_DATA]
                }] }, { type: i1$4.MatSnackBarRef }], propDecorators: { isClassContainer: [{
                type: HostBinding,
                args: ['class.cgi-toaster']
            }] } });

class CGIToasterBrandModule {
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.2", ngImport: i0, type: CGIToasterBrandModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule }); }
    static { this.ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "20.3.2", ngImport: i0, type: CGIToasterBrandModule, declarations: [CGIToasterBrandComponent], imports: [CommonModule, MatIconModule, MatButtonModule], exports: [CGIToasterBrandComponent] }); }
    static { this.ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "20.3.2", ngImport: i0, type: CGIToasterBrandModule, imports: [CommonModule, MatIconModule, MatButtonModule] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.2", ngImport: i0, type: CGIToasterBrandModule, decorators: [{
            type: NgModule,
            args: [{
                    imports: [CommonModule, MatIconModule, MatButtonModule],
                    declarations: [CGIToasterBrandComponent],
                    exports: [CGIToasterBrandComponent],
                    providers: [],
                }]
        }] });

/** Presentational component for entry avatar */
class CGITimelineEntryAvatarBrandComponent {
    /** Empty constructor */
    constructor() { }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.2", ngImport: i0, type: CGITimelineEntryAvatarBrandComponent, deps: [], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "20.3.2", type: CGITimelineEntryAvatarBrandComponent, isStandalone: false, selector: "cgi-timeline-entry-avatar", ngImport: i0, template: "<div mat-card-avatar class=\"cgi-timeline-entry-avatar\">\n  <ng-content></ng-content>\n</div>\n", styles: [".cgi-timeline-entry-avatar{background:#006f95;color:#fff;line-height:2.5em;margin-left:-15px;margin-right:15px;text-align:center;vertical-align:middle}\n"], dependencies: [{ kind: "directive", type: i1$5.MatCardAvatar, selector: "[mat-card-avatar], [matCardAvatar]" }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.2", ngImport: i0, type: CGITimelineEntryAvatarBrandComponent, decorators: [{
            type: Component,
            args: [{ selector: 'cgi-timeline-entry-avatar', standalone: false, template: "<div mat-card-avatar class=\"cgi-timeline-entry-avatar\">\n  <ng-content></ng-content>\n</div>\n", styles: [".cgi-timeline-entry-avatar{background:#006f95;color:#fff;line-height:2.5em;margin-left:-15px;margin-right:15px;text-align:center;vertical-align:middle}\n"] }]
        }], ctorParameters: () => [] });

/** Presentational Component for entry body */
class CGITimelineEntryBodyBrandComponent {
    /** Empty constructor */
    constructor() { }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.2", ngImport: i0, type: CGITimelineEntryBodyBrandComponent, deps: [], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "20.3.2", type: CGITimelineEntryBodyBrandComponent, isStandalone: false, selector: "cgi-timeline-entry-body", ngImport: i0, template: "<mat-card-subtitle>\n  <ng-content></ng-content>\n</mat-card-subtitle>\n", styles: [":host{margin-top:-8px}:host mat-card-subtitle{font-size:12px;margin-bottom:0}\n"], dependencies: [{ kind: "directive", type: i1$5.MatCardSubtitle, selector: "mat-card-subtitle, [mat-card-subtitle], [matCardSubtitle]" }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.2", ngImport: i0, type: CGITimelineEntryBodyBrandComponent, decorators: [{
            type: Component,
            args: [{ selector: 'cgi-timeline-entry-body', standalone: false, template: "<mat-card-subtitle>\n  <ng-content></ng-content>\n</mat-card-subtitle>\n", styles: [":host{margin-top:-8px}:host mat-card-subtitle{font-size:12px;margin-bottom:0}\n"] }]
        }], ctorParameters: () => [] });

/** Presentational component for timeline entry icon */
class CGITimelineEntryIconBrandComponent {
    /** Empty constructor */
    constructor() { }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.2", ngImport: i0, type: CGITimelineEntryIconBrandComponent, deps: [], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "20.3.2", type: CGITimelineEntryIconBrandComponent, isStandalone: false, selector: "cgi-timeline-entry-icon", ngImport: i0, template: "<ng-content></ng-content>\n", styles: [":host{background:#a5acb0;border-radius:50%;border-style:solid;color:#fff;height:2.375em;left:100%;margin-left:-22px;position:absolute;text-align:center;top:12px;width:38px}:host ::ng-deep mat-icon{line-height:1.6em}\n"] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.2", ngImport: i0, type: CGITimelineEntryIconBrandComponent, decorators: [{
            type: Component,
            args: [{ selector: 'cgi-timeline-entry-icon', standalone: false, template: "<ng-content></ng-content>\n", styles: [":host{background:#a5acb0;border-radius:50%;border-style:solid;color:#fff;height:2.375em;left:100%;margin-left:-22px;position:absolute;text-align:center;top:12px;width:38px}:host ::ng-deep mat-icon{line-height:1.6em}\n"] }]
        }], ctorParameters: () => [] });

/** Presentational component for timeline entry title */
class CGITimelineEntryTitleBrandComponent {
    /** Empty constructor */
    constructor() { }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.2", ngImport: i0, type: CGITimelineEntryTitleBrandComponent, deps: [], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "20.3.2", type: CGITimelineEntryTitleBrandComponent, isStandalone: false, selector: "cgi-timeline-entry-title", ngImport: i0, template: "<mat-card-title>\n  <ng-content></ng-content>\n</mat-card-title>\n", styles: [""], dependencies: [{ kind: "directive", type: i1$5.MatCardTitle, selector: "mat-card-title, [mat-card-title], [matCardTitle]" }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.2", ngImport: i0, type: CGITimelineEntryTitleBrandComponent, decorators: [{
            type: Component,
            args: [{ selector: 'cgi-timeline-entry-title', standalone: false, template: "<mat-card-title>\n  <ng-content></ng-content>\n</mat-card-title>\n" }]
        }], ctorParameters: () => [] });

/** Presentational component to represent unit of timeline entry */
class CGITimelineEntryBrandComponent {
    /** Empty constructor */
    constructor() {
        /** whether the timeline entry is inverted */
        this._inverted = false;
    }
    /** Value of the inverted property. */
    get inverted() {
        return this._inverted;
    }
    /** Set value of the inverted property. */
    set inverted(value) {
        const transformedBool = value === 'true' || value === '';
        if (transformedBool) {
            this._inverted = transformedBool;
        }
        else {
            this._inverted = false;
        }
    }
    /** ngoninignitninitnit */
    ngOnInit() { }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.2", ngImport: i0, type: CGITimelineEntryBrandComponent, deps: [], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "20.3.2", type: CGITimelineEntryBrandComponent, isStandalone: false, selector: "cgi-timeline-entry", inputs: { inverted: "inverted" }, ngImport: i0, template: "<li [ngClass]=\"{ 'timeline-inverted': inverted }\">\n  <ng-content select=\"cgi-timeline-entry-icon\"></ng-content>\n  <div class=\"timeline-entry\">\n    <mat-card appearance=\"outlined\">\n      <mat-card-header>\n        <ng-content select=\"cgi-timeline-entry-avatar\"></ng-content>\n        <div class=\"cgi-timeline-entry-text\">\n          <ng-content select=\"cgi-timeline-entry-title\"></ng-content>\n          <ng-content select=\"cgi-timeline-entry-body\"></ng-content>\n        </div>\n      </mat-card-header>\n    </mat-card>\n    <!--end .card -->\n  </div>\n  <!--end .timeline-entry -->\n</li>\n", styles: [".cgi-vertical-spacer-1{height:2rem;width:100%}.cgi-vertical-spacer-2{height:4rem;width:100%}.cgi-vertical-spacer-3{height:6rem;width:100%}.cgi-vertical-spacer-4{height:8rem;width:100%}.cgi-vertical-spacer-5{height:10rem;width:100%}.cgi-vertical-spacer-6{height:12rem;width:100%}.cgi-vertical-spacer-7{height:14rem;width:100%}.cgi-vertical-spacer-8{height:16rem;width:100%}.cgi-vertical-spacer-9{height:18rem;width:100%}.cgi-vertical-spacer-10{height:20rem;width:100%}:host li{display:block;left:-50%;position:relative;width:50%}:host mat-card{border-radius:12px!important;box-shadow:0 0 10px #00001933!important;padding:15px!important}.cgi-timeline-entry-text{display:flex;flex-direction:column}.timeline-entry{display:inline-block;position:relative;width:100%}.timeline-entry mat-card{margin-right:26px}.timeline-entry mat-card:before{border-color:transparent transparent transparent #000019;border-style:solid;border-width:7px 0 7px 7px;content:\"\";height:0;position:absolute;right:-7px;top:26px;width:0}.timeline-entry mat-card:after{border-color:transparent transparent transparent #ffffff;border-style:solid;border-width:7px 0 7px 7px;content:\"\";height:0;position:absolute;right:-7px;top:26px;width:0}.timeline-inverted .timeline-entry{left:100%}.timeline-inverted .timeline-entry mat-card{margin-left:30px;margin-right:0}.timeline-inverted .timeline-entry mat-card:before{border-color:transparent transparent transparent #000019;border-style:solid;border-width:7px 0 7px 7px;content:\"\";height:0;left:-7px;position:absolute;right:-7px;top:26px;transform:rotate(-180deg);width:0}.timeline-inverted .timeline-entry mat-card:after{border-color:transparent transparent transparent #ffffff;border-style:solid;border-width:7px 0 7px 7px;content:\"\";height:0;left:-7px;position:absolute;right:-7px;top:26px;transform:rotate(-180deg);width:0}\n"], dependencies: [{ kind: "directive", type: i1.NgClass, selector: "[ngClass]", inputs: ["class", "ngClass"] }, { kind: "component", type: i1$5.MatCard, selector: "mat-card", inputs: ["appearance"], exportAs: ["matCard"] }, { kind: "component", type: i1$5.MatCardHeader, selector: "mat-card-header" }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.2", ngImport: i0, type: CGITimelineEntryBrandComponent, decorators: [{
            type: Component,
            args: [{ selector: 'cgi-timeline-entry', standalone: false, template: "<li [ngClass]=\"{ 'timeline-inverted': inverted }\">\n  <ng-content select=\"cgi-timeline-entry-icon\"></ng-content>\n  <div class=\"timeline-entry\">\n    <mat-card appearance=\"outlined\">\n      <mat-card-header>\n        <ng-content select=\"cgi-timeline-entry-avatar\"></ng-content>\n        <div class=\"cgi-timeline-entry-text\">\n          <ng-content select=\"cgi-timeline-entry-title\"></ng-content>\n          <ng-content select=\"cgi-timeline-entry-body\"></ng-content>\n        </div>\n      </mat-card-header>\n    </mat-card>\n    <!--end .card -->\n  </div>\n  <!--end .timeline-entry -->\n</li>\n", styles: [".cgi-vertical-spacer-1{height:2rem;width:100%}.cgi-vertical-spacer-2{height:4rem;width:100%}.cgi-vertical-spacer-3{height:6rem;width:100%}.cgi-vertical-spacer-4{height:8rem;width:100%}.cgi-vertical-spacer-5{height:10rem;width:100%}.cgi-vertical-spacer-6{height:12rem;width:100%}.cgi-vertical-spacer-7{height:14rem;width:100%}.cgi-vertical-spacer-8{height:16rem;width:100%}.cgi-vertical-spacer-9{height:18rem;width:100%}.cgi-vertical-spacer-10{height:20rem;width:100%}:host li{display:block;left:-50%;position:relative;width:50%}:host mat-card{border-radius:12px!important;box-shadow:0 0 10px #00001933!important;padding:15px!important}.cgi-timeline-entry-text{display:flex;flex-direction:column}.timeline-entry{display:inline-block;position:relative;width:100%}.timeline-entry mat-card{margin-right:26px}.timeline-entry mat-card:before{border-color:transparent transparent transparent #000019;border-style:solid;border-width:7px 0 7px 7px;content:\"\";height:0;position:absolute;right:-7px;top:26px;width:0}.timeline-entry mat-card:after{border-color:transparent transparent transparent #ffffff;border-style:solid;border-width:7px 0 7px 7px;content:\"\";height:0;position:absolute;right:-7px;top:26px;width:0}.timeline-inverted .timeline-entry{left:100%}.timeline-inverted .timeline-entry mat-card{margin-left:30px;margin-right:0}.timeline-inverted .timeline-entry mat-card:before{border-color:transparent transparent transparent #000019;border-style:solid;border-width:7px 0 7px 7px;content:\"\";height:0;left:-7px;position:absolute;right:-7px;top:26px;transform:rotate(-180deg);width:0}.timeline-inverted .timeline-entry mat-card:after{border-color:transparent transparent transparent #ffffff;border-style:solid;border-width:7px 0 7px 7px;content:\"\";height:0;left:-7px;position:absolute;right:-7px;top:26px;transform:rotate(-180deg);width:0}\n"] }]
        }], ctorParameters: () => [], propDecorators: { inverted: [{
                type: Input
            }] } });

/** Presentational container for timeline */
class CGITimelineBrandComponent {
    /** Empty constructor */
    constructor() { }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.2", ngImport: i0, type: CGITimelineBrandComponent, deps: [], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "20.3.2", type: CGITimelineBrandComponent, isStandalone: false, selector: "cgi-timeline", ngImport: i0, template: "<!-- BEGIN RESPONSIVE TIMELINE -->\n<ul class=\"timeline collapse-md\">\n  <ng-content></ng-content>\n</ul>\n<!-- END RESPONSIVE TIMELINE -->\n", styles: [".cgi-vertical-spacer-1{height:2rem;width:100%}.cgi-vertical-spacer-2{height:4rem;width:100%}.cgi-vertical-spacer-3{height:6rem;width:100%}.cgi-vertical-spacer-4{height:8rem;width:100%}.cgi-vertical-spacer-5{height:10rem;width:100%}.cgi-vertical-spacer-6{height:12rem;width:100%}.cgi-vertical-spacer-7{height:14rem;width:100%}.cgi-vertical-spacer-8{height:16rem;width:100%}.cgi-vertical-spacer-9{height:18rem;width:100%}.cgi-vertical-spacer-10{height:20rem;width:100%}.timeline{left:50%;padding:20px 0 0;position:relative}.timeline:before{background-color:#000019;bottom:0;content:\" \";left:0;margin-left:-2px;opacity:.15;position:absolute;top:0;width:4px}\n"] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.2", ngImport: i0, type: CGITimelineBrandComponent, decorators: [{
            type: Component,
            args: [{ selector: 'cgi-timeline', standalone: false, template: "<!-- BEGIN RESPONSIVE TIMELINE -->\n<ul class=\"timeline collapse-md\">\n  <ng-content></ng-content>\n</ul>\n<!-- END RESPONSIVE TIMELINE -->\n", styles: [".cgi-vertical-spacer-1{height:2rem;width:100%}.cgi-vertical-spacer-2{height:4rem;width:100%}.cgi-vertical-spacer-3{height:6rem;width:100%}.cgi-vertical-spacer-4{height:8rem;width:100%}.cgi-vertical-spacer-5{height:10rem;width:100%}.cgi-vertical-spacer-6{height:12rem;width:100%}.cgi-vertical-spacer-7{height:14rem;width:100%}.cgi-vertical-spacer-8{height:16rem;width:100%}.cgi-vertical-spacer-9{height:18rem;width:100%}.cgi-vertical-spacer-10{height:20rem;width:100%}.timeline{left:50%;padding:20px 0 0;position:relative}.timeline:before{background-color:#000019;bottom:0;content:\" \";left:0;margin-left:-2px;opacity:.15;position:absolute;top:0;width:4px}\n"] }]
        }], ctorParameters: () => [] });

class CGITimelineBrandModule {
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.2", ngImport: i0, type: CGITimelineBrandModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule }); }
    static { this.ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "20.3.2", ngImport: i0, type: CGITimelineBrandModule, declarations: [CGITimelineBrandComponent,
            CGITimelineEntryBrandComponent,
            CGITimelineEntryTitleBrandComponent,
            CGITimelineEntryIconBrandComponent,
            CGITimelineEntryBodyBrandComponent,
            CGITimelineEntryAvatarBrandComponent], imports: [CommonModule, MatIconModule, MatCardModule], exports: [CGITimelineBrandComponent,
            CGITimelineEntryBrandComponent,
            CGITimelineEntryTitleBrandComponent,
            CGITimelineEntryIconBrandComponent,
            CGITimelineEntryBodyBrandComponent,
            CGITimelineEntryAvatarBrandComponent] }); }
    static { this.ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "20.3.2", ngImport: i0, type: CGITimelineBrandModule, imports: [CommonModule, MatIconModule, MatCardModule] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.2", ngImport: i0, type: CGITimelineBrandModule, decorators: [{
            type: NgModule,
            args: [{
                    imports: [CommonModule, MatIconModule, MatCardModule],
                    declarations: [
                        CGITimelineBrandComponent,
                        CGITimelineEntryBrandComponent,
                        CGITimelineEntryTitleBrandComponent,
                        CGITimelineEntryIconBrandComponent,
                        CGITimelineEntryBodyBrandComponent,
                        CGITimelineEntryAvatarBrandComponent,
                    ],
                    exports: [
                        CGITimelineBrandComponent,
                        CGITimelineEntryBrandComponent,
                        CGITimelineEntryTitleBrandComponent,
                        CGITimelineEntryIconBrandComponent,
                        CGITimelineEntryBodyBrandComponent,
                        CGITimelineEntryAvatarBrandComponent,
                    ],
                }]
        }] });

/** Timepicker component */
class CGITimepickerBrandComponent {
    /**
     * Constructor
     */
    constructor(parentFormGroup) {
        this.parentFormGroup = parentFormGroup;
        /** Input type (string): error message for timepicker */
        this.errorMessage = 'Time is required';
        /** Input type (boolean): If component is required */
        this.required = false;
        /** Input type (boolean): If component is disabled */
        this.disabled = false;
        /** Input type (boolean): If component is read-only. When true, only displays the selected period (AM or PM) button */
        this.readonly = false;
        /** Input type (string): Appearance style of the timepicker (fill, outline, legacy, standard) */
        this.appearance = 'outline';
        /** Input type (number): Minimum hour value */
        this.minHour = 1;
        /** Input type (number): Maximum hour value */
        this.maxHour = 12;
        /** Input type (string): Label for hour field */
        this.hourLabel = 'Hr';
        /** Input type (string): Label for minute field */
        this.minuteLabel = 'Min';
        /** Input type (string): Placeholder for hour field */
        this.hourPlaceholder = '00';
        /** Input type (string): Placeholder for minute field */
        this.minutePlaceholder = '00';
        /** Input type (string): Label for AM period */
        this.amLabel = 'AM';
        /** Input type (string): Label for PM period */
        this.pmLabel = 'PM';
        /** Input type (string): Default period (am/pm) when component initializes without setDateTime */
        this.defaultPeriod = 'am';
        /** Output for time */
        this.timeSelected = new EventEmitter();
        /** Output for hour change */
        this.hourChanged = new EventEmitter();
        /** Output for minute change */
        this.minuteChanged = new EventEmitter();
        /** Output for period change */
        this.periodChanged = new EventEmitter();
        /** Variable to determine if form elements are valid */
        this.valid = false;
        /** Autocomplete options for hours */
        this.hours = [];
        /** Autocomplete options for minutes */
        this.minutes = [];
        /** Form Control for hour field */
        this.hourFC = new UntypedFormControl();
        /** Form control for minute field */
        this.minutesFC = new UntypedFormControl();
        /** Form control for AM/PM field */
        this.dayPeriodFC = new UntypedFormControl();
        /** Properties bound to ngModel in template */
        this.selectedHrTime = '';
        this.selectedMinTime = '';
        this.selectedPeriod = 'am';
        /** Input type (boolean): Indicates if the current time violates minTime/maxTime constraints */
        this.isTimeOutOfRange = false;
        /** Input type (string): Error message displayed when time is outside the allowed range */
        this.rangeErrorMessage = '';
        this.isClassContainer = true;
        if (this.parentFormGroup) {
            this.parentForm = this.parentFormGroup;
        }
    }
    ngOnChanges(changes) {
        // Handle setDateTime input changes
        if (changes['setDateTime'] && !changes['setDateTime'].firstChange && changes['setDateTime'].currentValue) {
            console.log('setDateTime changed:', changes['setDateTime'].currentValue);
            this.setTimeFromDateTime(changes['setDateTime'].currentValue);
        }
        // Disable form controls if component is disabled or readonly
        if (this.disabled || this.readonly) {
            this.hourFC.disable();
            this.minutesFC.disable();
            this.dayPeriodFC.disable();
            this.valid = true;
        }
        else if (!this.disabled || !this.readonly) {
            this.hourFC.enable();
            this.minutesFC.enable();
            this.dayPeriodFC.enable();
            this.valid = true;
        }
    }
    /**
     * Initialize time arrays based on dynamic configuration
     */
    initializeTimeArrays() {
        // Generate hours for 12-hour format
        this.hours = this.generateArray(this.minHour, this.maxHour);
        // Generate minutes (0-59)
        this.minutes = this.generateArray(0, 59);
        // Apply default values if set and no setDateTime provided
        if (!this.setDateTime && (this.defaultHour !== undefined || this.defaultMinute !== undefined)) {
            this.applyDefaultTime();
        }
    }
    /**
     * Generate array for autocomplete options
     */
    generateArray(start, length) {
        const array = [];
        for (let i = start; i <= length; i++) {
            if (i < 10) {
                const value = '0' + i.toString();
                array.push(value);
            }
            else {
                array.push(i.toString());
            }
        }
        return array;
    }
    /**
     * Apply default time values
     */
    applyDefaultTime() {
        if (this.defaultHour !== undefined) {
            const hourStr = this.defaultHour < 10 ? '0' + this.defaultHour : this.defaultHour.toString();
            this.hourFC.setValue(hourStr);
            this.selectedHrTime = hourStr;
        }
        if (this.defaultMinute !== undefined) {
            const minuteStr = this.defaultMinute < 10 ? '0' + this.defaultMinute : this.defaultMinute.toString();
            this.minutesFC.setValue(minuteStr);
            this.selectedMinTime = minuteStr;
        }
        if (this.defaultPeriod) {
            this.dayPeriodFC.setValue(this.defaultPeriod);
            this.selectedPeriod = this.defaultPeriod;
        }
        this.updateTime();
    }
    /**
     * Set time from a Date object, string, or number
     * Converts the input to a Date object and extracts the time portion
     * Handles 12-hour format conversion with AM/PM period
     * @param dateTime - Date object, ISO string, timestamp, or any valid Date constructor input
     */
    setTimeFromDateTime(dateTime) {
        // Convert to Date object if needed
        let date;
        if (dateTime instanceof Date) {
            date = dateTime;
        }
        else if (typeof dateTime === 'string' || typeof dateTime === 'number') {
            date = new Date(dateTime);
        }
        else {
            console.error('Invalid dateTime value:', dateTime);
            return;
        }
        // Validate the date is valid
        if (isNaN(date.getTime())) {
            console.error('Invalid date:', dateTime);
            return;
        }
        let hour = date.getHours();
        const minutes = date.getMinutes();
        const minuteStr = minutes < 10 ? '0' + minutes : minutes.toString();
        this.minutesFC.setValue(minuteStr);
        this.selectedMinTime = minuteStr;
        // If given dateTime is midnight
        if (hour === 0) {
            this.hourFC.setValue('12');
            this.selectedHrTime = '12';
            this.dayPeriodFC.setValue('am');
            this.selectedPeriod = 'am';
        }
        // If given dateTime is noon
        else if (hour === 12) {
            this.hourFC.setValue(hour.toString());
            this.selectedHrTime = hour.toString();
            this.dayPeriodFC.setValue('pm');
            this.selectedPeriod = 'pm';
        }
        // If given dateTime is afternoon
        else if (hour > 12) {
            hour = hour - 12;
            const hourStr = hour < 10 ? '0' + hour : hour.toString();
            this.hourFC.setValue(hourStr);
            this.selectedHrTime = hourStr;
            this.dayPeriodFC.setValue('pm');
            this.selectedPeriod = 'pm';
        }
        // If given dateTime is morning
        else {
            const hourStr = hour < 10 ? '0' + hour : hour.toString();
            this.hourFC.setValue(hourStr);
            this.selectedHrTime = hourStr;
            this.dayPeriodFC.setValue('am');
            this.selectedPeriod = 'am';
        }
        this.valid = true;
    }
    /**
     * Initialization block when component is loaded
     */
    ngOnInit() {
        // Initialize hour and minute arrays based on format and step
        this.initializeTimeArrays();
        // Set time if given a date
        if (this.setDateTime) {
            this.setTimeFromDateTime(this.setDateTime);
        }
        // Disable form controls if component is disabled or readonly
        if (this.disabled || this.readonly) {
            this.hourFC.disable();
            this.minutesFC.disable();
            this.dayPeriodFC.disable();
            this.valid = true;
        }
    }
    /**
     * Private function: filter autocomplete lists
     */
    filterList(value, list) {
        return list.filter((option) => option.toLowerCase().includes(value));
    }
    /**
     * Updates the timepicker and emits time-related events
     * - Validates and constrains hour input within minHour/maxHour range
     * - Validates and constrains minute input within 0-59 range
     * - Checks time against minTime/maxTime constraints
     * - Preserves the date portion from setDateTime input if provided, otherwise uses current date
     * - Emits hourChanged, minuteChanged, periodChanged, and timeSelected events
     * - Auto-corrects invalid times to nearest valid boundary
     */
    updateTime() {
        let time;
        let hour;
        let min;
        // Restrict hour input within limit (12-hour format)
        if (this.hourFC.value === '' || this.hourFC.value === null) {
            this.hourFC.setValue('');
            this.selectedHrTime = '';
            hour = null;
        }
        else {
            const max = this.maxHour;
            const min = this.minHour;
            if (this.hourFC.value > max) {
                this.hourFC.setValue(max);
                this.selectedHrTime = max.toString();
                hour = max;
            }
            else if (this.hourFC.value < min) {
                this.hourFC.setValue(min);
                this.selectedHrTime = min.toString();
                hour = min;
            }
            else {
                hour = Number(this.hourFC.value);
                this.selectedHrTime = this.hourFC.value;
            }
        }
        // Emit hour change
        if (hour !== null) {
            this.hourChanged.emit(hour);
        }
        // Restrict minutes input within limit (0-59)
        if (this.minutesFC.value === '' || this.minutesFC.value === null) {
            this.minutesFC.setValue('');
            this.selectedMinTime = '';
            min = null;
        }
        else if (this.minutesFC.value > 59) {
            this.minutesFC.setValue('59');
            this.selectedMinTime = '59';
            min = 59;
        }
        else if (this.minutesFC.value <= 0) {
            this.minutesFC.setValue('00');
            this.selectedMinTime = '00';
            min = 0;
        }
        else if (this.minutesFC.value < 10 && this.minutesFC.value > 0) {
            const value = this.minutesFC.value.toString();
            const paddedValue = value.padStart(2, '0');
            this.minutesFC.setValue(paddedValue);
            this.selectedMinTime = paddedValue;
            min = Number(this.minutesFC.value);
        }
        else {
            min = Number(this.minutesFC.value);
            this.selectedMinTime = this.minutesFC.value;
        }
        // Emit minute change
        if (min !== null) {
            this.minuteChanged.emit(min);
        }
        // Check if time is within min/max constraints
        const isTimeValid = this.validateTimeRange(hour, min);
        if (!isTimeValid) {
            this.valid = false;
            return;
        }
        // Only update time when all required fields are populated
        if (this.hourFC.value != null && this.minutesFC.value != null && this.dayPeriodFC.value != null) {
            // Use the original date from setDateTime if provided, otherwise use current date
            let time;
            if (this.setDateTime) {
                // Preserve the date portion from setDateTime
                time = new Date(this.setDateTime);
            }
            else {
                // Use current date
                time = new Date();
            }
            // Emit period change
            this.periodChanged.emit(this.dayPeriodFC.value);
            // Case 1: it is 12 AM
            if (this.hourFC.value == 12 && this.dayPeriodFC.value === 'am') {
                time.setHours(0, min, 0, 0);
                this.timeSelected.emit(time);
                this.valid = true;
            }
            // Case 2: it is between 12PM to 12AM
            else if (this.dayPeriodFC.value === 'pm' && this.hourFC.value != 12) {
                time.setHours(hour + 12, min, 0, 0);
                this.timeSelected.emit(time);
                this.valid = true;
            }
            // Case 3: it is between 12AM to 12PM
            else {
                time.setHours(hour, min, 0, 0);
                this.timeSelected.emit(time);
                this.valid = true;
            }
        }
        else {
            this.valid = false;
        }
    }
    /**
     * Validate if time is within min/max constraints
     * If validation fails, automatically corrects the time to the nearest valid boundary
     * and displays an appropriate error message to the user
     * @param hour - The hour value to validate (in 12-hour format)
     * @param min - The minute value to validate (0-59)
     * @returns boolean - true if time is valid, false if time was corrected
     */
    validateTimeRange(hour, min) {
        if (!this.minTime && !this.maxTime) {
            this.isTimeOutOfRange = false;
            this.rangeErrorMessage = '';
            return true;
        }
        if (hour === null || min === null) {
            return true;
        }
        const currentTime = new Date();
        let checkHour = hour;
        // Convert to 24-hour for comparison (12-hour format)
        if (this.dayPeriodFC.value) {
            if (this.dayPeriodFC.value === 'pm' && hour !== 12) {
                checkHour = hour + 12;
            }
            else if (this.dayPeriodFC.value === 'am' && hour === 12) {
                checkHour = 0;
            }
        }
        currentTime.setHours(checkHour, min, 0, 0);
        if (this.minTime) {
            const minCompare = new Date();
            minCompare.setHours(this.minTime.getHours(), this.minTime.getMinutes(), 0, 0);
            if (currentTime < minCompare) {
                this.isTimeOutOfRange = true;
                const minHour12 = this.minTime.getHours() > 12 ? this.minTime.getHours() - 12 : (this.minTime.getHours() === 0 ? 12 : this.minTime.getHours());
                const minPeriod = this.minTime.getHours() >= 12 ? 'PM' : 'AM';
                const maxHour12 = this.maxTime ? (this.maxTime.getHours() > 12 ? this.maxTime.getHours() - 12 : (this.maxTime.getHours() === 0 ? 12 : this.maxTime.getHours())) : null;
                const maxPeriod = this.maxTime ? (this.maxTime.getHours() >= 12 ? 'PM' : 'AM') : null;
                this.rangeErrorMessage = maxHour12 ?
                    `Time must be between ${minHour12}:${this.minTime.getMinutes().toString().padStart(2, '0')} ${minPeriod} and ${maxHour12}:${this.maxTime.getMinutes().toString().padStart(2, '0')} ${maxPeriod}` :
                    `Time must be after ${minHour12}:${this.minTime.getMinutes().toString().padStart(2, '0')} ${minPeriod}`;
                this.correctToMinTime();
                return false;
            }
        }
        if (this.maxTime) {
            const maxCompare = new Date();
            maxCompare.setHours(this.maxTime.getHours(), this.maxTime.getMinutes(), 0, 0);
            if (currentTime > maxCompare) {
                this.isTimeOutOfRange = true;
                const maxHour12 = this.maxTime.getHours() > 12 ? this.maxTime.getHours() - 12 : (this.maxTime.getHours() === 0 ? 12 : this.maxTime.getHours());
                const maxPeriod = this.maxTime.getHours() >= 12 ? 'PM' : 'AM';
                const minHour12 = this.minTime ? (this.minTime.getHours() > 12 ? this.minTime.getHours() - 12 : (this.minTime.getHours() === 0 ? 12 : this.minTime.getHours())) : null;
                const minPeriod = this.minTime ? (this.minTime.getHours() >= 12 ? 'PM' : 'AM') : null;
                this.rangeErrorMessage = minHour12 ?
                    `Time must be between ${minHour12}:${this.minTime.getMinutes().toString().padStart(2, '0')} ${minPeriod} and ${maxHour12}:${this.maxTime.getMinutes().toString().padStart(2, '0')} ${maxPeriod}` :
                    `Time must be before ${maxHour12}:${this.maxTime.getMinutes().toString().padStart(2, '0')} ${maxPeriod}`;
                this.correctToMaxTime();
                return false;
            }
        }
        this.isTimeOutOfRange = false;
        this.rangeErrorMessage = '';
        return true;
    }
    /**
     * Correct time to minimum allowed time
     * Automatically adjusts hour, minute, and period (AM/PM) to match the minTime constraint
     * Converts 24-hour format from minTime to 12-hour format for display
     * Updates both form controls and ngModel properties for bidirectional binding
     */
    correctToMinTime() {
        if (!this.minTime)
            return;
        const minHour24 = this.minTime.getHours();
        const minMinute = this.minTime.getMinutes();
        // Convert to 12-hour format
        let hour12;
        let period;
        if (minHour24 === 0) {
            hour12 = 12;
            period = 'am';
        }
        else if (minHour24 < 12) {
            hour12 = minHour24;
            period = 'am';
        }
        else if (minHour24 === 12) {
            hour12 = 12;
            period = 'pm';
        }
        else {
            hour12 = minHour24 - 12;
            period = 'pm';
        }
        // Update form controls and ngModel properties
        this.hourFC.setValue(hour12.toString().padStart(2, '0'));
        this.selectedHrTime = hour12.toString().padStart(2, '0');
        this.minutesFC.setValue(minMinute.toString().padStart(2, '0'));
        this.selectedMinTime = minMinute.toString().padStart(2, '0');
        this.dayPeriodFC.setValue(period);
        this.selectedPeriod = period;
        // Clear error after correction
        setTimeout(() => {
            this.isTimeOutOfRange = false;
            this.rangeErrorMessage = '';
        }, 2000);
    }
    /**
     * Correct time to maximum allowed time
     * Automatically adjusts hour, minute, and period (AM/PM) to match the maxTime constraint
     * Converts 24-hour format from maxTime to 12-hour format for display
     * Updates both form controls and ngModel properties for bidirectional binding
     */
    correctToMaxTime() {
        if (!this.maxTime)
            return;
        const maxHour24 = this.maxTime.getHours();
        const maxMinute = this.maxTime.getMinutes();
        // Convert to 12-hour format
        let hour12;
        let period;
        if (maxHour24 === 0) {
            hour12 = 12;
            period = 'am';
        }
        else if (maxHour24 < 12) {
            hour12 = maxHour24;
            period = 'am';
        }
        else if (maxHour24 === 12) {
            hour12 = 12;
            period = 'pm';
        }
        else {
            hour12 = maxHour24 - 12;
            period = 'pm';
        }
        // Update form controls and ngModel properties
        this.hourFC.setValue(hour12.toString().padStart(2, '0'));
        this.selectedHrTime = hour12.toString().padStart(2, '0');
        this.minutesFC.setValue(maxMinute.toString().padStart(2, '0'));
        this.selectedMinTime = maxMinute.toString().padStart(2, '0');
        this.dayPeriodFC.setValue(period);
        this.selectedPeriod = period;
        // Clear error after correction
        setTimeout(() => {
            this.isTimeOutOfRange = false;
            this.rangeErrorMessage = '';
        }, 2000);
    }
    /** Get function that returns if form elements in component are valid */
    getValidity() {
        if (!this.required) {
            this.valid = true;
        }
        return this.valid;
    }
    /**
     * Handle hour input change from template (on every keystroke)
     * Updates both the FormControl and ngModel property without triggering validation
     * Validation occurs only on blur to allow complete input
     * @param event - The input value from the hour field
     */
    onHrTimeChange(event) {
        this.hourFC.setValue(event);
        this.selectedHrTime = event;
        // Don't validate on every keystroke, only on blur
    }
    /**
     * Handle hour input blur event
     * Triggers validation and time update only when user leaves the field
     * This approach prevents premature validation during typing (e.g., typing "09" won't validate after "0")
     */
    onHrBlur() {
        this.updateTime();
    }
    /**
     * Handle minute input change from template (on every keystroke)
     * Updates both the FormControl and ngModel property without triggering validation
     * Validation occurs only on blur to allow complete input
     * @param event - The input value from the minute field
     */
    onMinTimeChange(event) {
        this.minutesFC.setValue(event);
        this.selectedMinTime = event;
        // Don't validate on every keystroke, only on blur
    }
    /**
     * Handle minute input blur event
     * Triggers validation and time update only when user leaves the field
     * This approach prevents premature validation during typing (e.g., typing "09" won't validate after "0")
     */
    onMinBlur() {
        this.updateTime();
    }
    /**
     * Handle period (AM/PM) change from template
     * Updates the period FormControl and immediately triggers time validation and update
     * Period changes are validated immediately (not on blur) since they come from button toggles
     * @param event - The MatButtonToggleChange event containing the selected period value
     */
    onPeriodChange(event) {
        this.dayPeriodFC.setValue(event.value);
        this.selectedPeriod = event.value;
        this.updateTime();
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.2", ngImport: i0, type: CGITimepickerBrandComponent, deps: [{ token: i1$2.FormGroupDirective }], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "20.3.2", type: CGITimepickerBrandComponent, isStandalone: false, selector: "cgi-timepicker-brand", inputs: { setDateTime: "setDateTime", errorMessage: "errorMessage", required: "required", disabled: "disabled", readonly: "readonly", appearance: "appearance", minHour: "minHour", maxHour: "maxHour", hourLabel: "hourLabel", minuteLabel: "minuteLabel", hourPlaceholder: "hourPlaceholder", minutePlaceholder: "minutePlaceholder", amLabel: "amLabel", pmLabel: "pmLabel", minTime: "minTime", maxTime: "maxTime", defaultHour: "defaultHour", defaultMinute: "defaultMinute", defaultPeriod: "defaultPeriod" }, outputs: { timeSelected: "timeSelected", hourChanged: "hourChanged", minuteChanged: "minuteChanged", periodChanged: "periodChanged" }, host: { properties: { "class.cgi-timepicker": "this.isClassContainer" } }, usesOnChanges: true, ngImport: i0, template: "<div class=\"time-input-group d-flex\">\n  <div class=\"time-input-item\">\n    <mat-form-field class=\"mat-form-field-time custom-placeholder\" [appearance]=\"appearance\" [ngClass]=\"{\n              'cgi-forms-readonly': readonly,\n              'mat-form-field-invalid':\n                (hourFC.touched && !hourFC.valid) || (minutesFC.touched && !minutesFC.valid)\n            }\" [attr.aria-label]=\"hourLabel\">\n      <input matInput [(ngModel)]=\"selectedHrTime\" [placeholder]=\"hourPlaceholder\" maxlength=\"2\"\n        (ngModelChange)=\"onHrTimeChange($event)\" (blur)=\"onHrBlur()\" class=\"time_picker\" [disabled]=\"disabled\" [readonly]=\"readonly\" />\n    </mat-form-field>\n    <span class=\"time-input-separator\">&nbsp;:&nbsp;</span>\n    <mat-form-field class=\"mat-form-field-time custom-placeholder\" [appearance]=\"appearance\" [ngClass]=\"{\n              'cgi-forms-readonly': readonly,\n              'mat-form-field-invalid':\n                (hourFC.touched && !hourFC.valid) || (minutesFC.touched && !minutesFC.valid)\n            }\" [attr.aria-label]=\"minuteLabel\">\n      <input matInput [(ngModel)]=\"selectedMinTime\" [placeholder]=\"minutePlaceholder\" maxlength=\"2\"\n        (ngModelChange)=\"onMinTimeChange($event)\" (blur)=\"onMinBlur()\" class=\"time_picker\" [disabled]=\"disabled\" [readonly]=\"readonly\" />\n    </mat-form-field>\n  </div>\n  <div class=\"time-input-item\">\n    <mat-button-toggle-group class=\"mat-toggle-group mat-button-toggle-time mat-button-toggle-group-time me-0\"\n      #group=\"matButtonToggleGroup\" hideSingleSelectionIndicator=\"true\" [value]=\"selectedPeriod\"\n      (change)=\"onPeriodChange($event)\" [disabled]=\"disabled || readonly\"\n      [ngClass]=\"{ 'cgi-forms-readonly': readonly }\" aria-label=\"Time period toggle\">\n      <mat-button-toggle *ngIf=\"!readonly || selectedPeriod === 'am'\" value=\"am\" class=\"mat-button-toggle-time\" [ngClass]=\"{ 'mat-button-toggle-readonly': readonly }\" [attr.aria-label]=\"'Time picker toggle for ' + amLabel\">\n        {{ amLabel }}\n      </mat-button-toggle>\n      <mat-button-toggle *ngIf=\"!readonly || selectedPeriod === 'pm'\" value=\"pm\" class=\"mat-button-toggle-time\" [ngClass]=\"{ 'mat-button-toggle-readonly': readonly }\" [attr.aria-label]=\"'Time picker toggle for ' + pmLabel\">\n        {{ pmLabel }}\n      </mat-button-toggle>\n    </mat-button-toggle-group>\n  </div>\n</div>\n<mat-error *ngIf=\"\n    required &&\n    ((hourFC.touched && !hourFC.valid) ||\n      (minutesFC.touched && !minutesFC.valid) ||\n      (!getValidity() && parentForm.submitted))\n  \">{{ errorMessage }}</mat-error>\n<mat-error *ngIf=\"isTimeOutOfRange\" class=\"time-range-error\">\n  {{ rangeErrorMessage }}\n</mat-error>", styles: [":host(.cgi-timepicker) .mat-mdc-form-field{width:40px}:host(.cgi-timepicker) .mat-mdc-form-field.mat-form-field-invalid ::ng-deep .mat-form-field-wrapper{margin-bottom:0!important;padding-bottom:0!important}:host(.cgi-timepicker) .mat-toggle-group{margin-bottom:0}:host(.cgi-timepicker) [class^=cgi-forms-readonly].mat-form-field-disabled ::ng-deep .mat-form-field-outline-start,:host(.cgi-timepicker) [class^=cgi-forms-readonly].mat-form-field-disabled ::ng-deep .mat-form-field-outline-gap,:host(.cgi-timepicker) [class^=cgi-forms-readonly].mat-form-field-disabled ::ng-deep .mat-form-field-outline-end,:host(.cgi-timepicker) [class*=cgi-forms-readonly].mat-form-field-disabled ::ng-deep .mat-form-field-outline-start,:host(.cgi-timepicker) [class*=cgi-forms-readonly].mat-form-field-disabled ::ng-deep .mat-form-field-outline-gap,:host(.cgi-timepicker) [class*=cgi-forms-readonly].mat-form-field-disabled ::ng-deep .mat-form-field-outline-end{border:0}:host(.cgi-timepicker) [class^=cgi-forms-readonly].mat-form-field-disabled .mat-mdc-input-element,:host(.cgi-timepicker) [class*=cgi-forms-readonly].mat-form-field-disabled .mat-mdc-input-element{color:currentColor}:host(.cgi-timepicker) [class^=cgi-forms-readonly] ::ng-deep .mat-form-field-flex,:host(.cgi-timepicker) [class*=cgi-forms-readonly] ::ng-deep .mat-form-field-flex{padding:0!important}:host(.cgi-timepicker) .mat-mdc-form-field-error{font-size:12px}.cdk-overlay-container .cgi-timepicker .mat-toggle-group .mat-button-toggle-label-content,.cgi-nav-content .cgi-timepicker .mat-toggle-group .mat-button-toggle-label-content{line-height:40px}.cgi-timepicker--shift-mins-label.mat-form-field-appearance-outline.mat-form-field-can-float.mat-form-field-should-float ::ng-deep .mat-form-field-label{overflow:visible;transform:translate(-3px) translateY(-1.4em) scale(.75)}.cgi-readonly-dayperiod{color:#888d91}::ng-deep .cgi-forms-readonly-bold .cgi-readonly-dayperiod{font-weight:700}\n"], dependencies: [{ kind: "directive", type: i1.NgClass, selector: "[ngClass]", inputs: ["class", "ngClass"] }, { kind: "directive", type: i1.NgIf, selector: "[ngIf]", inputs: ["ngIf", "ngIfThen", "ngIfElse"] }, { kind: "directive", type: i4$4.MatButtonToggleGroup, selector: "mat-button-toggle-group", inputs: ["appearance", "name", "vertical", "value", "multiple", "disabled", "disabledInteractive", "hideSingleSelectionIndicator", "hideMultipleSelectionIndicator"], outputs: ["valueChange", "change"], exportAs: ["matButtonToggleGroup"] }, { kind: "component", type: i4$4.MatButtonToggle, selector: "mat-button-toggle", inputs: ["aria-label", "aria-labelledby", "id", "name", "value", "tabIndex", "disableRipple", "appearance", "checked", "disabled", "disabledInteractive"], outputs: ["change"], exportAs: ["matButtonToggle"] }, { kind: "component", type: i8.MatFormField, selector: "mat-form-field", inputs: ["hideRequiredMarker", "color", "floatLabel", "appearance", "subscriptSizing", "hintLabel"], exportAs: ["matFormField"] }, { kind: "directive", type: i8.MatError, selector: "mat-error, [matError]", inputs: ["id"] }, { kind: "directive", type: i1$2.DefaultValueAccessor, selector: "input:not([type=checkbox])[formControlName],textarea[formControlName],input:not([type=checkbox])[formControl],textarea[formControl],input:not([type=checkbox])[ngModel],textarea[ngModel],[ngDefaultControl]" }, { kind: "directive", type: i1$2.NgControlStatus, selector: "[formControlName],[ngModel],[formControl]" }, { kind: "directive", type: i1$2.MaxLengthValidator, selector: "[maxlength][formControlName],[maxlength][formControl],[maxlength][ngModel]", inputs: ["maxlength"] }, { kind: "directive", type: i1$2.NgModel, selector: "[ngModel]:not([formControlName]):not([formControl])", inputs: ["name", "disabled", "ngModel", "ngModelOptions"], outputs: ["ngModelChange"], exportAs: ["ngModel"] }, { kind: "directive", type: i4$3.MatInput, selector: "input[matInput], textarea[matInput], select[matNativeControl],      input[matNativeControl], textarea[matNativeControl]", inputs: ["disabled", "id", "placeholder", "name", "required", "type", "errorStateMatcher", "aria-describedby", "value", "readonly", "disabledInteractive"], exportAs: ["matInput"] }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.2", ngImport: i0, type: CGITimepickerBrandComponent, decorators: [{
            type: Component,
            args: [{ selector: 'cgi-timepicker-brand', standalone: false, template: "<div class=\"time-input-group d-flex\">\n  <div class=\"time-input-item\">\n    <mat-form-field class=\"mat-form-field-time custom-placeholder\" [appearance]=\"appearance\" [ngClass]=\"{\n              'cgi-forms-readonly': readonly,\n              'mat-form-field-invalid':\n                (hourFC.touched && !hourFC.valid) || (minutesFC.touched && !minutesFC.valid)\n            }\" [attr.aria-label]=\"hourLabel\">\n      <input matInput [(ngModel)]=\"selectedHrTime\" [placeholder]=\"hourPlaceholder\" maxlength=\"2\"\n        (ngModelChange)=\"onHrTimeChange($event)\" (blur)=\"onHrBlur()\" class=\"time_picker\" [disabled]=\"disabled\" [readonly]=\"readonly\" />\n    </mat-form-field>\n    <span class=\"time-input-separator\">&nbsp;:&nbsp;</span>\n    <mat-form-field class=\"mat-form-field-time custom-placeholder\" [appearance]=\"appearance\" [ngClass]=\"{\n              'cgi-forms-readonly': readonly,\n              'mat-form-field-invalid':\n                (hourFC.touched && !hourFC.valid) || (minutesFC.touched && !minutesFC.valid)\n            }\" [attr.aria-label]=\"minuteLabel\">\n      <input matInput [(ngModel)]=\"selectedMinTime\" [placeholder]=\"minutePlaceholder\" maxlength=\"2\"\n        (ngModelChange)=\"onMinTimeChange($event)\" (blur)=\"onMinBlur()\" class=\"time_picker\" [disabled]=\"disabled\" [readonly]=\"readonly\" />\n    </mat-form-field>\n  </div>\n  <div class=\"time-input-item\">\n    <mat-button-toggle-group class=\"mat-toggle-group mat-button-toggle-time mat-button-toggle-group-time me-0\"\n      #group=\"matButtonToggleGroup\" hideSingleSelectionIndicator=\"true\" [value]=\"selectedPeriod\"\n      (change)=\"onPeriodChange($event)\" [disabled]=\"disabled || readonly\"\n      [ngClass]=\"{ 'cgi-forms-readonly': readonly }\" aria-label=\"Time period toggle\">\n      <mat-button-toggle *ngIf=\"!readonly || selectedPeriod === 'am'\" value=\"am\" class=\"mat-button-toggle-time\" [ngClass]=\"{ 'mat-button-toggle-readonly': readonly }\" [attr.aria-label]=\"'Time picker toggle for ' + amLabel\">\n        {{ amLabel }}\n      </mat-button-toggle>\n      <mat-button-toggle *ngIf=\"!readonly || selectedPeriod === 'pm'\" value=\"pm\" class=\"mat-button-toggle-time\" [ngClass]=\"{ 'mat-button-toggle-readonly': readonly }\" [attr.aria-label]=\"'Time picker toggle for ' + pmLabel\">\n        {{ pmLabel }}\n      </mat-button-toggle>\n    </mat-button-toggle-group>\n  </div>\n</div>\n<mat-error *ngIf=\"\n    required &&\n    ((hourFC.touched && !hourFC.valid) ||\n      (minutesFC.touched && !minutesFC.valid) ||\n      (!getValidity() && parentForm.submitted))\n  \">{{ errorMessage }}</mat-error>\n<mat-error *ngIf=\"isTimeOutOfRange\" class=\"time-range-error\">\n  {{ rangeErrorMessage }}\n</mat-error>", styles: [":host(.cgi-timepicker) .mat-mdc-form-field{width:40px}:host(.cgi-timepicker) .mat-mdc-form-field.mat-form-field-invalid ::ng-deep .mat-form-field-wrapper{margin-bottom:0!important;padding-bottom:0!important}:host(.cgi-timepicker) .mat-toggle-group{margin-bottom:0}:host(.cgi-timepicker) [class^=cgi-forms-readonly].mat-form-field-disabled ::ng-deep .mat-form-field-outline-start,:host(.cgi-timepicker) [class^=cgi-forms-readonly].mat-form-field-disabled ::ng-deep .mat-form-field-outline-gap,:host(.cgi-timepicker) [class^=cgi-forms-readonly].mat-form-field-disabled ::ng-deep .mat-form-field-outline-end,:host(.cgi-timepicker) [class*=cgi-forms-readonly].mat-form-field-disabled ::ng-deep .mat-form-field-outline-start,:host(.cgi-timepicker) [class*=cgi-forms-readonly].mat-form-field-disabled ::ng-deep .mat-form-field-outline-gap,:host(.cgi-timepicker) [class*=cgi-forms-readonly].mat-form-field-disabled ::ng-deep .mat-form-field-outline-end{border:0}:host(.cgi-timepicker) [class^=cgi-forms-readonly].mat-form-field-disabled .mat-mdc-input-element,:host(.cgi-timepicker) [class*=cgi-forms-readonly].mat-form-field-disabled .mat-mdc-input-element{color:currentColor}:host(.cgi-timepicker) [class^=cgi-forms-readonly] ::ng-deep .mat-form-field-flex,:host(.cgi-timepicker) [class*=cgi-forms-readonly] ::ng-deep .mat-form-field-flex{padding:0!important}:host(.cgi-timepicker) .mat-mdc-form-field-error{font-size:12px}.cdk-overlay-container .cgi-timepicker .mat-toggle-group .mat-button-toggle-label-content,.cgi-nav-content .cgi-timepicker .mat-toggle-group .mat-button-toggle-label-content{line-height:40px}.cgi-timepicker--shift-mins-label.mat-form-field-appearance-outline.mat-form-field-can-float.mat-form-field-should-float ::ng-deep .mat-form-field-label{overflow:visible;transform:translate(-3px) translateY(-1.4em) scale(.75)}.cgi-readonly-dayperiod{color:#888d91}::ng-deep .cgi-forms-readonly-bold .cgi-readonly-dayperiod{font-weight:700}\n"] }]
        }], ctorParameters: () => [{ type: i1$2.FormGroupDirective }], propDecorators: { isClassContainer: [{
                type: HostBinding,
                args: ['class.cgi-timepicker']
            }], setDateTime: [{
                type: Input
            }], errorMessage: [{
                type: Input
            }], required: [{
                type: Input
            }], disabled: [{
                type: Input
            }], readonly: [{
                type: Input
            }], appearance: [{
                type: Input
            }], minHour: [{
                type: Input
            }], maxHour: [{
                type: Input
            }], hourLabel: [{
                type: Input
            }], minuteLabel: [{
                type: Input
            }], hourPlaceholder: [{
                type: Input
            }], minutePlaceholder: [{
                type: Input
            }], amLabel: [{
                type: Input
            }], pmLabel: [{
                type: Input
            }], minTime: [{
                type: Input
            }], maxTime: [{
                type: Input
            }], defaultHour: [{
                type: Input
            }], defaultMinute: [{
                type: Input
            }], defaultPeriod: [{
                type: Input
            }], timeSelected: [{
                type: Output
            }], hourChanged: [{
                type: Output
            }], minuteChanged: [{
                type: Output
            }], periodChanged: [{
                type: Output
            }] } });

class CGITimepickerBrandModule {
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.2", ngImport: i0, type: CGITimepickerBrandModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule }); }
    static { this.ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "20.3.2", ngImport: i0, type: CGITimepickerBrandModule, declarations: [CGITimepickerBrandComponent], imports: [CommonModule,
            MatAutocompleteModule,
            MatButtonToggleModule,
            MatFormFieldModule,
            FormsModule,
            MatInputModule,
            ReactiveFormsModule], exports: [CGITimepickerBrandComponent] }); }
    static { this.ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "20.3.2", ngImport: i0, type: CGITimepickerBrandModule, imports: [CommonModule,
            MatAutocompleteModule,
            MatButtonToggleModule,
            MatFormFieldModule,
            FormsModule,
            MatInputModule,
            ReactiveFormsModule] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.2", ngImport: i0, type: CGITimepickerBrandModule, decorators: [{
            type: NgModule,
            args: [{
                    declarations: [CGITimepickerBrandComponent],
                    imports: [
                        CommonModule,
                        MatAutocompleteModule,
                        MatButtonToggleModule,
                        MatFormFieldModule,
                        FormsModule,
                        MatInputModule,
                        ReactiveFormsModule,
                    ],
                    exports: [CGITimepickerBrandComponent],
                }]
        }] });

/**
 * GlobalSearchGroupOptions class
 */
class GlobalSearchGroupBrandOptions {
    /** constructor
     * @param contents getting GlobalSearchEntity type of array
     * @param totalRecords getting total name of result
     * @param category getting category data ( not necessary )
     */
    constructor(contents, totalRecords, category, expandCategory) {
        this.category = category;
        this.contents = contents || [];
        this.totalRecords = totalRecords || 0;
        this.expandCategory = expandCategory || false;
    }
}

/**
 * GlobalSearchEntity class
 */
class GlobalSearchBrandEntity {
    /**
     * constructor ( it receive variables ( code, name ) and saving )
     * @param code code for content
     * @param name name for content
     */
    constructor(code, name) {
        this.code = code || '';
        this.name = name || '';
    }
}

/**
 * GlobalSearchCategory class
 */
class GlobalSearchBrandCategory {
    /**
     * constructor ( it receive variables ( name, value ) and saving )
     * @param name getting category name
     * @param value getting category value
     * @param icon getting category icon name
     * @param moreResultsLink getting category link for more results
     * @param queryParamKey getting key for queryparams
     */
    constructor(name, value, icon, moreResultsLink, queryParamKey) {
        this.name = name || '';
        this.value = value || '';
        this.icon = icon || '';
        this.moreResultsLink = moreResultsLink || '';
        this.queryParamKey = queryParamKey || null;
    }
}

/**
 * Footer Container component.
 *
 */
class CGIFooterContainerBrandComponent {
    /** constructor for DI */
    constructor(cgiNavContainer, document, breakpointObserver) {
        this.cgiNavContainer = cgiNavContainer;
        this.document = document;
        this.breakpointObserver = breakpointObserver;
        /** footer container css selector */
        this.cgiFooter = '.cgi-footer-container';
    }
    /** subscribes to sidenav value and screen size for footer flexibility  */
    ngOnInit() {
        /** reference to the footer */
        const footer = document.querySelector(this.cgiFooter);
        /** reference to the sidenav */
        const sideNav = document.querySelector('.cgi-side-nav');
        if (footer !== null) {
            this.navBarScreenObservable$ = combineLatest([
                this.cgiNavContainer.changes,
                this.breakpointObserver.observe(['(min-width: 600px)']),
            ]).subscribe(([navOpen, fullScreenSize]) => {
                if (navOpen && fullScreenSize.matches) {
                    footer.classList.add('cgi-footer-container--collapsed');
                }
                else {
                    footer.classList.remove('cgi-footer-container--collapsed');
                }
            });
            /** when sidenav does not exist extend the footer all the way to the left */
            if (!sideNav) {
                footer.classList.add('cgi-footer-container--full-width');
            }
        }
    }
    /** toggles the footer */
    ngOnChanges() {
        /** reference to the footer */
        const footer = document.querySelector(this.cgiFooter);
        if (footer !== null && this.toggle) {
            footer.classList.add('cgi-footer-container--opened');
            footer.setAttribute('aria-hidden', 'false');
        }
        else {
            footer.classList.remove('cgi-footer-container--opened');
            footer.setAttribute('aria-hidden', 'true');
        }
    }
    /** cleaning up observables */
    ngOnDestroy() {
        if (this.navBarScreenObservable$) {
            this.navBarScreenObservable$.unsubscribe();
        }
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.2", ngImport: i0, type: CGIFooterContainerBrandComponent, deps: [{ token: CGINavContainerService, optional: true }, { token: DOCUMENT }, { token: i1$1.BreakpointObserver }], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "20.3.2", type: CGIFooterContainerBrandComponent, isStandalone: false, selector: "cgi-footer-container", inputs: { toggle: "toggle" }, usesOnChanges: true, ngImport: i0, template: "<ng-content></ng-content>\n", styles: [":host(.cgi-footer-container){background-color:#f6f7f7;bottom:0;box-shadow:0 -2px 7px #00001940;display:flex;left:4.4rem;position:fixed;right:0;transform:translateY(110%);transition:.2s cubic-bezier(.25,.8,.25,1);visibility:hidden}:host(.cgi-footer-container).cgi-footer-container--opened{transform:translateY(0);visibility:visible}:host(.cgi-footer-container).cgi-footer-container--collapsed{margin-left:13.6rem}:host(.cgi-footer-container).cgi-footer-container--full-width{left:0!important}@media (max-width: 599px){:host(.cgi-footer-container){left:0}}:host(.cgi-footer-container) ::ng-deep .cgi-footer__text{align-self:center;margin:8px 30px}:host(.cgi-footer-container) ::ng-deep .cgi-footer__right-button-group{align-self:center;margin-left:auto;margin-right:22px;white-space:nowrap}\n"] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.2", ngImport: i0, type: CGIFooterContainerBrandComponent, decorators: [{
            type: Component,
            args: [{ selector: 'cgi-footer-container', standalone: false, template: "<ng-content></ng-content>\n", styles: [":host(.cgi-footer-container){background-color:#f6f7f7;bottom:0;box-shadow:0 -2px 7px #00001940;display:flex;left:4.4rem;position:fixed;right:0;transform:translateY(110%);transition:.2s cubic-bezier(.25,.8,.25,1);visibility:hidden}:host(.cgi-footer-container).cgi-footer-container--opened{transform:translateY(0);visibility:visible}:host(.cgi-footer-container).cgi-footer-container--collapsed{margin-left:13.6rem}:host(.cgi-footer-container).cgi-footer-container--full-width{left:0!important}@media (max-width: 599px){:host(.cgi-footer-container){left:0}}:host(.cgi-footer-container) ::ng-deep .cgi-footer__text{align-self:center;margin:8px 30px}:host(.cgi-footer-container) ::ng-deep .cgi-footer__right-button-group{align-self:center;margin-left:auto;margin-right:22px;white-space:nowrap}\n"] }]
        }], ctorParameters: () => [{ type: CGINavContainerService, decorators: [{
                    type: Optional
                }] }, { type: undefined, decorators: [{
                    type: Inject,
                    args: [DOCUMENT]
                }] }, { type: i1$1.BreakpointObserver }], propDecorators: { toggle: [{
                type: Input
            }] } });

class CGIFooterBrandModule {
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.2", ngImport: i0, type: CGIFooterBrandModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule }); }
    static { this.ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "20.3.2", ngImport: i0, type: CGIFooterBrandModule, declarations: [CGIFooterContainerBrandComponent], imports: [CommonModule, MatIconModule, MatButtonModule, ReactiveFormsModule], exports: [CGIFooterContainerBrandComponent] }); }
    static { this.ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "20.3.2", ngImport: i0, type: CGIFooterBrandModule, imports: [CommonModule, MatIconModule, MatButtonModule, ReactiveFormsModule] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.2", ngImport: i0, type: CGIFooterBrandModule, decorators: [{
            type: NgModule,
            args: [{
                    imports: [CommonModule, MatIconModule, MatButtonModule, ReactiveFormsModule],
                    declarations: [CGIFooterContainerBrandComponent],
                    exports: [CGIFooterContainerBrandComponent],
                    providers: [],
                }]
        }] });

/**
 *  Headstone Component
 */
class CGIHeadstoneBrandComponent {
    /** Constructor */
    constructor() { }
    /** Life cycle hook for when the component is first initiated. */
    ngOnInit() {
        this.isClassContainer = true;
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.2", ngImport: i0, type: CGIHeadstoneBrandComponent, deps: [], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "20.3.2", type: CGIHeadstoneBrandComponent, isStandalone: false, selector: "cgi-headstone", host: { properties: { "class.cgi-headstone": "this.isClassContainer" } }, ngImport: i0, template: "<mat-card appearance=\"outlined\">\n  <mat-card-content>\n    <div class=\"d-flex no-gutters overflow-auto\" style=\"gap: 48px\">\n      <ng-content></ng-content>\n    </div>\n  </mat-card-content>\n</mat-card>\n<ng-content select=\"cgi-headstone-accordion\"></ng-content>\n", styles: [":host(.cgi-headstone) .mat-mdc-card{background-color:#e6e3f3;padding:16px!important;border:0px;box-shadow:0 1px 2px #15151540!important;z-index:2}:host(.cgi-headstone).cgi-headstone--embedded>.mat-mdc-card{background-color:transparent;width:100%;box-shadow:none!important;padding:6px!important}:host(.cgi-headstone).cgi-headstone--dashboard ::ng-deep .cgi-headstone-item{font-size:22px;white-space:nowrap}:host(.cgi-headstone).cgi-headstone--dashboard ::ng-deep .cgi-headstone-item mat-icon{margin-right:5px}@media (min-width: 992px){:host(.cgi-headstone).cgi-headstone--dashboard ::ng-deep .cgi-headstone-item{flex:0 0 16.66666667%;max-width:100%}}@media (max-width: 992px){:host(.cgi-headstone).cgi-headstone--dashboard ::ng-deep .cgi-headstone-item{flex:0 0 50%;max-width:50%}}:host(.cgi-headstone) ::ng-deep .cgi-headstone-style__tables{display:flex;flex-direction:column;max-height:300px;min-width:300px;overflow:hidden}:host(.cgi-headstone) ::ng-deep .cgi-headstone-style__tables .mat-mdc-table .mat-mdc-row .mat-mdc-cell:nth-child(1){color:var(--Text-CGI-Default, #333)!important}:host(.cgi-headstone) ::ng-deep .cgi-headstone-style__tables .cgi-data-table--header-right.mat-mdc-header-cell:not(.mat-sort-header){padding-right:0!important}:host(.cgi-headstone) ::ng-deep .cgi-headstone-style__tables .mat-mdc-table .mat-mdc-row .mat-mdc-cell:nth-child(5){padding-left:3%!important}:host(.cgi-headstone) ::ng-deep .cgi-headstone-style__image{display:flex;padding:0 32px;justify-content:center;align-items:center;gap:10px;align-self:stretch}:host(.cgi-headstone) ::ng-deep .gap_right{margin-right:4px}:host(.cgi-headstone) ::ng-deep .cgi-headstone_value{color:#200a58}:host(.cgi-headstone) ::ng-deep .black_color{color:#151515}:host(.cgi-headstone) ::ng-deep #chart{padding:0;min-height:286px;width:260px}:host(.cgi-headstone) ::ng-deep .divider{width:1px;height:286px;transform:rotate(0);align-self:stretch;background:var(--primary-cgi-grey-cgi-grey-200-light-1, #A8A8A8)}:host(.cgi-headstone) ::ng-deep .chart-table{height:286px;flex-direction:column;align-items:center;gap:10px;flex:1 0 0}:host(.cgi-headstone) ::ng-deep .chart-container{display:flex;flex-direction:column;align-items:center;align-self:stretch}:host(.cgi-headstone) ::ng-deep .chart-main{display:flex;align-items:flex-start;align-self:stretch}:host(.cgi-headstone) ::ng-deep .mat-mdc-cell:nth-child(1){color:#333!important}:host(.cgi-headstone) ::ng-deep .error-text{color:#e31937!important}\n"], dependencies: [{ kind: "component", type: i1$5.MatCard, selector: "mat-card", inputs: ["appearance"], exportAs: ["matCard"] }, { kind: "directive", type: i1$5.MatCardContent, selector: "mat-card-content" }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.2", ngImport: i0, type: CGIHeadstoneBrandComponent, decorators: [{
            type: Component,
            args: [{ selector: 'cgi-headstone', standalone: false, template: "<mat-card appearance=\"outlined\">\n  <mat-card-content>\n    <div class=\"d-flex no-gutters overflow-auto\" style=\"gap: 48px\">\n      <ng-content></ng-content>\n    </div>\n  </mat-card-content>\n</mat-card>\n<ng-content select=\"cgi-headstone-accordion\"></ng-content>\n", styles: [":host(.cgi-headstone) .mat-mdc-card{background-color:#e6e3f3;padding:16px!important;border:0px;box-shadow:0 1px 2px #15151540!important;z-index:2}:host(.cgi-headstone).cgi-headstone--embedded>.mat-mdc-card{background-color:transparent;width:100%;box-shadow:none!important;padding:6px!important}:host(.cgi-headstone).cgi-headstone--dashboard ::ng-deep .cgi-headstone-item{font-size:22px;white-space:nowrap}:host(.cgi-headstone).cgi-headstone--dashboard ::ng-deep .cgi-headstone-item mat-icon{margin-right:5px}@media (min-width: 992px){:host(.cgi-headstone).cgi-headstone--dashboard ::ng-deep .cgi-headstone-item{flex:0 0 16.66666667%;max-width:100%}}@media (max-width: 992px){:host(.cgi-headstone).cgi-headstone--dashboard ::ng-deep .cgi-headstone-item{flex:0 0 50%;max-width:50%}}:host(.cgi-headstone) ::ng-deep .cgi-headstone-style__tables{display:flex;flex-direction:column;max-height:300px;min-width:300px;overflow:hidden}:host(.cgi-headstone) ::ng-deep .cgi-headstone-style__tables .mat-mdc-table .mat-mdc-row .mat-mdc-cell:nth-child(1){color:var(--Text-CGI-Default, #333)!important}:host(.cgi-headstone) ::ng-deep .cgi-headstone-style__tables .cgi-data-table--header-right.mat-mdc-header-cell:not(.mat-sort-header){padding-right:0!important}:host(.cgi-headstone) ::ng-deep .cgi-headstone-style__tables .mat-mdc-table .mat-mdc-row .mat-mdc-cell:nth-child(5){padding-left:3%!important}:host(.cgi-headstone) ::ng-deep .cgi-headstone-style__image{display:flex;padding:0 32px;justify-content:center;align-items:center;gap:10px;align-self:stretch}:host(.cgi-headstone) ::ng-deep .gap_right{margin-right:4px}:host(.cgi-headstone) ::ng-deep .cgi-headstone_value{color:#200a58}:host(.cgi-headstone) ::ng-deep .black_color{color:#151515}:host(.cgi-headstone) ::ng-deep #chart{padding:0;min-height:286px;width:260px}:host(.cgi-headstone) ::ng-deep .divider{width:1px;height:286px;transform:rotate(0);align-self:stretch;background:var(--primary-cgi-grey-cgi-grey-200-light-1, #A8A8A8)}:host(.cgi-headstone) ::ng-deep .chart-table{height:286px;flex-direction:column;align-items:center;gap:10px;flex:1 0 0}:host(.cgi-headstone) ::ng-deep .chart-container{display:flex;flex-direction:column;align-items:center;align-self:stretch}:host(.cgi-headstone) ::ng-deep .chart-main{display:flex;align-items:flex-start;align-self:stretch}:host(.cgi-headstone) ::ng-deep .mat-mdc-cell:nth-child(1){color:#333!important}:host(.cgi-headstone) ::ng-deep .error-text{color:#e31937!important}\n"] }]
        }], ctorParameters: () => [], propDecorators: { isClassContainer: [{
                type: HostBinding,
                args: ['class.cgi-headstone']
            }] } });

/**
 * Headstone Accordion component.
 */
class CGIHeadstoneAccordionBrandComponent {
    /** Component Constructor */
    constructor() {
        /** Boolean to toggle Accordion expansion */
        this.accordionExpanded = false;
        this.isClassContainer = true;
    }
    /** Life cycle hook for when the component is first initiated. */
    ngOnInit() { }
    /** Toggle Accordion expansion */
    toggle() {
        this.accordionExpanded = !this.accordionExpanded;
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.2", ngImport: i0, type: CGIHeadstoneAccordionBrandComponent, deps: [], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "20.3.2", type: CGIHeadstoneAccordionBrandComponent, isStandalone: false, selector: "cgi-headstone-accordion", inputs: { accordionExpanded: "accordionExpanded" }, host: { properties: { "class.cgi-headstone-accordion": "this.isClassContainer" } }, ngImport: i0, template: "<div class=\"cgi-vertical-spacer-8\"></div>\n<mat-card appearance=\"outlined\" class=\"headstone-accordion\">\n  <div [ngClass]=\"accordionExpanded?'cgi-headstone-space':''\">\n    <mat-expansion-panel [expanded]=\"accordionExpanded\" >\n      <ng-content select=\".cgi-headstone-accordion__header\"></ng-content>\n      <mat-divider></mat-divider>\n      <ng-content></ng-content>\n    </mat-expansion-panel>\n  </div>\n  <div class=\"cgi-headstone-accordion__toggle\" [ngClass]=\"accordionExpanded?'cgi-headstone-expanded':''\">\n    <button mat-button color=\"primary\" *ngIf=\"!accordionExpanded\" (click)=\"toggle()\">\n      Show more\n    </button>\n    <button mat-button color=\"primary\" *ngIf=\"accordionExpanded\" (click)=\"toggle()\">Hide</button>\n  </div>\n</mat-card>\n", styles: [":host(.cgi-headstone-accordion){z-index:1}:host(.cgi-headstone-accordion) .cgi-headstone-accordion__toggle{align-items:center;display:flex;justify-content:center;padding:0!important}:host(.cgi-headstone-accordion) .cgi-headstone-accordion__toggle button{color:#5236ab;height:33px;background-color:transparent;border:0;font-size:14px;font-weight:700;line-height:17px;margin:0;padding:0;width:100%}:host(.cgi-headstone-accordion) .cgi-headstone-accordion__toggle button:hover{color:#2d1e5e!important}:host(.cgi-headstone-accordion) .cgi-headstone-accordion__toggle .mdc-button__label{color:#6a7c97}:host(.cgi-headstone-accordion) .cgi-headstone-space{padding:8px 0}:host(.cgi-headstone-accordion) .cgi-headstone-expanded{box-shadow:0 2px 6px 2px #00000026,0 2px 6px 2px #00000026;border-radius:0 0 4px 4px}:host(.cgi-headstone-accordion) ::ng-deep .mat-expansion-panel .mat-expansion-panel-body{padding:0}:host(.cgi-headstone-accordion) ::ng-deep .cgi-headstone-accordion__header{align-items:center;display:flex;font-size:20px;font-weight:700;justify-content:space-between;padding:16px 16px 16px 24px}:host(.cgi-headstone-accordion) ::ng-deep button{margin:0}:host(.cgi-headstone-accordion) ::ng-deep button mat-icon{font-size:20px}:host(.cgi-headstone-accordion) ::ng-deep .mat-expansion-panel{box-shadow:none;border:none}:host(.cgi-headstone-accordion) ::ng-deep .mat-expansion-panel.mat-expanded{border-radius:4px 4px 0 0}:host(.cgi-headstone-accordion) ::ng-deep .headstone-accordion{padding:0;overflow:hidden}\n"], dependencies: [{ kind: "directive", type: i1.NgClass, selector: "[ngClass]", inputs: ["class", "ngClass"] }, { kind: "directive", type: i1.NgIf, selector: "[ngIf]", inputs: ["ngIf", "ngIfThen", "ngIfElse"] }, { kind: "component", type: i4.MatButton, selector: "    button[matButton], a[matButton], button[mat-button], button[mat-raised-button],    button[mat-flat-button], button[mat-stroked-button], a[mat-button], a[mat-raised-button],    a[mat-flat-button], a[mat-stroked-button]  ", inputs: ["matButton"], exportAs: ["matButton", "matAnchor"] }, { kind: "component", type: i1$5.MatCard, selector: "mat-card", inputs: ["appearance"], exportAs: ["matCard"] }, { kind: "component", type: i4$5.MatDivider, selector: "mat-divider", inputs: ["vertical", "inset"] }, { kind: "component", type: i4$2.MatExpansionPanel, selector: "mat-expansion-panel", inputs: ["hideToggle", "togglePosition"], outputs: ["afterExpand", "afterCollapse"], exportAs: ["matExpansionPanel"] }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.2", ngImport: i0, type: CGIHeadstoneAccordionBrandComponent, decorators: [{
            type: Component,
            args: [{ selector: 'cgi-headstone-accordion', standalone: false, template: "<div class=\"cgi-vertical-spacer-8\"></div>\n<mat-card appearance=\"outlined\" class=\"headstone-accordion\">\n  <div [ngClass]=\"accordionExpanded?'cgi-headstone-space':''\">\n    <mat-expansion-panel [expanded]=\"accordionExpanded\" >\n      <ng-content select=\".cgi-headstone-accordion__header\"></ng-content>\n      <mat-divider></mat-divider>\n      <ng-content></ng-content>\n    </mat-expansion-panel>\n  </div>\n  <div class=\"cgi-headstone-accordion__toggle\" [ngClass]=\"accordionExpanded?'cgi-headstone-expanded':''\">\n    <button mat-button color=\"primary\" *ngIf=\"!accordionExpanded\" (click)=\"toggle()\">\n      Show more\n    </button>\n    <button mat-button color=\"primary\" *ngIf=\"accordionExpanded\" (click)=\"toggle()\">Hide</button>\n  </div>\n</mat-card>\n", styles: [":host(.cgi-headstone-accordion){z-index:1}:host(.cgi-headstone-accordion) .cgi-headstone-accordion__toggle{align-items:center;display:flex;justify-content:center;padding:0!important}:host(.cgi-headstone-accordion) .cgi-headstone-accordion__toggle button{color:#5236ab;height:33px;background-color:transparent;border:0;font-size:14px;font-weight:700;line-height:17px;margin:0;padding:0;width:100%}:host(.cgi-headstone-accordion) .cgi-headstone-accordion__toggle button:hover{color:#2d1e5e!important}:host(.cgi-headstone-accordion) .cgi-headstone-accordion__toggle .mdc-button__label{color:#6a7c97}:host(.cgi-headstone-accordion) .cgi-headstone-space{padding:8px 0}:host(.cgi-headstone-accordion) .cgi-headstone-expanded{box-shadow:0 2px 6px 2px #00000026,0 2px 6px 2px #00000026;border-radius:0 0 4px 4px}:host(.cgi-headstone-accordion) ::ng-deep .mat-expansion-panel .mat-expansion-panel-body{padding:0}:host(.cgi-headstone-accordion) ::ng-deep .cgi-headstone-accordion__header{align-items:center;display:flex;font-size:20px;font-weight:700;justify-content:space-between;padding:16px 16px 16px 24px}:host(.cgi-headstone-accordion) ::ng-deep button{margin:0}:host(.cgi-headstone-accordion) ::ng-deep button mat-icon{font-size:20px}:host(.cgi-headstone-accordion) ::ng-deep .mat-expansion-panel{box-shadow:none;border:none}:host(.cgi-headstone-accordion) ::ng-deep .mat-expansion-panel.mat-expanded{border-radius:4px 4px 0 0}:host(.cgi-headstone-accordion) ::ng-deep .headstone-accordion{padding:0;overflow:hidden}\n"] }]
        }], ctorParameters: () => [], propDecorators: { isClassContainer: [{
                type: HostBinding,
                args: ['class.cgi-headstone-accordion']
            }], accordionExpanded: [{
                type: Input
            }] } });

/**
 * Headstone Item Component
 */
class CGIHeadstoneItemBrandComponent {
    /** constructor */
    constructor() {
        /** HostBinding for CSS */
        this.class = 'col-6 col-sm-4 col-md-3 col-lg-auto cgi-headstone-item';
    }
    /** Life cycle hook for when the component is first initiated. */
    ngOnInit() { }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.2", ngImport: i0, type: CGIHeadstoneItemBrandComponent, deps: [], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "20.3.2", type: CGIHeadstoneItemBrandComponent, isStandalone: false, selector: "cgi-headstone-item", inputs: { toolTip: "toolTip" }, host: { properties: { "class": "this.class" } }, ngImport: i0, template: "<div\n  class=\"cgi-caption cgi-body-14 cgi-headstone-item__title d-flex\"\n  matTooltip=\"{{ toolTip }}\"\n  matTooltipPosition=\"above\"\n>\n  <ng-content select=\"label\"></ng-content>\n</div>\n<ng-content></ng-content>\n<small><ng-content select=\".cgi-headstone-item__footer\"></ng-content></small>\n", styles: [":host(.cgi-headstone-item){color:#13283e;font-size:16px;font-weight:700}:host(.cgi-headstone-item) ::ng-deep a.cgi-link-icon{font-weight:400;margin-left:20px}:host(.cgi-headstone-item) ::ng-deep a.cgi-link-icon>mat-icon{height:18px;width:18px}:host(.cgi-headstone-item) ::ng-deep .cgi-headstone-item__title{font-weight:500}:host(.cgi-headstone-item) ::ng-deep label{margin-bottom:0;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}:host(.cgi-headstone-item) ::ng-deep .cgi-headstone-item__footer{color:#616161;font-size:12px;font-weight:400}@media (max-width: 960px){:host(.cgi-headstone-item) ::ng-deep a.cgi-link-icon{font-size:0;margin-left:5px}:host(.cgi-headstone-item) ::ng-deep a.cgi-link-icon mat-icon{font-size:14px}}\n"], dependencies: [{ kind: "directive", type: i1$6.MatTooltip, selector: "[matTooltip]", inputs: ["matTooltipPosition", "matTooltipPositionAtOrigin", "matTooltipDisabled", "matTooltipShowDelay", "matTooltipHideDelay", "matTooltipTouchGestures", "matTooltip", "matTooltipClass"], exportAs: ["matTooltip"] }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.2", ngImport: i0, type: CGIHeadstoneItemBrandComponent, decorators: [{
            type: Component,
            args: [{ selector: 'cgi-headstone-item', standalone: false, template: "<div\n  class=\"cgi-caption cgi-body-14 cgi-headstone-item__title d-flex\"\n  matTooltip=\"{{ toolTip }}\"\n  matTooltipPosition=\"above\"\n>\n  <ng-content select=\"label\"></ng-content>\n</div>\n<ng-content></ng-content>\n<small><ng-content select=\".cgi-headstone-item__footer\"></ng-content></small>\n", styles: [":host(.cgi-headstone-item){color:#13283e;font-size:16px;font-weight:700}:host(.cgi-headstone-item) ::ng-deep a.cgi-link-icon{font-weight:400;margin-left:20px}:host(.cgi-headstone-item) ::ng-deep a.cgi-link-icon>mat-icon{height:18px;width:18px}:host(.cgi-headstone-item) ::ng-deep .cgi-headstone-item__title{font-weight:500}:host(.cgi-headstone-item) ::ng-deep label{margin-bottom:0;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}:host(.cgi-headstone-item) ::ng-deep .cgi-headstone-item__footer{color:#616161;font-size:12px;font-weight:400}@media (max-width: 960px){:host(.cgi-headstone-item) ::ng-deep a.cgi-link-icon{font-size:0;margin-left:5px}:host(.cgi-headstone-item) ::ng-deep a.cgi-link-icon mat-icon{font-size:14px}}\n"] }]
        }], ctorParameters: () => [], propDecorators: { class: [{
                type: HostBinding,
                args: ['class']
            }], toolTip: [{
                type: Input
            }] } });

class CGIHeadstoneBrandModule {
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.2", ngImport: i0, type: CGIHeadstoneBrandModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule }); }
    static { this.ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "20.3.2", ngImport: i0, type: CGIHeadstoneBrandModule, declarations: [CGIHeadstoneBrandComponent,
            CGIHeadstoneItemBrandComponent,
            CGIHeadstoneAccordionBrandComponent], imports: [CommonModule,
            MatButtonModule,
            MatCardModule,
            MatDividerModule,
            MatExpansionModule,
            MatTooltipModule], exports: [CGIHeadstoneBrandComponent,
            CGIHeadstoneItemBrandComponent,
            CGIHeadstoneAccordionBrandComponent] }); }
    static { this.ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "20.3.2", ngImport: i0, type: CGIHeadstoneBrandModule, imports: [CommonModule,
            MatButtonModule,
            MatCardModule,
            MatDividerModule,
            MatExpansionModule,
            MatTooltipModule] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.2", ngImport: i0, type: CGIHeadstoneBrandModule, decorators: [{
            type: NgModule,
            args: [{
                    imports: [
                        CommonModule,
                        MatButtonModule,
                        MatCardModule,
                        MatDividerModule,
                        MatExpansionModule,
                        MatTooltipModule,
                    ],
                    declarations: [
                        CGIHeadstoneBrandComponent,
                        CGIHeadstoneItemBrandComponent,
                        CGIHeadstoneAccordionBrandComponent,
                    ],
                    exports: [
                        CGIHeadstoneBrandComponent,
                        CGIHeadstoneItemBrandComponent,
                        CGIHeadstoneAccordionBrandComponent,
                    ],
                }]
        }] });

class CGIMultiSelectCheckboxesBrandComponent {
    constructor(table, cdRef) {
        this.table = table;
        this.cdRef = cdRef;
        /** Event Emitter to emit the modified selection set back to the parent component */
        this.updatedSelectionSet = new EventEmitter();
        /** Aria labels in HTML */
        this.checkboxLabel = 'multiSelectCheckbox';
        /** flag to keep track of whether the shift key is being held down - defaulted to false */
        this.shiftKeyHeldDown = false;
        /**
         * HostBinding initiate
         */
        this.isClassContainer = true;
    }
    ngAfterViewInit() {
        this.selectionSet.totalSelected = 0;
        this.selectionSet.lastSelected = 0;
    }
    ngOnInit() {
        /** Adds the select column */
        if (this.table) {
            this.cdRef.detectChanges();
            this.table.addColumnDef(this.columnDef);
        }
    }
    /** function: detects when a shift key is clicked - associated with (click) to allow multi select */
    shiftHandler(event) {
        event.stopPropagation();
        // checks if shift key was held during click
        if (event.shiftKey) {
            this.shiftKeyHeldDown = true;
        }
        else {
            this.shiftKeyHeldDown = false;
        }
    }
    /** function: handles a click event for multi-select table - associated with (change) but occurs after (click) */
    clickHandler(row, index, checkboxClicked) {
        // checks if shift key was held during click
        if (this.shiftKeyHeldDown) {
            this.selectRows(index);
        }
        else if (checkboxClicked) {
            this.selectionSet.selection.toggle(row);
            if (this.selectionSet.selection.isSelected(row)) {
                this.selectionSet.totalSelected++;
            }
            else {
                this.selectionSet.totalSelected--;
                if (this.selectionSet.totalSelected === 0) {
                    this.selectionSet.lastSelected = 0;
                }
            }
            this.checkLastSelected();
        }
        this.updatedSelectionSet.emit(this.selectionSet);
    }
    /** function: checks the last data value selected on multi-select table */
    checkLastSelected() {
        let lastSelectedIndex = 0;
        this.dataSourceSorted.forEach((row) => {
            if (this.selectionSet.selection.isSelected(row)) {
                this.selectionSet.lastSelected = lastSelectedIndex;
            }
            lastSelectedIndex++;
        });
    }
    /**  function: selects multiple rows at once on multi-select table */
    selectRows(index) {
        this.checkLastSelected();
        const indexOne = this.selectionSet.lastSelected;
        const indexTwo = index;
        let startIndex;
        let endIndex;
        if (indexOne > indexTwo) {
            // select rows in descending order
            startIndex = indexTwo;
            endIndex = indexOne;
        }
        else {
            // select rows in ascending order
            startIndex = indexOne;
            endIndex = indexTwo;
        }
        let currentIndex = 0;
        this.dataSourceSorted.forEach((row) => {
            if (currentIndex >= startIndex && currentIndex <= endIndex) {
                if (!this.selectionSet.selection.isSelected(row)) {
                    this.selectionSet.totalSelected++;
                }
                this.selectionSet.selection.select(row);
            }
            currentIndex++;
            this.checkLastSelected();
        });
    }
    /** function: checks if all values in multi-select table are selected */
    isAllSelected() {
        const numSelected = this.selectionSet.selection.selected.length;
        const numRows = this.dataSourceSorted.length;
        return numSelected === numRows;
    }
    /** function: selects/deselects all values in multi-select table */
    masterToggle() {
        if (this.isAllSelected()) {
            this.selectionSet.selection.clear();
            this.selectionSet.totalSelected = 0;
        }
        else {
            this.selectionSet.selection.select(...this.dataSourceSorted);
            this.selectionSet.totalSelected = this.dataSourceSorted.length;
        }
        this.selectionSet.lastSelected = 0;
        this.updatedSelectionSet.emit(this.selectionSet);
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.2", ngImport: i0, type: CGIMultiSelectCheckboxesBrandComponent, deps: [{ token: i1$7.MatTable, optional: true }, { token: i0.ChangeDetectorRef }], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "20.3.2", type: CGIMultiSelectCheckboxesBrandComponent, isStandalone: false, selector: "cgi-multi-select-checkboxes", inputs: { selection: "selection", selectionSet: "selectionSet", dataSourceSorted: "dataSourceSorted" }, outputs: { updatedSelectionSet: "updatedSelectionSet" }, host: { properties: { "class.cgi-multi-select-checkboxes": "this.isClassContainer" } }, viewQueries: [{ propertyName: "columnDef", first: true, predicate: MatColumnDef, descendants: true }], ngImport: i0, template: "<ng-container matColumnDef=\"select\">\n  <th mat-header-cell *matHeaderCellDef>\n    <mat-checkbox\n      (change)=\"$event ? masterToggle() : null\"\n      [checked]=\"selectionSet.selection.hasValue() && isAllSelected()\"\n      [indeterminate]=\"selectionSet.selection.hasValue() && !isAllSelected()\"\n      [aria-label]=\"checkboxLabel\"\n      color=\"primary\"\n      class=\"checkbox-red\"\n    >\n    </mat-checkbox>\n  </th>\n  <td mat-cell *matCellDef=\"let row; let i = index\">\n    <mat-checkbox\n      (click)=\"shiftHandler($event)\"\n      (change)=\"clickHandler(row, i, true)\"\n      [checked]=\"selectionSet.selection.isSelected(row)\"\n      [aria-label]=\"checkboxLabel\"\n      color=\"primary\"\n    >\n    </mat-checkbox>\n  </td>\n</ng-container>\n", styles: ["::ng-deep label.mat-checkbox-layout{margin-bottom:2px}\n"], dependencies: [{ kind: "directive", type: i1$7.MatHeaderCellDef, selector: "[matHeaderCellDef]" }, { kind: "directive", type: i1$7.MatColumnDef, selector: "[matColumnDef]", inputs: ["matColumnDef"] }, { kind: "directive", type: i1$7.MatCellDef, selector: "[matCellDef]" }, { kind: "directive", type: i1$7.MatHeaderCell, selector: "mat-header-cell, th[mat-header-cell]" }, { kind: "directive", type: i1$7.MatCell, selector: "mat-cell, td[mat-cell]" }, { kind: "component", type: i2$2.MatCheckbox, selector: "mat-checkbox", inputs: ["aria-label", "aria-labelledby", "aria-describedby", "aria-expanded", "aria-controls", "aria-owns", "id", "required", "labelPosition", "name", "value", "disableRipple", "tabIndex", "color", "disabledInteractive", "checked", "disabled", "indeterminate"], outputs: ["change", "indeterminateChange"], exportAs: ["matCheckbox"] }], changeDetection: i0.ChangeDetectionStrategy.OnPush }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.2", ngImport: i0, type: CGIMultiSelectCheckboxesBrandComponent, decorators: [{
            type: Component,
            args: [{ selector: 'cgi-multi-select-checkboxes', changeDetection: ChangeDetectionStrategy.OnPush, standalone: false, template: "<ng-container matColumnDef=\"select\">\n  <th mat-header-cell *matHeaderCellDef>\n    <mat-checkbox\n      (change)=\"$event ? masterToggle() : null\"\n      [checked]=\"selectionSet.selection.hasValue() && isAllSelected()\"\n      [indeterminate]=\"selectionSet.selection.hasValue() && !isAllSelected()\"\n      [aria-label]=\"checkboxLabel\"\n      color=\"primary\"\n      class=\"checkbox-red\"\n    >\n    </mat-checkbox>\n  </th>\n  <td mat-cell *matCellDef=\"let row; let i = index\">\n    <mat-checkbox\n      (click)=\"shiftHandler($event)\"\n      (change)=\"clickHandler(row, i, true)\"\n      [checked]=\"selectionSet.selection.isSelected(row)\"\n      [aria-label]=\"checkboxLabel\"\n      color=\"primary\"\n    >\n    </mat-checkbox>\n  </td>\n</ng-container>\n", styles: ["::ng-deep label.mat-checkbox-layout{margin-bottom:2px}\n"] }]
        }], ctorParameters: () => [{ type: i1$7.MatTable, decorators: [{
                    type: Optional
                }] }, { type: i0.ChangeDetectorRef }], propDecorators: { isClassContainer: [{
                type: HostBinding,
                args: ['class.cgi-multi-select-checkboxes']
            }], columnDef: [{
                type: ViewChild,
                args: [MatColumnDef]
            }], selection: [{
                type: Input
            }], selectionSet: [{
                type: Input
            }], dataSourceSorted: [{
                type: Input
            }], updatedSelectionSet: [{
                type: Output
            }] } });

/**
 * Header component for multi-select tables displaying selection count.
 *
 * Applies a container CSS class and exposes the number of selected rows.
 */
class CGIMultiSelectHeaderBrandComponent {
    constructor() {
        /**
         * HostBinding initiate
         */
        this.isClassContainer = true;
    }
    /**
     * Lifecycle hook called after data-bound properties initialization
     */
    ngOnInit() { }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.2", ngImport: i0, type: CGIMultiSelectHeaderBrandComponent, deps: [], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "20.3.2", type: CGIMultiSelectHeaderBrandComponent, isStandalone: false, selector: "cgi-multi-select-header", inputs: { totalSelected: "totalSelected" }, host: { properties: { "class.cgi-multi-select-header": "this.isClassContainer" } }, ngImport: i0, template: "<mat-card-header class=\"cgi-multi-select-header__row-margin\">\n  <div class=\"cgi-multi-select-header__row\">\n    <p class=\"cgi-body-1 cgi-multi-select-header__text\"><b>{{ totalSelected }}</b> total selected</p>\n    <ng-content></ng-content>\n  </div>\n</mat-card-header>\n", styles: [":host(.cgi-multi-select-header) .cgi-multi-select-header__row{background-color:#fff;padding:0 24px 4px;width:100%;border-bottom:1px solid #E8E8E8}:host(.cgi-multi-select-header) .cgi-multi-select-header__row .cgi-multi-select-header__text{display:inline-block;margin-bottom:0;margin-right:16px}\n"], dependencies: [{ kind: "component", type: i1$5.MatCardHeader, selector: "mat-card-header" }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.2", ngImport: i0, type: CGIMultiSelectHeaderBrandComponent, decorators: [{
            type: Component,
            args: [{ selector: 'cgi-multi-select-header', standalone: false, template: "<mat-card-header class=\"cgi-multi-select-header__row-margin\">\n  <div class=\"cgi-multi-select-header__row\">\n    <p class=\"cgi-body-1 cgi-multi-select-header__text\"><b>{{ totalSelected }}</b> total selected</p>\n    <ng-content></ng-content>\n  </div>\n</mat-card-header>\n", styles: [":host(.cgi-multi-select-header) .cgi-multi-select-header__row{background-color:#fff;padding:0 24px 4px;width:100%;border-bottom:1px solid #E8E8E8}:host(.cgi-multi-select-header) .cgi-multi-select-header__row .cgi-multi-select-header__text{display:inline-block;margin-bottom:0;margin-right:16px}\n"] }]
        }], ctorParameters: () => [], propDecorators: { isClassContainer: [{
                type: HostBinding,
                args: ['class.cgi-multi-select-header']
            }], totalSelected: [{
                type: Input
            }] } });

class CGIMultiSelectBrandModule {
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.2", ngImport: i0, type: CGIMultiSelectBrandModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule }); }
    static { this.ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "20.3.2", ngImport: i0, type: CGIMultiSelectBrandModule, declarations: [CGIMultiSelectCheckboxesBrandComponent, CGIMultiSelectHeaderBrandComponent], imports: [CommonModule,
            MatCardModule,
            MatIconModule,
            MatButtonModule,
            MatTableModule,
            MatSortModule,
            MatCheckboxModule], exports: [CGIMultiSelectCheckboxesBrandComponent, CGIMultiSelectHeaderBrandComponent] }); }
    static { this.ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "20.3.2", ngImport: i0, type: CGIMultiSelectBrandModule, imports: [CommonModule,
            MatCardModule,
            MatIconModule,
            MatButtonModule,
            MatTableModule,
            MatSortModule,
            MatCheckboxModule] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.2", ngImport: i0, type: CGIMultiSelectBrandModule, decorators: [{
            type: NgModule,
            args: [{
                    declarations: [CGIMultiSelectCheckboxesBrandComponent, CGIMultiSelectHeaderBrandComponent],
                    exports: [CGIMultiSelectCheckboxesBrandComponent, CGIMultiSelectHeaderBrandComponent],
                    imports: [
                        CommonModule,
                        MatCardModule,
                        MatIconModule,
                        MatButtonModule,
                        MatTableModule,
                        MatSortModule,
                        MatCheckboxModule,
                    ],
                }]
        }] });

/**
 * Directive to define custom content for individual accordion panels.
 * Used with content projection to allow unique templates for each panel.
 *
 * @example
 * <cgi-accordion [panels]="panels">
 *   <ng-template cgiAccordionPanel="0" let-panel>
 *     <div class="custom-content">{{ panel.title }} - Custom Content for Panel 1</div>
 *   </ng-template>
 *   <ng-template cgiAccordionPanel="1" let-panel>
 *     <my-component [data]="panel"></my-component>
 *   </ng-template>
 * </cgi-accordion>
 */
class CgiAccordionPanelDirective {
    constructor(templateRef) {
        this.templateRef = templateRef;
        /**
         * Panel index this template applies to.
         * Can be a number or 'all' to apply to all panels without specific templates.
         */
        this.panelIndex = 'all';
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.2", ngImport: i0, type: CgiAccordionPanelDirective, deps: [{ token: i0.TemplateRef }], target: i0.ɵɵFactoryTarget.Directive }); }
    static { this.ɵdir = i0.ɵɵngDeclareDirective({ minVersion: "14.0.0", version: "20.3.2", type: CgiAccordionPanelDirective, isStandalone: false, selector: "[cgiAccordionPanel]", inputs: { panelIndex: ["cgiAccordionPanel", "panelIndex"] }, ngImport: i0 }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.2", ngImport: i0, type: CgiAccordionPanelDirective, decorators: [{
            type: Directive,
            args: [{
                    selector: '[cgiAccordionPanel]',
                    standalone: false
                }]
        }], ctorParameters: () => [{ type: i0.TemplateRef }], propDecorators: { panelIndex: [{
                type: Input,
                args: ['cgiAccordionPanel']
            }] } });
/**
 * Directive to define custom header for individual accordion panels.
 *
 * @example
 * <cgi-accordion [panels]="panels">
 *   <ng-template cgiAccordionHeader="0" let-panel let-i="index">
 *     <span class="badge">{{ i + 1 }}</span> {{ panel.title }}
 *   </ng-template>
 * </cgi-accordion>
 */
class CgiAccordionHeaderDirective {
    constructor(templateRef) {
        this.templateRef = templateRef;
        /** Panel index this header template applies to */
        this.panelIndex = 'all';
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.2", ngImport: i0, type: CgiAccordionHeaderDirective, deps: [{ token: i0.TemplateRef }], target: i0.ɵɵFactoryTarget.Directive }); }
    static { this.ɵdir = i0.ɵɵngDeclareDirective({ minVersion: "14.0.0", version: "20.3.2", type: CgiAccordionHeaderDirective, isStandalone: false, selector: "[cgiAccordionHeader]", inputs: { panelIndex: ["cgiAccordionHeader", "panelIndex"] }, ngImport: i0 }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.2", ngImport: i0, type: CgiAccordionHeaderDirective, decorators: [{
            type: Directive,
            args: [{
                    selector: '[cgiAccordionHeader]',
                    standalone: false
                }]
        }], ctorParameters: () => [{ type: i0.TemplateRef }], propDecorators: { panelIndex: [{
                type: Input,
                args: ['cgiAccordionHeader']
            }] } });
/**
 * Directive to define custom icon for individual accordion panels.
 *
 * @example
 * <cgi-accordion [panels]="panels">
 *   <ng-template cgiAccordionIcon="0" let-expanded>
 *     <mat-icon>{{ expanded ? 'keyboard_arrow_up' : 'keyboard_arrow_down' }}</mat-icon>
 *   </ng-template>
 * </cgi-accordion>
 */
class CgiAccordionIconDirective {
    constructor(templateRef) {
        this.templateRef = templateRef;
        /** Panel index this icon template applies to */
        this.panelIndex = 'all';
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.2", ngImport: i0, type: CgiAccordionIconDirective, deps: [{ token: i0.TemplateRef }], target: i0.ɵɵFactoryTarget.Directive }); }
    static { this.ɵdir = i0.ɵɵngDeclareDirective({ minVersion: "14.0.0", version: "20.3.2", type: CgiAccordionIconDirective, isStandalone: false, selector: "[cgiAccordionIcon]", inputs: { panelIndex: ["cgiAccordionIcon", "panelIndex"] }, ngImport: i0 }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.2", ngImport: i0, type: CgiAccordionIconDirective, decorators: [{
            type: Directive,
            args: [{
                    selector: '[cgiAccordionIcon]',
                    standalone: false
                }]
        }], ctorParameters: () => [{ type: i0.TemplateRef }], propDecorators: { panelIndex: [{
                type: Input,
                args: ['cgiAccordionIcon']
            }] } });

/**
 * @description Reusable accordion component that supports single/multiple expanded panels
 * with optional table of contents sidebar for anchor scroll navigation.
 *
 * @example
 * // Simple accordion with single panel expanded
 * <cgi-accordion
 *   [step]="step"
 *   [panels]="defaultPanels"
 *   [expandedIndex]="0">
 * </cgi-accordion>
 *
 * // Multiple expanded panels
 * <cgi-accordion
 *   [isOpen]="isOpen"
 *   [panels]="defaultPanels"
 *   [allowMultiple]="true">
 * </cgi-accordion>
 *
 * // With table of contents
 * <cgi-accordion
 *   [step]="step"
 *   [stepIndex]="4"
 *   [panels]="anchorPanels"
 *   [showTableOfContents]="true">
 * </cgi-accordion>
 *
 * // With per-panel content projection
 * <cgi-accordion [panels]="panels">
 *   <ng-template cgiAccordionPanel="0" let-panel>
 *     <custom-component [data]="panel"></custom-component>
 *   </ng-template>
 *   <ng-template cgiAccordionPanel="1" let-panel>
 *     <another-component></another-component>
 *   </ng-template>
 *   <ng-template cgiAccordionHeader="all" let-panel let-i="index">
 *     <span class="badge">{{ i + 1 }}</span> {{ panel.title }}
 *   </ng-template>
 * </cgi-accordion>
 */
class CGIAccordionComponent {
    constructor(cdr) {
        this.cdr = cdr;
        // ============================================================
        // INPUT PROPERTIES - WITH TOC MODE (Table of Contents)
        // Uses step[stepIndex] to track single expanded panel
        // ============================================================
        /** Array to track the current step state of accordions (which panel is open) */
        this.step = [];
        // ============================================================
        // INPUT PROPERTIES - WITHOUT TOC MODE (Simple Accordion)
        // Single mode: uses expandedIndex
        // Multiple mode: uses isOpen[] array
        // ============================================================
        /** Array to track open/closed state of accordions for multiple mode (1 = open, 0 = closed) */
        this.isOpen = [];
        /** Array of accordion panel configurations */
        this.panels = [];
        /** Allow multiple panels to be open simultaneously */
        this.allowMultiple = false;
        /** Index of the initially expanded panel (single-selection mode) */
        this.expandedIndex = -1;
        /** Enable table of contents sidebar for anchor scroll navigation */
        this.showTableOfContents = false;
        /** Step index for tracking state in anchor scroll mode */
        this.stepIndex = 0;
        this.expandedPanels = []; // For multi mode - which panels are initially expanded
        this.expandIcon = 'add';
        this.collapseIcon = 'remove';
        // Customization inputs
        this.showIcons = true;
        this.headerClass = 'cgi-display-5';
        this.panelClass = '';
        // ============================================================
        // OUTPUT EVENTS
        // ============================================================
        /** Emits panel index when a panel is opened (without TOC mode) */
        this.panelOpened = new EventEmitter();
        /** Emits panel index when a panel is closed (without TOC mode) */
        this.panelClosed = new EventEmitter();
        /** Emits step change info (with TOC mode) */
        this.stepChanged = new EventEmitter();
        // ============================================================
        // INTERNAL STATE
        // ============================================================
        /** Internal tracking for expanded panel index (single mode without TOC) */
        this._expandedIndex = -1;
        /** Internal tracking for expanded panels (multiple mode without TOC) */
        this._expandedPanels = new Set();
    }
    /**
     * Angular lifecycle hook - called after component initialization
     * Initializes state arrays based on the mode (TOC vs non-TOC)
     */
    ngOnInit() {
        this.initializeState();
    }
    /**
     * Angular lifecycle hook - called when input properties change
     * Re-initializes state when relevant inputs change
     */
    ngOnChanges(changes) {
        if (changes['expandedIndex'] || changes['expandedPanels'] || changes['panels'] || changes['isOpen']) {
            this.initializeState();
        }
    }
    /**
     * Initialize state arrays based on mode
     *
     * MODE 1: With TOC (showTableOfContents = true)
     *   - Uses step[stepIndex] for tracking single expanded panel
     *   - Initialized with -1 (all collapsed)
     *
     * MODE 2: Without TOC (showTableOfContents = false)
     *   - Single mode (allowMultiple = false): uses _expandedIndex
     *   - Multiple mode (allowMultiple = true): uses _expandedPanels Set and isOpen[]
     *
     * @private
     */
    initializeState() {
        // ---- WITH TOC MODE ----
        // Initialize step array for TOC anchor scroll navigation
        if (!this.step || this.step.length === 0) {
            this.step = Array(10).fill(-1);
        }
        // ---- WITHOUT TOC MODE ----
        if (!this.showTableOfContents) {
            if (this.allowMultiple) {
                // Initialize isOpen array for multiple-selection accordions
                if (!this.isOpen || this.isOpen.length === 0) {
                    this.isOpen = Array(this.panels.length).fill(0);
                }
                // Sync internal Set with isOpen array
                this._expandedPanels.clear();
                this.isOpen.forEach((val, idx) => {
                    if (val === 1) {
                        this._expandedPanels.add(idx);
                    }
                });
                // Also add any pre-defined expandedPanels
                this.expandedPanels.forEach(idx => {
                    this._expandedPanels.add(idx);
                    if (this.isOpen[idx] !== undefined) {
                        this.isOpen[idx] = 1;
                    }
                });
            }
            else {
                // Single mode: sync internal index with input
                this._expandedIndex = this.expandedIndex;
            }
        }
    }
    /**
     * Toggle a single accordion panel (single-selection mode)
     * Closing one panel when opening another
     *
     * @param panelIndex - Index of the panel to toggle
     * @param arrayIndex - Index in the step array to modify
     */
    setStep(panelIndex, arrayIndex) {
        if (!this.step || this.step.length === 0) {
            return;
        }
        if (this.step[arrayIndex] === panelIndex) {
            this.step[arrayIndex] = -1;
        }
        else {
            this.step[arrayIndex] = panelIndex;
        }
        // Emit step change event with panel info
        this.stepChanged.emit({
            index: panelIndex,
            panel: this.panels[panelIndex]
        });
        // Trigger change detection for OnPush strategy
        this.cdr.markForCheck();
    }
    /**
     * Toggle a panel's open/closed state (multiple-selection mode)
     * Allows multiple panels to be open simultaneously
     *
     * @param panelIndex - Index of the panel to toggle
     */
    setStepData(panelIndex) {
        if (!this.isOpen || this.isOpen.length === 0) {
            return;
        }
        this.isOpen[panelIndex] = this.isOpen[panelIndex] === 1 ? 0 : 1;
    }
    /**
     * Determine if a panel should be expanded based on current mode
     *
     * WITHOUT TOC MODE:
     *   - Single mode: checks if index matches _expandedIndex
     *   - Multiple mode: checks if index is in _expandedPanels Set
     *
     * @param index - Panel index
     * @returns true if panel should be expanded
     */
    isPanelExpanded(index) {
        if (this.allowMultiple) {
            return this._expandedPanels.has(index);
        }
        return this._expandedIndex === index;
    }
    /**
     * Get the icon name for a panel header
     *
     * WITHOUT TOC MODE:
     *   - Returns collapseIcon if panel is expanded
     *   - Returns expandIcon if panel is collapsed
     *
     * @param index - Panel index
     * @returns Icon name string (e.g., 'remove' or 'add')
     */
    getIcon(index) {
        return this.isPanelExpanded(index) ? this.collapseIcon : this.expandIcon;
    }
    /**
     * Handler for panel opened event (WITHOUT TOC MODE)
     * Updates internal state and triggers change detection
     *
     * @param index - Index of the opened panel
     */
    onPanelOpened(index) {
        if (this.allowMultiple) {
            // Multiple mode: add to Set and update isOpen array
            this._expandedPanels.add(index);
            if (this.isOpen[index] !== undefined) {
                this.isOpen[index] = 1;
            }
        }
        else {
            // Single mode: update internal index
            this._expandedIndex = index;
        }
        // Trigger change detection for OnPush strategy
        this.cdr.markForCheck();
        this.panelOpened.emit(index);
    }
    /**
     * Handler for panel closed event (WITHOUT TOC MODE)
     * Updates internal state and triggers change detection
     *
     * @param index - Index of the closed panel
     */
    onPanelClosed(index) {
        if (this.allowMultiple) {
            // Multiple mode: remove from Set and update isOpen array
            this._expandedPanels.delete(index);
            if (this.isOpen[index] !== undefined) {
                this.isOpen[index] = 0;
            }
        }
        else {
            // Single mode: reset internal index if it matches
            if (this._expandedIndex === index) {
                this._expandedIndex = -1;
            }
        }
        // Trigger change detection for OnPush strategy
        this.cdr.markForCheck();
        this.panelClosed.emit(index);
    }
    // ============================================================
    // TEMPLATE GETTERS FOR PER-PANEL PROJECTION
    // ============================================================
    /**
     * Get the content template for a specific panel.
     * Priority: panel-specific template > 'all' template > legacy contentTemplate > null
     *
     * @param index - Panel index
     * @returns TemplateRef or null if using default content
     */
    getPanelContentTemplate(index) {
        if (!this.panelTemplates || this.panelTemplates.length === 0) {
            return this.contentTemplate || null;
        }
        // First, look for panel-specific template
        const specificTemplate = this.panelTemplates.find(t => t.panelIndex === index || t.panelIndex === index.toString());
        if (specificTemplate) {
            return specificTemplate.templateRef;
        }
        // Then, look for 'all' template
        const allTemplate = this.panelTemplates.find(t => t.panelIndex === 'all');
        if (allTemplate) {
            return allTemplate.templateRef;
        }
        // Fall back to legacy contentTemplate
        return this.contentTemplate || null;
    }
    /**
     * Get the header template for a specific panel.
     * Priority: panel-specific template > 'all' template > legacy headerTemplate > null
     *
     * @param index - Panel index
     * @returns TemplateRef or null if using default header
     */
    getPanelHeaderTemplate(index) {
        if (!this.headerTemplates || this.headerTemplates.length === 0) {
            return this.headerTemplate || null;
        }
        // First, look for panel-specific template
        const specificTemplate = this.headerTemplates.find(t => t.panelIndex === index || t.panelIndex === index.toString());
        if (specificTemplate) {
            return specificTemplate.templateRef;
        }
        // Then, look for 'all' template
        const allTemplate = this.headerTemplates.find(t => t.panelIndex === 'all');
        if (allTemplate) {
            return allTemplate.templateRef;
        }
        // Fall back to legacy headerTemplate
        return this.headerTemplate || null;
    }
    /**
     * Get the icon template for a specific panel.
     * Priority: panel-specific template > 'all' template > legacy iconTemplate > null
     *
     * @param index - Panel index
     * @returns TemplateRef or null if using default icon
     */
    getPanelIconTemplate(index) {
        if (!this.iconTemplates || this.iconTemplates.length === 0) {
            return this.iconTemplate || null;
        }
        // First, look for panel-specific template
        const specificTemplate = this.iconTemplates.find(t => t.panelIndex === index || t.panelIndex === index.toString());
        if (specificTemplate) {
            return specificTemplate.templateRef;
        }
        // Then, look for 'all' template
        const allTemplate = this.iconTemplates.find(t => t.panelIndex === 'all');
        if (allTemplate) {
            return allTemplate.templateRef;
        }
        // Fall back to legacy iconTemplate
        return this.iconTemplate || null;
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.2", ngImport: i0, type: CGIAccordionComponent, deps: [{ token: i0.ChangeDetectorRef }], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "20.3.2", type: CGIAccordionComponent, isStandalone: false, selector: "cgi-accordion", inputs: { step: "step", isOpen: "isOpen", panels: "panels", allowMultiple: "allowMultiple", expandedIndex: "expandedIndex", showTableOfContents: "showTableOfContents", stepIndex: "stepIndex", expandedPanels: "expandedPanels", expandIcon: "expandIcon", collapseIcon: "collapseIcon", showIcons: "showIcons", headerClass: "headerClass", panelClass: "panelClass" }, outputs: { panelOpened: "panelOpened", panelClosed: "panelClosed", stepChanged: "stepChanged" }, queries: [{ propertyName: "headerTemplate", first: true, predicate: ["headerTemplate"], descendants: true }, { propertyName: "contentTemplate", first: true, predicate: ["contentTemplate"], descendants: true }, { propertyName: "iconTemplate", first: true, predicate: ["iconTemplate"], descendants: true }, { propertyName: "panelTemplates", predicate: CgiAccordionPanelDirective }, { propertyName: "headerTemplates", predicate: CgiAccordionHeaderDirective }, { propertyName: "iconTemplates", predicate: CgiAccordionIconDirective }], usesOnChanges: true, ngImport: i0, template: "<div class=\"accordian-container\">\n  <!-- ============================================================\n       MODE 1: WITH TABLE OF CONTENTS (TOC) SIDEBAR\n       - Uses step[stepIndex] to track which panel is expanded\n       - Single selection only (clicking new panel closes previous)\n       - TOC sidebar provides anchor scroll navigation\n       - Supports template projection for header, icon, and content\n       ============================================================ -->\n  <div *ngIf=\"showTableOfContents\" class=\"cgi-anchor-scroll-accordian-container\">\n    <div class=\"cgi-anchor-scroll-container__toc ps-0\">\n      <div class=\"cgi-anchor-scroll-container__links\">\n        <ng-container *ngFor=\"let panel of panels; let i = index; let last = last\">\n          <div class=\"tagAnchor\" [ngClass]=\"step[stepIndex] === i ? 'blackColor' : 'blueColor'\"\n            (click)=\"setStep(i, stepIndex)\" (keydown.enter)=\"setStep(i, stepIndex)\"\n            (keydown.space)=\"setStep(i, stepIndex); $event.preventDefault()\" role=\"button\" [attr.tabindex]=\"0\"\n            [attr.aria-expanded]=\"step[stepIndex] === i\" [attr.aria-controls]=\"'panel-' + i\">\n            {{ panel.title }}\n          </div>\n          <div class=\"cgi-vertical-spacer-16\" *ngIf=\"!last\"></div>\n        </ng-container>\n      </div>\n    </div>\n\n    <!-- Accordion Content with TOC -->\n    <div class=\"cgi-anchor-scroll-container__contents\">\n      <mat-accordion class=\"accordian-headers-align\">\n        <mat-expansion-panel *ngFor=\"let panel of panels; let i = index\" [expanded]=\"step[stepIndex] === i\"\n          (click)=\"setStep(i, stepIndex)\" hideToggle [disabled]=\"panel.disabled\">\n          <mat-expansion-panel-header>\n            <mat-panel-title>\n              <!-- ============================================================\n                   HEADER TEMPLATE PROJECTION (TOC Mode)\n                   Priority: per-panel template > 'all' template > legacy > default\n                   ============================================================ -->\n              <ng-container *ngIf=\"getPanelHeaderTemplate(i) as headerTpl; else defaultTocHeader\">\n                <ng-container\n                  *ngTemplateOutlet=\"headerTpl; context: { $implicit: panel, index: i, expanded: step[stepIndex] === i }\"></ng-container>\n              </ng-container>\n              <ng-template #defaultTocHeader>\n                <h5 class=\"cgi-display-5\">{{ panel.title }}</h5>\n              </ng-template>\n            </mat-panel-title>\n\n            <!-- ============================================================\n                 ICON TEMPLATE PROJECTION (TOC Mode)\n                 Priority: per-panel template > 'all' template > legacy > default\n                 ============================================================ -->\n            <ng-container *ngIf=\"getPanelIconTemplate(i) as iconTpl; else defaultTocIcon\">\n              <ng-container\n                *ngTemplateOutlet=\"iconTpl; context: { $implicit: step[stepIndex] === i, expanded: step[stepIndex] === i, index: i }\"></ng-container>\n            </ng-container>\n            <ng-template #defaultTocIcon>\n              <mat-icon class=\"accordian-icon-color\">{{ step[stepIndex] === i ? collapseIcon : expandIcon }}</mat-icon>\n            </ng-template>\n          </mat-expansion-panel-header>\n\n          <!-- ============================================================\n               CONTENT TEMPLATE PROJECTION (TOC Mode)\n               Priority: per-panel template > 'all' template > legacy > default\n               ============================================================ -->\n          <ng-container *ngIf=\"getPanelContentTemplate(i) as contentTpl; else defaultTocContent\">\n            <ng-container\n              *ngTemplateOutlet=\"contentTpl; context: { $implicit: panel, index: i, expanded: step[stepIndex] === i }\"></ng-container>\n          </ng-container>\n          <ng-template #defaultTocContent>\n            <p class=\"cgi-screen\">{{ panel.content }}</p>\n            <ul class=\"cgi-body-1\" *ngIf=\"panel.items\">\n              <li class=\"cgi-body-1\" *ngFor=\"let item of panel.items\">{{ item }}</li>\n            </ul>\n          </ng-template>\n        </mat-expansion-panel>\n      </mat-accordion>\n    </div>\n  </div>\n\n  <!-- ============================================================\n       MODE 2: SIMPLE ACCORDION (without TOC)\n       - Single mode (allowMultiple=false): uses _expandedIndex internally\n       - Multiple mode (allowMultiple=true): uses _expandedPanels Set internally\n       - Supports custom templates for header, icon, and content\n       ============================================================ -->\n  <mat-accordion *ngIf=\"!showTableOfContents\" class=\"accordian-headers-align\" [multi]=\"allowMultiple\">\n    <mat-expansion-panel *ngFor=\"let panel of panels; let i = index\" [expanded]=\"isPanelExpanded(i)\"\n      (opened)=\"onPanelOpened(i)\" (closed)=\"onPanelClosed(i)\" hideToggle [disabled]=\"panel.disabled\">\n      <mat-expansion-panel-header>\n        <mat-panel-title>\n          <!-- ============================================================\n               HEADER TEMPLATE PROJECTION\n               Priority: per-panel template > 'all' template > legacy > default\n               ============================================================ -->\n          <ng-container *ngIf=\"getPanelHeaderTemplate(i) as headerTpl; else defaultHeader\">\n            <ng-container\n              *ngTemplateOutlet=\"headerTpl; context: { $implicit: panel, index: i, expanded: isPanelExpanded(i) }\"></ng-container>\n          </ng-container>\n          <ng-template #defaultHeader>\n            <h5 class=\"cgi-display-5\">{{ panel.title }}</h5>\n          </ng-template>\n        </mat-panel-title>\n\n        <!-- ============================================================\n             ICON TEMPLATE PROJECTION\n             Priority: per-panel template > 'all' template > legacy > default\n             ============================================================ -->\n        <ng-container *ngIf=\"getPanelIconTemplate(i) as iconTpl; else defaultIcon\">\n          <ng-container\n            *ngTemplateOutlet=\"iconTpl; context: { $implicit: isPanelExpanded(i), expanded: isPanelExpanded(i), index: i }\"></ng-container>\n        </ng-container>\n        <ng-template #defaultIcon>\n          <mat-icon class=\"accordian-icon-color\">{{ getIcon(i) }}</mat-icon>\n        </ng-template>\n      </mat-expansion-panel-header>\n\n      <!-- ============================================================\n           CONTENT TEMPLATE PROJECTION\n           Priority: per-panel template > 'all' template > legacy > default\n           ============================================================ -->\n      <ng-container *ngIf=\"getPanelContentTemplate(i) as contentTpl; else defaultContent\">\n        <ng-container\n          *ngTemplateOutlet=\"contentTpl; context: { $implicit: panel, index: i, expanded: isPanelExpanded(i) }\"></ng-container>\n      </ng-container>\n      <ng-template #defaultContent>\n        <p class=\"cgi-screen\">{{ panel.content }}</p>\n        <ul class=\"cgi-body-1\" *ngIf=\"panel.items\">\n          <li class=\"cgi-body-1\" *ngFor=\"let item of panel.items\">{{ item }}</li>\n        </ul>\n      </ng-template>\n    </mat-expansion-panel>\n  </mat-accordion>\n</div>", styles: [":host ::ng-deep .accordian-icon-color,.accordian-icon-color{background:linear-gradient(to right,#e31937,#a82465,#5236ab);background-clip:text;-webkit-background-clip:text;-webkit-text-fill-color:transparent;-moz-text-fill-color:transparent}:host ::ng-deep .accordian-icon,.accordian-icon{color:#5236ab}.accordian-container{width:100%}:host ::ng-deep .accordian-headers-align .mat-expansion-panel-header-description,.accordian-headers-align .mat-expansion-panel-header-description{justify-content:space-between;align-items:center}:host ::ng-deep .accordian-headers-align .mat-expansion-panel-spacing,.accordian-headers-align .mat-expansion-panel-spacing{margin:0}:host ::ng-deep .accordian-headers-align .mat-expansion-panel .mat-expansion-panel-header,.accordian-headers-align .mat-expansion-panel .mat-expansion-panel-header{padding:16px}:host ::ng-deep .accordian-headers-align .mat-expansion-panel .mat-expansion-panel-body,.accordian-headers-align .mat-expansion-panel .mat-expansion-panel-body{padding:0 16px 16px}:host ::ng-deep .accordian-headers-align .mat-expansion-panel .mat-expansion-panel-body .mat-grid-tile-content,.accordian-headers-align .mat-expansion-panel .mat-expansion-panel-body .mat-grid-tile-content{justify-content:flex-start}:host ::ng-deep .accordian-headers-align p.cgi-screen,.accordian-headers-align p.cgi-screen{margin:0}:host ::ng-deep .accordian-headers-align li.cgi-body-1,.accordian-headers-align li.cgi-body-1{padding-bottom:0;margin-top:24px}:host ::ng-deep .mat-accordion .mat-expansion-panel,.mat-accordion .mat-expansion-panel{box-shadow:0 0!important}.cgi-anchor-scroll-accordian-container{display:flex;gap:24px}.cgi-anchor-scroll-container__toc{flex:0 0 200px;position:sticky;top:16px;align-self:flex-start}.cgi-anchor-scroll-container__contents{flex:1}.tagAnchor{cursor:pointer;font-family:Source Sans Pro,sans-serif;font-style:normal;font-weight:700;font-size:14px;line-height:17px}.blueColor{color:#5236ab;text-decoration:underline;font-weight:400}.blackColor{color:#200a58!important}.cgi-vertical-spacer-16{height:16px}.mat-accordion .mat-expansion-panel.mat-expanded{margin-top:8px;margin-bottom:8px}\n"], dependencies: [{ kind: "directive", type: i1.NgClass, selector: "[ngClass]", inputs: ["class", "ngClass"] }, { kind: "directive", type: i1.NgForOf, selector: "[ngFor][ngForOf]", inputs: ["ngForOf", "ngForTrackBy", "ngForTemplate"] }, { kind: "directive", type: i1.NgIf, selector: "[ngIf]", inputs: ["ngIf", "ngIfThen", "ngIfElse"] }, { kind: "directive", type: i1.NgTemplateOutlet, selector: "[ngTemplateOutlet]", inputs: ["ngTemplateOutletContext", "ngTemplateOutlet", "ngTemplateOutletInjector"] }, { kind: "directive", type: i4$2.MatAccordion, selector: "mat-accordion", inputs: ["hideToggle", "displayMode", "togglePosition"], exportAs: ["matAccordion"] }, { kind: "component", type: i4$2.MatExpansionPanel, selector: "mat-expansion-panel", inputs: ["hideToggle", "togglePosition"], outputs: ["afterExpand", "afterCollapse"], exportAs: ["matExpansionPanel"] }, { kind: "component", type: i4$2.MatExpansionPanelHeader, selector: "mat-expansion-panel-header", inputs: ["expandedHeight", "collapsedHeight", "tabIndex"] }, { kind: "directive", type: i4$2.MatExpansionPanelTitle, selector: "mat-panel-title" }, { kind: "component", type: i5.MatIcon, selector: "mat-icon", inputs: ["color", "inline", "svgIcon", "fontSet", "fontIcon"], exportAs: ["matIcon"] }], changeDetection: i0.ChangeDetectionStrategy.OnPush }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.2", ngImport: i0, type: CGIAccordionComponent, decorators: [{
            type: Component,
            args: [{ selector: 'cgi-accordion', standalone: false, changeDetection: ChangeDetectionStrategy.OnPush, template: "<div class=\"accordian-container\">\n  <!-- ============================================================\n       MODE 1: WITH TABLE OF CONTENTS (TOC) SIDEBAR\n       - Uses step[stepIndex] to track which panel is expanded\n       - Single selection only (clicking new panel closes previous)\n       - TOC sidebar provides anchor scroll navigation\n       - Supports template projection for header, icon, and content\n       ============================================================ -->\n  <div *ngIf=\"showTableOfContents\" class=\"cgi-anchor-scroll-accordian-container\">\n    <div class=\"cgi-anchor-scroll-container__toc ps-0\">\n      <div class=\"cgi-anchor-scroll-container__links\">\n        <ng-container *ngFor=\"let panel of panels; let i = index; let last = last\">\n          <div class=\"tagAnchor\" [ngClass]=\"step[stepIndex] === i ? 'blackColor' : 'blueColor'\"\n            (click)=\"setStep(i, stepIndex)\" (keydown.enter)=\"setStep(i, stepIndex)\"\n            (keydown.space)=\"setStep(i, stepIndex); $event.preventDefault()\" role=\"button\" [attr.tabindex]=\"0\"\n            [attr.aria-expanded]=\"step[stepIndex] === i\" [attr.aria-controls]=\"'panel-' + i\">\n            {{ panel.title }}\n          </div>\n          <div class=\"cgi-vertical-spacer-16\" *ngIf=\"!last\"></div>\n        </ng-container>\n      </div>\n    </div>\n\n    <!-- Accordion Content with TOC -->\n    <div class=\"cgi-anchor-scroll-container__contents\">\n      <mat-accordion class=\"accordian-headers-align\">\n        <mat-expansion-panel *ngFor=\"let panel of panels; let i = index\" [expanded]=\"step[stepIndex] === i\"\n          (click)=\"setStep(i, stepIndex)\" hideToggle [disabled]=\"panel.disabled\">\n          <mat-expansion-panel-header>\n            <mat-panel-title>\n              <!-- ============================================================\n                   HEADER TEMPLATE PROJECTION (TOC Mode)\n                   Priority: per-panel template > 'all' template > legacy > default\n                   ============================================================ -->\n              <ng-container *ngIf=\"getPanelHeaderTemplate(i) as headerTpl; else defaultTocHeader\">\n                <ng-container\n                  *ngTemplateOutlet=\"headerTpl; context: { $implicit: panel, index: i, expanded: step[stepIndex] === i }\"></ng-container>\n              </ng-container>\n              <ng-template #defaultTocHeader>\n                <h5 class=\"cgi-display-5\">{{ panel.title }}</h5>\n              </ng-template>\n            </mat-panel-title>\n\n            <!-- ============================================================\n                 ICON TEMPLATE PROJECTION (TOC Mode)\n                 Priority: per-panel template > 'all' template > legacy > default\n                 ============================================================ -->\n            <ng-container *ngIf=\"getPanelIconTemplate(i) as iconTpl; else defaultTocIcon\">\n              <ng-container\n                *ngTemplateOutlet=\"iconTpl; context: { $implicit: step[stepIndex] === i, expanded: step[stepIndex] === i, index: i }\"></ng-container>\n            </ng-container>\n            <ng-template #defaultTocIcon>\n              <mat-icon class=\"accordian-icon-color\">{{ step[stepIndex] === i ? collapseIcon : expandIcon }}</mat-icon>\n            </ng-template>\n          </mat-expansion-panel-header>\n\n          <!-- ============================================================\n               CONTENT TEMPLATE PROJECTION (TOC Mode)\n               Priority: per-panel template > 'all' template > legacy > default\n               ============================================================ -->\n          <ng-container *ngIf=\"getPanelContentTemplate(i) as contentTpl; else defaultTocContent\">\n            <ng-container\n              *ngTemplateOutlet=\"contentTpl; context: { $implicit: panel, index: i, expanded: step[stepIndex] === i }\"></ng-container>\n          </ng-container>\n          <ng-template #defaultTocContent>\n            <p class=\"cgi-screen\">{{ panel.content }}</p>\n            <ul class=\"cgi-body-1\" *ngIf=\"panel.items\">\n              <li class=\"cgi-body-1\" *ngFor=\"let item of panel.items\">{{ item }}</li>\n            </ul>\n          </ng-template>\n        </mat-expansion-panel>\n      </mat-accordion>\n    </div>\n  </div>\n\n  <!-- ============================================================\n       MODE 2: SIMPLE ACCORDION (without TOC)\n       - Single mode (allowMultiple=false): uses _expandedIndex internally\n       - Multiple mode (allowMultiple=true): uses _expandedPanels Set internally\n       - Supports custom templates for header, icon, and content\n       ============================================================ -->\n  <mat-accordion *ngIf=\"!showTableOfContents\" class=\"accordian-headers-align\" [multi]=\"allowMultiple\">\n    <mat-expansion-panel *ngFor=\"let panel of panels; let i = index\" [expanded]=\"isPanelExpanded(i)\"\n      (opened)=\"onPanelOpened(i)\" (closed)=\"onPanelClosed(i)\" hideToggle [disabled]=\"panel.disabled\">\n      <mat-expansion-panel-header>\n        <mat-panel-title>\n          <!-- ============================================================\n               HEADER TEMPLATE PROJECTION\n               Priority: per-panel template > 'all' template > legacy > default\n               ============================================================ -->\n          <ng-container *ngIf=\"getPanelHeaderTemplate(i) as headerTpl; else defaultHeader\">\n            <ng-container\n              *ngTemplateOutlet=\"headerTpl; context: { $implicit: panel, index: i, expanded: isPanelExpanded(i) }\"></ng-container>\n          </ng-container>\n          <ng-template #defaultHeader>\n            <h5 class=\"cgi-display-5\">{{ panel.title }}</h5>\n          </ng-template>\n        </mat-panel-title>\n\n        <!-- ============================================================\n             ICON TEMPLATE PROJECTION\n             Priority: per-panel template > 'all' template > legacy > default\n             ============================================================ -->\n        <ng-container *ngIf=\"getPanelIconTemplate(i) as iconTpl; else defaultIcon\">\n          <ng-container\n            *ngTemplateOutlet=\"iconTpl; context: { $implicit: isPanelExpanded(i), expanded: isPanelExpanded(i), index: i }\"></ng-container>\n        </ng-container>\n        <ng-template #defaultIcon>\n          <mat-icon class=\"accordian-icon-color\">{{ getIcon(i) }}</mat-icon>\n        </ng-template>\n      </mat-expansion-panel-header>\n\n      <!-- ============================================================\n           CONTENT TEMPLATE PROJECTION\n           Priority: per-panel template > 'all' template > legacy > default\n           ============================================================ -->\n      <ng-container *ngIf=\"getPanelContentTemplate(i) as contentTpl; else defaultContent\">\n        <ng-container\n          *ngTemplateOutlet=\"contentTpl; context: { $implicit: panel, index: i, expanded: isPanelExpanded(i) }\"></ng-container>\n      </ng-container>\n      <ng-template #defaultContent>\n        <p class=\"cgi-screen\">{{ panel.content }}</p>\n        <ul class=\"cgi-body-1\" *ngIf=\"panel.items\">\n          <li class=\"cgi-body-1\" *ngFor=\"let item of panel.items\">{{ item }}</li>\n        </ul>\n      </ng-template>\n    </mat-expansion-panel>\n  </mat-accordion>\n</div>", styles: [":host ::ng-deep .accordian-icon-color,.accordian-icon-color{background:linear-gradient(to right,#e31937,#a82465,#5236ab);background-clip:text;-webkit-background-clip:text;-webkit-text-fill-color:transparent;-moz-text-fill-color:transparent}:host ::ng-deep .accordian-icon,.accordian-icon{color:#5236ab}.accordian-container{width:100%}:host ::ng-deep .accordian-headers-align .mat-expansion-panel-header-description,.accordian-headers-align .mat-expansion-panel-header-description{justify-content:space-between;align-items:center}:host ::ng-deep .accordian-headers-align .mat-expansion-panel-spacing,.accordian-headers-align .mat-expansion-panel-spacing{margin:0}:host ::ng-deep .accordian-headers-align .mat-expansion-panel .mat-expansion-panel-header,.accordian-headers-align .mat-expansion-panel .mat-expansion-panel-header{padding:16px}:host ::ng-deep .accordian-headers-align .mat-expansion-panel .mat-expansion-panel-body,.accordian-headers-align .mat-expansion-panel .mat-expansion-panel-body{padding:0 16px 16px}:host ::ng-deep .accordian-headers-align .mat-expansion-panel .mat-expansion-panel-body .mat-grid-tile-content,.accordian-headers-align .mat-expansion-panel .mat-expansion-panel-body .mat-grid-tile-content{justify-content:flex-start}:host ::ng-deep .accordian-headers-align p.cgi-screen,.accordian-headers-align p.cgi-screen{margin:0}:host ::ng-deep .accordian-headers-align li.cgi-body-1,.accordian-headers-align li.cgi-body-1{padding-bottom:0;margin-top:24px}:host ::ng-deep .mat-accordion .mat-expansion-panel,.mat-accordion .mat-expansion-panel{box-shadow:0 0!important}.cgi-anchor-scroll-accordian-container{display:flex;gap:24px}.cgi-anchor-scroll-container__toc{flex:0 0 200px;position:sticky;top:16px;align-self:flex-start}.cgi-anchor-scroll-container__contents{flex:1}.tagAnchor{cursor:pointer;font-family:Source Sans Pro,sans-serif;font-style:normal;font-weight:700;font-size:14px;line-height:17px}.blueColor{color:#5236ab;text-decoration:underline;font-weight:400}.blackColor{color:#200a58!important}.cgi-vertical-spacer-16{height:16px}.mat-accordion .mat-expansion-panel.mat-expanded{margin-top:8px;margin-bottom:8px}\n"] }]
        }], ctorParameters: () => [{ type: i0.ChangeDetectorRef }], propDecorators: { step: [{
                type: Input
            }], isOpen: [{
                type: Input
            }], panels: [{
                type: Input
            }], allowMultiple: [{
                type: Input
            }], expandedIndex: [{
                type: Input
            }], showTableOfContents: [{
                type: Input
            }], stepIndex: [{
                type: Input
            }], expandedPanels: [{
                type: Input
            }], expandIcon: [{
                type: Input
            }], collapseIcon: [{
                type: Input
            }], headerTemplate: [{
                type: ContentChild,
                args: ['headerTemplate']
            }], contentTemplate: [{
                type: ContentChild,
                args: ['contentTemplate']
            }], iconTemplate: [{
                type: ContentChild,
                args: ['iconTemplate']
            }], panelTemplates: [{
                type: ContentChildren,
                args: [CgiAccordionPanelDirective]
            }], headerTemplates: [{
                type: ContentChildren,
                args: [CgiAccordionHeaderDirective]
            }], iconTemplates: [{
                type: ContentChildren,
                args: [CgiAccordionIconDirective]
            }], showIcons: [{
                type: Input
            }], headerClass: [{
                type: Input
            }], panelClass: [{
                type: Input
            }], panelOpened: [{
                type: Output
            }], panelClosed: [{
                type: Output
            }], stepChanged: [{
                type: Output
            }] } });

/**
 * Module that provides the CGIAccordionComponent and its dependencies.
 *
 * Also exports directives for per-panel template projection:
 * - CgiAccordionPanelDirective: Custom content for individual panels
 * - CgiAccordionHeaderDirective: Custom header for individual panels
 * - CgiAccordionIconDirective: Custom icon for individual panels
 *
 * @example
 * // Basic usage
 * <cgi-accordion [panels]="panels"></cgi-accordion>
 *
 * // With per-panel content projection
 * <cgi-accordion [panels]="panels">
 *   <ng-template cgiAccordionPanel="0" let-panel>
 *     <custom-component [data]="panel"></custom-component>
 *   </ng-template>
 *   <ng-template cgiAccordionPanel="1" let-panel>
 *     <other-component></other-component>
 *   </ng-template>
 * </cgi-accordion>
 */
class CGIAccordionModule {
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.2", ngImport: i0, type: CGIAccordionModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule }); }
    static { this.ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "20.3.2", ngImport: i0, type: CGIAccordionModule, declarations: [CGIAccordionComponent,
            CgiAccordionPanelDirective,
            CgiAccordionHeaderDirective,
            CgiAccordionIconDirective], imports: [CommonModule, MatExpansionModule, MatIconModule], exports: [CGIAccordionComponent,
            CgiAccordionPanelDirective,
            CgiAccordionHeaderDirective,
            CgiAccordionIconDirective] }); }
    static { this.ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "20.3.2", ngImport: i0, type: CGIAccordionModule, imports: [CommonModule, MatExpansionModule, MatIconModule] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.2", ngImport: i0, type: CGIAccordionModule, decorators: [{
            type: NgModule,
            args: [{
                    declarations: [
                        CGIAccordionComponent,
                        CgiAccordionPanelDirective,
                        CgiAccordionHeaderDirective,
                        CgiAccordionIconDirective
                    ],
                    imports: [CommonModule, MatExpansionModule, MatIconModule],
                    exports: [
                        CGIAccordionComponent,
                        CgiAccordionPanelDirective,
                        CgiAccordionHeaderDirective,
                        CgiAccordionIconDirective
                    ],
                }]
        }] });

/**
 * Numeric counter input component with increment/decrement controls.
 *
 * Implements Angular's ControlValueAccessor to integrate with reactive forms.
 * Supports min/max boundaries, step size, layout direction, and appearance customization.
 */
class CgiCounterComponent {
    constructor() {
        /** Amount to increase/decrease the value per click */
        this.step = 1;
        /** Layout orientation of the controls ('horizontal' | 'vertical') */
        this.direction = 'horizontal';
        /** Whether to use outlined style for buttons/field */
        this.outlined = true;
        /** Show the value as an editable input field */
        this.inputCounter = true;
        /** Icon style for increment/decrement buttons (e.g., 'chevron') */
        this.iconType = 'chevron';
        /** Angular Material form-field appearance */
        this.appearance = 'fill';
        /** Label for the counter input */
        this.label = 'Number';
        /** Emits the new value whenever it changes */
        this.change = new EventEmitter();
        /** Function assigned by Angular forms to propagate value changes */
        this.propagateChange = (_) => {
        };
    }
    /**
     * Current value accessor
     * @returns The current numeric value
     */
    get value() {
        return this._value;
    }
    /**
     * Updates the current value and notifies listeners
     * @param val New value to set
     */
    set value(val) {
        this._value = val;
        this.propagateChange(this._value);
        this.change.emit(this._value);
    }
    /** Lifecycle hook called after component initialization */
    ngOnInit() {
    }
    /** Increments the value by the configured step */
    increment() {
        if (!this.value) {
            this.value = 0;
        }
        this.value += this.step;
    }
    /** Decrements the value by the configured step */
    decrement() {
        if (!this.value) {
            this.value = 0;
        }
        this.value -= this.step;
    }
    /**
     * Writes a value from the external form control into the component
     * @param obj Value provided by Angular forms
     */
    writeValue(obj) {
        if (obj) {
            this.value = obj;
        }
    }
    /**
     * Registers a change handler with Angular forms
     * @param fn Function to call when value changes
     */
    registerOnChange(fn) {
        this.propagateChange = fn;
    }
    /** Registers a touched handler (not used) */
    registerOnTouched(fn) {
    }
    /** Sets the disabled state of the component (not used) */
    setDisabledState(isDisabled) {
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.2", ngImport: i0, type: CgiCounterComponent, deps: [], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "20.3.2", type: CgiCounterComponent, isStandalone: false, selector: "cgi-counter", inputs: { _value: "_value", max: "max", min: "min", step: "step", direction: "direction", outlined: "outlined", inputCounter: "inputCounter", iconType: "iconType", appearance: "appearance", placeholder: "placeholder", label: "label" }, outputs: { change: "change" }, providers: [
            {
                provide: NG_VALUE_ACCESSOR,
                useExisting: forwardRef(() => CgiCounterComponent),
                multi: true
            }
        ], ngImport: i0, template: "<div [ngClass]=\"{'horizontal': direction === 'horizontal', 'unbordered': !outlined, 'counter-container':true, 'vertical': direction != 'horizontal'}\">\n    <button mat-stroked-button class=\"counter_button increment\" (click)=\"increment()\" [disabled]=\"value + step > max\">\n        <mat-icon [ngClass]=\"{\n            'material-symbols-outlined':true, \n            'vertical_chevron_icon':direction === 'vertical' && iconType === 'chevron', \n            'horizontal_chevron_icon':direction === 'horizontal' && iconType === 'chevron'\n        }\" >{{iconType === 'chevron'?'arrow_back_ios':'add_circle_outlined'}}</mat-icon>\n    </button>\n    @if(inputCounter) {\n        <mat-form-field [appearance]=\"appearance\" class=\"cgi-body-2 counter_label filled-counter-input\">\n            <input matInput  #input [placeholder]=\"placeholder\" type=\"number\" class=\"align-center\" onKeyPress=\"if(this.value.length==3) return false;\"  [(ngModel)]=\"value\" >\n        </mat-form-field>\n    }\n    @else {\n        <p class=\"cgi-body-2 counter_label\">{{value}}</p>\n    }\n    <button mat-stroked-button class=\"counter_button decrement\" (click)=\"decrement()\" [disabled]=\"value - step < min\">\n        <mat-icon [ngClass]=\"{\n            'material-symbols-outlined':true, \n            'vertical_chevron_icon':direction === 'vertical' && iconType === 'chevron', \n            'horizontal_chevron_icon':direction === 'horizontal' && iconType === 'chevron'\n        }\">{{iconType === 'chevron'?'arrow_forward_ios':'remove_circle_outlined'}}</mat-icon>\n    </button>\n</div>\n", styles: [".counter-container{display:flex;flex-direction:column}.counter-container.horizontal{flex-direction:row-reverse;justify-content:start}.counter-container.horizontal .increment{border-left:none;border-bottom-right-radius:4px;border-top-right-radius:4px}.counter-container.horizontal .increment .horizontal_chevron_icon{position:relative;right:4px}.counter-container.horizontal .decrement{border-right:none;border-bottom-left-radius:4px;border-top-left-radius:4px}.counter-container.vertical .increment{border-bottom:none;border-top-right-radius:4px;border-top-left-radius:4px}.counter-container.vertical .increment .vertical_chevron_icon{position:relative;top:4px}.counter-container.vertical .decrement{border-top:none;border-bottom-right-radius:4px;border-bottom-left-radius:4px}.unbordered.counter-container button.counter_button{background-color:transparent;border:none;outline:none;color:#200a58}.unbordered.counter-container button.counter_button:hover,.unbordered.counter-container button.counter_button.outline-hover{color:#5236ab;background-color:var(--Primary-CGI-Purple-CGI-Purple-100, #E6E3F3)}.unbordered.counter-container button.counter_button:focus,.unbordered.counter-container button.counter_button:focus-within,.unbordered.counter-container button.counter_button.cdk-keyboard-focused,.unbordered.counter-container button.counter_button.outline-focus{color:#5236ab;background-color:#f2f1f9}.unbordered.counter-container button.counter_button:active,.unbordered.counter-container button.counter_button.outline-pressed{color:#5236ab;background-color:#e6e3f3}.unbordered.counter-container button.counter_button[disabled]{color:#a8a8a8;background-color:transparent}.unbordered ::ng-deep .counter_label{border:none!important;outline:none;background:transparent!important}.vertical_chevron_icon{transform:rotate(90deg)}.horizontal_chevron_icon{transform:rotate(180deg)}.counter_label{width:56px;height:48px;margin:0;padding:12px 15px;text-align:center;background:#fff;border:none;outline:1px solid #5236ab;font-size:16px;font-family:Source Sans Pro}.counter-container button.counter_button{padding:12px 16px;height:48px;min-width:56px;width:56px;border-radius:0;border:none;outline:1px solid;background:#fff;color:#5236ab}.counter-container button.counter_button mat-icon{width:24px;height:24px;font-size:24px;margin:0}.counter-container button.counter_button{color:#5236ab}.counter-container button.counter_button:hover,.counter-container button.counter_button.outline-hover{background-color:#f2f1f9}.counter-container button.counter_button:focus,.counter-container button.counter_button:focus-within,.counter-container button.counter_button.cdk-keyboard-focused,.counter-container button.counter_button.outline-focus{color:#200a58;background-color:#e6e3f3}.counter-container button.counter_button:active,.counter-container button.counter_button.outline-pressed{color:#200a58;background-color:#cbc3e6}.counter-container button.counter_button[disabled]{background-color:#fff;color:#151515;opacity:.45;border-color:#efefef}input::-webkit-outer-spin-button,input::-webkit-inner-spin-button{-webkit-appearance:none;margin:0}input[type=number]{-moz-appearance:textfield}.mat-mdc-form-field.mat-form-field-appearance-outline .mat-mdc-input-element.align-center,.mat-mdc-form-field.mat-form-field-appearance-fill .mat-mdc-input-element.align-center{text-align:center}\n"], dependencies: [{ kind: "directive", type: i1.NgClass, selector: "[ngClass]", inputs: ["class", "ngClass"] }, { kind: "component", type: i5.MatIcon, selector: "mat-icon", inputs: ["color", "inline", "svgIcon", "fontSet", "fontIcon"], exportAs: ["matIcon"] }, { kind: "component", type: i4.MatButton, selector: "    button[matButton], a[matButton], button[mat-button], button[mat-raised-button],    button[mat-flat-button], button[mat-stroked-button], a[mat-button], a[mat-raised-button],    a[mat-flat-button], a[mat-stroked-button]  ", inputs: ["matButton"], exportAs: ["matButton", "matAnchor"] }, { kind: "directive", type: i4$3.MatInput, selector: "input[matInput], textarea[matInput], select[matNativeControl],      input[matNativeControl], textarea[matNativeControl]", inputs: ["disabled", "id", "placeholder", "name", "required", "type", "errorStateMatcher", "aria-describedby", "value", "readonly", "disabledInteractive"], exportAs: ["matInput"] }, { kind: "component", type: i8.MatFormField, selector: "mat-form-field", inputs: ["hideRequiredMarker", "color", "floatLabel", "appearance", "subscriptSizing", "hintLabel"], exportAs: ["matFormField"] }, { kind: "directive", type: i1$2.DefaultValueAccessor, selector: "input:not([type=checkbox])[formControlName],textarea[formControlName],input:not([type=checkbox])[formControl],textarea[formControl],input:not([type=checkbox])[ngModel],textarea[ngModel],[ngDefaultControl]" }, { kind: "directive", type: i1$2.NumberValueAccessor, selector: "input[type=number][formControlName],input[type=number][formControl],input[type=number][ngModel]" }, { kind: "directive", type: i1$2.NgControlStatus, selector: "[formControlName],[ngModel],[formControl]" }, { kind: "directive", type: i1$2.NgModel, selector: "[ngModel]:not([formControlName]):not([formControl])", inputs: ["name", "disabled", "ngModel", "ngModelOptions"], outputs: ["ngModelChange"], exportAs: ["ngModel"] }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.2", ngImport: i0, type: CgiCounterComponent, decorators: [{
            type: Component,
            args: [{ selector: 'cgi-counter', providers: [
                        {
                            provide: NG_VALUE_ACCESSOR,
                            useExisting: forwardRef(() => CgiCounterComponent),
                            multi: true
                        }
                    ], standalone: false, template: "<div [ngClass]=\"{'horizontal': direction === 'horizontal', 'unbordered': !outlined, 'counter-container':true, 'vertical': direction != 'horizontal'}\">\n    <button mat-stroked-button class=\"counter_button increment\" (click)=\"increment()\" [disabled]=\"value + step > max\">\n        <mat-icon [ngClass]=\"{\n            'material-symbols-outlined':true, \n            'vertical_chevron_icon':direction === 'vertical' && iconType === 'chevron', \n            'horizontal_chevron_icon':direction === 'horizontal' && iconType === 'chevron'\n        }\" >{{iconType === 'chevron'?'arrow_back_ios':'add_circle_outlined'}}</mat-icon>\n    </button>\n    @if(inputCounter) {\n        <mat-form-field [appearance]=\"appearance\" class=\"cgi-body-2 counter_label filled-counter-input\">\n            <input matInput  #input [placeholder]=\"placeholder\" type=\"number\" class=\"align-center\" onKeyPress=\"if(this.value.length==3) return false;\"  [(ngModel)]=\"value\" >\n        </mat-form-field>\n    }\n    @else {\n        <p class=\"cgi-body-2 counter_label\">{{value}}</p>\n    }\n    <button mat-stroked-button class=\"counter_button decrement\" (click)=\"decrement()\" [disabled]=\"value - step < min\">\n        <mat-icon [ngClass]=\"{\n            'material-symbols-outlined':true, \n            'vertical_chevron_icon':direction === 'vertical' && iconType === 'chevron', \n            'horizontal_chevron_icon':direction === 'horizontal' && iconType === 'chevron'\n        }\">{{iconType === 'chevron'?'arrow_forward_ios':'remove_circle_outlined'}}</mat-icon>\n    </button>\n</div>\n", styles: [".counter-container{display:flex;flex-direction:column}.counter-container.horizontal{flex-direction:row-reverse;justify-content:start}.counter-container.horizontal .increment{border-left:none;border-bottom-right-radius:4px;border-top-right-radius:4px}.counter-container.horizontal .increment .horizontal_chevron_icon{position:relative;right:4px}.counter-container.horizontal .decrement{border-right:none;border-bottom-left-radius:4px;border-top-left-radius:4px}.counter-container.vertical .increment{border-bottom:none;border-top-right-radius:4px;border-top-left-radius:4px}.counter-container.vertical .increment .vertical_chevron_icon{position:relative;top:4px}.counter-container.vertical .decrement{border-top:none;border-bottom-right-radius:4px;border-bottom-left-radius:4px}.unbordered.counter-container button.counter_button{background-color:transparent;border:none;outline:none;color:#200a58}.unbordered.counter-container button.counter_button:hover,.unbordered.counter-container button.counter_button.outline-hover{color:#5236ab;background-color:var(--Primary-CGI-Purple-CGI-Purple-100, #E6E3F3)}.unbordered.counter-container button.counter_button:focus,.unbordered.counter-container button.counter_button:focus-within,.unbordered.counter-container button.counter_button.cdk-keyboard-focused,.unbordered.counter-container button.counter_button.outline-focus{color:#5236ab;background-color:#f2f1f9}.unbordered.counter-container button.counter_button:active,.unbordered.counter-container button.counter_button.outline-pressed{color:#5236ab;background-color:#e6e3f3}.unbordered.counter-container button.counter_button[disabled]{color:#a8a8a8;background-color:transparent}.unbordered ::ng-deep .counter_label{border:none!important;outline:none;background:transparent!important}.vertical_chevron_icon{transform:rotate(90deg)}.horizontal_chevron_icon{transform:rotate(180deg)}.counter_label{width:56px;height:48px;margin:0;padding:12px 15px;text-align:center;background:#fff;border:none;outline:1px solid #5236ab;font-size:16px;font-family:Source Sans Pro}.counter-container button.counter_button{padding:12px 16px;height:48px;min-width:56px;width:56px;border-radius:0;border:none;outline:1px solid;background:#fff;color:#5236ab}.counter-container button.counter_button mat-icon{width:24px;height:24px;font-size:24px;margin:0}.counter-container button.counter_button{color:#5236ab}.counter-container button.counter_button:hover,.counter-container button.counter_button.outline-hover{background-color:#f2f1f9}.counter-container button.counter_button:focus,.counter-container button.counter_button:focus-within,.counter-container button.counter_button.cdk-keyboard-focused,.counter-container button.counter_button.outline-focus{color:#200a58;background-color:#e6e3f3}.counter-container button.counter_button:active,.counter-container button.counter_button.outline-pressed{color:#200a58;background-color:#cbc3e6}.counter-container button.counter_button[disabled]{background-color:#fff;color:#151515;opacity:.45;border-color:#efefef}input::-webkit-outer-spin-button,input::-webkit-inner-spin-button{-webkit-appearance:none;margin:0}input[type=number]{-moz-appearance:textfield}.mat-mdc-form-field.mat-form-field-appearance-outline .mat-mdc-input-element.align-center,.mat-mdc-form-field.mat-form-field-appearance-fill .mat-mdc-input-element.align-center{text-align:center}\n"] }]
        }], propDecorators: { _value: [{
                type: Input
            }], max: [{
                type: Input
            }], min: [{
                type: Input
            }], step: [{
                type: Input
            }], direction: [{
                type: Input
            }], outlined: [{
                type: Input
            }], inputCounter: [{
                type: Input
            }], iconType: [{
                type: Input
            }], appearance: [{
                type: Input
            }], placeholder: [{
                type: Input
            }], label: [{
                type: Input
            }], change: [{
                type: Output
            }] } });

class CGICounterModule {
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.2", ngImport: i0, type: CGICounterModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule }); }
    static { this.ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "20.3.2", ngImport: i0, type: CGICounterModule, declarations: [CgiCounterComponent], imports: [CommonModule,
            MatIconModule,
            MatButtonModule,
            MatIconModule,
            MatInputModule,
            FormsModule], exports: [CgiCounterComponent] }); }
    static { this.ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "20.3.2", ngImport: i0, type: CGICounterModule, imports: [CommonModule,
            MatIconModule,
            MatButtonModule,
            MatIconModule,
            MatInputModule,
            FormsModule] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.2", ngImport: i0, type: CGICounterModule, decorators: [{
            type: NgModule,
            args: [{
                    imports: [
                        CommonModule,
                        MatIconModule,
                        MatButtonModule,
                        MatIconModule,
                        MatInputModule,
                        FormsModule
                    ],
                    declarations: [CgiCounterComponent],
                    exports: [CgiCounterComponent],
                    providers: [],
                }]
        }] });

/**
 * Displays the CGI brand logo with optional header and subheader.
 *
 * Supports different logo styles and optional text labels.
 */
class CgiLogoComponent {
    constructor() {
        /** Logo variant to display */
        this.logoType = 'original';
        /** Optional header text displayed next to the logo */
        this.header = '';
        /** Optional subheader text displayed below the header */
        this.subHeader = '';
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.2", ngImport: i0, type: CgiLogoComponent, deps: [], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "20.3.2", type: CgiLogoComponent, isStandalone: false, selector: "cgi-logo", inputs: { logoType: "logoType", header: "header", subHeader: "subHeader" }, ngImport: i0, template: "<div class=\"cgi-logo-container\">\n  <div class=\"cgi-logo-image-container\">\n    <img\n      *ngIf=\"logoType === 'original'\"\n      src=\"assets/images/CGI-original-logo.svg\"\n      alt=\"Original Logo\"\n      class=\"logo\"\n    />\n    <img\n      *ngIf=\"logoType === 'black'\"\n      src=\"assets/images/CGI-black-logo.svg\"\n      alt=\"Black Logo\"\n      class=\"logo black\"\n    />\n  </div>\n\n  <div class=\"cgi-logo-separator\" *ngIf=\"header && logoType !== 'black'\">|</div>\n  <div class=\"header-container\">\n    <div *ngIf=\"header\" class=\"header\">{{ header }}</div>\n    <div *ngIf=\"subHeader\" class=\"sub-header\">{{ subHeader }}</div>\n  </div>\n</div>\n", styles: [".cgi-logo-container{display:flex;align-items:center}.logo{max-width:100%;height:auto}.header{font-size:1.5rem;font-weight:400;margin-left:0!important;color:#333;line-height:normal}.sub-header{font-size:14px;color:#333;font-weight:400;line-height:normal}.header-container{padding-left:16px}.cgi-logo-separator{color:#a8a8a8}.logo{padding:16px}.logo.black{background-color:#333}.cgi-logo-image-container{width:101.272px;height:64px}\n"], dependencies: [{ kind: "directive", type: i1.NgIf, selector: "[ngIf]", inputs: ["ngIf", "ngIfThen", "ngIfElse"] }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.2", ngImport: i0, type: CgiLogoComponent, decorators: [{
            type: Component,
            args: [{ selector: 'cgi-logo', standalone: false, template: "<div class=\"cgi-logo-container\">\n  <div class=\"cgi-logo-image-container\">\n    <img\n      *ngIf=\"logoType === 'original'\"\n      src=\"assets/images/CGI-original-logo.svg\"\n      alt=\"Original Logo\"\n      class=\"logo\"\n    />\n    <img\n      *ngIf=\"logoType === 'black'\"\n      src=\"assets/images/CGI-black-logo.svg\"\n      alt=\"Black Logo\"\n      class=\"logo black\"\n    />\n  </div>\n\n  <div class=\"cgi-logo-separator\" *ngIf=\"header && logoType !== 'black'\">|</div>\n  <div class=\"header-container\">\n    <div *ngIf=\"header\" class=\"header\">{{ header }}</div>\n    <div *ngIf=\"subHeader\" class=\"sub-header\">{{ subHeader }}</div>\n  </div>\n</div>\n", styles: [".cgi-logo-container{display:flex;align-items:center}.logo{max-width:100%;height:auto}.header{font-size:1.5rem;font-weight:400;margin-left:0!important;color:#333;line-height:normal}.sub-header{font-size:14px;color:#333;font-weight:400;line-height:normal}.header-container{padding-left:16px}.cgi-logo-separator{color:#a8a8a8}.logo{padding:16px}.logo.black{background-color:#333}.cgi-logo-image-container{width:101.272px;height:64px}\n"] }]
        }], propDecorators: { logoType: [{
                type: Input
            }], header: [{
                type: Input
            }], subHeader: [{
                type: Input
            }] } });

class CGILogoModule {
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.2", ngImport: i0, type: CGILogoModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule }); }
    static { this.ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "20.3.2", ngImport: i0, type: CGILogoModule, declarations: [CgiLogoComponent], imports: [CommonModule], exports: [CgiLogoComponent] }); }
    static { this.ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "20.3.2", ngImport: i0, type: CGILogoModule, imports: [CommonModule] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.2", ngImport: i0, type: CGILogoModule, decorators: [{
            type: NgModule,
            args: [{
                    imports: [CommonModule],
                    declarations: [CgiLogoComponent],
                    exports: [CgiLogoComponent],
                    providers: [],
                }]
        }] });

/**
 * Explorer list component that renders a searchable list of items.
 *
 * Supports filtering by configured properties, single selection, and an optional
 * 'All' selection that emits a synthetic item representing the entire set.
 */
class CGIExplorerListComponent {
    constructor() {
        /** Full list of items to display */
        this.list = [];
        /** Disables interactions when true */
        this.disabled = false;
        /** Currently selected item (or null) */
        this.selected = null;
        /** Enables the synthetic 'All' selection option */
        this.isAllOptionEnabled = true;
        /** Emits when selection changes */
        this.selectionChange = new EventEmitter();
        /** Current search string used for filtering */
        this.searchInput = '';
        /** Items after applying the current filter */
        this.filteredItems = [];
        /** Internal selected item reference */
        this.selectedItem = null;
    }
    /** initialize component */
    ngOnInit() {
        this.filteredItems = this.list;
        this.selectedItem = this.selected ?? null;
        this.isClassContainer = true;
    }
    /**
     * Reacts to changes in the search term or the item list
     * @param changes Object containing changed input values
     */
    ngOnChanges(changes) {
        if (changes['searchInput'] || changes['list']) {
            console.log(this.list + this.explorerListConfig.listName);
            this.applyFilter();
        }
    }
    /**
     * Applies the search filter to the list based on configured properties
     */
    applyFilter() {
        if (!this.searchInput) {
            this.filteredItems = [...this.list];
            return;
        }
        const search = this.searchInput.toLowerCase();
        const filterProps = this.explorerListConfig.filterByProperties?.length
            ? this.explorerListConfig.filterByProperties
            : [this.explorerListConfig.listItemName];
        this.filteredItems = this.list.filter(item => filterProps.some(prop => (item[prop] ?? '').toString().toLowerCase().includes(search)));
    }
    /**
     * Handles user selection of a specific item
     * @param item The item selected by the user
     * @emits selectionChange Emits the selected item
     */
    handleSelection(item) {
        this.selectedItem = item;
        this.selectionChange.emit(item);
    }
    /**
     * Selects the synthetic 'All' option and clears the search term
     * @emits selectionChange Emits a synthetic item representing 'All'
     */
    handleSelectAll() {
        this.searchInput = '';
        this.selectedItem = { code: 'all', name: 'All', type: '', childCodeList: [] };
        this.selectionChange.emit(this.selectedItem);
    }
    /**
     * Determines if a given item is currently selected
     * @param item Item to test
     * @returns True if the item matches the current selection
     */
    isSelected(item) {
        return (this.selected &&
            this.selected[this.explorerListConfig.listItemCode] === item[this.explorerListConfig.listItemCode]);
    }
    /**
     * Indicates if the current selection is the synthetic 'All' option
     * @returns True if 'All' is selected
     */
    isAllSelected() {
        return this.selected?.code === 'all';
    }
    /**
     * Checks if an item is enabled based on the configured type filter
     * @param item Item to evaluate
     * @returns True if the item type matches the required type or no filter is set
     */
    isOptionEnabledByType(item) {
        const requiredType = this.explorerListConfig.enabledOptionType;
        if (requiredType) {
            return item[this.explorerListConfig.listItemType] === requiredType;
        }
        return true;
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.2", ngImport: i0, type: CGIExplorerListComponent, deps: [], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "20.3.2", type: CGIExplorerListComponent, isStandalone: false, selector: "cgi-explorer-list", inputs: { list: "list", explorerListConfig: "explorerListConfig", disabled: "disabled", selected: "selected", isAllOptionEnabled: "isAllOptionEnabled" }, outputs: { selectionChange: "selectionChange" }, host: { properties: { "class.cgi-explorer-list": "this.isClassContainer" } }, usesOnChanges: true, ngImport: i0, template: "<div class=\"cgi-explorer\">\n  <mat-form-field appearance=\"outline\" class=\"w-100\">\n    <mat-label>Search by {{ explorerListConfig.listName }}</mat-label>\n    <input\n      matInput\n      [(ngModel)]=\"searchInput\"\n      (ngModelChange)=\"applyFilter()\"\n      [disabled]=\"disabled\"\n      placeholder=\"Search\"\n    />\n    <mat-icon matPrefix>search</mat-icon>\n  </mat-form-field>\n\n  <mat-list class=\"cgi-explorer-list list-style\">\n    <mat-list-item *ngIf=\"filteredItems.length === 0 && !disabled\">\n      <span class=\"text-muted\">No results</span>\n    </mat-list-item>\n\n    <mat-list-item\n      *ngIf=\"isAllOptionEnabled && filteredItems.length > 0\"\n      (click)=\"handleSelectAll()\"\n      [class.selected]=\"isAllSelected()\"\n      role=\"button\"\n    >\n      <div matLine class=\"cgi-body-2\">All</div>\n    </mat-list-item>\n\n    <mat-list-item\n      *ngFor=\"let item of filteredItems; index as i\"\n      (click)=\"handleSelection(item)\"\n      [class.selected]=\"isSelected(item)\"\n      [class.disabled]=\"!isOptionEnabledByType(item) || disabled\"\n      role=\"button\"\n    >\n      <div matLine class=\"list-item-text cgi-body-2\">\n        {{ item[explorerListConfig.listItemName] }}\n      </div>\n      <mat-icon *ngIf=\"item.childCodeList?.length\">keyboard_arrow_right</mat-icon>\n    </mat-list-item>\n  </mat-list>\n</div>\n", styles: [":host(.cgi-explorer-list) ::ng-deep .list-item-text{display:flex;flex-direction:column;justify-content:center;flex:1 0 0;align-self:stretch}:host(.cgi-explorer-list) ::ng-deep .cgi-explorer-list{height:288px;overflow-y:auto;border-bottom:1px solid #A8A8A8;border-left:1px solid #A8A8A8;background-color:#f2f1f9}:host(.cgi-explorer-list) ::ng-deep .mat-mdc-list{border-radius:0}\n"], dependencies: [{ kind: "directive", type: i1.NgForOf, selector: "[ngFor][ngForOf]", inputs: ["ngForOf", "ngForTrackBy", "ngForTemplate"] }, { kind: "directive", type: i1.NgIf, selector: "[ngIf]", inputs: ["ngIf", "ngIfThen", "ngIfElse"] }, { kind: "component", type: i8.MatFormField, selector: "mat-form-field", inputs: ["hideRequiredMarker", "color", "floatLabel", "appearance", "subscriptSizing", "hintLabel"], exportAs: ["matFormField"] }, { kind: "directive", type: i8.MatLabel, selector: "mat-label" }, { kind: "directive", type: i8.MatPrefix, selector: "[matPrefix], [matIconPrefix], [matTextPrefix]", inputs: ["matTextPrefix"] }, { kind: "component", type: i12.MatList, selector: "mat-list", exportAs: ["matList"] }, { kind: "component", type: i12.MatListItem, selector: "mat-list-item, a[mat-list-item], button[mat-list-item]", inputs: ["activated"], exportAs: ["matListItem"] }, { kind: "directive", type: i1$2.DefaultValueAccessor, selector: "input:not([type=checkbox])[formControlName],textarea[formControlName],input:not([type=checkbox])[formControl],textarea[formControl],input:not([type=checkbox])[ngModel],textarea[ngModel],[ngDefaultControl]" }, { kind: "directive", type: i1$2.NgControlStatus, selector: "[formControlName],[ngModel],[formControl]" }, { kind: "directive", type: i1$2.NgModel, selector: "[ngModel]:not([formControlName]):not([formControl])", inputs: ["name", "disabled", "ngModel", "ngModelOptions"], outputs: ["ngModelChange"], exportAs: ["ngModel"] }, { kind: "directive", type: i4$3.MatInput, selector: "input[matInput], textarea[matInput], select[matNativeControl],      input[matNativeControl], textarea[matNativeControl]", inputs: ["disabled", "id", "placeholder", "name", "required", "type", "errorStateMatcher", "aria-describedby", "value", "readonly", "disabledInteractive"], exportAs: ["matInput"] }, { kind: "component", type: i5.MatIcon, selector: "mat-icon", inputs: ["color", "inline", "svgIcon", "fontSet", "fontIcon"], exportAs: ["matIcon"] }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.2", ngImport: i0, type: CGIExplorerListComponent, decorators: [{
            type: Component,
            args: [{ selector: 'cgi-explorer-list', standalone: false, template: "<div class=\"cgi-explorer\">\n  <mat-form-field appearance=\"outline\" class=\"w-100\">\n    <mat-label>Search by {{ explorerListConfig.listName }}</mat-label>\n    <input\n      matInput\n      [(ngModel)]=\"searchInput\"\n      (ngModelChange)=\"applyFilter()\"\n      [disabled]=\"disabled\"\n      placeholder=\"Search\"\n    />\n    <mat-icon matPrefix>search</mat-icon>\n  </mat-form-field>\n\n  <mat-list class=\"cgi-explorer-list list-style\">\n    <mat-list-item *ngIf=\"filteredItems.length === 0 && !disabled\">\n      <span class=\"text-muted\">No results</span>\n    </mat-list-item>\n\n    <mat-list-item\n      *ngIf=\"isAllOptionEnabled && filteredItems.length > 0\"\n      (click)=\"handleSelectAll()\"\n      [class.selected]=\"isAllSelected()\"\n      role=\"button\"\n    >\n      <div matLine class=\"cgi-body-2\">All</div>\n    </mat-list-item>\n\n    <mat-list-item\n      *ngFor=\"let item of filteredItems; index as i\"\n      (click)=\"handleSelection(item)\"\n      [class.selected]=\"isSelected(item)\"\n      [class.disabled]=\"!isOptionEnabledByType(item) || disabled\"\n      role=\"button\"\n    >\n      <div matLine class=\"list-item-text cgi-body-2\">\n        {{ item[explorerListConfig.listItemName] }}\n      </div>\n      <mat-icon *ngIf=\"item.childCodeList?.length\">keyboard_arrow_right</mat-icon>\n    </mat-list-item>\n  </mat-list>\n</div>\n", styles: [":host(.cgi-explorer-list) ::ng-deep .list-item-text{display:flex;flex-direction:column;justify-content:center;flex:1 0 0;align-self:stretch}:host(.cgi-explorer-list) ::ng-deep .cgi-explorer-list{height:288px;overflow-y:auto;border-bottom:1px solid #A8A8A8;border-left:1px solid #A8A8A8;background-color:#f2f1f9}:host(.cgi-explorer-list) ::ng-deep .mat-mdc-list{border-radius:0}\n"] }]
        }], propDecorators: { isClassContainer: [{
                type: HostBinding,
                args: ['class.cgi-explorer-list']
            }], list: [{
                type: Input
            }], explorerListConfig: [{
                type: Input
            }], disabled: [{
                type: Input
            }], selected: [{
                type: Input
            }], isAllOptionEnabled: [{
                type: Input
            }], selectionChange: [{
                type: Output
            }] } });

/**
 * Displays the details panel for an explorer list selection.
 *
 * Renders a list of detail items and optionally shows an action button
 * that emits selected detail data to the parent component.
 */
class CGIExplorerListDetailsComponent {
    constructor() {
        /** List of detail items to render */
        this.list = [];
        /** Text label for the action button */
        this.actionText = '';
        /** Controls visibility of the action button */
        this.isAction = false;
        /** Emits the current detail items when an action is triggered */
        this.action = new EventEmitter();
        /** Internal flag mirroring `isAction` to show/hide the action button */
        this.isActionVisible = false;
        /** Local copy of the detail list used for rendering and emission */
        this.viewData = [];
    }
    /** initialize component */
    ngOnInit() {
        this.isClassContainer = true;
    }
    /**
     * Reacts to changes in inputs and updates internal state
     * @param changes Object containing changed input values
     */
    ngOnChanges(changes) {
        if (changes['isAction']) {
            this.isActionVisible = this.isAction;
        }
        if (changes['list']) {
            this.viewData = [...this.list];
        }
    }
    /**
     * Handles click on the action button
     * @emits action Emits the current `viewData` list
     */
    handleActionClick() {
        this.action.emit(this.viewData);
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.2", ngImport: i0, type: CGIExplorerListDetailsComponent, deps: [], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "20.3.2", type: CGIExplorerListDetailsComponent, isStandalone: false, selector: "cgi-explorer-list-details", inputs: { list: "list", actionText: "actionText", isAction: "isAction" }, outputs: { action: "action" }, host: { properties: { "class.cgi-explorer-list-details": "this.isClassContainer" } }, usesOnChanges: true, ngImport: i0, template: "<div class=\"explorer-info\">\n  <div class=\"details-text\">\n    <div class=\"details-pair\" *ngFor=\"let item of viewData; let i = index\">\n      <span class=\"label cgi-body-1-bold\">{{ item.label }}: </span>\n      <span class=\"value cgi-body-1\">{{ item.value }}</span>\n    </div>\n  </div>\n\n  <div class=\"button-container\" *ngIf=\"isActionVisible\">\n    <button\n      class=\"small-button\"\n      mat-stroked-button\n      aria-label=\"Default option text button\"\n      (click)=\"handleActionClick()\"\n    >\n      {{ actionText }}\n    </button>\n  </div>\n</div>\n", styles: [":host(.cgi-explorer-list-details) ::ng-deep .explorer-info{display:flex;max-height:336px;padding:16px;flex-direction:column;align-items:flex-start;gap:8px;align-self:stretch;border-radius:0 4px 4px 0;border:1px solid #A8A8A8;background:#fcfdfd}:host(.cgi-explorer-list-details) ::ng-deep .details-text{display:flex;flex-direction:column;gap:8px;overflow-y:auto;width:100%}:host(.cgi-explorer-list-details) ::ng-deep .label{width:120px;align-self:stretch}:host(.cgi-explorer-list-details) ::ng-deep .value{flex:1 0 0;align-self:stretch}:host(.cgi-explorer-list-details) ::ng-deep .details-pair{display:flex;align-items:flex-start;gap:8px;align-self:stretch}:host(.cgi-explorer-list-details) ::ng-deep .button-container{display:flex;padding:8px 0;flex-direction:column;justify-content:flex-end;align-items:center;gap:10px;align-self:stretch}\n"], dependencies: [{ kind: "directive", type: i1.NgForOf, selector: "[ngFor][ngForOf]", inputs: ["ngForOf", "ngForTrackBy", "ngForTemplate"] }, { kind: "directive", type: i1.NgIf, selector: "[ngIf]", inputs: ["ngIf", "ngIfThen", "ngIfElse"] }, { kind: "component", type: i4.MatButton, selector: "    button[matButton], a[matButton], button[mat-button], button[mat-raised-button],    button[mat-flat-button], button[mat-stroked-button], a[mat-button], a[mat-raised-button],    a[mat-flat-button], a[mat-stroked-button]  ", inputs: ["matButton"], exportAs: ["matButton", "matAnchor"] }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.2", ngImport: i0, type: CGIExplorerListDetailsComponent, decorators: [{
            type: Component,
            args: [{ selector: 'cgi-explorer-list-details', standalone: false, template: "<div class=\"explorer-info\">\n  <div class=\"details-text\">\n    <div class=\"details-pair\" *ngFor=\"let item of viewData; let i = index\">\n      <span class=\"label cgi-body-1-bold\">{{ item.label }}: </span>\n      <span class=\"value cgi-body-1\">{{ item.value }}</span>\n    </div>\n  </div>\n\n  <div class=\"button-container\" *ngIf=\"isActionVisible\">\n    <button\n      class=\"small-button\"\n      mat-stroked-button\n      aria-label=\"Default option text button\"\n      (click)=\"handleActionClick()\"\n    >\n      {{ actionText }}\n    </button>\n  </div>\n</div>\n", styles: [":host(.cgi-explorer-list-details) ::ng-deep .explorer-info{display:flex;max-height:336px;padding:16px;flex-direction:column;align-items:flex-start;gap:8px;align-self:stretch;border-radius:0 4px 4px 0;border:1px solid #A8A8A8;background:#fcfdfd}:host(.cgi-explorer-list-details) ::ng-deep .details-text{display:flex;flex-direction:column;gap:8px;overflow-y:auto;width:100%}:host(.cgi-explorer-list-details) ::ng-deep .label{width:120px;align-self:stretch}:host(.cgi-explorer-list-details) ::ng-deep .value{flex:1 0 0;align-self:stretch}:host(.cgi-explorer-list-details) ::ng-deep .details-pair{display:flex;align-items:flex-start;gap:8px;align-self:stretch}:host(.cgi-explorer-list-details) ::ng-deep .button-container{display:flex;padding:8px 0;flex-direction:column;justify-content:flex-end;align-items:center;gap:10px;align-self:stretch}\n"] }]
        }], propDecorators: { isClassContainer: [{
                type: HostBinding,
                args: ['class.cgi-explorer-list-details']
            }], list: [{
                type: Input
            }], actionText: [{
                type: Input
            }], isAction: [{
                type: Input
            }], action: [{
                type: Output
            }] } });

/**
 * Container component orchestrating multiple explorer list segments.
 *
 * Manages cascaded selections across segments, filters subsequent segments
 * based on parent-child relationships, and exposes a details view with an
 * optional action trigger.
 */
class CGIExplorerListContainerComponent {
    constructor() {
        /**
          * Input array of explorer list items
          */
        this.listData = [];
        /**
         * Input array of explorer list configuration
         */
        this.listConfigData = [];
        /**
       * Input object for selections state
       */
        this.selections = {};
        /**
        * Input array of explorer list details
        */
        this.infoData = [];
        /**
       * Input for test data identifier
       */
        this.dataTestId = '';
        /**
       * Event emitter for selection changes
       */
        this.onSelectionChange = new EventEmitter();
        /**
       * Event emitter for details actions
       */
        this.onDetailsAction = new EventEmitter();
        /** Current list of selected items per segment */
        this.selected = [];
        /** Most recently updated selection and its segment index */
        this.currentSelection = {};
        /** Details data currently shown in the info panel */
        this.viewData = [];
        /** Whether the info action is enabled and visible */
        this.infoAction = true;
        /** Working copy of the segment data after filtering */
        this.segmentData = [];
        /** Original unfiltered segment data snapshot */
        this.segmentDataOriginal = [];
    }
    /** Initialize default values */
    ngOnInit() {
        this.segmentData = [...this.listData];
        this.segmentDataOriginal = [...this.listData];
        this.viewData = [...this.infoData];
        this.selected = this.initialSelected(this.segmentData);
        this.isClassContainer = true;
    }
    /**
     * Update details view when inputs change
     * @param changes Object containing changed input values
     */
    ngOnChanges(changes) {
        if (changes['infoData']) {
            this.viewData = [...this.infoData];
        }
    }
    /**
     * Computes initial selection for each segment
     * @param data Two-dimensional array of segment items
     * @returns Array of initially selected items per segment
     */
    initialSelected(data) {
        return data.map((segment, index) => {
            if (segment.length > 0 && index !== data.length - 1) {
                return { code: 'all', name: 'All' };
            }
            else if (segment.length > 0) {
                return segment[0];
            }
            return null;
        }).filter(Boolean);
    }
    /**
     * Handles updates when a new item is selected in a segment
     * @param data Selected item (or fallback)
     * @param index Segment index where selection occurred
     * @emits onSelectionChange Emits updated selection array
     */
    getSelectedEvent(data, index) {
        if (!data || Object.keys(data).length === 0) {
            data = this.selected[index] || { code: 'all', name: 'All' };
        }
        else {
            this.selected[index] = data;
        }
        if (data.childCodeList?.length > 0 && data.code !== 'all') {
            let updated = [...this.segmentData];
            let filterCodes = data.childCodeList;
            for (let i = index + 1; i < this.segmentDataOriginal.length; i++) {
                updated[i] = this.filteredNextSegmentData(filterCodes, this.segmentDataOriginal[i]);
                if (updated[i].length === 0) {
                    updated.length = i; // trim beyond
                    break;
                }
                else {
                    filterCodes = updated[i].reduce((acc, item) => {
                        return acc.concat(item.childCodeList || []);
                    }, []);
                }
            }
            this.segmentData = [...updated];
        }
        else if ((!data.childCodeList || data.childCodeList.length === 0) && data.code !== 'all') {
            this.segmentData = this.segmentData.slice(0, index + 1);
        }
        else if (data.code === 'all' && index !== this.segmentDataOriginal.length - 1) {
            const updated = [...this.segmentDataOriginal];
            this.segmentData = updated;
        }
        this.currentSelection = { data, index };
        this.selected = this.setListSelection(data, index, [...this.segmentData], [...this.selected]);
        this.onSelectionChange.emit(this.selected);
    }
    /**
     * Updates the selection array based on the current pick and segment layout
     * @param data The item selected
     * @param index Segment index where selection occurred
     * @param segmentData Working segment data after filters
     * @param currentSelection Previous selection array
     * @returns New selection array
     */
    setListSelection(data, index, segmentData, currentSelection) {
        let selectionResult = [...currentSelection];
        if (!data)
            return selectionResult;
        if (selectionResult.length > segmentData.length) {
            selectionResult = selectionResult.slice(0, segmentData.length);
        }
        if (index < segmentData.length - 1) {
            for (let i = index; i < segmentData.length; i++) {
                if (i === index) {
                    selectionResult[i] = data;
                }
                else if (i !== index && i < segmentData.length - 1) {
                    selectionResult[i] = { code: 'all', name: 'All' };
                }
                else {
                    selectionResult[i] = segmentData[i][0];
                }
            }
            /** Update previous selections if parentCode exists*/
            selectionResult =
                this.updatePreviousSegmentData(selectionResult, data, index, segmentData) || selectionResult;
        }
        else {
            selectionResult[index] = data;
            selectionResult =
                this.updatePreviousSegmentData(selectionResult, data, index, segmentData) || selectionResult;
        }
        return selectionResult;
    }
    /**
     * Walks back through previous segments to align selections with parent-child relationships
     * @param selections Current selection array
     * @param data Current selected item
     * @param index Current segment index
     * @param segmentData Working segment data
     * @returns Updated selections or void
     */
    updatePreviousSegmentData(selections, data, index, segmentData) {
        if (data.code !== 'all' && data.parentCode) {
            let selectedObject = data;
            for (let i = index - 1; i >= 0; i--) {
                if (selections.length && selections[i].code === 'all' && selectedObject?.parentCode) {
                    segmentData[i + 1] = this.filterCurrentSegmentData(selectedObject.parentCode, segmentData[i + 1]);
                }
                const prevList = segmentData[i];
                if (selectedObject?.parentCode) {
                    selectedObject = prevList.find((item) => item.code === selectedObject.parentCode);
                }
                selections[i] = selectedObject || selections[i];
            }
            this.segmentData = [...segmentData];
            return selections;
        }
    }
    /**
     * Filters a segment to only items with the given parent code
     * @param filterCode Parent code to match
     * @param segmentData Segment items to filter
     * @returns Filtered items for the segment
     */
    filterCurrentSegmentData(filterCode, segmentData) {
        return segmentData.filter((item) => item.parentCode === filterCode);
    }
    /**
     * Filters next segment(s) to items whose codes are included in the provided list
     * @param filterCodeList List of codes to include
     * @param data Segment items to filter
     * @returns Filtered items for the next segment(s)
     */
    filteredNextSegmentData(filterCodeList, data) {
        return data.filter(item => filterCodeList.includes(item.code));
    }
    /**
     * Indicates if the segment should show an 'All' selection option
     * @param index Segment index
     * @returns True if not the last segment and children exist
     */
    isSelectAll(index) {
        const hasChildren = this.segmentData[index]?.some(item => item.childCodeList?.length);
        return this.segmentDataOriginal.length - 1 !== index && !!hasChildren;
    }
    /** Emits the current selection for details action consumers */
    triggerDetailsAction() {
        this.onDetailsAction.emit(this.selected);
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.2", ngImport: i0, type: CGIExplorerListContainerComponent, deps: [], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "20.3.2", type: CGIExplorerListContainerComponent, isStandalone: false, selector: "cgi-explorer-list-container", inputs: { listData: "listData", listConfigData: "listConfigData", selections: "selections", infoData: "infoData", dataTestId: "dataTestId" }, outputs: { onSelectionChange: "onSelectionChange", onDetailsAction: "onDetailsAction" }, host: { properties: { "class.cgi-explorer-list-container": "this.isClassContainer" } }, viewQueries: [{ propertyName: "scrollRef", first: true, predicate: ["scrollRef"], descendants: true }], usesOnChanges: true, ngImport: i0, template: "\n    <div *ngFor=\"let segment of segmentData; let i = index\" #scrollRef class=\"explorer-list\">\n      <h6 class=\"cgi-display-6\">{{ listConfigData[i]?.listName }}</h6>\n      <div class=\"cgi-vertical-spacer-12\"></div>\n      <cgi-explorer-list\n        [list]=\"segment\"\n        [explorerListConfig]=\"listConfigData[i]\"\n        [selected]=\"selected[i]\"\n        [isAllOptionEnabled]=\"isSelectAll(i)\"\n        (selectionChange)=\"getSelectedEvent($event, i)\">\n      </cgi-explorer-list>\n    </div>\n\n  <div class=\"details-container\">\n    <h6 class=\"cgi-display-6\">About {{ selected?.[segmentData.length - 1]?.name }}</h6>\n    <div class=\"cgi-vertical-spacer-12\"></div>\n    <cgi-explorer-list-details\n      [list]=\"viewData\"\n      [actionText]=\"'Button'\"\n      [isAction]=\"infoAction\"\n      (action)=\"triggerDetailsAction()\"\n    ></cgi-explorer-list-details>\n  </div>\n", styles: [":host(.cgi-explorer-list-container) ::ng-deep{display:flex;align-self:stretch}:host(.cgi-explorer-list-container) ::ng-deep .mdc-notched-outline{border-radius:0}:host(.cgi-explorer-list-container) ::ng-deep .explorer-list{flex:0 0 25%;max-width:25%;min-width:25%}:host(.cgi-explorer-list-container) ::ng-deep .explorer-list:first-of-type .mat-mdc-form-field .mdc-notched-outline{border-top-left-radius:4px}:host(.cgi-explorer-list-container) ::ng-deep .explorer-list:first-of-type .mat-mdc-list{border-radius:0 0 0 4px}:host(.cgi-explorer-list-container) ::ng-deep .details-container{flex:0 0 25%;max-width:25%;min-width:25%}\n"], dependencies: [{ kind: "directive", type: i1.NgForOf, selector: "[ngFor][ngForOf]", inputs: ["ngForOf", "ngForTrackBy", "ngForTemplate"] }, { kind: "component", type: CGIExplorerListComponent, selector: "cgi-explorer-list", inputs: ["list", "explorerListConfig", "disabled", "selected", "isAllOptionEnabled"], outputs: ["selectionChange"] }, { kind: "component", type: CGIExplorerListDetailsComponent, selector: "cgi-explorer-list-details", inputs: ["list", "actionText", "isAction"], outputs: ["action"] }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.2", ngImport: i0, type: CGIExplorerListContainerComponent, decorators: [{
            type: Component,
            args: [{ selector: 'cgi-explorer-list-container', standalone: false, template: "\n    <div *ngFor=\"let segment of segmentData; let i = index\" #scrollRef class=\"explorer-list\">\n      <h6 class=\"cgi-display-6\">{{ listConfigData[i]?.listName }}</h6>\n      <div class=\"cgi-vertical-spacer-12\"></div>\n      <cgi-explorer-list\n        [list]=\"segment\"\n        [explorerListConfig]=\"listConfigData[i]\"\n        [selected]=\"selected[i]\"\n        [isAllOptionEnabled]=\"isSelectAll(i)\"\n        (selectionChange)=\"getSelectedEvent($event, i)\">\n      </cgi-explorer-list>\n    </div>\n\n  <div class=\"details-container\">\n    <h6 class=\"cgi-display-6\">About {{ selected?.[segmentData.length - 1]?.name }}</h6>\n    <div class=\"cgi-vertical-spacer-12\"></div>\n    <cgi-explorer-list-details\n      [list]=\"viewData\"\n      [actionText]=\"'Button'\"\n      [isAction]=\"infoAction\"\n      (action)=\"triggerDetailsAction()\"\n    ></cgi-explorer-list-details>\n  </div>\n", styles: [":host(.cgi-explorer-list-container) ::ng-deep{display:flex;align-self:stretch}:host(.cgi-explorer-list-container) ::ng-deep .mdc-notched-outline{border-radius:0}:host(.cgi-explorer-list-container) ::ng-deep .explorer-list{flex:0 0 25%;max-width:25%;min-width:25%}:host(.cgi-explorer-list-container) ::ng-deep .explorer-list:first-of-type .mat-mdc-form-field .mdc-notched-outline{border-top-left-radius:4px}:host(.cgi-explorer-list-container) ::ng-deep .explorer-list:first-of-type .mat-mdc-list{border-radius:0 0 0 4px}:host(.cgi-explorer-list-container) ::ng-deep .details-container{flex:0 0 25%;max-width:25%;min-width:25%}\n"] }]
        }], propDecorators: { isClassContainer: [{
                type: HostBinding,
                args: ['class.cgi-explorer-list-container']
            }], listData: [{
                type: Input
            }], listConfigData: [{
                type: Input
            }], selections: [{
                type: Input
            }], infoData: [{
                type: Input
            }], dataTestId: [{
                type: Input
            }], onSelectionChange: [{
                type: Output
            }], onDetailsAction: [{
                type: Output
            }], scrollRef: [{
                type: ViewChild,
                args: ['scrollRef']
            }] } });

class CGIExplorerListContainerBrandModule {
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.2", ngImport: i0, type: CGIExplorerListContainerBrandModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule }); }
    static { this.ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "20.3.2", ngImport: i0, type: CGIExplorerListContainerBrandModule, declarations: [CGIExplorerListComponent, CGIExplorerListContainerComponent, CGIExplorerListDetailsComponent], imports: [CommonModule,
            MatFormFieldModule,
            MatListModule,
            FormsModule,
            MatInputModule,
            MatIconModule,
            ReactiveFormsModule,
            MatButtonModule], exports: [CGIExplorerListComponent, CGIExplorerListContainerComponent, CGIExplorerListDetailsComponent] }); }
    static { this.ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "20.3.2", ngImport: i0, type: CGIExplorerListContainerBrandModule, imports: [CommonModule,
            MatFormFieldModule,
            MatListModule,
            FormsModule,
            MatInputModule,
            MatIconModule,
            ReactiveFormsModule,
            MatButtonModule] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.2", ngImport: i0, type: CGIExplorerListContainerBrandModule, decorators: [{
            type: NgModule,
            args: [{
                    declarations: [CGIExplorerListComponent, CGIExplorerListContainerComponent, CGIExplorerListDetailsComponent],
                    imports: [
                        CommonModule,
                        MatFormFieldModule,
                        MatListModule,
                        FormsModule,
                        MatInputModule,
                        MatIconModule,
                        ReactiveFormsModule,
                        MatButtonModule
                    ],
                    exports: [CGIExplorerListComponent, CGIExplorerListContainerComponent, CGIExplorerListDetailsComponent],
                }]
        }] });

/**
 * CGI Datatable - A unified data table with integrated filter drawer, search, sorting, and pagination.
 * Combines filtering (standard/accordion modes), text search, column sorting, pagination, and action menus.
 *
 * @selector cgi-datatable
 */
class CGIDatatableComponent {
    constructor(fb) {
        this.fb = fb;
        /** Subscription for form value changes */
        this.formValueChangesSub = null;
        /** Whether the component has completed initial setup */
        this.initialized = false;
        // ==================== Column & Data Inputs ====================
        /** Column definitions for dynamic column rendering with type support */
        this.columnDefinitions = [];
        /**
         * Table columns to display (simple mode).
         * @deprecated Use columnDefinitions instead for full type/sort/action support
         */
        this.displayedColumns = [];
        /** Table column mapping for mat-table. Auto-generated from columnDefinitions if not provided. */
        this.columnMapping = [];
        /** Data to be filtered */
        this.data = [];
        /** Action menu items for action columns */
        this.actionMenuItems = [];
        // ==================== Search Inputs ====================
        /** Search text for filtering */
        this.searchText = '';
        /** Search input placeholder */
        this.searchPlaceholder = '';
        /** Property names to include in text search filtering */
        this.searchFields = ['clientName'];
        // ==================== Table Feature Inputs ====================
        /** Whether sorting is enabled on columns */
        this.enableSort = true;
        /** Whether pagination is enabled */
        this.enablePagination = true;
        /** Page size options for paginator */
        this.pageSizeOptions = [5, 10, 25, 50];
        /** Default page size */
        this.pageSize = 10;
        /** Table header title */
        this.tableTitle = '';
        // ==================== Filter Drawer Inputs ====================
        /** Controls drawer visibility */
        this.open = false;
        /** Title displayed in drawer header */
        this.title = '';
        /** Array of filter configurations */
        this.filters = [];
        /** Active filter values to initialize the form with */
        this.activeFilters = {};
        /** Display mode for filters */
        this.filterMode = 'standard';
        /** Placeholder for accordion search input */
        this.accordionSearchPlaceholder = '';
        /** Label for Apply button */
        this.applyButtonLabel = '';
        /** Filter count label */
        this.filterCountLabel = '';
        /** Clear all filters label */
        this.clearAllFiltersLabel = '';
        /** Filters button label */
        this.filtersButtonLabel = '';
        /** Market value range label */
        this.marketValueRangeLabel = '';
        // ==================== Outputs ====================
        /** Emits when the Filters button is clicked */
        this.openDrawer = new EventEmitter();
        /** Emits filtered data after filters/search applied */
        this.filteredData = new EventEmitter();
        /** Event emitted when action menu item is clicked */
        this.actionClicked = new EventEmitter();
        /** Emits when filter values change */
        this.filtersChanged = new EventEmitter();
        /** Emits when all filters are cleared */
        this.clearAllFilters = new EventEmitter();
        /** Emits when filters are applied */
        this.onApply = new EventEmitter();
        /** Emits when drawer is closed */
        this.drawerClosed = new EventEmitter();
        /** Emits when filter count changes */
        this.countChange = new EventEmitter();
        // ==================== Internal State ====================
        /** MatTableDataSource for sorting and pagination integration */
        this.dataSource = new MatTableDataSource([]);
        /** Internal computed column keys for mat-table */
        this._columnKeys = [];
        /** Internal resolved column definitions */
        this._resolvedColumns = [];
        /** Form group for managing filter controls */
        this.filterForm = this.fb.group({});
        /** Controls visibility of selected filters */
        this.viewSelected = false;
        /** Search term for filtering accordions */
        this.accordionSearch = '';
        /** Cached applied filter count */
        this.appliedFilterCount = 0;
        /** Cached filtered accordions list */
        this._cachedFilteredAccordions = [];
        this.marketValueMin = 0;
        this.marketValueMax = 0;
        this.marketValueStep = 0;
        this.marketValueTickCount = 0;
        this.marketValueMaxLabel = 0;
    }
    // ==================== Lifecycle ====================
    ngOnInit() {
        this.resolveColumns();
        this.initializeForm();
        this.updateFilteredData();
        this.initialized = true;
    }
    ngAfterViewInit() {
        if (this.enableSort && this.sort) {
            this.dataSource.sort = this.sort;
        }
        if (this.enablePagination && this.paginator) {
            this.dataSource.paginator = this.paginator;
        }
    }
    ngOnChanges(changes) {
        if (!this.initialized)
            return;
        if (changes['columnDefinitions'] || changes['displayedColumns'] || changes['columnMapping']) {
            this.resolveColumns();
        }
        if (changes['filters'] || changes['activeFilters']) {
            this.initializeForm();
        }
        if (changes['data'] ||
            changes['filters'] ||
            changes['activeFilters'] ||
            changes['searchText']) {
            this.updateFilteredData(false);
        }
        if (changes['enableSort'] && this.sort) {
            this.dataSource.sort = this.enableSort ? this.sort : null;
        }
        if (changes['enablePagination'] && this.paginator) {
            this.dataSource.paginator = this.enablePagination ? this.paginator : null;
        }
    }
    ngOnDestroy() {
        this.formValueChangesSub?.unsubscribe();
    }
    // ==================== Column Resolution ====================
    resolveColumns() {
        if (this.columnDefinitions && this.columnDefinitions.length > 0) {
            this._resolvedColumns = this.columnDefinitions;
            this._columnKeys = this.columnDefinitions.map((col) => col.key);
        }
        else if (this.displayedColumns && this.displayedColumns.length > 0) {
            const actionKeys = ['icon', 'action', 'actions'];
            const hasActions = this.actionMenuItems && this.actionMenuItems.length > 0;
            this._resolvedColumns = this.displayedColumns.map((col) => {
                const isActionCol = hasActions && actionKeys.includes(col.key.toLowerCase());
                return {
                    key: col.key,
                    header: col.header,
                    type: (isActionCol ? 'action' : 'text'),
                    sortable: !isActionCol,
                    headerClass: isActionCol ? 'cgi-data-table--header-right' : '',
                    cellClass: isActionCol ? 'action_padding cgi-data-table--cell-right cell-icon-right' : '',
                };
            });
            this._columnKeys = this.displayedColumns.map((col) => col.key);
        }
        if (this.columnMapping && this.columnMapping.length > 0 && !this.columnDefinitions?.length) {
            this._columnKeys = this.columnMapping;
        }
    }
    getColumnDef(key) {
        return this._resolvedColumns.find((col) => col.key === key);
    }
    getActionsForRow(colDef, row) {
        if (colDef.actionsProperty && row[colDef.actionsProperty]) {
            return row[colDef.actionsProperty];
        }
        return this.actionMenuItems;
    }
    onActionClick(action, row) {
        this.actionClicked.emit({ action, row });
    }
    // ==================== Form Initialization ====================
    initializeForm() {
        const formControls = {};
        this.filters.forEach((filter) => {
            if (filter.type === 'date' && filter.key === 'dateRange') {
                const activeDateRange = this.activeFilters && this.activeFilters.dateRange;
                const dateStartValue = activeDateRange?.start !== undefined ? activeDateRange.start : null;
                const dateEndValue = activeDateRange?.end !== undefined ? activeDateRange.end : null;
                const dateRangeGroup = new FormGroup({
                    start: new FormControl(dateStartValue),
                    end: new FormControl(dateEndValue),
                });
                formControls['dateRange'] = dateRangeGroup;
            }
            else {
                const activeValue = this.activeFilters && this.activeFilters[filter.key];
                formControls[filter.key] = new FormControl(activeValue || []);
            }
        });
        const { minValue, maxValue } = this.getMarketValueConfig();
        this.marketValueMin = Math.floor(minValue / 1000000);
        this.marketValueMax = Math.ceil(maxValue / 1000000);
        this.marketValueMaxLabel = this.marketValueMax;
        const range = this.marketValueMax - this.marketValueMin;
        if (range <= 10) {
            this.marketValueTickCount = range;
            this.marketValueStep = 1;
        }
        else if (range <= 50) {
            this.marketValueTickCount = Math.ceil(range / 5);
            this.marketValueStep = 5;
        }
        else if (range <= 200) {
            this.marketValueTickCount = Math.ceil(range / 20);
            this.marketValueStep = 20;
        }
        else if (range <= 1000) {
            this.marketValueTickCount = Math.ceil(range / 100);
            this.marketValueStep = 100;
        }
        else {
            const stepSize = Math.pow(10, Math.floor(Math.log10(range / 5)));
            this.marketValueTickCount = Math.ceil(range / stepSize);
            this.marketValueStep = stepSize;
        }
        this.marketValueTickCount = Math.max(2, Math.min(10, this.marketValueTickCount));
        const activeMarketValueRange = this.activeFilters && this.activeFilters.marketValueRange;
        let sliderValue = this.marketValueMin;
        if (activeMarketValueRange?.end !== undefined) {
            if (activeMarketValueRange.end <= this.marketValueMax * 2) {
                sliderValue = Math.min(this.marketValueMax, Math.max(this.marketValueMin, activeMarketValueRange.end));
            }
            else {
                sliderValue = Math.min(this.marketValueMax, Math.max(this.marketValueMin, Math.floor(activeMarketValueRange.end / 1000000)));
            }
        }
        const marketValueRangeGroup = new FormGroup({
            start: new FormControl(0),
            end: new FormControl(sliderValue),
        });
        formControls['marketValueRange'] = marketValueRangeGroup;
        this.filterForm = this.fb.group(formControls);
        this.formValueChangesSub?.unsubscribe();
        this.formValueChangesSub = this.filterForm.valueChanges.subscribe(() => {
            this.appliedFilterCount = this.calculateAppliedFilterCount();
            this._cachedFilteredAccordions = this.calculateFilteredAccordions();
        });
        this.appliedFilterCount = this.calculateAppliedFilterCount();
        this._cachedFilteredAccordions = this.calculateFilteredAccordions();
    }
    // ==================== Filtering ====================
    clearFilters() {
        const resetObj = {
            dateRange: { start: null, end: null },
            marketValueRange: { start: this.marketValueMin, end: this.marketValueMin },
        };
        this.filterForm.reset(resetObj);
        this.filters.forEach((filter) => {
            if (filter.type !== 'date' && filter.type !== 'range') {
                this.filterForm.get(filter.key)?.setValue([]);
            }
        });
        this.updateFilteredData();
    }
    updateFilteredData(emitChanges = true) {
        const formValues = { ...this.filterForm.value };
        if (formValues.dateRange) {
            if (!formValues.dateRange.start || formValues.dateRange.start === 'Invalid Date') {
                formValues.dateRange.start = null;
            }
            if (!formValues.dateRange.end || formValues.dateRange.end === 'Invalid Date') {
                formValues.dateRange.end = null;
            }
        }
        const filtered = (this.data || []).filter((row) => {
            const filterMatch = Object.entries(formValues).every(([key, values]) => {
                if (!values || (Array.isArray(values) && values.length === 0))
                    return true;
                if (key === 'dateRange' && values && typeof values === 'object') {
                    const dateValues = values;
                    const startValue = dateValues?.start;
                    const endValue = dateValues?.end;
                    const isStartEmpty = !startValue || startValue === 'Invalid Date' || startValue === '';
                    const isEndEmpty = !endValue || endValue === 'Invalid Date' || endValue === '';
                    if (isStartEmpty && isEndEmpty)
                        return true;
                    const startDate = startValue ? new Date(startValue).getTime() : null;
                    const endDate = endValue ? new Date(endValue).getTime() : null;
                    const rowDate = row.creationDate ? new Date(row.creationDate).getTime() : null;
                    if (!rowDate)
                        return false;
                    if (startDate && endDate)
                        return rowDate >= startDate && rowDate <= endDate;
                    if (startDate)
                        return rowDate >= startDate;
                    if (endDate)
                        return rowDate <= endDate;
                    return true;
                }
                if (key === 'marketValueRange' &&
                    values &&
                    typeof values === 'object' &&
                    values.end !== null) {
                    const mvValues = values;
                    const sliderValue = mvValues.end;
                    if (sliderValue === undefined || sliderValue === null)
                        return true;
                    if (sliderValue <= this.marketValueMin)
                        return true;
                    const minMarketValue = sliderValue * 1000000;
                    return row.marketValue >= minMarketValue;
                }
                if (Array.isArray(values))
                    return values.includes(row[key]);
                return true;
            });
            const search = (this.searchText || '').toLowerCase();
            const searchMatch = !search ||
                this.searchFields.some((field) => row[field]?.toString().toLowerCase().includes(search));
            return filterMatch && searchMatch;
        });
        this.dataSource.data = filtered;
        this.filteredData.emit(filtered);
        if (emitChanges) {
            this.filtersChanged.emit(formValues);
        }
        this.appliedFilterCount = this.calculateAppliedFilterCount();
        this.countChange.emit(this.appliedFilterCount);
        this._cachedFilteredAccordions = this.calculateFilteredAccordions();
    }
    applyFilters() {
        this.updateFilteredData();
        this.onApply.emit();
        this.drawerClosed.emit();
    }
    onSearchKeyup() {
        this.updateFilteredData();
    }
    getFilteredData() {
        return this.dataSource.data;
    }
    // ==================== Filter Count ====================
    getAppliedFilterCount() {
        return this.appliedFilterCount;
    }
    calculateAppliedFilterCount() {
        let count = 0;
        const values = this.filterForm.value;
        for (const key in values) {
            const val = values[key];
            if (Array.isArray(val)) {
                count += val.filter((v) => !!v).length;
            }
            else if (val && typeof val === 'object') {
                if (key === 'dateRange') {
                    if (val.start || val.end)
                        count++;
                }
                else if (key === 'marketValueRange') {
                    if (val.end !== this.marketValueMin)
                        count++;
                }
                else {
                    count += Object.values(val).filter((v) => !!v).length;
                }
            }
        }
        return count;
    }
    // ==================== Accordion Filtering ====================
    getFilteredAccordions() {
        return this._cachedFilteredAccordions;
    }
    updateFilteredAccordions() {
        this._cachedFilteredAccordions = this.calculateFilteredAccordions();
    }
    calculateFilteredAccordions() {
        let filteredAccordions = this.filters;
        if (this.viewSelected) {
            filteredAccordions = filteredAccordions.filter((accordion) => {
                const control = this.filterForm.get(accordion.key);
                if (!control)
                    return false;
                const value = control.value;
                if (Array.isArray(value))
                    return value.length > 0;
                if (value && typeof value === 'object') {
                    if (accordion.key === 'dateRange')
                        return value.start || value.end;
                    if (accordion.key === 'marketValueRange') {
                        return value.start !== this.marketValueMin || value.end !== this.marketValueMin;
                    }
                }
                return false;
            });
        }
        if (this.accordionSearch.trim()) {
            const searchTerm = this.accordionSearch.toLowerCase();
            filteredAccordions = filteredAccordions.filter((accordion) => accordion.label.toLowerCase().includes(searchTerm) ||
                (accordion.options?.some((option) => option.toLowerCase().includes(searchTerm)) ?? false));
        }
        return filteredAccordions;
    }
    // ==================== TrackBy Functions ====================
    trackByKey(index, item) {
        return item.key;
    }
    trackByOption(index, item) {
        return item;
    }
    trackByAction(index, item) {
        return item.action;
    }
    trackByColumn(index, item) {
        return item.key;
    }
    // ==================== Checkbox Handling ====================
    onCheckboxChange(key, option, isChecked) {
        const control = this.filterForm.get(key);
        if (!control)
            return;
        const currentValue = control.value || [];
        if (isChecked) {
            control.setValue([...currentValue, option]);
        }
        else {
            control.setValue(currentValue.filter((value) => value !== option));
        }
    }
    // ==================== Market Value Helpers ====================
    getMarketValueDisplay(sliderValue) {
        if (sliderValue === undefined || sliderValue === null) {
            return this.marketValueMax.toString();
        }
        if (sliderValue >= 1000) {
            return (sliderValue / 1000).toFixed(1) + 'B';
        }
        return sliderValue.toString();
    }
    getMarketValueConfig() {
        const marketValueFilter = this.filters.find((filter) => filter.key === 'marketValueRange');
        const minValue = marketValueFilter && marketValueFilter.minValue !== undefined
            ? marketValueFilter.minValue
            : 0;
        const maxValue = marketValueFilter && marketValueFilter.maxValue !== undefined
            ? marketValueFilter.maxValue
            : 500000000;
        return { minValue, maxValue };
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.2", ngImport: i0, type: CGIDatatableComponent, deps: [{ token: i1$2.FormBuilder }], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "20.3.2", type: CGIDatatableComponent, isStandalone: false, selector: "cgi-datatable", inputs: { columnDefinitions: "columnDefinitions", displayedColumns: "displayedColumns", columnMapping: "columnMapping", data: "data", actionMenuItems: "actionMenuItems", searchText: "searchText", searchPlaceholder: "searchPlaceholder", searchFields: "searchFields", enableSort: "enableSort", enablePagination: "enablePagination", pageSizeOptions: "pageSizeOptions", pageSize: "pageSize", tableTitle: "tableTitle", open: "open", title: "title", filters: "filters", activeFilters: "activeFilters", filterMode: "filterMode", accordionSearchPlaceholder: "accordionSearchPlaceholder", applyButtonLabel: "applyButtonLabel", filterCountLabel: "filterCountLabel", clearAllFiltersLabel: "clearAllFiltersLabel", filtersButtonLabel: "filtersButtonLabel", marketValueRangeLabel: "marketValueRangeLabel" }, outputs: { openDrawer: "openDrawer", filteredData: "filteredData", actionClicked: "actionClicked", filtersChanged: "filtersChanged", clearAllFilters: "clearAllFilters", onApply: "onApply", drawerClosed: "drawerClosed", countChange: "countChange" }, viewQueries: [{ propertyName: "sort", first: true, predicate: MatSort, descendants: true }, { propertyName: "paginator", first: true, predicate: MatPaginator, descendants: true }], usesOnChanges: true, ngImport: i0, template: "<mat-drawer-container [hasBackdrop]=\"true\">\n  <mat-drawer mode=\"over\" [opened]=\"open\" position=\"end\" class=\"filter-drawer\" #drawer>\n    <div class=\"drawer-header d-flex justify-content-between align-items-center\">\n      <h3 class=\"cgi-display-3\">{{ title }}</h3>\n      <div class=\"filter-controls d-flex align-items-center\">\n        <ng-container *ngIf=\"filterMode === 'accordion'\">\n          <mat-slide-toggle [(ngModel)]=\"viewSelected\" [disabled]=\"appliedFilterCount === 0\"\n            (ngModelChange)=\"updateFilteredAccordions()\">View selected</mat-slide-toggle\n          >\n          <mat-form-field [appearance]=\"'outline'\" class=\"cgi-mat-label-text-search\">\n            <div class=\"mat-textarea\">\n              <mat-icon class=\"search-icon\">search</mat-icon>\n              <input\n                type=\"text\"\n                [placeholder]=\"accordionSearchPlaceholder\"\n                matInput\n                [(ngModel)]=\"accordionSearch\"\n                (ngModelChange)=\"updateFilteredAccordions()\"\n              />\n            </div>\n          </mat-form-field>\n        </ng-container>\n        <button mat-icon-button (click)=\"drawerClosed.emit()\">\n          <mat-icon>close</mat-icon>\n        </button>\n      </div>\n    </div>\n    <div class=\"drawer-body\" [formGroup]=\"filterForm\">\n      <div *ngIf=\"filterMode === 'standard'\">\n        <div class=\"d-flex justify-content-between\">\n          <div *ngFor=\"let filter of filters; trackBy: trackByKey\">\n            <ng-container *ngIf=\"filter.type === 'checkbox'\">\n              <h6 class=\"cgi-display-6\">{{ filter.label }}</h6>\n              <div class=\"d-flex flex-column gap-8\">\n                <mat-checkbox\n                  color=\"primary\"\n                  *ngFor=\"let option of filter.options; trackBy: trackByOption\"\n                  [checked]=\"filterForm.get(filter.key)?.value?.includes(option)\"\n                  (change)=\"onCheckboxChange(filter.key, option, $event.checked)\"\n                >\n                  <span class=\"cgi-body-2\"> {{ option }}</span>\n                </mat-checkbox>\n              </div>\n            </ng-container>\n          </div>\n        </div>\n        <div *ngFor=\"let filter of filters; trackBy: trackByKey\">\n          <div>\n            <ng-container *ngIf=\"filter.type === 'date'\">\n              <div class=\"date-range-container\" formGroupName=\"dateRange\">\n                <h6 class=\"cgi-display-6\">{{ filter.label }}</h6>\n                <div class=\"d-flex range-dates-fields\">\n                  <mat-form-field [appearance]=\"'outline'\" class=\"cgi-mat-label\">\n                    <mat-label>From</mat-label>\n                    <input formControlName=\"start\" matInput [matDatepicker]=\"startDate\" />\n                    <mat-datepicker-toggle matSuffix [for]=\"startDate\">\n                      <mat-icon class=\"material-symbols-outlined iconColor\" matDatepickerToggleIcon>date_range</mat-icon>\n                    </mat-datepicker-toggle>\n                    <mat-datepicker #startDate></mat-datepicker>\n                  </mat-form-field>\n                  <mat-form-field [appearance]=\"'outline'\" class=\"cgi-mat-label\">\n                    <mat-label>To</mat-label>\n                    <input formControlName=\"end\" matInput [matDatepicker]=\"endDate\" />\n                    <mat-datepicker-toggle matSuffix [for]=\"endDate\">\n                      <mat-icon class=\"material-symbols-outlined iconColor\" matDatepickerToggleIcon>date_range</mat-icon>\n                    </mat-datepicker-toggle>\n                    <mat-datepicker #endDate></mat-datepicker>\n                  </mat-form-field>\n                </div>\n              </div>\n            </ng-container>\n            <ng-container *ngIf=\"filter.type === 'range'\">\n              <div class=\"value-container\">\n                <h6 class=\"cgi-display-6\">{{ marketValueRangeLabel }}</h6>\n                <div formGroupName=\"marketValueRange\">\n                  <div class=\"d-flex flex-row align-items-center\">\n                    <span class=\"d-inline-block\">${{ marketValueMin }}{{ marketValueMin >= 1000 ? 'B' : 'M' }}</span>\n                    <mat-slider class=\"custom-slider-width\" [min]=\"marketValueMin\" [max]=\"marketValueMax\" [step]=\"marketValueStep\"\n                      showTickMarks discrete>\n                      <input matSliderThumb [formControl]=\"$any(filterForm.get('marketValueRange')?.get('end'))\" />\n                    </mat-slider>\n                    <span class=\"d-inline-block\">${{ marketValueMaxLabel }}M</span>\n                  </div>\n                </div>\n              </div>\n            </ng-container>\n          </div>\n        </div>\n      </div>\n      <div *ngIf=\"filterMode === 'accordion'\">\n        <mat-accordion class=\"accordian-headers-align\">\n          <mat-expansion-panel\n            *ngFor=\"let filter of _cachedFilteredAccordions; trackBy: trackByKey\"\n            [ngClass]=\"{\n              selected:\n                filterForm.get(filter.key)?.value?.length ||\n                (filter.type === 'date' &&\n                  (filterForm.get('dateRange')?.get('start')?.value ||\n                    filterForm.get('dateRange')?.get('end')?.value)) ||\n                (filter.type === 'range' &&\n                  (filterForm.get('marketValueRange')?.get('start')?.value !== marketValueMin ||\n                    filterForm.get('marketValueRange')?.get('end')?.value !== marketValueMin))\n            }\"\n          >\n            <mat-expansion-panel-header>\n              <mat-panel-title>\n                <h5 class=\"cgi-display-5\">{{ filter.label }}</h5>\n                <ng-container\n                  *ngIf=\"\n                    filterForm.get(filter.key)?.value?.length ||\n                    (filter.type === 'date' && filterForm.get('dateRange')?.get('start')?.value) ||\n                    (filter.type === 'date' && filterForm.get('dateRange')?.get('end')?.value) ||\n                    (filter.type === 'range' &&\n                      (filterForm.get('marketValueRange')?.get('start')?.value !== marketValueMin ||\n                        filterForm.get('marketValueRange')?.get('end')?.value !== marketValueMin))\n                  \"\n                >\n                  <a class=\"cgi-link-body-2\" (click)=\"filterForm.get(filter.key)?.reset()\">Clear</a>\n                </ng-container>\n              </mat-panel-title>\n            </mat-expansion-panel-header>\n            <ng-container *ngIf=\"filter.type === 'checkbox'\">\n              <mat-form-field [appearance]=\"'outline'\" class=\"cgi-mat-label w-100\" color=\"primary\">\n                <mat-label>{{ filter.label }}</mat-label>\n                <mat-select multiple [formControlName]=\"filter.key\">\n                  <mat-option *ngFor=\"let option of filter.options; trackBy: trackByOption\" [value]=\"option\">\n                    {{ option }}\n                  </mat-option>\n                </mat-select>\n              </mat-form-field>\n            </ng-container>\n            <ng-container *ngIf=\"filter.type === 'date'\">\n              <div class=\"d-flex range-dates-fields\" formGroupName=\"dateRange\">\n                <mat-form-field [appearance]=\"'outline'\" class=\"cgi-mat-label\">\n                  <mat-label>From</mat-label>\n                  <input formControlName=\"start\" matInput [matDatepicker]=\"startDate\" />\n                  <mat-datepicker-toggle matSuffix [for]=\"startDate\">\n                    <mat-icon class=\"material-symbols-outlined iconColor\" matDatepickerToggleIcon>date_range</mat-icon>\n                  </mat-datepicker-toggle>\n                  <mat-datepicker #startDate></mat-datepicker>\n                </mat-form-field>\n                <mat-form-field [appearance]=\"'outline'\" class=\"cgi-mat-label\">\n                  <mat-label>To</mat-label>\n                  <input formControlName=\"end\" matInput [matDatepicker]=\"endDate\" />\n                  <mat-datepicker-toggle matSuffix [for]=\"endDate\">\n                    <mat-icon class=\"material-symbols-outlined iconColor\" matDatepickerToggleIcon>date_range</mat-icon>\n                  </mat-datepicker-toggle>\n                  <mat-datepicker #endDate></mat-datepicker>\n                </mat-form-field>\n              </div>\n            </ng-container>\n            <ng-container *ngIf=\"filter.type === 'range'\">\n              <div formGroupName=\"marketValueRange\">\n                <div class=\"d-flex flex-row align-items-center\">\n                  <span class=\"d-inline-block\">${{ marketValueMin\n                    }}{{\n                      marketValueMin >= 1000000\n                      ? 'T'\n                      : marketValueMin >= 1000\n                      ? 'B'\n                      : marketValueMin >= 1\n                      ? 'M'\n                      : 'K'\n                    }}</span>\n                    <mat-slider class=\"custom-slider-width\" [min]=\"marketValueMin\" [max]=\"marketValueMax\" [step]=\"marketValueStep\"\n                      showTickMarks discrete>\n                      <input matSliderThumb [formControl]=\"$any(filterForm.get('marketValueRange')?.get('end'))\" />\n                  </mat-slider>\n                  <span class=\"d-inline-block\">${{ marketValueMaxLabel\n                    }}{{\n                      marketValueMaxLabel >= 1000000\n                      ? 'T'\n                      : marketValueMaxLabel >= 1000\n                      ? 'B'\n                      : marketValueMaxLabel >= 1\n                      ? 'M'\n                      : 'K'\n                    }}</span>\n                </div>\n              </div>\n            </ng-container>\n          </mat-expansion-panel>\n        </mat-accordion>\n      </div>\n    </div>\n\n    <div class=\"drawer-actions d-flex justify-content-between align-items-center\">\n      <a class=\"cgi-link-body-2\" rel=\"noopener noreferrer\" (click)=\"clearFilters()\">\n        {{ clearAllFiltersLabel }}\n      </a>\n      <button mat-raised-button color=\"primary\" (click)=\"applyFilters()\">\n        {{ applyButtonLabel }} ({{ appliedFilterCount }})\n      </button>\n    </div>\n  </mat-drawer>\n  <mat-drawer-content>\n    <div class=\"table-header d-flex justify-content-between align-items-center\">\n      <div class=\"d-flex align-items-center\">\n        <h3 class=\"cgi-display-3\">{{ tableTitle }}</h3>\n        <span *ngIf=\"appliedFilterCount > 0\">\n          <span class=\"cgi-body-1 ml-32\">{{ appliedFilterCount }} {{ filterCountLabel }}</span>\n          <span class=\"diff-pipe\">|</span>\n          <a class=\"cgi-link-body-underline-1\" rel=\"noopener noreferrer\" (click)=\"clearFilters()\">\n            {{ clearAllFiltersLabel }}\n          </a>\n        </span>\n      </div>\n      <div class=\"head-end-container d-flex justify-content-end align-items-center col-lg-4\">\n        <mat-form-field [appearance]=\"'outline'\" class=\"cgi-mat-label-text-search mr-2\">\n          <div class=\"mat-textarea\">\n            <mat-icon class=\"search-icon\">search</mat-icon>\n            <input\n              type=\"text\"\n              [placeholder]=\"searchPlaceholder\"\n              aria-label=\"Search\"\n              matInput\n              [(ngModel)]=\"searchText\"\n              (keyup)=\"onSearchKeyup()\"\n            />\n          </div>\n        </mat-form-field>\n        <a\n          class=\"cgi-link-body-underline-2\"\n          rel=\"noopener noreferrer\"\n          [matBadge]=\"appliedFilterCount\"\n          [matBadgeHidden]=\"appliedFilterCount === 0\"\n          (click)=\"openDrawer.emit()\"\n        >\n          {{ filtersButtonLabel }}\n        </a>\n      </div>\n    </div>\n    <div class=\"table\">\n      <table mat-table [dataSource]=\"dataSource\" matSort class=\"mat-elevation-z8\">\n        <ng-container *ngFor=\"let colDef of _resolvedColumns; trackBy: trackByColumn\" [matColumnDef]=\"colDef.key\">\n          <th\n            mat-header-cell\n            *matHeaderCellDef\n            [mat-sort-header]=\"enableSort && colDef.sortable !== false ? colDef.key : null\"\n            [disabled]=\"!enableSort || colDef.sortable === false\"\n            [class]=\"colDef.headerClass || ''\"\n          >\n            {{ colDef.header }}\n          </th>\n          <td mat-cell *matCellDef=\"let row\" [class]=\"colDef.cellClass || ''\">\n            <ng-container [ngSwitch]=\"colDef.type || 'text'\">\n              <!-- Text type (default) -->\n              <ng-container *ngSwitchCase=\"'text'\">\n                {{ row[colDef.key] }}\n              </ng-container>\n\n              <!-- Number type -->\n              <ng-container *ngSwitchCase=\"'number'\">\n                {{ row[colDef.key] | number : colDef.numberFormat || '1.0-2' }}\n              </ng-container>\n\n              <!-- Date type -->\n              <ng-container *ngSwitchCase=\"'date'\">\n                {{ row[colDef.key] | date : colDef.dateFormat || 'MMM d, y' }}\n              </ng-container>\n\n              <!-- Icon type -->\n              <ng-container *ngSwitchCase=\"'icon'\">\n                <mat-icon>{{ colDef.iconName || row[colDef.key] || 'check' }}</mat-icon>\n              </ng-container>\n\n              <!-- Action type -->\n              <ng-container *ngSwitchCase=\"'action'\">\n                <button\n                  mat-icon-button\n                  class=\"button_icon\"\n                  [matMenuTriggerFor]=\"actionMenu\"\n                  aria-label=\"Toggle Menu\"\n                >\n                  <mat-icon>more_horiz</mat-icon>\n                </button>\n                <mat-menu #actionMenu=\"matMenu\">\n                  <button\n                    mat-menu-item\n                    *ngFor=\"let item of getActionsForRow(colDef, row); trackBy: trackByAction\"\n                    [attr.aria-label]=\"item.label\"\n                    (click)=\"onActionClick(item.action, row)\"\n                  >\n                    <mat-icon>\n                      <span class=\"material-icons-outlined mx-1\">{{ item.icon }}</span>\n                    </mat-icon>\n                    <span>{{ item.label }}</span>\n                  </button>\n                </mat-menu>\n              </ng-container>\n            </ng-container>\n          </td>\n        </ng-container>\n\n        <tr mat-header-row *matHeaderRowDef=\"_columnKeys\"></tr>\n        <tr mat-row *matRowDef=\"let row; columns: _columnKeys\"></tr>\n      </table>\n    </div>\n    <mat-paginator\n      *ngIf=\"enablePagination\"\n      [pageSizeOptions]=\"pageSizeOptions\"\n      [pageSize]=\"pageSize\"\n      showFirstLastButtons\n    ></mat-paginator>\n  </mat-drawer-content>\n</mat-drawer-container>\n", styles: ["mat-drawer-container{border:1px solid #efefef;border-radius:4px;min-height:540px}mat-drawer-container mat-drawer-content{border-top:5px solid #efefef}mat-drawer{width:580px;height:526px;padding:0}.mat-drawer.filter-drawer .drawer-header{padding:16px;border-bottom:1px solid #C0C0C0}.mat-drawer.filter-drawer .drawer-header .mat-mdc-slide-toggle .mat-internal-form-field{font-size:16px!important}.mat-drawer.filter-drawer .drawer-header .mdc-icon-button.mat-mdc-icon-button{width:24px;height:24px;display:flex;flex-direction:column;position:relative}.mat-drawer.filter-drawer .drawer-header .mdc-icon-button.mat-mdc-icon-button .mat-icon{position:absolute;top:0;left:0}.mat-drawer.filter-drawer .drawer-body{padding:16px;overflow-y:auto;height:396px}.mat-drawer.filter-drawer .drawer-body .mat-accordion .mat-expansion-panel{box-shadow:0 1px 2px #00000040!important}.mat-drawer.filter-drawer .date-range-container{margin-top:24px;margin-bottom:24px}.mat-drawer.filter-drawer .value-container{padding-top:24px}.mat-drawer.filter-drawer .range-dates-fields{gap:16px}.mat-drawer.filter-drawer mat-slider{width:97%}.mat-drawer.filter-drawer .drawer-actions{background-color:#f6f8f9;box-shadow:0 -2px 7px #00000040;padding:8px 16px;position:sticky;bottom:0}.mat-drawer.filter-drawer .filter-controls{gap:12px}.mat-drawer.filter-drawer .cgi-mat-label-text-search{width:240px}.mat-drawer.filter-drawer mat-slide-toggle ::ng-deep .mdc-label{margin-bottom:0;font-size:16px}.mat-drawer.filter-drawer mat-panel-title{display:flex;justify-content:space-between;align-items:center}.mat-drawer.filter-drawer mat-expansion-panel.selected{border:2px solid #5236ab}.mat-drawer.filter-drawer .gap-8{gap:8px}.diff-pipe{margin-left:16px;margin-right:16px}.ml-32{margin-left:32px}.table-header{padding:16px;background-color:#fff}.table-header .cgi-link-body-underline-1{color:#5236ab}.head-end-container{gap:20px}.head-end-container .cgi-link-body-underline-2{cursor:pointer}.table .mat-elevation-z8{box-shadow:none!important}mat-paginator{border-top:1px solid #efefef}mat-accordion .cgi-display-5{color:#333!important}\n"], dependencies: [{ kind: "directive", type: i1.NgClass, selector: "[ngClass]", inputs: ["class", "ngClass"] }, { kind: "directive", type: i1.NgForOf, selector: "[ngFor][ngForOf]", inputs: ["ngForOf", "ngForTrackBy", "ngForTemplate"] }, { kind: "directive", type: i1.NgIf, selector: "[ngIf]", inputs: ["ngIf", "ngIfThen", "ngIfElse"] }, { kind: "directive", type: i1.NgSwitch, selector: "[ngSwitch]", inputs: ["ngSwitch"] }, { kind: "directive", type: i1.NgSwitchCase, selector: "[ngSwitchCase]", inputs: ["ngSwitchCase"] }, { kind: "directive", type: i1$2.DefaultValueAccessor, selector: "input:not([type=checkbox])[formControlName],textarea[formControlName],input:not([type=checkbox])[formControl],textarea[formControl],input:not([type=checkbox])[ngModel],textarea[ngModel],[ngDefaultControl]" }, { kind: "directive", type: i1$2.NgControlStatus, selector: "[formControlName],[ngModel],[formControl]" }, { kind: "directive", type: i1$2.NgControlStatusGroup, selector: "[formGroupName],[formArrayName],[ngModelGroup],[formGroup],form:not([ngNoForm]),[ngForm]" }, { kind: "directive", type: i1$2.NgModel, selector: "[ngModel]:not([formControlName]):not([formControl])", inputs: ["name", "disabled", "ngModel", "ngModelOptions"], outputs: ["ngModelChange"], exportAs: ["ngModel"] }, { kind: "directive", type: i1$2.FormControlDirective, selector: "[formControl]", inputs: ["formControl", "disabled", "ngModel"], outputs: ["ngModelChange"], exportAs: ["ngForm"] }, { kind: "directive", type: i1$2.FormGroupDirective, selector: "[formGroup]", inputs: ["formGroup"], outputs: ["ngSubmit"], exportAs: ["ngForm"] }, { kind: "directive", type: i1$2.FormControlName, selector: "[formControlName]", inputs: ["formControlName", "disabled", "ngModel"], outputs: ["ngModelChange"] }, { kind: "directive", type: i1$2.FormGroupName, selector: "[formGroupName]", inputs: ["formGroupName"] }, { kind: "component", type: i3$2.MatDrawer, selector: "mat-drawer", inputs: ["position", "mode", "disableClose", "autoFocus", "opened"], outputs: ["openedChange", "opened", "openedStart", "closed", "closedStart", "positionChanged"], exportAs: ["matDrawer"] }, { kind: "component", type: i3$2.MatDrawerContainer, selector: "mat-drawer-container", inputs: ["autosize", "hasBackdrop"], outputs: ["backdropClick"], exportAs: ["matDrawerContainer"] }, { kind: "component", type: i3$2.MatDrawerContent, selector: "mat-drawer-content" }, { kind: "component", type: i4$6.MatSlideToggle, selector: "mat-slide-toggle", inputs: ["name", "id", "labelPosition", "aria-label", "aria-labelledby", "aria-describedby", "required", "color", "disabled", "disableRipple", "tabIndex", "checked", "hideIcon", "disabledInteractive"], outputs: ["change", "toggleChange"], exportAs: ["matSlideToggle"] }, { kind: "component", type: i4.MatButton, selector: "    button[matButton], a[matButton], button[mat-button], button[mat-raised-button],    button[mat-flat-button], button[mat-stroked-button], a[mat-button], a[mat-raised-button],    a[mat-flat-button], a[mat-stroked-button]  ", inputs: ["matButton"], exportAs: ["matButton", "matAnchor"] }, { kind: "component", type: i4.MatIconButton, selector: "button[mat-icon-button], a[mat-icon-button], button[matIconButton], a[matIconButton]", exportAs: ["matButton", "matAnchor"] }, { kind: "component", type: i5.MatIcon, selector: "mat-icon", inputs: ["color", "inline", "svgIcon", "fontSet", "fontIcon"], exportAs: ["matIcon"] }, { kind: "directive", type: i4$3.MatInput, selector: "input[matInput], textarea[matInput], select[matNativeControl],      input[matNativeControl], textarea[matNativeControl]", inputs: ["disabled", "id", "placeholder", "name", "required", "type", "errorStateMatcher", "aria-describedby", "value", "readonly", "disabledInteractive"], exportAs: ["matInput"] }, { kind: "component", type: i8.MatFormField, selector: "mat-form-field", inputs: ["hideRequiredMarker", "color", "floatLabel", "appearance", "subscriptSizing", "hintLabel"], exportAs: ["matFormField"] }, { kind: "directive", type: i8.MatLabel, selector: "mat-label" }, { kind: "directive", type: i8.MatSuffix, selector: "[matSuffix], [matIconSuffix], [matTextSuffix]", inputs: ["matTextSuffix"] }, { kind: "component", type: i2$2.MatCheckbox, selector: "mat-checkbox", inputs: ["aria-label", "aria-labelledby", "aria-describedby", "aria-expanded", "aria-controls", "aria-owns", "id", "required", "labelPosition", "name", "value", "disableRipple", "tabIndex", "color", "disabledInteractive", "checked", "disabled", "indeterminate"], outputs: ["change", "indeterminateChange"], exportAs: ["matCheckbox"] }, { kind: "component", type: i10.MatSlider, selector: "mat-slider", inputs: ["disabled", "discrete", "showTickMarks", "min", "color", "disableRipple", "max", "step", "displayWith"], exportAs: ["matSlider"] }, { kind: "directive", type: i10.MatSliderThumb, selector: "input[matSliderThumb]", inputs: ["value"], outputs: ["valueChange", "dragStart", "dragEnd"], exportAs: ["matSliderThumb"] }, { kind: "component", type: i11.MatDatepicker, selector: "mat-datepicker", exportAs: ["matDatepicker"] }, { kind: "directive", type: i11.MatDatepickerInput, selector: "input[matDatepicker]", inputs: ["matDatepicker", "min", "max", "matDatepickerFilter"], exportAs: ["matDatepickerInput"] }, { kind: "component", type: i11.MatDatepickerToggle, selector: "mat-datepicker-toggle", inputs: ["for", "tabIndex", "aria-label", "disabled", "disableRipple"], exportAs: ["matDatepickerToggle"] }, { kind: "directive", type: i11.MatDatepickerToggleIcon, selector: "[matDatepickerToggleIcon]" }, { kind: "directive", type: i4$2.MatAccordion, selector: "mat-accordion", inputs: ["hideToggle", "displayMode", "togglePosition"], exportAs: ["matAccordion"] }, { kind: "component", type: i4$2.MatExpansionPanel, selector: "mat-expansion-panel", inputs: ["hideToggle", "togglePosition"], outputs: ["afterExpand", "afterCollapse"], exportAs: ["matExpansionPanel"] }, { kind: "component", type: i4$2.MatExpansionPanelHeader, selector: "mat-expansion-panel-header", inputs: ["expandedHeight", "collapsedHeight", "tabIndex"] }, { kind: "directive", type: i4$2.MatExpansionPanelTitle, selector: "mat-panel-title" }, { kind: "component", type: i8.MatSelect, selector: "mat-select", inputs: ["aria-describedby", "panelClass", "disabled", "disableRipple", "tabIndex", "hideSingleSelectionIndicator", "placeholder", "required", "multiple", "disableOptionCentering", "compareWith", "value", "aria-label", "aria-labelledby", "errorStateMatcher", "typeaheadDebounceInterval", "sortComparator", "id", "panelWidth", "canSelectNullableOptions"], outputs: ["openedChange", "opened", "closed", "selectionChange", "valueChange"], exportAs: ["matSelect"] }, { kind: "component", type: i6.MatOption, selector: "mat-option", inputs: ["value", "id", "disabled"], outputs: ["onSelectionChange"], exportAs: ["matOption"] }, { kind: "component", type: i4$1.MatMenu, selector: "mat-menu", inputs: ["backdropClass", "aria-label", "aria-labelledby", "aria-describedby", "xPosition", "yPosition", "overlapTrigger", "hasBackdrop", "class", "classList"], outputs: ["closed", "close"], exportAs: ["matMenu"] }, { kind: "component", type: i4$1.MatMenuItem, selector: "[mat-menu-item]", inputs: ["role", "disabled", "disableRipple"], exportAs: ["matMenuItem"] }, { kind: "directive", type: i4$1.MatMenuTrigger, selector: "[mat-menu-trigger-for], [matMenuTriggerFor]", inputs: ["mat-menu-trigger-for", "matMenuTriggerFor", "matMenuTriggerData", "matMenuTriggerRestoreFocus"], outputs: ["menuOpened", "onMenuOpen", "menuClosed", "onMenuClose"], exportAs: ["matMenuTrigger"] }, { kind: "component", type: i1$7.MatTable, selector: "mat-table, table[mat-table]", exportAs: ["matTable"] }, { kind: "directive", type: i1$7.MatHeaderCellDef, selector: "[matHeaderCellDef]" }, { kind: "directive", type: i1$7.MatHeaderRowDef, selector: "[matHeaderRowDef]", inputs: ["matHeaderRowDef", "matHeaderRowDefSticky"] }, { kind: "directive", type: i1$7.MatColumnDef, selector: "[matColumnDef]", inputs: ["matColumnDef"] }, { kind: "directive", type: i1$7.MatCellDef, selector: "[matCellDef]" }, { kind: "directive", type: i1$7.MatRowDef, selector: "[matRowDef]", inputs: ["matRowDefColumns", "matRowDefWhen"] }, { kind: "directive", type: i1$7.MatHeaderCell, selector: "mat-header-cell, th[mat-header-cell]" }, { kind: "directive", type: i1$7.MatCell, selector: "mat-cell, td[mat-cell]" }, { kind: "component", type: i1$7.MatHeaderRow, selector: "mat-header-row, tr[mat-header-row]", exportAs: ["matHeaderRow"] }, { kind: "component", type: i1$7.MatRow, selector: "mat-row, tr[mat-row]", exportAs: ["matRow"] }, { kind: "directive", type: i16.MatSort, selector: "[matSort]", inputs: ["matSortActive", "matSortStart", "matSortDirection", "matSortDisableClear", "matSortDisabled"], outputs: ["matSortChange"], exportAs: ["matSort"] }, { kind: "component", type: i16.MatSortHeader, selector: "[mat-sort-header]", inputs: ["mat-sort-header", "arrowPosition", "start", "disabled", "sortActionDescription", "disableClear"], exportAs: ["matSortHeader"] }, { kind: "component", type: i17.MatPaginator, selector: "mat-paginator", inputs: ["color", "pageIndex", "length", "pageSize", "pageSizeOptions", "hidePageSize", "showFirstLastButtons", "selectConfig", "disabled"], outputs: ["page"], exportAs: ["matPaginator"] }, { kind: "directive", type: i3.MatBadge, selector: "[matBadge]", inputs: ["matBadgeColor", "matBadgeOverlap", "matBadgeDisabled", "matBadgePosition", "matBadge", "matBadgeDescription", "matBadgeSize", "matBadgeHidden"] }, { kind: "pipe", type: i1.DecimalPipe, name: "number" }, { kind: "pipe", type: i1.DatePipe, name: "date" }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.2", ngImport: i0, type: CGIDatatableComponent, decorators: [{
            type: Component,
            args: [{ selector: 'cgi-datatable', standalone: false, template: "<mat-drawer-container [hasBackdrop]=\"true\">\n  <mat-drawer mode=\"over\" [opened]=\"open\" position=\"end\" class=\"filter-drawer\" #drawer>\n    <div class=\"drawer-header d-flex justify-content-between align-items-center\">\n      <h3 class=\"cgi-display-3\">{{ title }}</h3>\n      <div class=\"filter-controls d-flex align-items-center\">\n        <ng-container *ngIf=\"filterMode === 'accordion'\">\n          <mat-slide-toggle [(ngModel)]=\"viewSelected\" [disabled]=\"appliedFilterCount === 0\"\n            (ngModelChange)=\"updateFilteredAccordions()\">View selected</mat-slide-toggle\n          >\n          <mat-form-field [appearance]=\"'outline'\" class=\"cgi-mat-label-text-search\">\n            <div class=\"mat-textarea\">\n              <mat-icon class=\"search-icon\">search</mat-icon>\n              <input\n                type=\"text\"\n                [placeholder]=\"accordionSearchPlaceholder\"\n                matInput\n                [(ngModel)]=\"accordionSearch\"\n                (ngModelChange)=\"updateFilteredAccordions()\"\n              />\n            </div>\n          </mat-form-field>\n        </ng-container>\n        <button mat-icon-button (click)=\"drawerClosed.emit()\">\n          <mat-icon>close</mat-icon>\n        </button>\n      </div>\n    </div>\n    <div class=\"drawer-body\" [formGroup]=\"filterForm\">\n      <div *ngIf=\"filterMode === 'standard'\">\n        <div class=\"d-flex justify-content-between\">\n          <div *ngFor=\"let filter of filters; trackBy: trackByKey\">\n            <ng-container *ngIf=\"filter.type === 'checkbox'\">\n              <h6 class=\"cgi-display-6\">{{ filter.label }}</h6>\n              <div class=\"d-flex flex-column gap-8\">\n                <mat-checkbox\n                  color=\"primary\"\n                  *ngFor=\"let option of filter.options; trackBy: trackByOption\"\n                  [checked]=\"filterForm.get(filter.key)?.value?.includes(option)\"\n                  (change)=\"onCheckboxChange(filter.key, option, $event.checked)\"\n                >\n                  <span class=\"cgi-body-2\"> {{ option }}</span>\n                </mat-checkbox>\n              </div>\n            </ng-container>\n          </div>\n        </div>\n        <div *ngFor=\"let filter of filters; trackBy: trackByKey\">\n          <div>\n            <ng-container *ngIf=\"filter.type === 'date'\">\n              <div class=\"date-range-container\" formGroupName=\"dateRange\">\n                <h6 class=\"cgi-display-6\">{{ filter.label }}</h6>\n                <div class=\"d-flex range-dates-fields\">\n                  <mat-form-field [appearance]=\"'outline'\" class=\"cgi-mat-label\">\n                    <mat-label>From</mat-label>\n                    <input formControlName=\"start\" matInput [matDatepicker]=\"startDate\" />\n                    <mat-datepicker-toggle matSuffix [for]=\"startDate\">\n                      <mat-icon class=\"material-symbols-outlined iconColor\" matDatepickerToggleIcon>date_range</mat-icon>\n                    </mat-datepicker-toggle>\n                    <mat-datepicker #startDate></mat-datepicker>\n                  </mat-form-field>\n                  <mat-form-field [appearance]=\"'outline'\" class=\"cgi-mat-label\">\n                    <mat-label>To</mat-label>\n                    <input formControlName=\"end\" matInput [matDatepicker]=\"endDate\" />\n                    <mat-datepicker-toggle matSuffix [for]=\"endDate\">\n                      <mat-icon class=\"material-symbols-outlined iconColor\" matDatepickerToggleIcon>date_range</mat-icon>\n                    </mat-datepicker-toggle>\n                    <mat-datepicker #endDate></mat-datepicker>\n                  </mat-form-field>\n                </div>\n              </div>\n            </ng-container>\n            <ng-container *ngIf=\"filter.type === 'range'\">\n              <div class=\"value-container\">\n                <h6 class=\"cgi-display-6\">{{ marketValueRangeLabel }}</h6>\n                <div formGroupName=\"marketValueRange\">\n                  <div class=\"d-flex flex-row align-items-center\">\n                    <span class=\"d-inline-block\">${{ marketValueMin }}{{ marketValueMin >= 1000 ? 'B' : 'M' }}</span>\n                    <mat-slider class=\"custom-slider-width\" [min]=\"marketValueMin\" [max]=\"marketValueMax\" [step]=\"marketValueStep\"\n                      showTickMarks discrete>\n                      <input matSliderThumb [formControl]=\"$any(filterForm.get('marketValueRange')?.get('end'))\" />\n                    </mat-slider>\n                    <span class=\"d-inline-block\">${{ marketValueMaxLabel }}M</span>\n                  </div>\n                </div>\n              </div>\n            </ng-container>\n          </div>\n        </div>\n      </div>\n      <div *ngIf=\"filterMode === 'accordion'\">\n        <mat-accordion class=\"accordian-headers-align\">\n          <mat-expansion-panel\n            *ngFor=\"let filter of _cachedFilteredAccordions; trackBy: trackByKey\"\n            [ngClass]=\"{\n              selected:\n                filterForm.get(filter.key)?.value?.length ||\n                (filter.type === 'date' &&\n                  (filterForm.get('dateRange')?.get('start')?.value ||\n                    filterForm.get('dateRange')?.get('end')?.value)) ||\n                (filter.type === 'range' &&\n                  (filterForm.get('marketValueRange')?.get('start')?.value !== marketValueMin ||\n                    filterForm.get('marketValueRange')?.get('end')?.value !== marketValueMin))\n            }\"\n          >\n            <mat-expansion-panel-header>\n              <mat-panel-title>\n                <h5 class=\"cgi-display-5\">{{ filter.label }}</h5>\n                <ng-container\n                  *ngIf=\"\n                    filterForm.get(filter.key)?.value?.length ||\n                    (filter.type === 'date' && filterForm.get('dateRange')?.get('start')?.value) ||\n                    (filter.type === 'date' && filterForm.get('dateRange')?.get('end')?.value) ||\n                    (filter.type === 'range' &&\n                      (filterForm.get('marketValueRange')?.get('start')?.value !== marketValueMin ||\n                        filterForm.get('marketValueRange')?.get('end')?.value !== marketValueMin))\n                  \"\n                >\n                  <a class=\"cgi-link-body-2\" (click)=\"filterForm.get(filter.key)?.reset()\">Clear</a>\n                </ng-container>\n              </mat-panel-title>\n            </mat-expansion-panel-header>\n            <ng-container *ngIf=\"filter.type === 'checkbox'\">\n              <mat-form-field [appearance]=\"'outline'\" class=\"cgi-mat-label w-100\" color=\"primary\">\n                <mat-label>{{ filter.label }}</mat-label>\n                <mat-select multiple [formControlName]=\"filter.key\">\n                  <mat-option *ngFor=\"let option of filter.options; trackBy: trackByOption\" [value]=\"option\">\n                    {{ option }}\n                  </mat-option>\n                </mat-select>\n              </mat-form-field>\n            </ng-container>\n            <ng-container *ngIf=\"filter.type === 'date'\">\n              <div class=\"d-flex range-dates-fields\" formGroupName=\"dateRange\">\n                <mat-form-field [appearance]=\"'outline'\" class=\"cgi-mat-label\">\n                  <mat-label>From</mat-label>\n                  <input formControlName=\"start\" matInput [matDatepicker]=\"startDate\" />\n                  <mat-datepicker-toggle matSuffix [for]=\"startDate\">\n                    <mat-icon class=\"material-symbols-outlined iconColor\" matDatepickerToggleIcon>date_range</mat-icon>\n                  </mat-datepicker-toggle>\n                  <mat-datepicker #startDate></mat-datepicker>\n                </mat-form-field>\n                <mat-form-field [appearance]=\"'outline'\" class=\"cgi-mat-label\">\n                  <mat-label>To</mat-label>\n                  <input formControlName=\"end\" matInput [matDatepicker]=\"endDate\" />\n                  <mat-datepicker-toggle matSuffix [for]=\"endDate\">\n                    <mat-icon class=\"material-symbols-outlined iconColor\" matDatepickerToggleIcon>date_range</mat-icon>\n                  </mat-datepicker-toggle>\n                  <mat-datepicker #endDate></mat-datepicker>\n                </mat-form-field>\n              </div>\n            </ng-container>\n            <ng-container *ngIf=\"filter.type === 'range'\">\n              <div formGroupName=\"marketValueRange\">\n                <div class=\"d-flex flex-row align-items-center\">\n                  <span class=\"d-inline-block\">${{ marketValueMin\n                    }}{{\n                      marketValueMin >= 1000000\n                      ? 'T'\n                      : marketValueMin >= 1000\n                      ? 'B'\n                      : marketValueMin >= 1\n                      ? 'M'\n                      : 'K'\n                    }}</span>\n                    <mat-slider class=\"custom-slider-width\" [min]=\"marketValueMin\" [max]=\"marketValueMax\" [step]=\"marketValueStep\"\n                      showTickMarks discrete>\n                      <input matSliderThumb [formControl]=\"$any(filterForm.get('marketValueRange')?.get('end'))\" />\n                  </mat-slider>\n                  <span class=\"d-inline-block\">${{ marketValueMaxLabel\n                    }}{{\n                      marketValueMaxLabel >= 1000000\n                      ? 'T'\n                      : marketValueMaxLabel >= 1000\n                      ? 'B'\n                      : marketValueMaxLabel >= 1\n                      ? 'M'\n                      : 'K'\n                    }}</span>\n                </div>\n              </div>\n            </ng-container>\n          </mat-expansion-panel>\n        </mat-accordion>\n      </div>\n    </div>\n\n    <div class=\"drawer-actions d-flex justify-content-between align-items-center\">\n      <a class=\"cgi-link-body-2\" rel=\"noopener noreferrer\" (click)=\"clearFilters()\">\n        {{ clearAllFiltersLabel }}\n      </a>\n      <button mat-raised-button color=\"primary\" (click)=\"applyFilters()\">\n        {{ applyButtonLabel }} ({{ appliedFilterCount }})\n      </button>\n    </div>\n  </mat-drawer>\n  <mat-drawer-content>\n    <div class=\"table-header d-flex justify-content-between align-items-center\">\n      <div class=\"d-flex align-items-center\">\n        <h3 class=\"cgi-display-3\">{{ tableTitle }}</h3>\n        <span *ngIf=\"appliedFilterCount > 0\">\n          <span class=\"cgi-body-1 ml-32\">{{ appliedFilterCount }} {{ filterCountLabel }}</span>\n          <span class=\"diff-pipe\">|</span>\n          <a class=\"cgi-link-body-underline-1\" rel=\"noopener noreferrer\" (click)=\"clearFilters()\">\n            {{ clearAllFiltersLabel }}\n          </a>\n        </span>\n      </div>\n      <div class=\"head-end-container d-flex justify-content-end align-items-center col-lg-4\">\n        <mat-form-field [appearance]=\"'outline'\" class=\"cgi-mat-label-text-search mr-2\">\n          <div class=\"mat-textarea\">\n            <mat-icon class=\"search-icon\">search</mat-icon>\n            <input\n              type=\"text\"\n              [placeholder]=\"searchPlaceholder\"\n              aria-label=\"Search\"\n              matInput\n              [(ngModel)]=\"searchText\"\n              (keyup)=\"onSearchKeyup()\"\n            />\n          </div>\n        </mat-form-field>\n        <a\n          class=\"cgi-link-body-underline-2\"\n          rel=\"noopener noreferrer\"\n          [matBadge]=\"appliedFilterCount\"\n          [matBadgeHidden]=\"appliedFilterCount === 0\"\n          (click)=\"openDrawer.emit()\"\n        >\n          {{ filtersButtonLabel }}\n        </a>\n      </div>\n    </div>\n    <div class=\"table\">\n      <table mat-table [dataSource]=\"dataSource\" matSort class=\"mat-elevation-z8\">\n        <ng-container *ngFor=\"let colDef of _resolvedColumns; trackBy: trackByColumn\" [matColumnDef]=\"colDef.key\">\n          <th\n            mat-header-cell\n            *matHeaderCellDef\n            [mat-sort-header]=\"enableSort && colDef.sortable !== false ? colDef.key : null\"\n            [disabled]=\"!enableSort || colDef.sortable === false\"\n            [class]=\"colDef.headerClass || ''\"\n          >\n            {{ colDef.header }}\n          </th>\n          <td mat-cell *matCellDef=\"let row\" [class]=\"colDef.cellClass || ''\">\n            <ng-container [ngSwitch]=\"colDef.type || 'text'\">\n              <!-- Text type (default) -->\n              <ng-container *ngSwitchCase=\"'text'\">\n                {{ row[colDef.key] }}\n              </ng-container>\n\n              <!-- Number type -->\n              <ng-container *ngSwitchCase=\"'number'\">\n                {{ row[colDef.key] | number : colDef.numberFormat || '1.0-2' }}\n              </ng-container>\n\n              <!-- Date type -->\n              <ng-container *ngSwitchCase=\"'date'\">\n                {{ row[colDef.key] | date : colDef.dateFormat || 'MMM d, y' }}\n              </ng-container>\n\n              <!-- Icon type -->\n              <ng-container *ngSwitchCase=\"'icon'\">\n                <mat-icon>{{ colDef.iconName || row[colDef.key] || 'check' }}</mat-icon>\n              </ng-container>\n\n              <!-- Action type -->\n              <ng-container *ngSwitchCase=\"'action'\">\n                <button\n                  mat-icon-button\n                  class=\"button_icon\"\n                  [matMenuTriggerFor]=\"actionMenu\"\n                  aria-label=\"Toggle Menu\"\n                >\n                  <mat-icon>more_horiz</mat-icon>\n                </button>\n                <mat-menu #actionMenu=\"matMenu\">\n                  <button\n                    mat-menu-item\n                    *ngFor=\"let item of getActionsForRow(colDef, row); trackBy: trackByAction\"\n                    [attr.aria-label]=\"item.label\"\n                    (click)=\"onActionClick(item.action, row)\"\n                  >\n                    <mat-icon>\n                      <span class=\"material-icons-outlined mx-1\">{{ item.icon }}</span>\n                    </mat-icon>\n                    <span>{{ item.label }}</span>\n                  </button>\n                </mat-menu>\n              </ng-container>\n            </ng-container>\n          </td>\n        </ng-container>\n\n        <tr mat-header-row *matHeaderRowDef=\"_columnKeys\"></tr>\n        <tr mat-row *matRowDef=\"let row; columns: _columnKeys\"></tr>\n      </table>\n    </div>\n    <mat-paginator\n      *ngIf=\"enablePagination\"\n      [pageSizeOptions]=\"pageSizeOptions\"\n      [pageSize]=\"pageSize\"\n      showFirstLastButtons\n    ></mat-paginator>\n  </mat-drawer-content>\n</mat-drawer-container>\n", styles: ["mat-drawer-container{border:1px solid #efefef;border-radius:4px;min-height:540px}mat-drawer-container mat-drawer-content{border-top:5px solid #efefef}mat-drawer{width:580px;height:526px;padding:0}.mat-drawer.filter-drawer .drawer-header{padding:16px;border-bottom:1px solid #C0C0C0}.mat-drawer.filter-drawer .drawer-header .mat-mdc-slide-toggle .mat-internal-form-field{font-size:16px!important}.mat-drawer.filter-drawer .drawer-header .mdc-icon-button.mat-mdc-icon-button{width:24px;height:24px;display:flex;flex-direction:column;position:relative}.mat-drawer.filter-drawer .drawer-header .mdc-icon-button.mat-mdc-icon-button .mat-icon{position:absolute;top:0;left:0}.mat-drawer.filter-drawer .drawer-body{padding:16px;overflow-y:auto;height:396px}.mat-drawer.filter-drawer .drawer-body .mat-accordion .mat-expansion-panel{box-shadow:0 1px 2px #00000040!important}.mat-drawer.filter-drawer .date-range-container{margin-top:24px;margin-bottom:24px}.mat-drawer.filter-drawer .value-container{padding-top:24px}.mat-drawer.filter-drawer .range-dates-fields{gap:16px}.mat-drawer.filter-drawer mat-slider{width:97%}.mat-drawer.filter-drawer .drawer-actions{background-color:#f6f8f9;box-shadow:0 -2px 7px #00000040;padding:8px 16px;position:sticky;bottom:0}.mat-drawer.filter-drawer .filter-controls{gap:12px}.mat-drawer.filter-drawer .cgi-mat-label-text-search{width:240px}.mat-drawer.filter-drawer mat-slide-toggle ::ng-deep .mdc-label{margin-bottom:0;font-size:16px}.mat-drawer.filter-drawer mat-panel-title{display:flex;justify-content:space-between;align-items:center}.mat-drawer.filter-drawer mat-expansion-panel.selected{border:2px solid #5236ab}.mat-drawer.filter-drawer .gap-8{gap:8px}.diff-pipe{margin-left:16px;margin-right:16px}.ml-32{margin-left:32px}.table-header{padding:16px;background-color:#fff}.table-header .cgi-link-body-underline-1{color:#5236ab}.head-end-container{gap:20px}.head-end-container .cgi-link-body-underline-2{cursor:pointer}.table .mat-elevation-z8{box-shadow:none!important}mat-paginator{border-top:1px solid #efefef}mat-accordion .cgi-display-5{color:#333!important}\n"] }]
        }], ctorParameters: () => [{ type: i1$2.FormBuilder }], propDecorators: { columnDefinitions: [{
                type: Input
            }], displayedColumns: [{
                type: Input
            }], columnMapping: [{
                type: Input
            }], data: [{
                type: Input
            }], actionMenuItems: [{
                type: Input
            }], searchText: [{
                type: Input
            }], searchPlaceholder: [{
                type: Input
            }], searchFields: [{
                type: Input
            }], enableSort: [{
                type: Input
            }], enablePagination: [{
                type: Input
            }], pageSizeOptions: [{
                type: Input
            }], pageSize: [{
                type: Input
            }], tableTitle: [{
                type: Input
            }], open: [{
                type: Input
            }], title: [{
                type: Input
            }], filters: [{
                type: Input
            }], activeFilters: [{
                type: Input
            }], filterMode: [{
                type: Input
            }], accordionSearchPlaceholder: [{
                type: Input
            }], applyButtonLabel: [{
                type: Input
            }], filterCountLabel: [{
                type: Input
            }], clearAllFiltersLabel: [{
                type: Input
            }], filtersButtonLabel: [{
                type: Input
            }], marketValueRangeLabel: [{
                type: Input
            }], openDrawer: [{
                type: Output
            }], filteredData: [{
                type: Output
            }], actionClicked: [{
                type: Output
            }], filtersChanged: [{
                type: Output
            }], clearAllFilters: [{
                type: Output
            }], onApply: [{
                type: Output
            }], drawerClosed: [{
                type: Output
            }], countChange: [{
                type: Output
            }], sort: [{
                type: ViewChild,
                args: [MatSort]
            }], paginator: [{
                type: ViewChild,
                args: [MatPaginator]
            }] } });

class CgiDatatableModule {
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.2", ngImport: i0, type: CgiDatatableModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule }); }
    static { this.ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "20.3.2", ngImport: i0, type: CgiDatatableModule, declarations: [CGIDatatableComponent], imports: [CommonModule,
            FormsModule,
            ReactiveFormsModule,
            MatSidenavModule,
            MatSlideToggleModule,
            MatButtonModule,
            MatIconModule,
            MatInputModule,
            MatCheckboxModule,
            MatSliderModule,
            MatDatepickerModule,
            MatRadioModule,
            MatExpansionModule,
            MatSelectModule,
            MatOptionModule,
            MatDividerModule,
            MatMenuModule,
            MatTableModule,
            MatSortModule,
            MatPaginatorModule,
            MatBadgeModule], exports: [CGIDatatableComponent] }); }
    static { this.ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "20.3.2", ngImport: i0, type: CgiDatatableModule, imports: [CommonModule,
            FormsModule,
            ReactiveFormsModule,
            MatSidenavModule,
            MatSlideToggleModule,
            MatButtonModule,
            MatIconModule,
            MatInputModule,
            MatCheckboxModule,
            MatSliderModule,
            MatDatepickerModule,
            MatRadioModule,
            MatExpansionModule,
            MatSelectModule,
            MatOptionModule,
            MatDividerModule,
            MatMenuModule,
            MatTableModule,
            MatSortModule,
            MatPaginatorModule,
            MatBadgeModule] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.2", ngImport: i0, type: CgiDatatableModule, decorators: [{
            type: NgModule,
            args: [{
                    declarations: [CGIDatatableComponent],
                    imports: [
                        CommonModule,
                        FormsModule,
                        ReactiveFormsModule,
                        MatSidenavModule,
                        MatSlideToggleModule,
                        MatButtonModule,
                        MatIconModule,
                        MatInputModule,
                        MatCheckboxModule,
                        MatSliderModule,
                        MatDatepickerModule,
                        MatRadioModule,
                        MatExpansionModule,
                        MatSelectModule,
                        MatOptionModule,
                        MatDividerModule,
                        MatMenuModule,
                        MatTableModule,
                        MatSortModule,
                        MatPaginatorModule,
                        MatBadgeModule,
                    ],
                    exports: [CGIDatatableComponent],
                }]
        }] });

/**
 *  Chip Autocomplete Example Component
 */
class CGIChipAutocompleteComponent {
    /** Constructor for Chip Autocomplete component */
    constructor() {
        /** Gets list of all selectable chips */
        this.allChips = [
            'Filter 1',
            'Filter 2',
            'Filter 3',
            'Filter 4',
            'Filter 5',
            'Filter 6',
        ];
        /** Gets list of selected chips. Predefined chips should be elements of allChips. */
        this.selectedChips = [];
        /** Whether or not the chip is selectable */
        this.selectable = true;
        /** Whether or not the chip is removable */
        this.removable = true;
        /** List of chips filtered by form input value and selectedChips[] */
        this.filteredChips = [];
        /** The list of key codes that will trigger a chipEnd event */
        this.separatorKeysCodes = [ENTER, COMMA];
        /** Used for accessing properties of the form */
        this.formCtrl = new UntypedFormControl();
        this.formCtrl.valueChanges.subscribe((input) => {
            this.applyFilter(input);
        });
        // optional: filter at the start in case there are preselected chips
        this.formCtrl.updateValueAndValidity({ onlySelf: false, emitEvent: true });
    }
    /** Event called when all selected chips are cleared */
    clearall() {
        this.selectedChips = [];
        this.applyFilter();
    }
    /** Event called when a chip is removed */
    remove(chip) {
        const index = this.selectedChips.indexOf(chip);
        if (index >= 0) {
            this.selectedChips.splice(index, 1);
        }
        this.applyFilter();
    }
    /** Event called when a chip is selected from the list */
    selected(event) {
        if (this.allChips.indexOf(event.option.viewValue) > -1 &&
            !(this.selectedChips.indexOf(event.option.viewValue) > -1)) {
            this.selectedChips.push(event.option.viewValue);
            this.chipInput.nativeElement.value = '';
        }
        this.formCtrl.setValue(null);
    }
    /** Custom filter used to filter chips based on current input and selected chips */
    _filter(value) {
        const filterValue = value.toLowerCase();
        return this.allChips.filter((chip) => chip.toLowerCase().indexOf(filterValue) === 0 &&
            !this.selectedChips.find((existingChip) => existingChip === chip));
    }
    /** Applies the filter when valueChanged event occurs in formCtrl */
    applyFilter(input = '') {
        if (input) {
            // filter based on current input and current chips
            this.filteredChips = this._filter(input);
        }
        else if (this.formCtrl.value) {
            // since input == null, use most recent input in form and current chips
            this.filteredChips = this._filter(this.formCtrl.value);
        }
        else {
            // since input is empty, filter based on current chips
            this.filteredChips = this.allChips.filter((x) => this.selectedChips.indexOf(x) < 0);
        }
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.2", ngImport: i0, type: CGIChipAutocompleteComponent, deps: [], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "20.3.2", type: CGIChipAutocompleteComponent, isStandalone: false, selector: "cgi-chip-autocomplete", inputs: { allChips: "allChips", selectedChips: "selectedChips", selectable: "selectable", removable: "removable" }, viewQueries: [{ propertyName: "chipInput", first: true, predicate: ["chipInput"], descendants: true }, { propertyName: "matAutocomplete", first: true, predicate: ["auto"], descendants: true }], ngImport: i0, template: "\n<div class=\"cgi-chip-autocomplete__clearall-container\">\n  <a\n    class=\"cgi-link-body-underline-1 cgi-chip-autocomplete__clearall-btn\"\n    aria-label=\"clear all\"\n    role=\"button\"\n    (click)=\"clearall()\"\n    ><ng-content select=\".clearall\"></ng-content\n  ></a>\n</div>\n<mat-form-field appearance=\"outline\" class=\"chip-auto-complete-form-field date cgi-mat-label-text-search\">\n  <mat-label>Add a filter</mat-label>\n  <mat-chip-grid #chipList aria-label=\"Chip autocomplete\" style=\"padding-left: 0px;\">\n <div class=\"mat-textarea\">\n <div class=\"row ms-0\">\n    <div class=\"col-1 chip-auto-complete-items\"><mat-icon class=\"cgi-chip-autocomplete__search-icon search-icon\" matPrefix>search</mat-icon></div> \n    <div class=\"col-11\" style=\"padding-left: 5px;\">\n   <mat-chip-row\n      *ngFor=\"let chip of selectedChips\"\n\n      [removable]=\"removable\"\n      (removed)=\"remove(chip)\"\n    >\n      {{ chip }}\n      <mat-icon matChipRemove *ngIf=\"removable\">close</mat-icon>\n    </mat-chip-row>\n    <input\n      style=\"margin-left: 12px;\"\n      placeholder=\"Add a filter\"\n      matInput\n      #chipInput\n      (focus)=\"matAutocomplete.showPanel = true\"\n      [formControl]=\"formCtrl\"\n      [matAutocomplete]=\"auto\"\n      [matChipInputFor]=\"chipList\"\n      [matChipInputSeparatorKeyCodes]=\"separatorKeysCodes\"\n      #trigger=\"matAutocompleteTrigger\"\n      aria-label=\"Chip Autocomplete in an expandable panel\"\n    />\n    </div>\n  </div>\n </div>\n  </mat-chip-grid>\n  <mat-autocomplete\n    #auto=\"matAutocomplete\"\n    (optionSelected)=\"selected($event)\"\n  >\n    <mat-option\n      *ngFor=\"let chip of filteredChips\"\n      [value]=\"chip\"\n      (click)=\"$event.stopPropagation(); trigger.openPanel()\"\n    >\n    <mat-checkbox></mat-checkbox>\n      {{ chip }}\n    </mat-option>\n    <mat-option style=\"text-align:center\" *ngIf=\"!filteredChips.length && selectedChips.length !== allChips.length\" disabled\n      >No results to display.\n    </mat-option>\n    <!--The mat-option below is optional; displays special message when all chips are selected-->\n    <mat-option *ngIf=\"selectedChips.length === allChips.length\" disabled\n      >All options selected.</mat-option\n    >\n  </mat-autocomplete>\n</mat-form-field>\n", styles: [".cgi-chip-autocomplete__form-field{width:100%}.chip-auto-complete-form-field:not(.mat-form-field-hide-placeholder) .mat-mdc-standard-chip{--mdc-chip-label-text-color: #ffffff;--mdc-chip-with-trailing-icon-trailing-icon-color: #ffffff;--mat-chip-trailing-action-opacity: 1}.chip-auto-complete-form-field:not(.mat-form-field-hide-placeholder) .mat-mdc-chip-set input::placeholder{opacity:1;color:#333}.cgi-chip-autocomplete__clearall-container{width:fit-content}.cgi-chip-autocomplete__clearall-btn{cursor:pointer}.cgi-chip-autocomplete__search-icon{color:#151515}:host::ng-deep .cgi-chip-autocomplete__form-field{width:320px!important;height:auto!important}:host::ng-deep .cgi-chip-autocomplete__form-field .mat-form-field-prefix{padding-top:.1em;padding-right:0}:host::ng-deep .cgi-chip-autocomplete__form-field .mat-form-field-infix{padding:12px 8px!important}:host::ng-deep .cgi-chip-autocomplete__form-field .mat-form-field-appearance-outline.mat-form-field-infix{padding:11px 4px!important;border-top:0px!important}:host::ng-deep .cgi-chip-autocomplete__form-field .mat-form-field-outline{min-height:43px}:host::ng-deep .cgi-chip-autocomplete__form-field .mat-chip-list-wrapper{min-height:28px}.mat-mdc-chip{background-color:#333!important;color:#fff}::placeholder{color:#333;font-family:Source Sans Pro,sans-serif;font-style:italic;font-weight:400;font-size:14px;line-height:16px}\n"], dependencies: [{ kind: "directive", type: i1.NgForOf, selector: "[ngFor][ngForOf]", inputs: ["ngForOf", "ngForTrackBy", "ngForTemplate"] }, { kind: "directive", type: i1.NgIf, selector: "[ngIf]", inputs: ["ngIf", "ngIfThen", "ngIfElse"] }, { kind: "component", type: i8.MatFormField, selector: "mat-form-field", inputs: ["hideRequiredMarker", "color", "floatLabel", "appearance", "subscriptSizing", "hintLabel"], exportAs: ["matFormField"] }, { kind: "directive", type: i8.MatLabel, selector: "mat-label" }, { kind: "directive", type: i8.MatPrefix, selector: "[matPrefix], [matIconPrefix], [matTextPrefix]", inputs: ["matTextPrefix"] }, { kind: "component", type: i3$3.MatChipGrid, selector: "mat-chip-grid", inputs: ["disabled", "placeholder", "required", "value", "errorStateMatcher"], outputs: ["change", "valueChange"] }, { kind: "directive", type: i3$3.MatChipInput, selector: "input[matChipInputFor]", inputs: ["matChipInputFor", "matChipInputAddOnBlur", "matChipInputSeparatorKeyCodes", "placeholder", "id", "disabled", "readonly", "matChipInputDisabledInteractive"], outputs: ["matChipInputTokenEnd"], exportAs: ["matChipInput", "matChipInputFor"] }, { kind: "directive", type: i3$3.MatChipRemove, selector: "[matChipRemove]" }, { kind: "component", type: i3$3.MatChipRow, selector: "mat-chip-row, [mat-chip-row], mat-basic-chip-row, [mat-basic-chip-row]", inputs: ["editable"], outputs: ["edited"] }, { kind: "component", type: i6.MatAutocomplete, selector: "mat-autocomplete", inputs: ["aria-label", "aria-labelledby", "displayWith", "autoActiveFirstOption", "autoSelectActiveOption", "requireSelection", "panelWidth", "disableRipple", "class", "hideSingleSelectionIndicator"], outputs: ["optionSelected", "opened", "closed", "optionActivated"], exportAs: ["matAutocomplete"] }, { kind: "component", type: i6.MatOption, selector: "mat-option", inputs: ["value", "id", "disabled"], outputs: ["onSelectionChange"], exportAs: ["matOption"] }, { kind: "directive", type: i6.MatAutocompleteTrigger, selector: "input[matAutocomplete], textarea[matAutocomplete]", inputs: ["matAutocomplete", "matAutocompletePosition", "matAutocompleteConnectedTo", "autocomplete", "matAutocompleteDisabled"], exportAs: ["matAutocompleteTrigger"] }, { kind: "component", type: i2$2.MatCheckbox, selector: "mat-checkbox", inputs: ["aria-label", "aria-labelledby", "aria-describedby", "aria-expanded", "aria-controls", "aria-owns", "id", "required", "labelPosition", "name", "value", "disableRipple", "tabIndex", "color", "disabledInteractive", "checked", "disabled", "indeterminate"], outputs: ["change", "indeterminateChange"], exportAs: ["matCheckbox"] }, { kind: "directive", type: i1$2.DefaultValueAccessor, selector: "input:not([type=checkbox])[formControlName],textarea[formControlName],input:not([type=checkbox])[formControl],textarea[formControl],input:not([type=checkbox])[ngModel],textarea[ngModel],[ngDefaultControl]" }, { kind: "directive", type: i1$2.NgControlStatus, selector: "[formControlName],[ngModel],[formControl]" }, { kind: "directive", type: i1$2.FormControlDirective, selector: "[formControl]", inputs: ["formControl", "disabled", "ngModel"], outputs: ["ngModelChange"], exportAs: ["ngForm"] }, { kind: "component", type: i5.MatIcon, selector: "mat-icon", inputs: ["color", "inline", "svgIcon", "fontSet", "fontIcon"], exportAs: ["matIcon"] }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.2", ngImport: i0, type: CGIChipAutocompleteComponent, decorators: [{
            type: Component,
            args: [{ selector: 'cgi-chip-autocomplete', standalone: false, template: "\n<div class=\"cgi-chip-autocomplete__clearall-container\">\n  <a\n    class=\"cgi-link-body-underline-1 cgi-chip-autocomplete__clearall-btn\"\n    aria-label=\"clear all\"\n    role=\"button\"\n    (click)=\"clearall()\"\n    ><ng-content select=\".clearall\"></ng-content\n  ></a>\n</div>\n<mat-form-field appearance=\"outline\" class=\"chip-auto-complete-form-field date cgi-mat-label-text-search\">\n  <mat-label>Add a filter</mat-label>\n  <mat-chip-grid #chipList aria-label=\"Chip autocomplete\" style=\"padding-left: 0px;\">\n <div class=\"mat-textarea\">\n <div class=\"row ms-0\">\n    <div class=\"col-1 chip-auto-complete-items\"><mat-icon class=\"cgi-chip-autocomplete__search-icon search-icon\" matPrefix>search</mat-icon></div> \n    <div class=\"col-11\" style=\"padding-left: 5px;\">\n   <mat-chip-row\n      *ngFor=\"let chip of selectedChips\"\n\n      [removable]=\"removable\"\n      (removed)=\"remove(chip)\"\n    >\n      {{ chip }}\n      <mat-icon matChipRemove *ngIf=\"removable\">close</mat-icon>\n    </mat-chip-row>\n    <input\n      style=\"margin-left: 12px;\"\n      placeholder=\"Add a filter\"\n      matInput\n      #chipInput\n      (focus)=\"matAutocomplete.showPanel = true\"\n      [formControl]=\"formCtrl\"\n      [matAutocomplete]=\"auto\"\n      [matChipInputFor]=\"chipList\"\n      [matChipInputSeparatorKeyCodes]=\"separatorKeysCodes\"\n      #trigger=\"matAutocompleteTrigger\"\n      aria-label=\"Chip Autocomplete in an expandable panel\"\n    />\n    </div>\n  </div>\n </div>\n  </mat-chip-grid>\n  <mat-autocomplete\n    #auto=\"matAutocomplete\"\n    (optionSelected)=\"selected($event)\"\n  >\n    <mat-option\n      *ngFor=\"let chip of filteredChips\"\n      [value]=\"chip\"\n      (click)=\"$event.stopPropagation(); trigger.openPanel()\"\n    >\n    <mat-checkbox></mat-checkbox>\n      {{ chip }}\n    </mat-option>\n    <mat-option style=\"text-align:center\" *ngIf=\"!filteredChips.length && selectedChips.length !== allChips.length\" disabled\n      >No results to display.\n    </mat-option>\n    <!--The mat-option below is optional; displays special message when all chips are selected-->\n    <mat-option *ngIf=\"selectedChips.length === allChips.length\" disabled\n      >All options selected.</mat-option\n    >\n  </mat-autocomplete>\n</mat-form-field>\n", styles: [".cgi-chip-autocomplete__form-field{width:100%}.chip-auto-complete-form-field:not(.mat-form-field-hide-placeholder) .mat-mdc-standard-chip{--mdc-chip-label-text-color: #ffffff;--mdc-chip-with-trailing-icon-trailing-icon-color: #ffffff;--mat-chip-trailing-action-opacity: 1}.chip-auto-complete-form-field:not(.mat-form-field-hide-placeholder) .mat-mdc-chip-set input::placeholder{opacity:1;color:#333}.cgi-chip-autocomplete__clearall-container{width:fit-content}.cgi-chip-autocomplete__clearall-btn{cursor:pointer}.cgi-chip-autocomplete__search-icon{color:#151515}:host::ng-deep .cgi-chip-autocomplete__form-field{width:320px!important;height:auto!important}:host::ng-deep .cgi-chip-autocomplete__form-field .mat-form-field-prefix{padding-top:.1em;padding-right:0}:host::ng-deep .cgi-chip-autocomplete__form-field .mat-form-field-infix{padding:12px 8px!important}:host::ng-deep .cgi-chip-autocomplete__form-field .mat-form-field-appearance-outline.mat-form-field-infix{padding:11px 4px!important;border-top:0px!important}:host::ng-deep .cgi-chip-autocomplete__form-field .mat-form-field-outline{min-height:43px}:host::ng-deep .cgi-chip-autocomplete__form-field .mat-chip-list-wrapper{min-height:28px}.mat-mdc-chip{background-color:#333!important;color:#fff}::placeholder{color:#333;font-family:Source Sans Pro,sans-serif;font-style:italic;font-weight:400;font-size:14px;line-height:16px}\n"] }]
        }], ctorParameters: () => [], propDecorators: { chipInput: [{
                type: ViewChild,
                args: ['chipInput']
            }], matAutocomplete: [{
                type: ViewChild,
                args: ['auto']
            }], allChips: [{
                type: Input
            }], selectedChips: [{
                type: Input
            }], selectable: [{
                type: Input
            }], removable: [{
                type: Input
            }] } });

class CGIChipAutocompleteModule {
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.2", ngImport: i0, type: CGIChipAutocompleteModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule }); }
    static { this.ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "20.3.2", ngImport: i0, type: CGIChipAutocompleteModule, declarations: [CGIChipAutocompleteComponent], imports: [CommonModule, MatFormFieldModule, MatChipsModule, MatAutocompleteModule, MatCheckboxModule, ReactiveFormsModule, MatIconModule], exports: [CGIChipAutocompleteComponent] }); }
    static { this.ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "20.3.2", ngImport: i0, type: CGIChipAutocompleteModule, imports: [CommonModule, MatFormFieldModule, MatChipsModule, MatAutocompleteModule, MatCheckboxModule, ReactiveFormsModule, MatIconModule] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.2", ngImport: i0, type: CGIChipAutocompleteModule, decorators: [{
            type: NgModule,
            args: [{
                    imports: [CommonModule, MatFormFieldModule, MatChipsModule, MatAutocompleteModule, MatCheckboxModule, ReactiveFormsModule, MatIconModule],
                    declarations: [CGIChipAutocompleteComponent],
                    exports: [CGIChipAutocompleteComponent]
                }]
        }] });

/**
 * Container component that wraps Angular Material steppers.
 *
 * Applies a standard CSS class to provide consistent CGI branding and styling
 * for stepper components. This component is used internally by the CgiStepperComponent.
 *
 * @example
 * ```html
 * <cgi-stepper-container>
 *   <mat-horizontal-stepper>
 *     <!-- stepper content -->
 *   </mat-horizontal-stepper>
 * </cgi-stepper-container>
 * ```
 */
class CgiStepperContainerComponent {
    constructor() {
        /**
         * Automatically applies the 'cgi-stepper-container' CSS class to the host element.
         * This enables consistent styling across all stepper instances.
         */
        this.isClassContainer = true;
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.2", ngImport: i0, type: CgiStepperContainerComponent, deps: [], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "20.3.2", type: CgiStepperContainerComponent, isStandalone: false, selector: "cgi-stepper-container", host: { properties: { "class.cgi-stepper-container": "this.isClassContainer" } }, ngImport: i0, template: "<ng-content></ng-content>\n", styles: ["::ng-deep .cgi-stepper-container .mat-step-header.mat-vertical-stepper-header[ng-reflect-state=edit]+.mat-stepper-vertical-line:before,::ng-deep .cgi-stepper-container .mat-step-header.mat-vertical-stepper-header:has(.mat-step-icon.mat-step-icon-state-edit)+.mat-stepper-vertical-line:before{border-left-color:#5236ab}::ng-deep .cgi-stepper-container .mat-step-header.mat-horizontal-stepper-header[ng-reflect-state=edit]+.mat-stepper-horizontal-line,::ng-deep .cgi-stepper-container .mat-step-header.mat-horizontal-stepper-header[ng-reflect-state=edit]:after,::ng-deep .cgi-stepper-container .mat-step-header.mat-horizontal-stepper-header[ng-reflect-state=edit]+.mat-stepper-horizontal-line+.mat-horizontal-stepper-header:before,::ng-deep .cgi-stepper-container .mat-step-header.mat-horizontal-stepper-header:has(.mat-step-icon.mat-step-icon-state-edit)+.mat-stepper-horizontal-line,::ng-deep .cgi-stepper-container .mat-step-header.mat-horizontal-stepper-header:has(.mat-step-icon.mat-step-icon-state-edit):after,::ng-deep .cgi-stepper-container .mat-step-header.mat-horizontal-stepper-header:has(.mat-step-icon.mat-step-icon-state-edit)+.mat-stepper-horizontal-line+.mat-horizontal-stepper-header:before{border-top-color:#5236ab}\n"] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.2", ngImport: i0, type: CgiStepperContainerComponent, decorators: [{
            type: Component,
            args: [{ selector: 'cgi-stepper-container', standalone: false, template: "<ng-content></ng-content>\n", styles: ["::ng-deep .cgi-stepper-container .mat-step-header.mat-vertical-stepper-header[ng-reflect-state=edit]+.mat-stepper-vertical-line:before,::ng-deep .cgi-stepper-container .mat-step-header.mat-vertical-stepper-header:has(.mat-step-icon.mat-step-icon-state-edit)+.mat-stepper-vertical-line:before{border-left-color:#5236ab}::ng-deep .cgi-stepper-container .mat-step-header.mat-horizontal-stepper-header[ng-reflect-state=edit]+.mat-stepper-horizontal-line,::ng-deep .cgi-stepper-container .mat-step-header.mat-horizontal-stepper-header[ng-reflect-state=edit]:after,::ng-deep .cgi-stepper-container .mat-step-header.mat-horizontal-stepper-header[ng-reflect-state=edit]+.mat-stepper-horizontal-line+.mat-horizontal-stepper-header:before,::ng-deep .cgi-stepper-container .mat-step-header.mat-horizontal-stepper-header:has(.mat-step-icon.mat-step-icon-state-edit)+.mat-stepper-horizontal-line,::ng-deep .cgi-stepper-container .mat-step-header.mat-horizontal-stepper-header:has(.mat-step-icon.mat-step-icon-state-edit):after,::ng-deep .cgi-stepper-container .mat-step-header.mat-horizontal-stepper-header:has(.mat-step-icon.mat-step-icon-state-edit)+.mat-stepper-horizontal-line+.mat-horizontal-stepper-header:before{border-top-color:#5236ab}\n"] }]
        }], propDecorators: { isClassContainer: [{
                type: HostBinding,
                args: ['class.cgi-stepper-container']
            }] } });

/**
 * CGI Stepper Component
 *
 * A reusable stepper component that wraps Angular Material stepper with CGI branding.
 * Supports horizontal and vertical orientations, configurable label positions,
 * and linear/non-linear navigation modes.
 *
 * @example
 * ```html
 * <cgi-stepper
 *   [steps]="stepConfigs"
 *   [orientation]="'horizontal'"
 *   [labelPosition]="'end'"
 *   [linear]="false"
 *   [selectedIndex]="2"
 *   (stepChange)="onStepChange($event)">
 * </cgi-stepper>
 * ```
 */
class CgiStepperComponent {
    constructor() {
        /**
         * Array of step configurations
         */
        this.steps = [];
        /**
         * Orientation of the stepper: 'horizontal' or 'vertical'
         */
        this.orientation = 'horizontal';
        /**
         * Position of step labels: 'end' (side) or 'bottom'
         * Only applies to horizontal steppers
         */
        this.labelPosition = 'end';
        /**
         * Whether the stepper requires completing steps in order
         */
        this.linear = false;
        /**
         * Whether to show step content area
         */
        this.showContent = true;
        /**
         * Whether to show navigation buttons (Back, Cancel, Next)
         */
        this.showNavigation = true;
        /**
         * Initial selected step index (0-based)
         */
        this.selectedIndex = 0;
        /**
         * Optional ID for the stepper element
         */
        this.stepperId = '';
        /**
         * Whether to show label before icon (title first, then icon).
         * Only applies to horizontal steppers with labelPosition 'end'.
         */
        this.labelFirst = true;
        /**
         * Label for the back button
         */
        this.backLabel = 'Back';
        /**
         * Label for the cancel button
         */
        this.cancelLabel = 'Cancel';
        /**
         * Label for the next button
         */
        this.nextLabel = 'Next';
        /**
         * Label for the reset button (shown on last step)
         */
        this.resetLabel = 'Reset';
        /**
         * Event emitted when the step changes
         */
        this.stepChange = new EventEmitter();
        /**
         * Event emitted when cancel button is clicked
         */
        this.cancelClick = new EventEmitter();
        /**
         * Event emitted when the stepper is reset
         */
        this.resetClick = new EventEmitter();
    }
    /**
     * Gets the active stepper reference based on orientation
     */
    get activeStepper() {
        return this.orientation === 'horizontal' ? this.horizontalStepper : this.verticalStepper;
    }
    /**
     * Sets the initial selected index after view initialization.
     * Navigates through each step sequentially to properly mark previous steps as completed.
     */
    ngAfterViewInit() {
        if (this.selectedIndex > 0 && this.activeStepper) {
            setTimeout(() => {
                if (this.activeStepper) {
                    // Navigate through each step sequentially to mark them as completed
                    // This mimics user navigation and properly sets the "edit" (completed) state
                    for (let i = 1; i <= this.selectedIndex; i++) {
                        this.activeStepper.selectedIndex = i;
                    }
                }
            });
        }
    }
    /**
     * Resets the stepper to the first step
     */
    reset() {
        this.activeStepper?.reset();
        this.resetClick.emit();
    }
    /**
     * Handles step selection change
     * @param index - The index of the selected step
     */
    onStepChange(index) {
        this.stepChange.emit(index);
    }
    /**
     * Handles cancel button click
     */
    onCancel() {
        this.cancelClick.emit();
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.2", ngImport: i0, type: CgiStepperComponent, deps: [], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "20.3.2", type: CgiStepperComponent, isStandalone: false, selector: "cgi-stepper", inputs: { steps: "steps", orientation: "orientation", labelPosition: "labelPosition", linear: "linear", showContent: "showContent", showNavigation: "showNavigation", selectedIndex: "selectedIndex", stepperId: "stepperId", labelFirst: "labelFirst", backLabel: "backLabel", cancelLabel: "cancelLabel", nextLabel: "nextLabel", resetLabel: "resetLabel" }, outputs: { stepChange: "stepChange", cancelClick: "cancelClick", resetClick: "resetClick" }, viewQueries: [{ propertyName: "horizontalStepper", first: true, predicate: ["horizontalStepper"], descendants: true }, { propertyName: "verticalStepper", first: true, predicate: ["verticalStepper"], descendants: true }], ngImport: i0, template: "<cgi-stepper-container>\n  <!-- Horizontal Stepper -->\n  <mat-horizontal-stepper \n    *ngIf=\"orientation === 'horizontal'\" \n    #horizontalStepper \n    [attr.id]=\"stepperId || null\"\n    [class.cgi-stepper-label-first]=\"labelFirst && labelPosition === 'end' && showContent\"\n    [class.cgi-stepper-indicator]=\"!showContent && labelPosition === 'end'\"\n    [labelPosition]=\"labelPosition\" \n    [linear]=\"linear\"\n    (selectionChange)=\"onStepChange($event.selectedIndex)\">\n    \n    <ng-template matStepperIcon=\"edit\">\n      <mat-icon class=\"material-icons-outlined\">check</mat-icon>\n    </ng-template>\n    <ng-template matStepperIcon=\"number\">\n      <mat-icon class=\"material-icons-outlined\">edit</mat-icon>\n    </ng-template>\n    \n    <mat-step \n      *ngFor=\"let step of steps; let i = index; let last = last\"\n      [editable]=\"step.editable !== false\">\n      <ng-template matStepLabel>\n        <h6 class=\"cgi-display-6\">{{ step.title }}</h6>\n        <p *ngIf=\"labelPosition === 'bottom' && step.subtitle\" class=\"cgi-caption\">{{ step.subtitle }}</p>\n      </ng-template>\n      \n      <ng-container *ngIf=\"showContent\">\n        <hr />\n        <div class=\"cgi-vertical-spacer-16\"></div>\n        <h5 class=\"cgi-display-5\">{{ step.title }}</h5>\n        <div class=\"cgi-vertical-spacer-16\"></div>\n        <p class=\"cgi-body-2 mb-0\">{{ step.content }}</p>\n        <div class=\"cgi-vertical-spacer-16\"></div>\n        \n        <div *ngIf=\"showNavigation\" class=\"row d-flex justify-content-between\">\n          <div class=\"col-auto\">\n            <button mat-button matStepperPrevious>{{ backLabel }}</button>\n          </div>\n          <div class=\"col-auto\">\n            <div class=\"d-flex\">\n              <div class=\"me-2\">\n                <button mat-button (click)=\"onCancel()\">{{ cancelLabel }}</button>\n              </div>\n              <div>\n                <button *ngIf=\"!last\" color=\"primary\" mat-flat-button matStepperNext>{{ nextLabel }}</button>\n                <button *ngIf=\"last\" color=\"primary\" mat-flat-button (click)=\"reset()\">{{ resetLabel }}</button>\n              </div>\n            </div>\n          </div>\n        </div>\n      </ng-container>\n    </mat-step>\n  </mat-horizontal-stepper>\n  \n  <!-- Vertical Stepper -->\n  <mat-vertical-stepper \n    *ngIf=\"orientation === 'vertical'\" \n    #verticalStepper \n    [linear]=\"linear\"\n    (selectionChange)=\"onStepChange($event.selectedIndex)\">\n    \n    <ng-template matStepperIcon=\"edit\">\n      <mat-icon class=\"material-icons-outlined\">check</mat-icon>\n    </ng-template>\n    <ng-template matStepperIcon=\"number\">\n      <mat-icon class=\"material-icons-outlined\">edit</mat-icon>\n    </ng-template>\n    \n    <mat-step \n      *ngFor=\"let step of steps; let i = index; let last = last\"\n      [editable]=\"step.editable !== false\">\n      <ng-template matStepLabel>\n        <h6 class=\"cgi-display-6\">{{ step.title }}</h6>\n      </ng-template>\n      \n      <ng-container *ngIf=\"showContent\">\n        <p class=\"cgi-body-2 mb-0\">{{ step.content }}</p>\n        <div class=\"cgi-vertical-spacer-16\"></div>\n        \n        <div *ngIf=\"showNavigation\" class=\"row d-flex justify-content-between\">\n          <div class=\"col-auto\">\n            <button mat-button matStepperPrevious>{{ backLabel }}</button>\n          </div>\n          <div class=\"col-auto\">\n            <div class=\"d-flex\">\n              <div class=\"me-2\">\n                <button mat-button (click)=\"onCancel()\">{{ cancelLabel }}</button>\n              </div>\n              <div>\n                <button *ngIf=\"!last\" color=\"primary\" mat-flat-button matStepperNext>{{ nextLabel }}</button>\n                <button *ngIf=\"last\" color=\"primary\" mat-flat-button (click)=\"reset()\">{{ resetLabel }}</button>\n              </div>\n            </div>\n          </div>\n        </div>\n        <div class=\"cgi-vertical-spacer-24\"></div>\n      </ng-container>\n    </mat-step>\n  </mat-vertical-stepper>\n</cgi-stepper-container>\n", styles: ["::ng-deep .cgi-stepper-label-first .mat-horizontal-stepper-header,::ng-deep .cgi-stepper-indicator .mat-horizontal-stepper-header{display:flex;flex-direction:row;justify-content:space-between;align-items:center;text-align:center}::ng-deep .cgi-stepper-label-first .mat-step-label,::ng-deep .cgi-stepper-indicator .mat-step-label{position:relative;margin-right:32px;overflow:visible}::ng-deep .cgi-stepper-label-first .mat-step-icon,::ng-deep .cgi-stepper-indicator .mat-step-icon{margin-right:-92px!important;margin-bottom:5px}::ng-deep .cgi-stepper-label-first .mat-step-header.mat-horizontal-stepper-header,::ng-deep .cgi-stepper-indicator .mat-step-header.mat-horizontal-stepper-header{padding-right:0;height:auto!important}::ng-deep .cgi-stepper-label-first .mat-stepper-horizontal-line,::ng-deep .cgi-stepper-indicator .mat-stepper-horizontal-line{margin-bottom:4px!important;margin-right:6px!important;margin-left:6px!important}::ng-deep .cgi-stepper-label-first .mat-horizontal-stepper-header .mat-step-icon,::ng-deep .cgi-stepper-label-first .mat-horizontal-stepper-header .mat-step-icon-not-touched,::ng-deep .cgi-stepper-indicator .mat-horizontal-stepper-header .mat-step-icon,::ng-deep .cgi-stepper-indicator .mat-horizontal-stepper-header .mat-step-icon-not-touched{margin-left:50px;align-items:center;text-align:center}::ng-deep .cgi-stepper-label-first .mat-step-header.mat-horizontal-stepper-header{padding-bottom:16px!important}::ng-deep .cgi-stepper-label-first .mat-stepper-horizontal-line{margin-top:15px!important}\n"], dependencies: [{ kind: "directive", type: i1.NgForOf, selector: "[ngFor][ngForOf]", inputs: ["ngForOf", "ngForTrackBy", "ngForTemplate"] }, { kind: "directive", type: i1.NgIf, selector: "[ngIf]", inputs: ["ngIf", "ngIfThen", "ngIfElse"] }, { kind: "component", type: i2$4.MatStep, selector: "mat-step", inputs: ["color"], exportAs: ["matStep"] }, { kind: "directive", type: i2$4.MatStepLabel, selector: "[matStepLabel]" }, { kind: "component", type: i2$4.MatStepper, selector: "mat-stepper, mat-vertical-stepper, mat-horizontal-stepper, [matStepper]", inputs: ["disableRipple", "color", "labelPosition", "headerPosition", "animationDuration"], outputs: ["animationDone"], exportAs: ["matStepper", "matVerticalStepper", "matHorizontalStepper"] }, { kind: "directive", type: i2$4.MatStepperNext, selector: "button[matStepperNext]" }, { kind: "directive", type: i2$4.MatStepperPrevious, selector: "button[matStepperPrevious]" }, { kind: "directive", type: i2$4.MatStepperIcon, selector: "ng-template[matStepperIcon]", inputs: ["matStepperIcon"] }, { kind: "component", type: i4.MatButton, selector: "    button[matButton], a[matButton], button[mat-button], button[mat-raised-button],    button[mat-flat-button], button[mat-stroked-button], a[mat-button], a[mat-raised-button],    a[mat-flat-button], a[mat-stroked-button]  ", inputs: ["matButton"], exportAs: ["matButton", "matAnchor"] }, { kind: "component", type: i5.MatIcon, selector: "mat-icon", inputs: ["color", "inline", "svgIcon", "fontSet", "fontIcon"], exportAs: ["matIcon"] }, { kind: "component", type: CgiStepperContainerComponent, selector: "cgi-stepper-container" }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.2", ngImport: i0, type: CgiStepperComponent, decorators: [{
            type: Component,
            args: [{ selector: 'cgi-stepper', standalone: false, template: "<cgi-stepper-container>\n  <!-- Horizontal Stepper -->\n  <mat-horizontal-stepper \n    *ngIf=\"orientation === 'horizontal'\" \n    #horizontalStepper \n    [attr.id]=\"stepperId || null\"\n    [class.cgi-stepper-label-first]=\"labelFirst && labelPosition === 'end' && showContent\"\n    [class.cgi-stepper-indicator]=\"!showContent && labelPosition === 'end'\"\n    [labelPosition]=\"labelPosition\" \n    [linear]=\"linear\"\n    (selectionChange)=\"onStepChange($event.selectedIndex)\">\n    \n    <ng-template matStepperIcon=\"edit\">\n      <mat-icon class=\"material-icons-outlined\">check</mat-icon>\n    </ng-template>\n    <ng-template matStepperIcon=\"number\">\n      <mat-icon class=\"material-icons-outlined\">edit</mat-icon>\n    </ng-template>\n    \n    <mat-step \n      *ngFor=\"let step of steps; let i = index; let last = last\"\n      [editable]=\"step.editable !== false\">\n      <ng-template matStepLabel>\n        <h6 class=\"cgi-display-6\">{{ step.title }}</h6>\n        <p *ngIf=\"labelPosition === 'bottom' && step.subtitle\" class=\"cgi-caption\">{{ step.subtitle }}</p>\n      </ng-template>\n      \n      <ng-container *ngIf=\"showContent\">\n        <hr />\n        <div class=\"cgi-vertical-spacer-16\"></div>\n        <h5 class=\"cgi-display-5\">{{ step.title }}</h5>\n        <div class=\"cgi-vertical-spacer-16\"></div>\n        <p class=\"cgi-body-2 mb-0\">{{ step.content }}</p>\n        <div class=\"cgi-vertical-spacer-16\"></div>\n        \n        <div *ngIf=\"showNavigation\" class=\"row d-flex justify-content-between\">\n          <div class=\"col-auto\">\n            <button mat-button matStepperPrevious>{{ backLabel }}</button>\n          </div>\n          <div class=\"col-auto\">\n            <div class=\"d-flex\">\n              <div class=\"me-2\">\n                <button mat-button (click)=\"onCancel()\">{{ cancelLabel }}</button>\n              </div>\n              <div>\n                <button *ngIf=\"!last\" color=\"primary\" mat-flat-button matStepperNext>{{ nextLabel }}</button>\n                <button *ngIf=\"last\" color=\"primary\" mat-flat-button (click)=\"reset()\">{{ resetLabel }}</button>\n              </div>\n            </div>\n          </div>\n        </div>\n      </ng-container>\n    </mat-step>\n  </mat-horizontal-stepper>\n  \n  <!-- Vertical Stepper -->\n  <mat-vertical-stepper \n    *ngIf=\"orientation === 'vertical'\" \n    #verticalStepper \n    [linear]=\"linear\"\n    (selectionChange)=\"onStepChange($event.selectedIndex)\">\n    \n    <ng-template matStepperIcon=\"edit\">\n      <mat-icon class=\"material-icons-outlined\">check</mat-icon>\n    </ng-template>\n    <ng-template matStepperIcon=\"number\">\n      <mat-icon class=\"material-icons-outlined\">edit</mat-icon>\n    </ng-template>\n    \n    <mat-step \n      *ngFor=\"let step of steps; let i = index; let last = last\"\n      [editable]=\"step.editable !== false\">\n      <ng-template matStepLabel>\n        <h6 class=\"cgi-display-6\">{{ step.title }}</h6>\n      </ng-template>\n      \n      <ng-container *ngIf=\"showContent\">\n        <p class=\"cgi-body-2 mb-0\">{{ step.content }}</p>\n        <div class=\"cgi-vertical-spacer-16\"></div>\n        \n        <div *ngIf=\"showNavigation\" class=\"row d-flex justify-content-between\">\n          <div class=\"col-auto\">\n            <button mat-button matStepperPrevious>{{ backLabel }}</button>\n          </div>\n          <div class=\"col-auto\">\n            <div class=\"d-flex\">\n              <div class=\"me-2\">\n                <button mat-button (click)=\"onCancel()\">{{ cancelLabel }}</button>\n              </div>\n              <div>\n                <button *ngIf=\"!last\" color=\"primary\" mat-flat-button matStepperNext>{{ nextLabel }}</button>\n                <button *ngIf=\"last\" color=\"primary\" mat-flat-button (click)=\"reset()\">{{ resetLabel }}</button>\n              </div>\n            </div>\n          </div>\n        </div>\n        <div class=\"cgi-vertical-spacer-24\"></div>\n      </ng-container>\n    </mat-step>\n  </mat-vertical-stepper>\n</cgi-stepper-container>\n", styles: ["::ng-deep .cgi-stepper-label-first .mat-horizontal-stepper-header,::ng-deep .cgi-stepper-indicator .mat-horizontal-stepper-header{display:flex;flex-direction:row;justify-content:space-between;align-items:center;text-align:center}::ng-deep .cgi-stepper-label-first .mat-step-label,::ng-deep .cgi-stepper-indicator .mat-step-label{position:relative;margin-right:32px;overflow:visible}::ng-deep .cgi-stepper-label-first .mat-step-icon,::ng-deep .cgi-stepper-indicator .mat-step-icon{margin-right:-92px!important;margin-bottom:5px}::ng-deep .cgi-stepper-label-first .mat-step-header.mat-horizontal-stepper-header,::ng-deep .cgi-stepper-indicator .mat-step-header.mat-horizontal-stepper-header{padding-right:0;height:auto!important}::ng-deep .cgi-stepper-label-first .mat-stepper-horizontal-line,::ng-deep .cgi-stepper-indicator .mat-stepper-horizontal-line{margin-bottom:4px!important;margin-right:6px!important;margin-left:6px!important}::ng-deep .cgi-stepper-label-first .mat-horizontal-stepper-header .mat-step-icon,::ng-deep .cgi-stepper-label-first .mat-horizontal-stepper-header .mat-step-icon-not-touched,::ng-deep .cgi-stepper-indicator .mat-horizontal-stepper-header .mat-step-icon,::ng-deep .cgi-stepper-indicator .mat-horizontal-stepper-header .mat-step-icon-not-touched{margin-left:50px;align-items:center;text-align:center}::ng-deep .cgi-stepper-label-first .mat-step-header.mat-horizontal-stepper-header{padding-bottom:16px!important}::ng-deep .cgi-stepper-label-first .mat-stepper-horizontal-line{margin-top:15px!important}\n"] }]
        }], propDecorators: { steps: [{
                type: Input
            }], orientation: [{
                type: Input
            }], labelPosition: [{
                type: Input
            }], linear: [{
                type: Input
            }], showContent: [{
                type: Input
            }], showNavigation: [{
                type: Input
            }], selectedIndex: [{
                type: Input
            }], stepperId: [{
                type: Input
            }], labelFirst: [{
                type: Input
            }], backLabel: [{
                type: Input
            }], cancelLabel: [{
                type: Input
            }], nextLabel: [{
                type: Input
            }], resetLabel: [{
                type: Input
            }], stepChange: [{
                type: Output
            }], cancelClick: [{
                type: Output
            }], resetClick: [{
                type: Output
            }], horizontalStepper: [{
                type: ViewChild,
                args: ['horizontalStepper']
            }], verticalStepper: [{
                type: ViewChild,
                args: ['verticalStepper']
            }] } });

/**
 * Module for CGI Stepper components.
 *
 * Provides reusable stepper components with CGI branding for displaying
 * progress through multi-step processes.
 *
 * @example
 * ```typescript
 * import { CGISteppersModule } from '@cgi/sentry-angular-components-lib';
 *
 * @NgModule({
 *   imports: [CGISteppersModule]
 * })
 * export class AppModule { }
 * ```
 */
class CGISteppersModule {
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.2", ngImport: i0, type: CGISteppersModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule }); }
    static { this.ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "20.3.2", ngImport: i0, type: CGISteppersModule, declarations: [CgiStepperContainerComponent,
            CgiStepperComponent], imports: [CommonModule,
            MatStepperModule,
            MatButtonModule,
            MatIconModule], exports: [CgiStepperContainerComponent,
            CgiStepperComponent] }); }
    static { this.ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "20.3.2", ngImport: i0, type: CGISteppersModule, imports: [CommonModule,
            MatStepperModule,
            MatButtonModule,
            MatIconModule] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.2", ngImport: i0, type: CGISteppersModule, decorators: [{
            type: NgModule,
            args: [{
                    imports: [
                        CommonModule,
                        MatStepperModule,
                        MatButtonModule,
                        MatIconModule
                    ],
                    declarations: [
                        CgiStepperContainerComponent,
                        CgiStepperComponent
                    ],
                    exports: [
                        CgiStepperContainerComponent,
                        CgiStepperComponent
                    ],
                }]
        }] });

/**
 * Snackbar component.
 *
 * Displays brief notification messages at the bottom of the screen.
 * Supports single-line or multi-line text with optional action buttons.
 */
class CgiSnackbarComponent {
    constructor(data, snackBarRef) {
        this.snackBarRef = snackBarRef;
        /** Text message to display in the snackbar */
        this.text = 'Single-line snackbar';
        /** Label text for the action button */
        this.buttonText = 'Button';
        /** Controls visibility of action buttons */
        this.showActions = true;
        // If data is provided from MatSnackBar, use it instead of @Input values
        if (data) {
            this.text = data.text || this.text;
            this.buttonText = data.buttonText || this.buttonText;
            this.showActions = data.showActions !== undefined ? data.showActions : this.showActions;
        }
    }
    /** Dismisses the snackbar when action button is clicked */
    dismissSnackbar() {
        if (this.snackBarRef) {
            this.snackBarRef.dismissWithAction();
        }
    }
    /** Determines if text is likely single-line based on character count (approximately 50 characters fit in a single line) */
    get isSingleLine() {
        return this.text.length <= 50;
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.2", ngImport: i0, type: CgiSnackbarComponent, deps: [{ token: MAT_SNACK_BAR_DATA, optional: true }, { token: i1$4.MatSnackBarRef, optional: true }], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "20.3.2", type: CgiSnackbarComponent, isStandalone: false, selector: "cgi-snackbar", inputs: { text: "text", buttonText: "buttonText", showActions: "showActions" }, ngImport: i0, template: "<div [ngClass]=\"(isSingleLine && showActions) ? 'snackbar-with-action' : 'snackbar'\">\n    <p class=\"cgi-body-2\" style=\"color: #f2f1f9; margin-bottom: 0px\">\n        {{ text }}\n    </p>\n    <div class=\"floating-action-buttons\" *ngIf=\"showActions\">\n        <button\n            class=\"snackbar-button snackbar-hover\"\n            mat-button\n            aria-label=\"Hover label only text button\"\n            (click)=\"dismissSnackbar()\"\n        >\n            {{ buttonText }}\n        </button>\n    </div>\n</div>", styles: [".snackbar-padding{display:flex;width:400px;border-radius:4px;padding:8px 20px;align-items:center;align-self:stretch;gap:4px;background-color:#333;justify-content:space-between;box-shadow:0 4px 4px #00000040}.floating-action-buttons{display:flex;align-self:stretch;justify-content:flex-end;gap:8px}.snackbar-button{color:#cbc3e6}.snackbar-button:hover:not([disabled]){color:#f2f1f9!important}.snackbar-button:focus:not([disabled]){background-color:#f2f1f9!important;color:#5236ab!important}.snackbar-button:active:not([disabled]){background-color:#e6e3f3!important;color:#5236ab!important}.snackbar-hover:hover,.snackbar-hover:active,.snackbar-hover:focus,.snackbar-hover:focus-within{color:#fff!important;background-color:transparent!important}.mat-mdc-snack-bar-container{padding:0;margin:0}.mat-mdc-snack-bar-container .mat-mdc-snackbar-surface,.mat-mdc-snack-bar-container .mat-mdc-snackbar-surface .mat-mdc-snack-bar-label{padding:0}\n"], dependencies: [{ kind: "directive", type: i1.NgClass, selector: "[ngClass]", inputs: ["class", "ngClass"] }, { kind: "directive", type: i1.NgIf, selector: "[ngIf]", inputs: ["ngIf", "ngIfThen", "ngIfElse"] }, { kind: "component", type: i4.MatButton, selector: "    button[matButton], a[matButton], button[mat-button], button[mat-raised-button],    button[mat-flat-button], button[mat-stroked-button], a[mat-button], a[mat-raised-button],    a[mat-flat-button], a[mat-stroked-button]  ", inputs: ["matButton"], exportAs: ["matButton", "matAnchor"] }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.2", ngImport: i0, type: CgiSnackbarComponent, decorators: [{
            type: Component,
            args: [{ selector: 'cgi-snackbar', standalone: false, template: "<div [ngClass]=\"(isSingleLine && showActions) ? 'snackbar-with-action' : 'snackbar'\">\n    <p class=\"cgi-body-2\" style=\"color: #f2f1f9; margin-bottom: 0px\">\n        {{ text }}\n    </p>\n    <div class=\"floating-action-buttons\" *ngIf=\"showActions\">\n        <button\n            class=\"snackbar-button snackbar-hover\"\n            mat-button\n            aria-label=\"Hover label only text button\"\n            (click)=\"dismissSnackbar()\"\n        >\n            {{ buttonText }}\n        </button>\n    </div>\n</div>", styles: [".snackbar-padding{display:flex;width:400px;border-radius:4px;padding:8px 20px;align-items:center;align-self:stretch;gap:4px;background-color:#333;justify-content:space-between;box-shadow:0 4px 4px #00000040}.floating-action-buttons{display:flex;align-self:stretch;justify-content:flex-end;gap:8px}.snackbar-button{color:#cbc3e6}.snackbar-button:hover:not([disabled]){color:#f2f1f9!important}.snackbar-button:focus:not([disabled]){background-color:#f2f1f9!important;color:#5236ab!important}.snackbar-button:active:not([disabled]){background-color:#e6e3f3!important;color:#5236ab!important}.snackbar-hover:hover,.snackbar-hover:active,.snackbar-hover:focus,.snackbar-hover:focus-within{color:#fff!important;background-color:transparent!important}.mat-mdc-snack-bar-container{padding:0;margin:0}.mat-mdc-snack-bar-container .mat-mdc-snackbar-surface,.mat-mdc-snack-bar-container .mat-mdc-snackbar-surface .mat-mdc-snack-bar-label{padding:0}\n"] }]
        }], ctorParameters: () => [{ type: undefined, decorators: [{
                    type: Optional
                }, {
                    type: Inject,
                    args: [MAT_SNACK_BAR_DATA]
                }] }, { type: i1$4.MatSnackBarRef, decorators: [{
                    type: Optional
                }] }], propDecorators: { text: [{
                type: Input
            }], buttonText: [{
                type: Input
            }], showActions: [{
                type: Input
            }] } });

class CGISnackbarBrandModule {
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.2", ngImport: i0, type: CGISnackbarBrandModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule }); }
    static { this.ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "20.3.2", ngImport: i0, type: CGISnackbarBrandModule, declarations: [CgiSnackbarComponent], imports: [CommonModule,
            MatButtonModule], exports: [CgiSnackbarComponent] }); }
    static { this.ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "20.3.2", ngImport: i0, type: CGISnackbarBrandModule, imports: [CommonModule,
            MatButtonModule] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.2", ngImport: i0, type: CGISnackbarBrandModule, decorators: [{
            type: NgModule,
            args: [{
                    imports: [
                        CommonModule,
                        MatButtonModule
                    ],
                    declarations: [
                        CgiSnackbarComponent,
                    ],
                    exports: [
                        CgiSnackbarComponent,
                    ],
                }]
        }] });

/* Public API Surface of sentry-angular-components-lib*/

/**
 * Generated bundle index. Do not edit.
 */

export { CGIAccordionComponent, CGIAccordionModule, CGIAlertBrandComponent, CGIAlertBrandDirective, CGIAlertComponent, CGIAlertContainerBrandComponent, CGIAlertContainerBrandModule, CGIAlertContainerComponent, CGIAlertContainerModule, CGIAlertDirective, CGIAnchorScrollBrandComponent, CGIAnchorScrollComponent, CGIAnchorScrollContainerBrandComponent, CGIAnchorScrollContainerBrandModule, CGIAnchorScrollContainerComponent, CGIAnchorScrollContainerModule, CGIBreadcrumbItemBrandComponent, CGIBreadcrumbItemComponent, CGIBreadcrumbsBrandComponent, CGIBreadcrumbsBrandModule, CGIBreadcrumbsComponent, CGIBreadcrumbsModule, CGIChipAutocompleteComponent, CGIChipAutocompleteModule, CGIClickOutsideBrandDirective, CGIClickOutsideDirective, CGICounterModule, CGIDatatableComponent, CGIExplorerListComponent, CGIExplorerListContainerBrandModule, CGIExplorerListContainerComponent, CGIExplorerListDetailsComponent, CGIFooterBrandModule, CGIFooterContainerBrandComponent, CGIFooterContainerComponent, CGIFooterModule, CGIGlobalSearchBrandModule, CGIGlobalSearchModule, CGIHeadstoneAccordionBrandComponent, CGIHeadstoneAccordionComponent, CGIHeadstoneBrandComponent, CGIHeadstoneBrandModule, CGIHeadstoneComponent, CGIHeadstoneItemBrandComponent, CGIHeadstoneItemComponent, CGIHeadstoneModule, CGILogoModule, CGIMultiSelectBrandModule, CGIMultiSelectCheckboxesBrandComponent, CGIMultiSelectCheckboxesComponent, CGIMultiSelectHeaderBrandComponent, CGIMultiSelectHeaderComponent, CGIMultiSelectModule, CGINavContainerBrandComponent, CGINavContainerBrandModule, CGINavContainerComponent, CGINavContainerModule, CGINavContentBrandComponent, CGINavContentComponent, CGIPopoverBrandComponent, CGIPopoverBrandModule, CGIPopoverComponent, CGIPopoverContentBrandComponent, CGIPopoverContentComponent, CGIPopoverFooterBrandComponent, CGIPopoverFooterComponent, CGIPopoverHeaderBrandComponent, CGIPopoverHeaderComponent, CGIPopoverModule, CGISelectSearchBrandComponent, CGISelectSearchBrandModule, CGISelectSearchComponent, CGISelectSearchModule, CGISideNavBrandComponent, CGISideNavComponent, CGISideNavItemBrandComponent, CGISideNavItemComponent, CGISkeletonBrandComponent, CGISkeletonBrandModule, CGISkeletonComponent, CGISkeletonModule, CGISnackbarBrandModule, CGISteppersModule, CGITimelineBrandComponent, CGITimelineBrandModule, CGITimelineComponent, CGITimelineEntryAvatarBrandComponent, CGITimelineEntryAvatarComponent, CGITimelineEntryBodyBrandComponent, CGITimelineEntryBodyComponent, CGITimelineEntryBrandComponent, CGITimelineEntryComponent, CGITimelineEntryIconBrandComponent, CGITimelineEntryIconComponent, CGITimelineEntryTitleBrandComponent, CGITimelineEntryTitleComponent, CGITimelineModule, CGITimepickerBrandComponent, CGITimepickerBrandModule, CGITimepickerComponent, CGITimepickerModule, CGIToasterBrandComponent, CGIToasterBrandModule, CGIToasterComponent, CGIToasterModule, CGITopNavBrandComponent, CGITopNavBrandModule, CGITopNavComponent, CGITopNavItemBrandComponent, CGITopNavItemComponent, CGITopNavModule, CgiAccordionHeaderDirective, CgiAccordionIconDirective, CgiAccordionPanelDirective, CgiCounterComponent, CgiDatatableModule, CgiGlobalSearchBrandComponent, CgiGlobalSearchComponent, CgiLogoComponent, CgiSnackbarComponent, CgiStepperComponent, CgiStepperContainerComponent, GlobalSearchBrandCategory, GlobalSearchBrandEntity, GlobalSearchCategory, GlobalSearchEntity, GlobalSearchGroupBrandOptions, GlobalSearchGroupOptions, SideNavBrandItem, SideNavItem };
//# sourceMappingURL=cgi-sentry-angular-components-lib.mjs.map
