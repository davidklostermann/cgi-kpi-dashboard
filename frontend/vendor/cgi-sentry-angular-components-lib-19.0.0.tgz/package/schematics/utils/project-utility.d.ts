import { WorkspaceProject, ProjectType } from '@schematics/angular/utility/workspace-models';
/**
 * Gets the Angular config file from the project workspace
 */
export declare function getConfigFile(project: WorkspaceProject<ProjectType>, option: string, configSection?: string): string;
