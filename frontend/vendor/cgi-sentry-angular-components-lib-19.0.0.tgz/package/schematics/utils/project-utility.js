"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.getConfigFile = getConfigFile;
const schematics_1 = require("@angular-devkit/schematics");
// We need to be a little careful with using all these above libraries, as they are subject to change and not well documented
// We could possibly just fork them and keep a local copy
// The Angular config file is necessary for a lot of schematics in order to determine file paths and project defaults
function getProjectOptions(project, target) {
    if (project.targets && project.targets[target] && project.targets[target].options) {
        return project.targets[target].options;
    }
    if (project.architect && project.architect[target] && project.architect[target].options) {
        return project.architect[target].options;
    }
    throw new schematics_1.SchematicsException(`Cannot determine the ${target} configuration for the project`);
}
/**
 * Gets the Angular config file from the project workspace
 */
function getConfigFile(project, option, configSection = 'build') {
    const options = getProjectOptions(project, configSection);
    if (!options) {
        throw new schematics_1.SchematicsException(`Could not find ${configSection} section` + `in workspace config ${project.sourceRoot} `);
    }
    if (!options[option]) {
        throw new schematics_1.SchematicsException(`Could not find project option ${option} in ` + `workspace config ${project.sourceRoot}`);
    }
    return options[option];
}
//# sourceMappingURL=project-utility.js.map