"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.addDeclarationToNgModule = addDeclarationToNgModule;
exports.addImportToNgModule = addImportToNgModule;
exports.declareComponentToNgModule = declareComponentToNgModule;
exports.addProviderToNgModule = addProviderToNgModule;
const core_1 = require("@angular-devkit/core");
const schematics_1 = require("@angular-devkit/schematics");
const ast_utils_1 = require("@schematics/angular/utility/ast-utils");
const change_1 = require("@schematics/angular/utility/change");
const find_module_1 = require("@schematics/angular/utility/find-module");
// import { createSourceFile, ScriptTarget } from 'typescript';
const typescript_1 = require("../../../../../node_modules/@schematics/angular/third_party/github.com/Microsoft/TypeScript/lib/typescript");
// We need to be a little careful with using all these above libraries, as they are subject to change and not well documented
// We could possibly just fork them and keep a local copy
// The readIntoSourceFile and addDeclarationToNgModule function are from Angular's Schematic library, specifically their Component Schematic
// https://github.com/angular/angular-cli/blob/master/packages/schematics/angular/component/index.ts
function readIntoSourceFile(host, modulePath) {
    const text = host.read(modulePath);
    if (text === null) {
        throw new schematics_1.SchematicsException(`File ${modulePath} does not exist.`);
    }
    const sourceText = text.toString('utf-8');
    return (0, typescript_1.createSourceFile)(modulePath, sourceText, typescript_1.ScriptTarget.Latest, true);
}
/**
 * Add a component declaration to the it's ngModule's declaration section - export as well if needed via options.export
 */
function addDeclarationToNgModule(options) {
    return (host) => {
        if (options.skipImport || !options.module) {
            return host;
        }
        options.type = options.type != null ? options.type : 'Component';
        const modulePath = options.module;
        const source = readIntoSourceFile(host, modulePath);
        const componentPath = `/${options.path}/` +
            (options.flat ? '' : core_1.strings.dasherize(options.name) + '/') +
            core_1.strings.dasherize(options.name) +
            (options.type ? '.' : '') +
            core_1.strings.dasherize(options.type);
        const relativePath = (0, find_module_1.buildRelativePath)(modulePath, componentPath);
        const classifiedName = core_1.strings.classify(options.name) + core_1.strings.classify(options.type);
        const declarationChanges = (0, ast_utils_1.addDeclarationToModule)(source, modulePath, classifiedName, relativePath);
        const declarationRecorder = host.beginUpdate(modulePath);
        for (const change of declarationChanges) {
            if (change instanceof change_1.InsertChange) {
                declarationRecorder.insertLeft(change.pos, change.toAdd);
            }
        }
        host.commitUpdate(declarationRecorder);
        if (options.export) {
            // Need to refresh the AST because we overwrote the file in the host.
            const updatedSource = readIntoSourceFile(host, modulePath);
            const exportRecorder = host.beginUpdate(modulePath);
            const exportChanges = (0, ast_utils_1.addExportToModule)(updatedSource, modulePath, core_1.strings.classify(options.name) + core_1.strings.classify(options.type), relativePath);
            for (const change of exportChanges) {
                if (change instanceof change_1.InsertChange) {
                    exportRecorder.insertLeft(change.pos, change.toAdd);
                }
            }
            host.commitUpdate(exportRecorder);
        }
        return host;
    };
}
/**
 * Add module imports to the generated component's ngModule.
 */
function addImportToNgModule(host, modulePath, moduleName, src) {
    const moduleSource = readIntoSourceFile(host, modulePath);
    const changes = (0, ast_utils_1.addImportToModule)(moduleSource, modulePath, moduleName, src);
    const recorder = host.beginUpdate(modulePath);
    for (const change of changes) {
        if (change instanceof change_1.InsertChange) {
            recorder.insertLeft(change.pos, change.toAdd);
        }
    }
    host.commitUpdate(recorder);
}
function declareComponentToNgModule(host, modulePath, moduleName, src) {
    const moduleSource = readIntoSourceFile(host, modulePath);
    const changes = (0, ast_utils_1.addDeclarationToModule)(moduleSource, modulePath, moduleName, src);
    const recorder = host.beginUpdate(modulePath);
    for (const change of changes) {
        if (change instanceof change_1.InsertChange) {
            recorder.insertLeft(change.pos, change.toAdd);
        }
    }
    host.commitUpdate(recorder);
}
/**
 * Add module providers to the generated component's ngModule.
 */
function addProviderToNgModule(host, modulePath, moduleName, src) {
    const moduleSource = readIntoSourceFile(host, modulePath);
    const changes = (0, ast_utils_1.addProviderToModule)(moduleSource, modulePath, moduleName, src);
    const recorder = host.beginUpdate(modulePath);
    for (const change of changes) {
        if (change instanceof change_1.InsertChange) {
            recorder.insertLeft(change.pos, change.toAdd);
        }
    }
    host.commitUpdate(recorder);
}
//# sourceMappingURL=module-utility.js.map