import { Rule, Tree } from '@angular-devkit/schematics';
import { Schema as ComponentOptions } from '@schematics/angular/component/schema';
/**
 * Add a component declaration to the it's ngModule's declaration section - export as well if needed via options.export
 */
export declare function addDeclarationToNgModule(options: ComponentOptions): Rule;
/**
 * Add module imports to the generated component's ngModule.
 */
export declare function addImportToNgModule(host: Tree, modulePath: string, moduleName: string, src: string): void;
export declare function declareComponentToNgModule(host: Tree, modulePath: string, moduleName: string, src: string): void;
/**
 * Add module providers to the generated component's ngModule.
 */
export declare function addProviderToNgModule(host: Tree, modulePath: string, moduleName: string, src: string): void;
