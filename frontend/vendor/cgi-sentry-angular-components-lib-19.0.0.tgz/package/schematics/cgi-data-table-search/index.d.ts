import { Rule } from '@angular-devkit/schematics';
import { Schema as CGIDataTableSearchSchema } from './schema';
export declare function CGIDataTableSearch(options: CGIDataTableSearchSchema): Rule;
