/**
 * Schema options for the Data Table Search schematic.
 */
export interface Schema {
    /** The name of the generated component/service */
    name: string;
    /** The path where the files should be created */
    path?: string;
    /** The Angular workspace project name */
    project: string;
    /** Whether to add quick search to the data table */
    quickSearch?: boolean;
    /** Whether to add advanced filter panel to the data table */
    advanceFilter?: boolean;
    /** Determines which inner filters to include in advanced filter panel */
    advanceInnerFilters?: any;
    /** Whether to include numerical range filter */
    numRangeFilter?: boolean;
    /** Whether to include date range filter */
    dateRangeFilter?: boolean;
    /** Target NgModule file path for updating declarations/imports */
    module: string;
    /** Whether to export the generated component from the module */
    export: boolean;
    /** Create files in a flat structure without a subfolder */
    flat: boolean;
    /** Skip automatic NgModule import/declaration updates */
    skipImport: boolean;
}
