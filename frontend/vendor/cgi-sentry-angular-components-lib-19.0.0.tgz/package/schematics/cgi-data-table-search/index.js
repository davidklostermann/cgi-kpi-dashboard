"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.CGIDataTableSearch = CGIDataTableSearch;
const schematics_1 = require("@angular-devkit/schematics");
const module_utility_1 = require("../utils/module-utility");
const find_module_1 = require("@schematics/angular/utility/find-module");
const core_1 = require("@angular-devkit/core");
function createHost(tree) {
    return {
        readFile(path) {
            return __awaiter(this, void 0, void 0, function* () {
                const data = tree.read(path);
                if (!data) {
                    throw new schematics_1.SchematicsException('File not found.');
                }
                return core_1.virtualFs.fileBufferToString(data);
            });
        },
        writeFile(path, data) {
            return __awaiter(this, void 0, void 0, function* () {
                return tree.overwrite(path, data);
            });
        },
        isDirectory(path) {
            return __awaiter(this, void 0, void 0, function* () {
                return !tree.exists(path) && tree.getDir(path).subfiles.length > 0;
            });
        },
        isFile(path) {
            return __awaiter(this, void 0, void 0, function* () {
                return tree.exists(path);
            });
        },
    };
}
function CGIDataTableSearch(options) {
    return (tree) => __awaiter(this, void 0, void 0, function* () {
        const host = createHost(tree);
        const { workspace } = yield core_1.workspaces.readWorkspace('/', host);
        const project = options.project != null ? workspace.projects.get(options.project) : null;
        if (!project) {
            throw new schematics_1.SchematicsException(`Invalid project name: ${options.project}`);
        }
        const projectType = project.extensions.projectType === 'application' ? 'app' : 'lib';
        if (options.path === undefined) {
            options.path = `${project.sourceRoot}/${projectType}`;
        }
        if (options.module === undefined) {
            options.module = options.module || (0, find_module_1.findModuleFromOptions)(tree, options) || '';
        }
        const templateSource = (0, schematics_1.apply)((0, schematics_1.url)('./files'), [
            (0, schematics_1.applyTemplates)({
                classify: core_1.strings.classify,
                dasherize: core_1.strings.dasherize,
                name: options.name,
                quickSearch: options.quickSearch,
                advanceFilter: options.advanceFilter,
                advanceInnerFilters: options.advanceInnerFilters,
                numRangeFilter: options.advanceInnerFilters[0],
                dateRangeFilter: options.advanceInnerFilters[1],
            }),
            (0, schematics_1.move)((0, core_1.normalize)(options.path)),
        ]);
        options.flat = true;
        return (0, schematics_1.chain)([
            (0, schematics_1.branchAndMerge)((0, schematics_1.chain)([
                (0, module_utility_1.addDeclarationToNgModule)(options),
                addImportsToNgModule(options),
                (0, schematics_1.mergeWith)(templateSource),
            ])),
        ]);
    });
}
// Need to import component's dependencies into it's ngModule
function addImportsToNgModule(options) {
    return (host) => {
        if (options.module || !options.skipImport) {
            (0, module_utility_1.addImportToNgModule)(host, options.module, 'MatPaginatorModule', '@angular/material/paginator');
            (0, module_utility_1.addImportToNgModule)(host, options.module, 'MatSortModule', '@angular/material/sort');
            (0, module_utility_1.addImportToNgModule)(host, options.module, 'MatTableModule', '@angular/material/table');
            (0, module_utility_1.addImportToNgModule)(host, options.module, 'MatCardModule', '@angular/material/card');
            if (options.advanceFilter) {
                (0, module_utility_1.addImportToNgModule)(host, options.module, 'MatSidenavModule', '@angular/material/sidenav');
                (0, module_utility_1.addImportToNgModule)(host, options.module, 'MatIconModule', '@angular/material/icon');
                (0, module_utility_1.addImportToNgModule)(host, options.module, 'MatExpansionModule', '@angular/material/expansion');
                if (options.advanceInnerFilters[1]) {
                    (0, module_utility_1.addProviderToNgModule)(host, options.module, 'DatePipe', '@angular/common');
                }
            }
        }
        return host;
    };
}
//# sourceMappingURL=index.js.map