import { Rule } from '@angular-devkit/schematics';
import { Schema as CGIDetailsPageSchema } from './schema';
export declare function CGIDetailsPage(options: CGIDetailsPageSchema): Rule;
