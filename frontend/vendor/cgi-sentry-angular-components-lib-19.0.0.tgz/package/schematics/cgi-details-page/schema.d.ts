/**
 * Schema options for the Details Page schematic.
 */
export interface Schema {
    /** The name of the generated component/service */
    name: string;
    /** The path where the files should be created */
    path?: string;
    /** The Angular workspace project name */
    project?: string;
    /** Target NgModule file path for updating declarations/imports */
    module: string;
    /** Whether to export the generated component from the module */
    export: boolean;
    /** Create files in a flat structure without a subfolder */
    flat: boolean;
    /** Skip automatic NgModule import/declaration updates */
    skipImport: boolean;
}
